
import hashlib
import importlib
import json
import math
import os
import sys
import traceback
from pathlib import Path

BF = Path('/home/ubuntu/workspace/BayesFilter')
MF = Path('/home/ubuntu/workspace/MacroFinance-dz5-neutra')
OUT = Path('/tmp/dz5-output')
sys.path[:0] = [str(MF), str(BF)]
report = {'schema': 'filter_repair_dz5_snapshot_import.v1', 'passed': False,
    'role': 'isolated_CPU_import_and_fixture_reference_only',
    'target_evaluated': False, 'adapter_admitted': False,
    'nonclaims': ['No target, initializer, transition, timing or retained qualification.']}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def diagnostic_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: diagnostic_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [diagnostic_json(item) for item in value]
    return value

try:
    manifest = json.loads(Path('/tmp/dz5-source/manifest.json').read_text())
    report['snapshot_manifest_sha256'] = sha('/tmp/dz5-source/manifest.json')
    expected = {path: entry['sha256'] for path, entry in manifest['sources'].items()}
    assert all(sha(path) == digest for path, digest in expected.items())
    gpu = os.environ['CUDA_VISIBLE_DEVICES'] != '-1'
    assert os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] == 'true'
    import tensorflow as tf
    from bayesfilter.runtime.gpu_memory_policy import configure_tensorflow_gpu_memory_growth
    memory = configure_tensorflow_gpu_memory_growth(tf, require_gpu=gpu)
    devices = tf.config.list_physical_devices('GPU')
    assert len(devices) == (1 if gpu else 0)
    report.update(device='GPU' if gpu else 'CPU',
        trust_basis='owner_designated_managed_session_visible_gpu_trusted' if gpu else 'CPU_reference',
        physical_gpus=[device.name for device in devices])
    report.update(gpu_memory_policy=memory, tensorflow=tf.__version__,
        cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'])

    from bayesfilter_estimation import audit_sources, declared_source_closure
    from two_currency_double_zlb_credit_estimation import (
        TFP_SPECIAL, TFP_SPECIAL_SHA, credit_fixture_identity)
    from two_currency_double_zlb_credit_fixtures import credit_fixture
    from two_currency_double_zlb_credit_target import CREDIT_FILTER_CONTRACT
    assert sha(TFP_SPECIAL) == TFP_SPECIAL_SHA
    fixture = credit_fixture('CDF', n_steps=96)
    identity = credit_fixture_identity(fixture)
    assert identity == 'e116fe853c8579369036ab2ce57724ba07544524d0920fa0a706d76714f75d8a'
    assert len(fixture.parameter_names) == 23 and fixture.observations.shape[0] == 96
    assert CREDIT_FILTER_CONTRACT == 'rectangular_srukf_full_rank_identity_prepared_cir_v2'
    closure = {}
    loaded, unexpected = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if not filename:
            continue
        path = Path(filename).resolve()
        named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
        owned = path.is_relative_to(BF) or path.is_relative_to(MF)
        if named or owned:
            digest = sha(path)
            loaded[name] = {'path': str(path), 'sha256': digest}
            if not owned or expected.get(str(path)) != digest:
                unexpected[name] = loaded[name]
    report.update(loaded_modules=loaded, unexpected_modules=unexpected,
        source_closure=closure, fixture_identity=identity,
        parameter_names=fixture.parameter_names, observation_shape=list(fixture.observations.shape),
        filter_contract=CREDIT_FILTER_CONTRACT, tfp_special_sha256=TFP_SPECIAL_SHA)
    assert not unexpected, unexpected
    mounts = {}
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        fields = line.split()
        if fields[4] in (str(BF), str(MF)):
            mounts[fields[4]] = fields[5].split(',')
    report['source_mount_options'] = mounts
    assert set(mounts) == {str(BF), str(MF)}
    assert all('ro' in options for options in mounts.values())
    assert all(sha(path) == digest for path, digest in expected.items())
    expected_sources = expected.copy()

    import time
    import resource
    from two_currency_double_zlb_credit_target import (
        credit_target_value_and_score, credit_target_numeric_outputs)
    batch = int(os.environ['FILTER_REPAIR_DZ5_BATCH'])
    tf.config.experimental.enable_tensor_float_32_execution(False)
    center = tf.constant(fixture.parameter_truth, tf.float64)
    scale = tf.constant(fixture.prior_scale, tf.float64)
    direction = tf.reshape(tf.sin(tf.cast(tf.range(batch * 23), tf.float64)), [batch, 23])
    initial = center[None, :] + 0.001 * scale[None, :] * direction
    if batch == 4:
        prior = tf.constant(fixture.prior_mean, tf.float64)
        initial = tf.stack([center, prior, center + 0.005 * scale, prior - 0.005 * scale])
    changed = initial + 0.0002 * scale[None, :]
    signature = [tf.TensorSpec([batch, 23], tf.float64)]
    def numeric_target(p, jit):
        if jit:
            fields = credit_target_numeric_outputs(p, fixture)
        else:
            value, score, diagnostics = credit_target_value_and_score(p, fixture,
                jit_compile=False, evaluation_policy='hmc_rejection')
            valid = diagnostics['valid_pre_regularized_score']
            fields = (value, score, tf.where(valid, 0, 9001), valid,
                tf.zeros_like(diagnostics['branch_status_code']), diagnostics['branch_status_code'],
                diagnostics['minimum_chart_pivot'], diagnostics['maximum_chart_residual'],
                diagnostics['maximum_support_residual'])
        return fields[0], fields[1], {
            'status_code': fields[2], 'valid_pre_regularized_score': fields[3],
            'regularization_count': fields[4], 'branch_status_code': fields[5],
            'minimum_chart_pivot': fields[6], 'maximum_chart_residual': fields[7],
            'maximum_support_residual': fields[8]}
    xla = tf.function(lambda p: numeric_target(p, True),
        input_signature=signature, jit_compile=True, autograph=False)
    graph = tf.function(lambda p: numeric_target(p, False),
        input_signature=signature, jit_compile=False, autograph=False)
    report.update(role='isolated_DZ5_target_graph_XLA_engineering_comparison',
        target_evaluated=False, target_execution_attempted=True, batch=batch, jit_compile=True,
        reference='same frozen actual CDF source with explicit archived graph reference',
        source_role=manifest['role'],
        archived_source_comparison_complete=False,
        nonclaims=['No admission, training, HMC, cost ranking or full archived-source qualification.'])
    comparisons = []
    report['comparisons'] = comparisons
    first = None
    for label, positions in (('initial', initial), ('changed', changed), ('replay', initial)):
        tick = time.monotonic()
        actual = xla(positions)
        tf.nest.map_structure(lambda v: v.numpy(), actual)
        report['target_evaluated'] = True
        xla_seconds = time.monotonic() - tick
        expected = graph(positions)
        tf.nest.map_structure(lambda v: v.numpy(), expected)
        comparisons.append({'label': label, 'positions': positions.numpy().tolist(),
            'value': actual[0].numpy().tolist(), 'score': actual[1].numpy().tolist(),
            'reference_value': expected[0].numpy().tolist(), 'reference_score': expected[1].numpy().tolist(),
            'status': {key: value.numpy().tolist() for key, value in actual[2].items()
                if value.dtype == tf.bool or value.dtype.is_integer},
            'floating_diagnostics': {key: value.numpy().tolist() for key, value in actual[2].items()
                if value.dtype.is_floating},
            'xla_seconds_in_shared_reference_process': xla_seconds})
        tf.debugging.assert_equal(actual[2]['valid_pre_regularized_score'], tf.ones([batch], tf.bool))
        tf.debugging.assert_equal(actual[2]['branch_status_code'], tf.zeros([batch], tf.int32))
        errors = {}
        for key, left, right in [('value', actual[0], expected[0]), ('score', actual[1], expected[1])]:
            tf.debugging.assert_all_finite(left, key)
            delta = tf.abs(left - right)
            limit = tf.constant(1e-8, tf.float64) + tf.constant(1e-7, tf.float64) * tf.abs(right)
            tf.debugging.assert_less_equal(delta, limit)
            errors[key] = float(tf.reduce_max(delta / limit).numpy())
        for key, value in actual[2].items():
            if value.dtype == tf.bool or value.dtype.is_integer:
                tf.debugging.assert_equal(value, expected[2][key])
            else:
                tf.debugging.assert_less_equal(tf.abs(value - expected[2][key]),
                    tf.constant(1e-8, tf.float64) + tf.constant(1e-7, tf.float64) * tf.abs(expected[2][key]))
        if label == 'initial':
            first = actual
        if label == 'replay':
            for left, right in zip(tf.nest.flatten(actual), tf.nest.flatten(first), strict=True):
                tf.debugging.assert_equal(left, right)
        comparisons[-1]['max_scaled_errors'] = errors
    if batch == 4:
        invalid = tf.tensor_scatter_nd_update(initial, [[1, 18], [2, 22]],
            tf.constant([float('nan'), -100.0], tf.float64))
        rejected = xla(invalid)
        graph_rejected = graph(invalid)
        report['invalid_rows'] = {
            'valid': rejected[2]['valid_pre_regularized_score'].numpy().tolist(),
            'branch_status_code': rejected[2]['branch_status_code'].numpy().tolist(),
            'value': rejected[0].numpy().tolist(), 'score': rejected[1].numpy().tolist()}
        tf.debugging.assert_equal(rejected[2]['valid_pre_regularized_score'], [True, False, False, True])
        tf.debugging.assert_equal(rejected[2]['branch_status_code'], graph_rejected[2]['branch_status_code'])
        tf.debugging.assert_equal(tf.gather(rejected[0], [1, 2]), tf.constant([-1e100, -1e100], tf.float64))
        tf.debugging.assert_equal(tf.gather(rejected[1], [1, 2]), tf.zeros([2, 23], tf.float64))
        for left, right in zip(rejected[:2], first[:2], strict=True):
            tf.debugging.assert_equal(tf.gather(left, [0, 3]), tf.gather(right, [0, 3]))
        report['invalid_row_isolation'] = True
    definition = xla.get_concrete_function().graph.as_graph_def()
    nodes = [*definition.node, *(n for f in definition.library.function for n in f.node_def)]
    forbidden = sorted({n.op for n in nodes if any(term in n.op.lower() for term in
        ('pyfunc', 'sylvester', 'principalsqrt', 'xlahostcompute'))})
    assert not forbidden, forbidden
    hlo = xla.experimental_get_compiler_ir(initial)(stage='hlo')
    changed_hlo = xla.experimental_get_compiler_ir(changed)(stage='hlo')
    assert hlo == changed_hlo
    assert xla.experimental_get_tracing_count() == 1
    (OUT / 'dz5-target.hlo.txt').write_text(hlo)
    report.update(comparisons=comparisons, trace_count=1, host_callbacks=forbidden,
        hlo_sha256=hashlib.sha256(hlo.encode()).hexdigest(), hlo_changed_input_equal=True,
        host_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        tf32_enabled=tf.config.experimental.tensor_float_32_execution_enabled())
    report['gpu_allocator'] = tf.config.experimental.get_memory_info('GPU:0') if devices else None
    # Re-audit all actual project imports after tracing numerical callbacks.
    unexpected, loaded_after = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            owned = path.is_relative_to(BF) or path.is_relative_to(MF)
            named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
            if owned or named:
                loaded_after[name] = {'path': str(path), 'sha256': sha(path)}
                if not owned or expected_sources.get(str(path)) != sha(path):
                    unexpected[name] = str(path)
    report['post_target_loaded_modules'] = loaded_after
    report['post_target_unexpected_modules'] = unexpected
    assert not unexpected, unexpected
    assert all(sha(path) == digest for path, digest in expected_sources.items())

    report['passed'] = True
except BaseException as error:
    report.update(error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
finally:
    (OUT / 'dz5-snapshot-import.json').write_text(json.dumps(diagnostic_json(report), indent=2, allow_nan=False)+'\n')
sys.exit(0 if report['passed'] else 1)
