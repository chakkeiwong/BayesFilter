# Expanded SQMC transport-iteration repair

The original two-flow-step calibration exposed invalid candidates, not a
broken oracle or infrastructure. CPU diagnostic localization suggested a reset mass failure, but its regenerated
inputs did not reproduce the saved GPU case. Repair-check-01 observed GPU
column TV 1.280e-3 above the unchanged 1e-4 guard; the next check must verify
saved observations/input hashes and compare backends on identical tensors.
Higher-moment validity, finite states/tangents and positive covariance were
healthy in that trace. This sufficiently explains rejection; it does not
establish that every rejected case has the same cause.

## Question and bounded repair

Can exact-scope calibration of terminal transport balancing produce valid
full-model comparisons without relaxing guards or changing the algorithm?
Keep all six full-A/full-SPD-Q scopes, four routes, N1020, FP64 GPU/XLA,
TF32 off, every score coordinate and exact Kalman comparator. Retain the
completed P44 comparisons unchanged. Original failed candidates remain
separate evidence. No production, default, HMC or superiority claim follows.

For each full scope/route, nominate the smallest balance count in 12,48,192
that passes the shared finite-program validity check and has maximum reset
column TV <=1e-6 and row error <=1e-8 on both fresh calibration seeds.
Use flow 8 for this scalar nomination. The stricter nomination margin is
100-fold inside the existing column guard; neither guard is relaxed.
Nomination uses one analytical direction and full observation horizon only
to expose transport validity, not to establish score accuracy. Save computed
transport, higher-moment and program diagnostics from the shared trace.

With the nominated balance count, run the existing complete-score flow grid
2 versus 8, validate the selected controls, then freeze them for untouched
final evaluation. All other controls and the numerical implementation are
unchanged. A failed nomination or full-score validation remains a candidate
failure; do not evaluate final cells with an unissued tuning artifact.

Use calibration seeds 199001,199002; validation 200001; final data 201001,
201002 crossed with filter seeds 202001,202002. These are disjoint from the
original partitions. All four routes share observations within each scope.
Preserved P44 results use the original partitions and must be labeled so.

## Evidence roles and assumptions

Primary engineering criterion: complete all coordinates with exact-scope
issued controls and intact observations/oracle provenance. Primary scientific
measurements remain raw likelihood/score and absolute error, not a threshold
or ranking. Guard failures veto the affected candidate. Wrong data, broken
oracle or derivative, unsafe resources, exhausted budget or deadline veto
continuation. Heuristic checks remain conditional promotion vetoes only.

Balance 12 is the rejected original baseline. Counts 48 and 192 are a bounded
geometric numerical-resolution ladder, not transferred optima. Direct
full-horizon calibration supplies target-specific evidence. Fixed epsilon,
ridge, correction caps and damping remain documented hypotheses; this repair
does not establish their adequacy. Flow-8 nomination could miss a flow-2
pathology; the subsequent full-score calibration catches it. Calibration
margin can fail on final data; preserve that failure without tuning on it.

The scalar trace uses the same shared analytical implementation. It cannot
replace all-coordinate calibration or final scores. Maximum column/row error,
higher-moment flags, finite-program validity and wall time are observability
records; numerical results are never altered by the diagnostic.

## Budget, execution and stop conditions

Original 43,200-second aggregate GPU cap and 2026-09-28 07:25:28.470267 UTC
deadline remain. After original run-01, 39,546.277 seconds remain. Charge all
new GPU wall time, including probes, compilation, rejected candidates and
retries. At most two infrastructure retries per unit; a planned stop for this
numerical repair is recorded separately from an infrastructure crash.

Before the repair ladder, use <=1,200 GPU seconds for trace compatibility and
worst-resolution full-d10 timing. Compare CPU/GPU guard localization on identical saved-input tensors from the
failed original case. Project remaining six full scopes at balance 192 with a
50% margin; launch only if the projection fits. Preserve unique repair-check
and repair-run directories under the existing renewal root. Per-worker
90-minute limits remain. No package/environment changes or external actions.

Skeptical audit: original fixed balancing was an unproved numerical-resolution
hypothesis and failed its mass-conservation check. Increasing resolution
addresses that check without weakening it. New seed partitions protect
validation/final separation. Final score tuning uses all coordinates; scalar
validity is not promoted to score accuracy. The cost check must precede the
expensive repair. If repair cost does not fit, stop as under-budgeted and
report the rejected comparison rather than silently shrinking the request.

Focused preflight audit: nine CPU control tests passed (2.46 seconds), including disjoint repair partitions, unchanged numerical source closure, original budget checks, and rejection of insufficient mass margin. GPU trace compatibility and repair cost remain untested until repair-check-01 completes.
