
import hashlib
import importlib
import json
import math
import os
import sys
import traceback
from pathlib import Path

BF = Path('/home/ubuntu/workspace/BayesFilter')
MF = Path('/home/ubuntu/workspace/MacroFinance-dz5-neutra')
OUT = Path('/tmp/dz5-output')
sys.path[:0] = [str(MF), str(BF)]
report = {'schema': 'filter_repair_dz5_snapshot_import.v1', 'passed': False,
    'role': 'isolated_CPU_import_and_fixture_reference_only',
    'target_evaluated': False, 'adapter_admitted': False,
    'nonclaims': ['No target, initializer, transition, timing or retained qualification.']}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def diagnostic_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: diagnostic_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [diagnostic_json(item) for item in value]
    return value

try:
    manifest = json.loads(Path('/tmp/dz5-source/manifest.json').read_text())
    report['snapshot_manifest_sha256'] = sha('/tmp/dz5-source/manifest.json')
    expected = {path: entry['sha256'] for path, entry in manifest['sources'].items()}
    assert all(sha(path) == digest for path, digest in expected.items())
    gpu = os.environ['CUDA_VISIBLE_DEVICES'] != '-1'
    assert os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] == 'true'
    import tensorflow as tf
    from bayesfilter.runtime.gpu_memory_policy import configure_tensorflow_gpu_memory_growth
    memory = configure_tensorflow_gpu_memory_growth(tf, require_gpu=gpu)
    devices = tf.config.list_physical_devices('GPU')
    assert len(devices) == (1 if gpu else 0)
    report.update(device='GPU' if gpu else 'CPU',
        trust_basis='owner_designated_managed_session_visible_gpu_trusted' if gpu else 'CPU_reference',
        physical_gpus=[device.name for device in devices])
    report.update(gpu_memory_policy=memory, tensorflow=tf.__version__,
        cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'])

    from bayesfilter_estimation import audit_sources, declared_source_closure
    from two_currency_double_zlb_credit_estimation import (
        TFP_SPECIAL, TFP_SPECIAL_SHA, credit_fixture_identity)
    from two_currency_double_zlb_credit_fixtures import credit_fixture
    from two_currency_double_zlb_credit_target import CREDIT_FILTER_CONTRACT
    importlib.import_module('bayesfilter_estimation_initialization')
    importlib.import_module('two_currency_double_zlb_credit_recovery')
    importlib.import_module('bayesfilter.inference.dense_initializer_seeded_tf')
    importlib.import_module('bayesfilter.inference.tensor_npz_archive')
    assert sha(TFP_SPECIAL) == TFP_SPECIAL_SHA
    fixture = credit_fixture('CDF', n_steps=96)
    identity = credit_fixture_identity(fixture)
    assert identity == 'e116fe853c8579369036ab2ce57724ba07544524d0920fa0a706d76714f75d8a'
    assert len(fixture.parameter_names) == 23 and fixture.observations.shape[0] == 96
    assert CREDIT_FILTER_CONTRACT == 'rectangular_srukf_full_rank_identity_prepared_cir_v2'
    closure = audit_sources(declared_source_closure((
        MF / 'scripts/prepare_dz5_cdf_proposal.py',
        BF / 'bayesfilter/runtime/runner.py')))
    assert all(expected.get(path) == digest for path, digest in closure.items())
    loaded, unexpected = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if not filename:
            continue
        path = Path(filename).resolve()
        named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
        owned = path.is_relative_to(BF) or path.is_relative_to(MF)
        if named or owned:
            digest = sha(path)
            loaded[name] = {'path': str(path), 'sha256': digest}
            if not owned or expected.get(str(path)) != digest:
                unexpected[name] = loaded[name]
    report.update(loaded_modules=loaded, unexpected_modules=unexpected,
        source_closure=closure, fixture_identity=identity,
        parameter_names=fixture.parameter_names, observation_shape=list(fixture.observations.shape),
        filter_contract=CREDIT_FILTER_CONTRACT, tfp_special_sha256=TFP_SPECIAL_SHA)
    assert not unexpected, unexpected
    mounts = {}
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        fields = line.split()
        if fields[4] in (str(BF), str(MF)):
            mounts[fields[4]] = fields[5].split(',')
    report['source_mount_options'] = mounts
    assert set(mounts) == {str(BF), str(MF)}
    assert all('ro' in options for options in mounts.values())
    assert all(sha(path) == digest for path, digest in expected.items())
    expected_sources = expected.copy()

    import resource
    import time
    import numpy as np  # Independent replay inspection/serialization only.
    from two_currency_double_zlb_credit_target import (
        build_credit_factor_model_and_derivatives, credit_fixed_branch,
        credit_target_value_and_score)
    from bayesfilter.nonlinear.rectangular_srukf_tf import tf_rectangular_srukf_value_and_score
    assert not gpu
    tf.config.experimental.enable_op_determinism()
    tf.config.experimental.enable_tensor_float_32_execution(False)
    horizon = int(os.environ['FILTER_REPAIR_DZ5_PREFIX'])
    route = os.environ['FILTER_REPAIR_DZ5_REPLAY_ROUTE']
    assert route in ('direct', 'public', 'public_tuple') and 1 <= horizon <= 96
    prepared = fixture.likelihood_observations()
    class PrefixFixture:
        def likelihood_observations(self):
            return prepared[:horizon]
        def __getattr__(self, name):
            return getattr(fixture, name)
    prefix_fixture = PrefixFixture()
    np.testing.assert_array_equal(prefix_fixture.likelihood_observations(), prepared[:horizon])
    center, scale = np.asarray(fixture.parameter_truth), np.asarray(fixture.prior_scale)
    bank = np.concatenate((center[None], *(center + multiplier * step * np.diag(scale)
        for step in (1e-3, 5e-4) for multiplier in (-2, -1, 1, 2))))
    assert bank.shape == (185, 23)
    def evaluate(parameters):
        if route in ('public', 'public_tuple'):
            value, score, diagnostics = credit_target_value_and_score(
                parameters, prefix_fixture, jit_compile=False, evaluation_policy='hmc_rejection')
            if route == 'public_tuple':
                return value, score, diagnostics['valid_pre_regularized_score'], diagnostics['branch_status_code']
            return {'value': value, 'score': score,
                'valid': diagnostics['valid_pre_regularized_score'],
                'branch_status': diagnostics['branch_status_code']}
        model, derivatives = build_credit_factor_model_and_derivatives(
            parameters, fixture, prepare_fixed_cir_points=True)
        observations = tf.constant(prefix_fixture.likelihood_observations()[:-1], tf.float64)
        result = tf_rectangular_srukf_value_and_score(
            tf.broadcast_to(observations, [185, *observations.shape.as_list()]),
            model, derivatives, branch=credit_fixed_branch(fixture), jit_compile=False)
        return {'initial_mean': model.initial_mean, 'initial_factor': model.initial_factor,
            'd_initial_mean': derivatives.d_initial_mean, 'd_initial_factor': derivatives.d_initial_factor,
            'value': result.log_likelihood, 'score': result.score, 'mean': result.filtered_mean,
            'factor': result.filtered_factor, 'd_mean': result.d_filtered_mean,
            'd_factor': result.d_filtered_factor, 'valid': result.diagnostics['score_valid'],
            'branch_status': result.diagnostics['branch_status_code']}

    from dataclasses import replace
    assert route == 'direct'
    target_device = '/CPU:0'
    frozen_path = os.environ.get('FILTER_REPAIR_DZ5_FROZEN_STEP_INPUT')
    state_fields = ('mean', 'factor', 'd_mean', 'd_factor')
    with tf.device(target_device):
        positions = tf.constant(bank)
        if frozen_path:
            with np.load(frozen_path, allow_pickle=False) as archive:
                frozen = {name: archive[name] for name in archive.files}
            np.testing.assert_array_equal(frozen['bank'], bank)
            np.testing.assert_array_equal(frozen['observation'], prepared[horizon - 1:horizon])
            assert int(frozen['prefix_steps']) == horizon - 1
            report['frozen_input_sha256'] = sha(frozen_path)
            report['prefix_preparation_seconds'] = 0.
        else:
            prepare = tf.function(evaluate, input_signature=[tf.TensorSpec([185, 23], tf.float64)],
                jit_compile=False, autograph=False)
            tick = time.monotonic()
            prefix_result = {key: value.numpy() for key, value in prepare(positions).items()}
            report['prefix_preparation_seconds'] = time.monotonic() - tick
            assert all(np.isfinite(value).all() for value in prefix_result.values())
            assert prefix_result['valid'].all() and not prefix_result['branch_status'].any()
            frozen = {name: prefix_result[name] for name in state_fields}
            frozen.update(bank=bank, observation=prepared[horizon - 1:horizon],
                prefix_steps=np.asarray(horizon - 1))
            np.savez_compressed(OUT / 'frozen-step-inputs.npz', **frozen)
            report['frozen_input_sha256'] = sha(OUT / 'frozen-step-inputs.npz')
        inputs = (positions, *(tf.constant(frozen[name]) for name in state_fields))
    def one_step(parameters, mean, factor, d_mean, d_factor):
        model, derivatives = build_credit_factor_model_and_derivatives(
            parameters, fixture, prepare_fixed_cir_points=True)
        model = replace(model, initial_mean=mean, initial_factor=factor)
        derivatives = replace(derivatives, d_initial_mean=d_mean, d_initial_factor=d_factor)
        observation = tf.constant(prepared[horizon - 1:horizon], tf.float64)
        result = tf_rectangular_srukf_value_and_score(
            tf.broadcast_to(observation, [185, *observation.shape.as_list()]),
            model, derivatives, branch=credit_fixed_branch(fixture), jit_compile=False)
        return {'value': result.log_likelihood, 'score': result.score,
            'mean': result.filtered_mean, 'factor': result.filtered_factor,
            'd_mean': result.d_filtered_mean, 'd_factor': result.d_filtered_factor,
            'valid': result.diagnostics['score_valid'],
            'branch_status': result.diagnostics['branch_status_code']}

    original_step = one_step
    original_while_loop = tf.while_loop
    captured_step = {}
    observed_names = (
        'augmented_mean', 'augmented_factor', 'd_augmented_mean', 'd_augmented_factor',
        'points', 'd_points', 'predicted_points', 'state_j', 'process_j', 'direct',
        'd_predicted_points', 'predicted_mean', 'd_predicted_mean',
        'state_stack', 'd_state_stack', 'observation_points', 'd_observation_points',
        'predicted_observation', 'd_predicted_observation', 'y_stack', 'dy_stack',
        'observation_stack', 'd_observation_stack', 'state_joint_stack', 'd_state_joint_stack',
        'innovation', 'd_innovation', 'inc', 'inc_score', 'increment', 'd_increment',
        'new_factor', 'new_d_factor', 'new_mean', 'new_d_mean')
    def instrumented_while_loop(cond, body, loop_vars, **kwargs):
        if body.__qualname__ != 'tf_rectangular_srukf_value_and_score.<locals>.run.<locals>.body':
            return original_while_loop(cond, body, loop_vars, **kwargs)
        assert len(loop_vars) == 11 and not captured_step
        def trace_body(*args):
            locals_at_return = {}
            def profile(frame, event, _argument):
                if frame.f_code is body.__code__ and event == 'return':
                    locals_at_return.update({name: frame.f_locals[name] for name in observed_names})
            previous_profile = sys.getprofile()
            sys.setprofile(profile)
            try:
                following = body(*args)
            finally:
                sys.setprofile(previous_profile)
            assert len(locals_at_return) == len(observed_names)
            return following, locals_at_return
        step_kernel = tf.function(trace_body,
            input_signature=[tf.TensorSpec(x.shape, x.dtype) for x in loop_vars],
            autograph=False, jit_compile=False)
        template = step_kernel.get_concrete_function().structured_outputs[1]
        empty = tf.nest.map_structure(lambda x: tf.zeros(x.shape, x.dtype), template)
        def recorded_body(*args):
            following, intermediate = step_kernel(*args[:-1])
            return (*following, intermediate)
        recorded = original_while_loop(lambda *args: cond(*args[:-1]), recorded_body,
            (*loop_vars, empty), **kwargs)
        captured_step.update({f'operand_{key}': value for key, value in recorded[-1].items()})
        return recorded[:-1]
    def one_step(*args):
        tf.while_loop = instrumented_while_loop
        try:
            result = original_step(*args)
            assert len(captured_step) == len(observed_names)
            return {**result, **captured_step}
        finally:
            tf.while_loop = original_while_loop

    kernel = tf.function(one_step, input_signature=[tf.TensorSpec(x.shape, x.dtype) for x in inputs],
        jit_compile=False, autograph=False)
    report.update(role='CPU_frozen_step_operands_replay_explanatory_only',
        evaluated_observations=1, prefix_steps=horizon - 1, jit_compile=False,
        original_fixture_observations=96, threads=int(os.environ['TF_NUM_INTRAOP_THREADS']),
        op_determinism_enabled=True, tf32_enabled=False, batch=185,
        input_tensor_policy='same_tensors_reused_and_verified_unchanged',
        call_seconds=[], replay_summaries=[], target_evaluated=False,
        nonclaims=['No oracle, full-trajectory, HMC, performance or default qualification.'])
    first = None
    retained_first_tensors = None
    for repeat in range(20):
        tick = time.monotonic()
        with tf.device(target_device):
            current_tensors = kernel(*inputs)
        current = {key: tensor.numpy() for key, tensor in current_tensors.items()}
        report['call_seconds'].append(time.monotonic() - tick)
        report['target_evaluated'] = True
        if first is None or any(not np.array_equal(value, first[key]) for key, value in current.items()):
            np.savez_compressed(OUT / f'late-step-replay-{repeat:02d}.npz', **current)
        assert all(np.isfinite(value).all() for value in current.values())
        assert current['valid'].all() and not current['branch_status'].any()
        for tensor, name in zip(inputs, ('bank', *state_fields), strict=True):
            np.testing.assert_array_equal(tensor.numpy(), frozen[name])
        if first is None:
            first = current
            retained_first_tensors = current_tensors
        else:
            report['replay_summaries'].append({key: {
                'changed_elements': int(np.count_nonzero(value != first[key])),
                'max_absolute_error': float(np.max(np.abs(value.astype(float) - first[key].astype(float))))}
                for key, value in current.items()})
        (OUT / 'dz5-late-step-replay.json').write_text(json.dumps(report, indent=2) + '\n')
    assert retained_first_tensors is not None and kernel.experimental_get_tracing_count() == 1
    report.update(trace_count=1, replay_exact=all(row['changed_elements'] == 0
        for summary in report['replay_summaries'] for row in summary.values()),
        host_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    (OUT / 'dz5-late-step-replay.json').write_text(json.dumps(report, indent=2) + '\n')
    # Re-audit all actual project imports after tracing numerical callbacks.
    unexpected, loaded_after = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            owned = path.is_relative_to(BF) or path.is_relative_to(MF)
            named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
            if owned or named:
                loaded_after[name] = {'path': str(path), 'sha256': sha(path)}
                if not owned or expected_sources.get(str(path)) != sha(path):
                    unexpected[name] = str(path)
    report['post_target_loaded_modules'] = loaded_after
    report['post_target_unexpected_modules'] = unexpected
    assert not unexpected, unexpected
    assert all(sha(path) == digest for path, digest in expected_sources.items())

    report['passed'] = True
except BaseException as error:
    report.update(error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
finally:
    (OUT / 'dz5-snapshot-import.json').write_text(json.dumps(diagnostic_json(report), indent=2, allow_nan=False)+'\n')
sys.exit(0 if report['passed'] else 1)
