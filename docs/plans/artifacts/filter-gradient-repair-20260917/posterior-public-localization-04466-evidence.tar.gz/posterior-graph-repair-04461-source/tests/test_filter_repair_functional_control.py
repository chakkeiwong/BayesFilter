"""Regression for local graph lowering without process-wide optimizer changes."""

import pytest
import tensorflow as tf

from bayesfilter.inference.functional_control_flow import (
    _retain_functional,
    functional_cond,
    functional_while_loop,
)


def test_functional_graph_preserves_branches_loops_resources_and_options():
    options = tf.config.optimizer.get_experimental_options()
    calls = tf.Variable(0, dtype=tf.int32)

    @tf.function(input_signature=[tf.TensorSpec([], tf.int32)], jit_compile=False, autograph=False)
    def program(limit):
        def step(index, value):
            tick = calls.assign_add(1)
            with tf.control_dependencies([tick]):
                value = functional_cond(index % 2 == 0, lambda: value + index, lambda: value - index)
            return index + 1, value

        return functional_while_loop(lambda index, value: index < limit, step,
            (tf.constant(0), tf.constant(0)), maximum_iterations=4, parallel_iterations=1)

    for limit, expected in ((0, (0, 0)), (3, (3, 1)), (4, (4, -2)), (0, (0, 0))):
        calls.assign(0)
        assert tuple(int(value) for value in program(tf.constant(limit))) == expected
        assert int(calls) == limit
    assert program.experimental_get_tracing_count() == 1
    assert tf.config.optimizer.get_experimental_options() == options
    graph = program.get_concrete_function().graph.as_graph_def()
    nodes = [*graph.node, *(node for function in graph.library.function for node in function.node_def)]
    controlled = [node for node in nodes if node.op in ("If", "StatelessIf", "While", "StatelessWhile")]
    assert len(controlled) == 2
    assert all("_lower_using_switch_merge" in node.attr and not node.attr["_lower_using_switch_merge"].b
        for node in controlled)


def test_functional_constructor_fails_on_unknown_graph_representation():
    @tf.function(jit_compile=False, autograph=False)
    def invalid():
        return _retain_functional(tf.constant(1))

    with pytest.raises(RuntimeError, match="unsupported functional control-flow operation: Const"):
        invalid.get_concrete_function()
