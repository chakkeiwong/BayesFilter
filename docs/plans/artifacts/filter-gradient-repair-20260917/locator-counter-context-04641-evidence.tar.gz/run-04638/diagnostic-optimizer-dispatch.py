def one_iteration(value_and_gradients_function, initial_position, **kwargs):
    kwargs['max_iterations'] = 1
    return real_lbfgs_minimize(value_and_gradients_function,
        initial_position=initial_position, **kwargs)
