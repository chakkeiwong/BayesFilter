"""Local functional control flow for explicit non-XLA diagnostic programs.

TensorFlow 2.19's Switch/Merge lowering plus dependency optimization can turn
outputs of the composed posterior fitter into dead (empty float32) tensors.
Retain its If/While operations without changing any body, predicate or loop
bound. Callers select these wrappers only for their explicit graph exception;
the default XLA path uses TensorFlow's ordinary constructors.

The private operation attribute is the same one used by TensorFlow's
control_flow_util_v2.maybe_set_lowering_attr. A changed operation representation
raises during tracing instead of silently losing the local repair. No process
optimizer option, executor or TensorFlow module binding is changed.
"""

import tensorflow as tf
from tensorflow.core.framework.attr_value_pb2 import AttrValue


def _retain_functional(outputs):
    if not tf.executing_eagerly():
        operation = tf.nest.flatten(outputs)[0].op
        # This walks graph metadata during tracing, never numerical loop state.
        while operation.type in ("Identity", "IdentityN"):
            operation = operation.inputs[0].op
        if operation.type not in ("If", "StatelessIf", "While", "StatelessWhile"):
            raise RuntimeError(f"unsupported functional control-flow operation: {operation.type}")
        operation._set_attr("_lower_using_switch_merge", AttrValue(b=False))
    return outputs


def functional_cond(*args, **kwargs):
    return _retain_functional(tf.cond(*args, **kwargs))


def functional_while_loop(*args, **kwargs):
    return _retain_functional(tf.while_loop(*args, **kwargs))
