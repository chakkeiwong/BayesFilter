# Filter and gradient repair resume checkpoint

Checkpoint through 04432, September 27. All 13 CPU public initializer checks
and eight GPU fixtures pass. D5 GPU 04432 timed out at 300 seconds without a
completed comparison. One identical-source 900-second retry is active in session
28131. Keep runtime/tests/runner/policy frozen until it finishes. If it passes,
resume posterior_public_complete_gpu at the usual 300 seconds; only the final
late-validation group remains. The source snapshot is posterior-public-04424-source
in the raw artifact root; the earlier CPU matrix snapshot is also preserved.

Next install /tmp/test_filter_repair_posterior_initializer_boundaries_20260927_v2.py
at tests/test_filter_repair_posterior_initializer_boundaries.py to replace the
incorrect eager-execution assumption from 04423 with a physical resource counter.
That worker already passed compiler/cache/collection checks; its wall numerical
comparison also passed. Run posterior_initializer_exported_checks_cpu and _gpu
with explicit devices. Original curvature tests are restored from 6bceb767e;
new initializer tests use test_filter_repair_posterior_initializer_public.py.

After those checks, review/install the prepared cost drafts using
/tmp/install_posterior_initializer_cost_harness_20260927.py. Drafts and installer
are outside the frozen source tree. Run policy and cost-analysis checks, then
D1/D3 prior/graph/XLA cost pilots and three interleaved repeats within the unit
budget. The analyzer retains failed arms and suppresses their performance ratios.

Charged through 04432: 90912.210295 CPU / 83699.113825 GPU seconds.
Remaining: 30.746608 CPU / 28.750246 GPU hours; the additional
24 CPU hours are included in the unchanged global 56/52-hour caps. Enclosing
unit charged 6154.618290 combined seconds before the active 900-second reservation;
its cap remains 10800 seconds and 96 CPU / 72 GPU workers. Main is unmerged and
all F01--F20 terminal gates are open. Latest pushed commit 6bceb767e already
contains fetched origin/main 06590cb5a. Controlling plan:
filter_gradient_posterior_initializer_enclosing_20260927.md.
