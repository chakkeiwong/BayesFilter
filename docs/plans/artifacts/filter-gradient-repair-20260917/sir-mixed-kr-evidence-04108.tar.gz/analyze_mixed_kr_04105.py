"""Post-run diagnostic summary; standard-library comparison only."""
import hashlib
import json
import statistics
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def flatten(value):
    if isinstance(value, list):
        return [leaf for item in value for leaf in flatten(item)]
    return [float(value)]

rows = []
sources = None
baselines = {}
for number in range(4094, 4106):
    directory = ROOT / f'run-{number:05d}'
    run_path, cost_path = directory / 'run.json', directory / 'mixed-kr-log-cost.json'
    run, cost = json.loads(run_path.read_text()), json.loads(cost_path.read_text())
    assert run['state'] == 'passed' and run['test_evidence']['passed']
    if sources is None:
        sources = run['source_sha256']
    assert sources == run['source_sha256'], number
    key = run['device'], cost['count']
    if cost['arm'] == 'previous':
        baselines[key] = cost
    reference = baselines[key]
    assert reference['points'] == cost['points']
    assert reference['previous_wrapper_sha256'] == cost['previous_wrapper_sha256']
    left, right = flatten(reference['result']), flatten(cost['result'])
    assert len(left) == len(right)
    error = max(abs(a-b) for a, b in zip(left, right))
    assert error <= 1e-10, (number, error)
    device = cost['device_provenance']
    assert reference['device_provenance']['uuid'] == device['uuid']
    sharing = any(process['pid'] != device['pid'] for sample in device['samples']
                  for process in sample['processes']) if device['enabled'] else None
    assert not device['errors']
    allocator = cost['compiled']['gpu']
    rows.append(dict(run=number, device=run['device'], arm=cost['arm'], count=cost['count'],
        cold_seconds=cost['cold_seconds'], warm_median_ms=statistics.median(cost['warm_seconds'])*1000,
        rss_compiled_mib=cost['compiled']['status']['VmRSS']/2**20,
        warm_rss_increase_kib=(cost['warm']['status']['VmRSS']-cost['compiled']['status']['VmRSS'])/1024,
        gpu_current_bytes=allocator['current'] if allocator else None,
        gpu_peak_bytes=allocator['peak'] if allocator else None,
        gpu_uuid=device['uuid'], observed_sharing=sharing, monitor_errors=device['errors'],
        max_absolute_difference=error, run_sha256=digest(run_path), cost_sha256=digest(cost_path)))
report = dict(rows=rows, source_file_count=len(sources),
    baseline='Partially compiled public wrappers at 5bbce48b5 with current native density dependency',
    role='Descriptive fresh-process fixture comparison, no statistical speed ranking',
    terminal_acceptance=False)
target = ROOT / 'mixed-kr-cost-summary-04105.json'
with target.open('x') as output:
    json.dump(report, output, indent=2, allow_nan=False)
    output.write('\n')
for row in rows:
    print({key: row[key] for key in ('run', 'device', 'arm', 'count', 'cold_seconds',
        'warm_median_ms', 'rss_compiled_mib', 'warm_rss_increase_kib', 'gpu_peak_bytes',
        'observed_sharing', 'max_absolute_difference')})
print('source_file_count', len(sources), 'saved', target)
