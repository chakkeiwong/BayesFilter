"""Canonical LEDH analytical recursive score (P4 assembly).

Registered claim-bearing score entry point
(``ledh_alg1_contract.ENTRY_POINTS``). Composes the oracle-gated stage
derivatives (derivation note 2026-08-21): S1 UKF-predict tangent (Cholesky
Phi differential), S2 anchor chaining, S3 flow-map + log-det tangent, S4
PF-PF weight tangent, S5 UKF-update tangent (gain differential), S8
softmax increment accumulation — with the covariance recursion CHAINED
(each step consumes the previous step's posterior covariance and its
parameter tangent).

NO autodiff anywhere in this module (contract C-9). The autodiff oracle
lives in ``ledh_canonical_autodiff_oracle_tf`` and judges this module's
gates; it never ships.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Callable, Mapping

import tensorflow as tf

import bayesfilter.highdim.ledh_small_matrix_tf as small_matrix

from bayesfilter.highdim.ledh_canonical_score_stages_tf import (
    _gaussian_log_density_and_tangent,
    ukf_predict_with_parameter_tangent,
    ukf_update_with_parameter_tangent,
)

from bayesfilter.highdim.ledh_numerical_safety_tf import (
    safe_cholesky, cholesky_differential, all_finite, finite_or_zero,
)
from bayesfilter.highdim.ledh_failure_status_tf import (
    FailureCode, FailureStage, initial_status, record_failure, first_invalid_particle,
)

Tensor = tf.Tensor

ANCESTRY_POLICIES = (
    "existing_one_to_one",
    "hilbert_inverse_cdf",
    "hilbert_permutation_one_to_one",
)
STATE_MAP_POLICIES = ("adaptive_empirical", "fixed_supplied")


def _sqmc_ancestor_indices(
    states: Tensor,
    incoming_log_weights: Tensor,
    ancestor_uniforms: Tensor,
    *,
    ancestry_policy: str,
    state_map_location: Tensor,
    state_map_scale: Tensor,
    hilbert_bits: int,
    state_map_policy: str,
) -> tuple[Tensor, Tensor, Tensor, Tensor]:
    """Delegate realized fixed-index ancestry to the established SQMC helper."""
    from bayesfilter.highdim.ledh_pfpf_genut_initial_rqmc_tf import (
        _transition_ancestors,
    )

    result = _transition_ancestors(
        states,
        tf.nn.softmax(incoming_log_weights),
        ancestor_uniforms,
        ancestry_policy=ancestry_policy,
        state_map_location=state_map_location,
        state_map_scale=state_map_scale,
        hilbert_bits=hilbert_bits,
        state_map_policy=state_map_policy,
    )
    ancestry_valid = tf.constant(True)
    if ancestry_policy == "hilbert_permutation_one_to_one":
        ancestry_valid = (
            result["equal_weight_valid"]
            & result["ancestry_permutation_valid"]
        )
    return (
        result["selected_row_identities"],
        result["hilbert_ties"],
        result["state_map_saturation"],
        ancestry_valid,
    )


@dataclass(frozen=True)
class NonlinearScoreModel:
    transition_mean_fn: Callable[[Tensor, Tensor], Tensor]
    transition_mean_tangent_fn: Callable[[Tensor, Tensor, Tensor], Tensor]
    observation_fn: Callable[[Tensor], Tensor]
    observation_jacobian_fn: Callable[[Tensor], Tensor]
    observation_tangent_fn: Callable[[Tensor, Tensor], Tensor]
    process_covariance: Tensor
    observation_covariance: Tensor
    # Total tangent of H_theta(x_theta).  None is valid only when the
    # observation Jacobian is constant in both theta and x along the executed
    # direction.  The observation-value tangent alone cannot recover dH.
    observation_jacobian_tangent_fn: Callable[[Tensor, Tensor], Tensor] | None = None
    # Optional NON-GAUSSIAN observation density for the WEIGHT/VALUE path
    # (the Gaussian observation_fn/covariance above remain the FLOW's
    # proposal-design inputs, corrected by the PF-PF identity). When set,
    # the tangent callback must return the TOTAL parameter tangent
    # (closure carries the score direction, same convention as the
    # transition tangent). Added 2026-08-23 after the KSC/generalized-SV
    # fidelity defects: heteroskedastic and mixture observation families.
    observation_log_density_fn: Callable[[Tensor, Tensor, Tensor], Tensor] | None = None
    observation_log_density_tangent_fn: (
        Callable[[Tensor, Tensor, Tensor, Tensor], Tensor] | None
    ) = None
    # Q(theta)/R(theta) support (Q1.3): direction-tangents of the noise
    # covariances (closure carries the score direction; None => constant).
    process_covariance_tangent_fn: Callable[[Tensor], Tensor] | None = None
    observation_covariance_tangent_fn: Callable[[Tensor], Tensor] | None = None
    transition_log_density_fn: Callable[[Tensor, Tensor, Tensor], Tensor] | None = None
    transition_log_density_tangent_fn: (
        Callable[[Tensor, Tensor, Tensor, Tensor, Tensor], Tensor] | None
    ) = None
    # Optional structural chart x=f(ancestor)+B e. With this field, process
    # covariance/noises are in innovation coordinates, not full-state space.
    # The full-state UKF uses B S B'; only proposals flow in innovation space.
    innovation_matrix: Tensor | None = None
    innovation_matrix_tangent_fn: Callable[[Tensor], Tensor] | None = None


def _value_and_analytical_score_impl(
    model: NonlinearScoreModel,
    theta: Tensor,
    initial_states: Tensor,
    initial_covariances: Tensor,
    noises: Tensor,
    observations: Tensor,
    *,
    flow_substeps: int = 24,
    with_score: bool,
    return_trace: bool = False,
    _stacked_trace: bool = False,
    return_status: bool = False,
    initial_state_tangent: Tensor | None = None,
    initial_covariance_tangent: Tensor | None = None,
    observation_factor_override: Callable[
        [Tensor, Tensor, Tensor, Tensor, Tensor, Tensor],
        tuple[Tensor, Tensor] | tuple[Tensor, Tensor, Mapping[str, Tensor]]
    ]
    | None = None,
    post_reset_transform: Callable[
        [int, Tensor, Tensor, Tensor, Tensor],
        tuple[
            Tensor,
            Tensor,
            Tensor,
            Tensor,
            Tensor,
            Tensor,
            Mapping[str, Tensor],
        ],
    ]
    | None = None,
    reset_policy: str = "none",
    reset_design: Tensor | None = None,
    reset_epsilon: float = 2.0,
    reset_sinkhorn_steps: int = 8,
    reset_balance_steps: int = 8,
    reset_ridge: float = 1.0e-5,
    correction_steps: int = 0,
    correction_strength: float = 0.2,
    correction_lm_damping: float = 1.0e-2,
    correction_lm_scale_floor: float = 1.0e-4,
    correction_trust_radius: float = 0.5,
    pairwise_steps: int = 0,
    pairwise_strength: float = 0.02,
    pairwise_rms_cap: float = 2.0,
    moment_safety: bool = False,
    coordinate_cap: float = 0.0,
    coordinate_cap_power: int = 8,
    coordinate_cap_identity_radius: float = 0.0,
    annealed_stages: int = 1,
    annealed_seed: int = 0,
    moment_provider: tuple[Callable, Callable] | None = None,
    moment_schedule: Mapping[str, Tensor] | None = None,
    importance_weight_policy: str = "ancestor",
    ancestry_policy: str = "existing_one_to_one",
    process_ancestor_uniforms: Tensor | None = None,
    state_map_location: Tensor | None = None,
    state_map_scale: Tensor | None = None,
    hilbert_bits: int = 12,
    state_map_policy: str = "adaptive_empirical",
) -> (
    tuple[Tensor, Tensor | None]
    | tuple[Tensor, Tensor | None, tuple[dict[str, Tensor | int], ...]]
):
    """Shared T-step LEDH analytical executor (single parameter direction).

    reset_policy="contract_e" runs the FULL per-step program (S6: Sinkhorn
    + Contract-E reset with analytical tangent; S7: optional dual-cap
    trust-region correction via the general implementation's hand-derived
    JVPs). reset_policy="none" is the historical gated slice.

    ESTIMAND WARNING (2026-08-25, fidelity ledger): with
    reset_policy="none" and annealed_stages=1, each step assumes uniform
    incoming weights but never resamples, so the returned VALUE is NOT a
    log-likelihood estimator for horizons T > 1 (measured on the frozen
    LGSSM anchor: N-independent score bias +4.2 at T=50). That slice is
    a derivative-parity/diagnostic object ONLY. Claim-bearing value or
    score cells must use the production program (contract_e reset, and
    annealed mode where the scope's calibration says so).

    The annealed telescope supports positive stage counts using native tensor
    control flow. Diagnostic traces and observation/post-reset overrides
    remain restricted to one stage. The separate prepared-score factory also
    retains its one-stage contract.

    Multi-parameter models call this per direction; the per-direction
    tangent callbacks close over the direction (same convention as the
    repository's model tangent adapters).

    ``observation_factor_override`` is repository-internal composition: it
    receives ``(time_index, points, d_points, observation, base_log,
    d_base_log)`` and returns the component log factors and their total
    tangents.  The registered canonical wrapper never supplies it.

    ``return_trace=True`` is an opt-in diagnostic surface.  It returns a third
    value containing the actual per-step clouds, weights, tangents, observation,
    and post-reset state produced by this same finite program.  The trace is
    not part of the default return contract and does not feed back into the
    value or score computation.
    """

    dtype = initial_states.dtype
    if importance_weight_policy not in ("ancestor", "marginal_mixture"):
        raise ValueError("unsupported importance_weight_policy")
    if importance_weight_policy == "marginal_mixture":
        if (annealed_stages != 1 or ancestry_policy != "existing_one_to_one"
                or model.innovation_matrix is not None
                or model.transition_log_density_fn is not None
                or model.transition_log_density_tangent_fn is not None):
            raise ValueError("marginal_mixture requires full-rank Gaussian transitions, "
                             "one-to-one ancestry and one annealing stage")
    if return_trace and annealed_stages != 1:
        raise ValueError(
            "return_trace currently supports only annealed_stages=1; "
            "the annealed telescope needs a separate prior-observation factorization"
        )
    if observation_factor_override is not None and annealed_stages != 1:
        raise ValueError(
            "an observation-factor override currently supports only annealed_stages=1"
        )
    if post_reset_transform is not None and reset_policy != "contract_e":
        raise ValueError("a post-reset transform requires reset_policy='contract_e'")
    if post_reset_transform is not None and annealed_stages != 1:
        raise ValueError("a post-reset transform currently requires annealed_stages=1")

    if not isinstance(annealed_stages, int) or annealed_stages < 1:
        raise ValueError("annealed_stages must be a positive integer")
    horizon = int(observations.shape[0])
    dim = int(initial_states.shape[1])
    particle_count = int(initial_states.shape[0])
    count = tf.shape(initial_states)[0]
    obs_dim = int(observations.shape[1])
    if ancestry_policy not in ANCESTRY_POLICIES:
        raise ValueError(f"unsupported ancestry policy: {ancestry_policy}")
    if state_map_policy not in STATE_MAP_POLICIES:
        raise ValueError(f"unsupported state-map policy: {state_map_policy}")
    if ancestry_policy != "existing_one_to_one" and reset_policy != "contract_e":
        raise ValueError("SQMC ancestry requires reset_policy='contract_e'")
    if process_ancestor_uniforms is None:
        process_ancestor_uniforms = tf.zeros([horizon, particle_count], dtype)
    process_ancestor_uniforms = tf.ensure_shape(
        tf.cast(process_ancestor_uniforms, dtype), [horizon, particle_count]
    )
    if state_map_location is None:
        state_map_location = tf.zeros([dim], dtype)
    if state_map_scale is None:
        state_map_scale = tf.ones([dim], dtype)
    state_map_location = tf.ensure_shape(
        tf.cast(state_map_location, dtype), [dim]
    )
    state_map_scale = tf.ensure_shape(tf.cast(state_map_scale, dtype), [dim])
    if state_map_policy == "fixed_supplied":
        tf.debugging.assert_positive(state_map_scale)
    eye = tf.eye(dim, dtype=dtype)
    if flow_substeps <= 0 or horizon <= 0 or initial_states.shape[0] == 0:
        raise ValueError("positive horizon, particle count and flow_substeps are required")
    if reset_policy not in ("none", "contract_e"):
        raise ValueError("reset_policy must be 'none' or 'contract_e'")
    if reset_policy == "contract_e" and reset_design is None:
        raise ValueError("Contract E requires an explicit fixed reset design")
    geometry = None
    if model.innovation_matrix is not None:
        from bayesfilter.highdim.ledh_structural_innovation_tf import affine_innovation_geometry
        if model.transition_log_density_fn is not None:
            raise ValueError("structural innovations currently require the declared Gaussian density")
        innovation_dim = int(model.process_covariance.shape[-1])
        if noises.shape[-1] != innovation_dim:
            raise ValueError("structural noises must have innovation dimension")
        geometry = affine_innovation_geometry(
            model.innovation_matrix,
            None if model.innovation_matrix_tangent_fn is None else model.innovation_matrix_tangent_fn(theta),
            state_dim=dim, innovation_dim=innovation_dim)
    elif model.innovation_matrix_tangent_fn is not None:
        raise ValueError("innovation_matrix_tangent_fn requires innovation_matrix")
    process_valid, process_chol = safe_cholesky(model.process_covariance, "process")
    observation_valid, obs_chol = safe_cholesky(model.observation_covariance, "observation")
    process_covariance = tf.where(process_valid, model.process_covariance,
                                  tf.eye(int(model.process_covariance.shape[-1]), dtype=dtype))
    observation_covariance = tf.where(observation_valid, model.observation_covariance,
                                      tf.eye(obs_dim, dtype=dtype))
    r_inv = small_matrix.cholesky_solve(obs_chol, tf.eye(obs_dim, dtype=dtype))

    d_q = (
        model.process_covariance_tangent_fn(theta)
        if model.process_covariance_tangent_fn is not None and theta is not None
        else None
    )
    d_r = (
        model.observation_covariance_tangent_fn(theta)
        if model.observation_covariance_tangent_fn is not None and theta is not None
        else None
    )
    d_process_chol = (
        cholesky_differential(process_chol, d_q, process_valid) if d_q is not None else None
    )
    # S/dS stay in innovation coordinates for transition density evaluation.
    # Q/dQ for UKF prediction include all dependence of the rectangular B.
    d_state_q = d_q
    if geometry is not None:
        process_covariance, d_state_q = geometry.state_covariance(
            process_covariance, tf.zeros_like(process_covariance) if d_q is None else d_q)
        process_valid = process_valid & geometry.value_valid
    d_r_inv = (
        -tf.linalg.matmul(tf.linalg.matmul(r_inv, d_r), r_inv)
        if d_r is not None
        else None
    )
    states = initial_states
    d_states = (tf.zeros_like(states) if initial_state_tangent is None else
                tf.ensure_shape(tf.convert_to_tensor(initial_state_tangent, dtype=dtype), states.shape))
    covariances = initial_covariances
    d_covariances = (tf.zeros_like(covariances) if initial_covariance_tangent is None else
                     tf.ensure_shape(tf.convert_to_tensor(initial_covariance_tangent, dtype=dtype), covariances.shape))
    uniform_log_weights = -tf.math.log(tf.cast(count, dtype)) * tf.ones([count], dtype)
    incoming_log_weights = uniform_log_weights
    d_incoming_log_weights = tf.zeros_like(uniform_log_weights)
    total = tf.zeros([], dtype)
    d_total = tf.zeros([], dtype)
    status = record_failure(initial_status(),
        all_finite(theta, states, covariances), all_finite(d_states, d_covariances, d_q, d_r),
        time=-1, stage=FailureStage.INITIAL)
    status = record_failure(status, process_valid & observation_valid,
        all_finite(d_process_chol, d_r_inv, d_state_q)
        & (geometry.force_valid if geometry is not None else tf.constant(True)),
        time=-1, stage=FailureStage.INITIAL,
        value_code=FailureCode.FACTORIZATION)
    states = tf.where(status['value_valid'], states, tf.zeros_like(states))
    covariances = tf.where(status['value_valid'], covariances, tf.broadcast_to(eye, tf.shape(covariances)))
    d_states = tf.where(status['force_valid'], d_states, tf.zeros_like(d_states))
    d_covariances = tf.where(status['force_valid'], d_covariances, tf.zeros_like(d_covariances))
    if d_q is not None:
        d_q = tf.where(status['force_valid'], d_q, tf.zeros_like(d_q))
        d_process_chol = tf.where(status['force_valid'], d_process_chol, tf.zeros_like(d_process_chol))
    if d_r is not None:
        d_r = tf.where(status['force_valid'], d_r, tf.zeros_like(d_r))
        d_r_inv = tf.where(status['force_valid'], d_r_inv, tf.zeros_like(d_r_inv))

    def mean_fn(points):
        return model.transition_mean_fn(theta, points)

    def mean_tangent_fn(points, d_points):
        return model.transition_mean_tangent_fn(theta, points, d_points)

    # Phase 1 while-loop: convert time loop (2026-09-14)
    # Reference: deleted implementation at 5cc59cfa~1, lines 691-714
    def time_loop_cond(t, *_):
        return t < horizon

    moment_predict, moment_update = (moment_provider if moment_provider is not None else
                                    (ukf_predict_with_parameter_tangent, ukf_update_with_parameter_tangent))
    if moment_schedule is not None and moment_provider is not None:
        raise ValueError("choose a recursive provider or an independent filter schedule")

    def scheduled_moments(t, prefix):
        moments = tuple(tf.broadcast_to(moment_schedule[prefix + name][t],
                     [count, dim, dim] if "covariances" in name else [count, dim])
                     for name in ("means", "covariances", "d_means", "d_covariances"))
        valid, _ = safe_cholesky(moments[1], "scheduled_covariance")
        schedule_valid = moment_schedule.get(prefix + "valid", tf.constant(True))
        return (*moments, valid & tf.broadcast_to(schedule_valid[t] if schedule_valid.shape.rank else schedule_valid, [count]))

    def predict_at(t, *args, **kwargs):
        return scheduled_moments(t, "predicted_") if moment_schedule is not None else moment_predict(*args, **kwargs)

    def update_at(t, *args, **kwargs):
        return scheduled_moments(t, "post_") if moment_schedule is not None else moment_update(*args, **kwargs)

    def time_loop_body(t, states, d_states, covariances, d_covariances, incoming_log_weights, d_incoming_log_weights, status, total, d_total):
        pushed_covariance_precision_repair_count = tf.constant(0, tf.int32)
        # Apply the fixed SQMC ancestry map used by the main score program.
        # The selected indices are part of the diagnostic trace so the realized
        # piecewise-constant program can be audited independently of its score.
        states = tf.ensure_shape(states, [particle_count, dim])
        (
            ancestor_indices,
            hilbert_ties,
            state_map_saturation,
            ancestry_valid,
        ) = _sqmc_ancestor_indices(
            states,
            incoming_log_weights,
            process_ancestor_uniforms[t],
            ancestry_policy=ancestry_policy,
            state_map_location=state_map_location,
            state_map_scale=state_map_scale,
            hilbert_bits=hilbert_bits,
            state_map_policy=state_map_policy,
        )
        status = record_failure(
            status,
            ancestry_valid,
            tf.constant(True),
            time=t,
            stage=FailureStage.WEIGHTS,
            value_code=FailureCode.CALLBACK,
        )
        states = tf.gather(states, ancestor_indices)
        d_states = tf.gather(d_states, ancestor_indices)
        covariances = tf.gather(covariances, ancestor_indices)
        d_covariances = tf.gather(d_covariances, ancestor_indices)
        incoming_log_weights = tf.gather(incoming_log_weights, ancestor_indices)
        d_incoming_log_weights = tf.gather(
            d_incoming_log_weights, ancestor_indices
        )
        observation = observations[t]
        noise = noises[t]
        status = record_failure(status, all_finite(observation, noise), True,
                                time=t, stage=FailureStage.INITIAL)
        observation, noise = finite_or_zero(observation), finite_or_zero(noise)
        step_incoming_log_weights = incoming_log_weights
        d_step_incoming_log_weights = d_incoming_log_weights

        # S1: UKF predict with chained covariance tangent
        (
            predicted_means,
            predicted_covs,
            d_predicted_means,
            d_predicted_covs,
            valid_predict,
        ) = predict_at(t,
            states,
            covariances,
            d_states,
            d_covariances,
            mean_fn,
            mean_tangent_fn,
            process_covariance,
            d_process_noise_covariance=d_state_q,
        )

        status = record_failure(status,
            tf.reduce_all(valid_predict) & all_finite(predicted_means, predicted_covs),
            all_finite(d_predicted_means, d_predicted_covs), time=t, stage=FailureStage.PREDICT,
            value_code=FailureCode.FACTORIZATION, particle=first_invalid_particle(valid_predict))
        predicted_means = tf.where(status['value_valid'], predicted_means, tf.zeros_like(predicted_means))
        predicted_covs = tf.where(status['value_valid'], predicted_covs, tf.broadcast_to(eye, tf.shape(predicted_covs)))
        d_predicted_means = tf.where(status['force_valid'], d_predicted_means, tf.zeros_like(d_predicted_means))
        d_predicted_covs = tf.where(status['force_valid'], d_predicted_covs, tf.zeros_like(d_predicted_covs))

        # S2: anchor + pre-flow (total tangent via model callback)
        anchors = mean_fn(states)
        d_anchors = mean_tangent_fn(states, d_states)
        innovation = tf.einsum("ij,nj->ni", process_chol, noise)
        d_innovation = tf.zeros_like(innovation)
        if d_process_chol is not None:
            d_innovation = tf.einsum("ij,nj->ni", d_process_chol, noise)
        if geometry is None:
            pre_flow, d_pre_flow = anchors + innovation, d_anchors + d_innovation
        else:
            pre_flow, d_pre_flow = geometry.complete(innovation, d_innovation, anchors, d_anchors)

        observation_record = {}

        # Per-step density evaluators shared by S4 and the annealed
        # telescope (model callback path or Gaussian fallback).
        def _transition_density(points, d_points, means, d_means):
            if geometry is not None:
                innovation, d_innovation = geometry.coordinates(points, d_points, means, d_means)
                # Same innovation measure in numerator and denominator; no
                # density in the singular full-state Lebesgue measure exists.
                return _gaussian_log_density_and_tangent(
                    innovation, d_innovation, tf.zeros_like(innovation),
                    tf.zeros_like(innovation), process_chol, d_covariance=d_q)
            if model.transition_log_density_fn is not None:
                return (
                    model.transition_log_density_fn(theta, points, means),
                    model.transition_log_density_tangent_fn(
                        theta, points, means, d_points, d_means
                    ),
                )
            return _gaussian_log_density_and_tangent(
                points,
                d_points,
                means,
                d_means,
                process_chol,
                d_covariance=d_q,
            )

        def _observation_density(points, d_points):
            if model.observation_log_density_fn is not None:
                base_result = (
                    model.observation_log_density_fn(theta, points, observation),
                    model.observation_log_density_tangent_fn(
                        theta, points, observation, d_points
                    ),
                )
            else:
                observed = model.observation_fn(points)
                d_observed = model.observation_tangent_fn(points, d_points)
                obs_target = tf.broadcast_to(observation[None, :], tf.shape(observed))
                base_result = _gaussian_log_density_and_tangent(
                    obs_target,
                    None,
                    observed,
                    d_observed,
                    obs_chol,
                    d_covariance=d_r,
                )
            if observation_factor_override is None:
                return base_result
            result = observation_factor_override(t, points, d_points,
                                                 observation, *base_result)
            if len(result) == 3:
                observation_record.update(result[2])
            return result[:2]

        if annealed_stages > 1:
            # Restore the same pre-conversion telescope in a bounded native
            # loop. Realized resampling indices are piecewise constant.
            k_f = tf.cast(annealed_stages, dtype)
            previous_transition, d_previous_transition = _transition_density(
                pre_flow, d_pre_flow, anchors, d_anchors)
            previous_observation, d_previous_observation = _observation_density(pre_flow,d_pre_flow)
            status = record_failure(status,
                all_finite(pre_flow,anchors,previous_transition,previous_observation),
                all_finite(d_pre_flow,d_anchors,d_previous_transition,d_previous_observation),
                time=t,stage=FailureStage.FLOW,value_code=FailureCode.CALLBACK)

            def stage_body(stage,current,d_current,stage_anchors,d_stage_anchors,
                           pm,d_pm,pc,d_pc,prev_trans,d_prev_trans,prev_obs,d_prev_obs,
                           stage_status,value_sum,score_sum):
                moved,d_moved,log_det,d_log_det,vv,fv = _flow_substeps_with_tangent(
                    model,current,d_current,stage_anchors,d_stage_anchors,
                    pc/k_f,d_pc/k_f,observation,observation_covariance*k_f,
                    None if d_r is None else d_r*k_f,r_inv/k_f,
                    None if d_r_inv is None else d_r_inv/k_f,
                    substeps=flow_substeps,eye=eye, innovation_geometry=geometry)
                stage_status=record_failure(stage_status,vv,fv,time=t,
                    stage=FailureStage.FLOW,value_code=FailureCode.FACTORIZATION,
                    particle=first_invalid_particle(vv))
                new_trans,d_new_trans=_transition_density(moved,d_moved,stage_anchors,d_stage_anchors)
                new_obs,d_new_obs=_observation_density(moved,d_moved)
                fraction=tf.cast(stage,dtype)/k_f
                previous_fraction=tf.cast(stage-1,dtype)/k_f
                stage_logits=new_trans+fraction*new_obs+log_det-prev_trans-previous_fraction*prev_obs
                d_stage_logits=d_new_trans+fraction*d_new_obs+d_log_det-d_prev_trans-previous_fraction*d_prev_obs
                stage_status=record_failure(stage_status,all_finite(stage_logits),
                    all_finite(d_stage_logits),time=t,stage=FailureStage.WEIGHTS,
                    value_code=FailureCode.CALLBACK)
                stage_logits=tf.where(stage_status['value_valid'],stage_logits,tf.zeros_like(stage_logits))
                d_stage_logits=tf.where(stage_status['force_valid'],d_stage_logits,tf.zeros_like(d_stage_logits))
                norm=tf.reduce_logsumexp(stage_logits)
                weights=tf.exp(stage_logits-norm)
                value_sum+=norm-tf.math.log(tf.cast(count,dtype))
                score_sum+=tf.reduce_sum(weights*d_stage_logits)
                offset=tf.random.stateless_uniform([],seed=tf.stack([
                    tf.constant(annealed_seed,tf.int32),t*annealed_stages+stage]),dtype=dtype)
                positions=(offset+tf.cast(tf.range(count),dtype))/tf.cast(count,dtype)
                indices=tf.minimum(tf.searchsorted(tf.cumsum(weights),positions),count-1)
                indices=tf.ensure_shape(indices,[initial_states.shape[0]])
                current,d_current=tf.gather(moved,indices),tf.gather(d_moved,indices)
                stage_anchors,d_stage_anchors=tf.gather(stage_anchors,indices),tf.gather(d_stage_anchors,indices)
                pm,d_pm=tf.gather(pm,indices),tf.gather(d_pm,indices)
                pc,d_pc=tf.gather(pc,indices),tf.gather(d_pc,indices)
                prev_trans,d_prev_trans=_transition_density(current,d_current,stage_anchors,d_stage_anchors)
                prev_obs,d_prev_obs=_observation_density(current,d_current)
                return (stage+1,current,d_current,stage_anchors,d_stage_anchors,
                        pm,d_pm,pc,d_pc,prev_trans,d_prev_trans,prev_obs,d_prev_obs,
                        stage_status,value_sum,score_sum)

            (_,children,d_children,_,_,predicted_means,d_predicted_means,
             predicted_covs,d_predicted_covs,_,_,_,_,status,total,d_total)=tf.while_loop(
                lambda stage,*_:stage<=annealed_stages,stage_body,
                (tf.constant(1),pre_flow,d_pre_flow,anchors,d_anchors,
                 predicted_means,d_predicted_means,predicted_covs,d_predicted_covs,
                 previous_transition,d_previous_transition,previous_observation,d_previous_observation,
                 status,total,d_total),parallel_iterations=1)
            softmax=tf.ones([count],dtype)/tf.cast(count,dtype)
            d_logits=tf.zeros([count],dtype)
        else:
            # S3: flow with per-particle predicted covariance AND its
            # tangent (shared helper), then S4: weight assembly (the
            # transition density tangent needs the total tangent of the
            # transition mean AT the ancestor: d_anchors).
            flow_outputs = _flow_substeps_with_tangent(
                model,
                pre_flow,
                d_pre_flow,
                anchors,
                d_anchors,
                predicted_covs,
                d_predicted_covs,
                observation,
                observation_covariance,
                d_r,
                r_inv,
                d_r_inv,
                substeps=flow_substeps,
                eye=eye,
                innovation_geometry=geometry,
                return_affine=importance_weight_policy == "marginal_mixture",
            )
            children, d_children, log_det, d_log_det, flow_value_valid, flow_force_valid = flow_outputs[:6]
            status = record_failure(status, flow_value_valid & all_finite(pre_flow, anchors),
                flow_force_valid & all_finite(d_pre_flow, d_anchors), time=t, stage=FailureStage.FLOW,
                value_code=FailureCode.FACTORIZATION, particle=first_invalid_particle(flow_value_valid))
            transition_log, d_transition_log = _transition_density(
                children, d_children, anchors, d_anchors
            )
            observation_log, d_observation_log = _observation_density(
                children, d_children
            )
            proposal_log, d_proposal_log = _transition_density(
                pre_flow, d_pre_flow, anchors, d_anchors
            )
            weights_log = step_incoming_log_weights
            prior_observation_logits = (
                weights_log + transition_log + log_det - proposal_log
            )
            d_prior_observation_logits = (
                d_step_incoming_log_weights
                + d_transition_log
                + d_log_det
                - d_proposal_log
            )
            if importance_weight_policy == "marginal_mixture":
                from bayesfilter.highdim.ledh_marginal_weights_tf import marginal_prior_ratio_tangent
                proposal_means, d_proposal_means, matrix, d_matrix = flow_outputs[6:]
                ratio, d_ratio, mixture_valid, mixture_force_valid, pushed_covariance_precision_repair_count = marginal_prior_ratio_tangent(
                    children, d_children, anchors, d_anchors, process_covariance,
                    tf.zeros_like(process_covariance) if d_q is None else d_q,
                    proposal_means, d_proposal_means, matrix, d_matrix,
                    weights_log, d_step_incoming_log_weights, return_precision_diagnostics=True)
                prior_observation_logits = weights_log + ratio
                d_prior_observation_logits = d_step_incoming_log_weights + d_ratio
                status = record_failure(status, mixture_valid, mixture_force_valid,
                    time=t, stage=FailureStage.WEIGHTS, value_code=FailureCode.FACTORIZATION)
            prior_observation_normalizer = tf.reduce_logsumexp(prior_observation_logits)
            prior_observation_weights = tf.exp(
                prior_observation_logits - prior_observation_normalizer
            )
            d_prior_observation_normalizer = tf.reduce_sum(
                prior_observation_weights * d_prior_observation_logits
            )
            d_prior_observation_weights = prior_observation_weights * (
                d_prior_observation_logits - d_prior_observation_normalizer
            )
            logits = prior_observation_logits + observation_log
            d_logits = d_prior_observation_logits + d_observation_log
            status = record_failure(status, all_finite(logits), all_finite(d_logits),
                time=t, stage=FailureStage.WEIGHTS, value_code=FailureCode.CALLBACK)
            logits = tf.where(status['value_valid'], logits, uniform_log_weights)
            d_logits = tf.where(status['force_valid'], d_logits, tf.zeros_like(d_logits))
            increment = tf.reduce_logsumexp(logits)
            softmax = tf.exp(logits - increment)
            total = total + increment
            d_total = d_total + tf.reduce_sum(softmax * d_logits)

        # S5: UKF update with chained tangent -> next step's covariances
        (
            _post_means,
            post_covs,
            _d_post_means,
            d_post_covs,
            valid_update,
        ) = update_at(t,
            predicted_means,
            predicted_covs,
            d_predicted_means,
            d_predicted_covs,
            model.observation_fn,
            model.observation_tangent_fn,
            observation_covariance,
            observation,
            d_observation_covariance=d_r,
        )

        status = record_failure(status,
            tf.reduce_all(valid_update) & all_finite(_post_means, post_covs),
            all_finite(_d_post_means, d_post_covs), time=t, stage=FailureStage.UPDATE,
            value_code=FailureCode.FACTORIZATION, particle=first_invalid_particle(valid_update))
        post_covs = tf.where(status['value_valid'], post_covs, tf.broadcast_to(eye, tf.shape(post_covs)))
        d_post_covs = tf.where(status['force_valid'], d_post_covs, tf.zeros_like(d_post_covs))
        children = tf.where(status['value_valid'], children, tf.zeros_like(children))
        d_children = tf.where(status['force_valid'], d_children, tf.zeros_like(d_children))
        step_weights = softmax
        d_step_weights = softmax * (d_logits - tf.reduce_sum(softmax * d_logits))
        reset_transport = tf.eye(count, dtype=dtype)
        d_reset_transport = tf.zeros_like(reset_transport)
        post_reset_record: Mapping[str, Tensor] = {}
        higher_moment_record: Mapping[str, Tensor] = {
            "higher_moment_valid": tf.constant(True),
            "higher_moment_pairwise_configured": tf.constant(False),
            "higher_moment_pairwise_target_mask": tf.zeros([dim, dim], dtype),
            "higher_moment_pairwise_co_skew_residual": tf.zeros([dim, dim], dtype),
            "higher_moment_pairwise_co_kurtosis_residual": tf.zeros([dim, dim], dtype),
            "higher_moment_maximum_pairwise_pre_cap_particle_rms": tf.zeros([], dtype),
            "higher_moment_maximum_pairwise_post_cap_particle_rms": tf.zeros([], dtype),
            "higher_moment_minimum_pairwise_particle_cap_scale": tf.ones([], dtype),
            "higher_moment_maximum_coordinatewise_pre_cap_absolute": tf.zeros(
                [], dtype
            ),
            "higher_moment_maximum_coordinatewise_post_cap_absolute": tf.zeros(
                [], dtype
            ),
            "higher_moment_mean_coordinatewise_cap_displacement": tf.zeros([], dtype),
            "higher_moment_fraction_coordinatewise_cap_active": tf.zeros([], dtype),
            "higher_moment_minimum_coordinatewise_cap_derivative": tf.ones([], dtype),
        }
        if reset_policy == "contract_e":
            from bayesfilter.highdim.ledh_canonical_reset_score_tf import (
                sinkhorn_contract_e_reset_triple_with_tangent,
            )

            (
                reset_states,
                d_reset_states,
                reset_covariances,
                d_reset_covariances,
                reset_transport,
                d_reset_transport,
                valid_reset,
            ) = sinkhorn_contract_e_reset_triple_with_tangent(
                children,
                d_children,
                post_covs,
                d_post_covs,
                step_weights,
                d_step_weights,
                reset_design,
                epsilon=reset_epsilon,
                sinkhorn_steps=reset_sinkhorn_steps,
                balance_steps=reset_balance_steps,
                ridge=reset_ridge,
            )
            status = record_failure(status,
                tf.reduce_all(valid_reset) & all_finite(reset_states, reset_covariances, reset_transport),
                all_finite(d_reset_states, d_reset_covariances, d_reset_transport),
                time=t, stage=FailureStage.RESET, value_code=FailureCode.RESET_CORRECTION)
            reset_states = tf.where(status['value_valid'], reset_states, tf.zeros_like(reset_states))
            reset_covariances = tf.where(status['value_valid'], reset_covariances, tf.broadcast_to(eye, tf.shape(reset_covariances)))
            d_reset_states = tf.where(status['force_valid'], d_reset_states, tf.zeros_like(d_reset_states))
            d_reset_covariances = tf.where(status['force_valid'], d_reset_covariances, tf.zeros_like(d_reset_covariances))
            if correction_steps > 0 or pairwise_steps > 0:
                from bayesfilter.highdim.ledh_unified_correction_tf import (
                    batched_higher_moment_shape_jvp,
                )

                batched_corrected = batched_higher_moment_shape_jvp(
                    children[None, ...],
                    step_weights[None, ...],
                    d_children[None, None, ...],
                    d_step_weights[None, None, ...],
                    reset_states[None, ...],
                    d_reset_states[None, None, ...],
                    active=status["value_valid"][None],
                    correction_steps=correction_steps,
                    strength=correction_strength,
                    floor=1.0e-5,
                    diagonal_lm_damping=correction_lm_damping,
                    diagonal_lm_scale_floor=correction_lm_scale_floor,
                    diagonal_trust_radius=correction_trust_radius,
                    pairwise_correction_steps=pairwise_steps,
                    pairwise_strength=pairwise_strength,
                    pairwise_floor=1.0e-5,
                    pairwise_particle_rms_cap=pairwise_rms_cap,
                    moment_safety=moment_safety,
                    coordinatewise_standardized_cap=coordinate_cap,
                    coordinatewise_standardized_cap_power=coordinate_cap_power,
                    coordinatewise_standardized_identity_radius=coordinate_cap_identity_radius,
                    return_stages=return_trace,
                )
                corrected = {
                    key: (
                        tf.transpose(value[:, 0], [1, 2, 0])
                        if key == "particles_tangent"
                        else value[0]
                    )
                    for key, value in batched_corrected.items()
                }
                status = record_failure(status, corrected['value_valid'], corrected['valid'],
                    time=t, stage=FailureStage.CORRECTION,
                    value_code=FailureCode.RESET_CORRECTION)
                reset_states = corrected["particles"]
                d_reset_states = corrected["particles_tangent"][:, :, 0]
                higher_moment_record = {
                    "higher_moment_valid": corrected["valid"],
                    "higher_moment_pairwise_configured": tf.constant(
                        bool(pairwise_steps > 0 and dim > 1)
                    ),
                    "higher_moment_pairwise_target_mask": corrected[
                        "pairwise_target_mask"
                    ],
                    "higher_moment_pairwise_co_skew_residual": corrected[
                        "pairwise_co_skew_residual"
                    ],
                    "higher_moment_pairwise_co_kurtosis_residual": corrected[
                        "pairwise_co_kurtosis_residual"
                    ],
                    "higher_moment_maximum_pairwise_pre_cap_particle_rms": corrected[
                        "maximum_pairwise_pre_cap_particle_rms"
                    ],
                    "higher_moment_maximum_pairwise_post_cap_particle_rms": corrected[
                        "maximum_pairwise_post_cap_particle_rms"
                    ],
                    "higher_moment_minimum_pairwise_particle_cap_scale": corrected[
                        "minimum_pairwise_particle_cap_scale"
                    ],
                    "higher_moment_maximum_coordinatewise_pre_cap_absolute": corrected[
                        "maximum_coordinatewise_pre_cap_absolute"
                    ],
                    "higher_moment_maximum_coordinatewise_post_cap_absolute": corrected[
                        "maximum_coordinatewise_post_cap_absolute"
                    ],
                    "higher_moment_mean_coordinatewise_cap_displacement": corrected[
                        "mean_coordinatewise_cap_displacement"
                    ],
                    "higher_moment_fraction_coordinatewise_cap_active": corrected[
                        "fraction_coordinatewise_cap_active"
                    ],
                    "higher_moment_minimum_coordinatewise_cap_derivative": corrected[
                        "minimum_coordinatewise_cap_derivative"
                    ],
                }
                # Retain every diagnostic computed by the shared correction.
                # These tensors never alter states, weights or their tangents.
                higher_moment_record.update({
                    "higher_moment_" + key: value
                    for key, value in corrected.items()
                    if key not in ("particles", "particles_tangent")
                })
            new_states, new_d_states = reset_states, d_reset_states
            new_covariances, new_d_covariances = (
                reset_covariances,
                d_reset_covariances,
            )
            new_incoming_log_weights = uniform_log_weights
            new_d_incoming_log_weights = tf.zeros_like(uniform_log_weights)
        else:
            new_states, new_d_states = children, d_children
            new_covariances, new_d_covariances = post_covs, d_post_covs
            new_incoming_log_weights = uniform_log_weights
            new_d_incoming_log_weights = tf.zeros_like(uniform_log_weights)

        if post_reset_transform is not None:
            (new_states, new_d_states, new_covariances, new_d_covariances,
             new_incoming_log_weights, new_d_incoming_log_weights,
             post_reset_record) = post_reset_transform(
                 t, new_states, new_d_states, new_covariances, new_d_covariances)
        callback_valid = (observation_record.get("observation_factor_valid", tf.constant(True))
                          & post_reset_record.get("post_reset_valid", tf.constant(True)))

        status = record_failure(status,
            tf.reduce_all(callback_valid) & all_finite(new_states, new_covariances, new_incoming_log_weights, total),
            all_finite(new_d_states, new_d_covariances, new_d_incoming_log_weights, d_total),
            time=t, stage=FailureStage.CALLBACK, value_code=FailureCode.CALLBACK)
        # Inactive trajectories keep finite arithmetic state and never revive.
        new_states = tf.where(status['value_valid'], new_states, tf.zeros_like(new_states))
        new_covariances = tf.where(status['value_valid'], new_covariances, tf.broadcast_to(eye, tf.shape(new_covariances)))
        new_incoming_log_weights = tf.where(status['value_valid'], new_incoming_log_weights, uniform_log_weights)
        new_d_states = tf.where(status['force_valid'], new_d_states, tf.zeros_like(new_d_states))
        new_d_covariances = tf.where(status['force_valid'], new_d_covariances, tf.zeros_like(new_d_covariances))
        new_d_incoming_log_weights = tf.where(status['force_valid'], new_d_incoming_log_weights, tf.zeros_like(new_d_incoming_log_weights))
        total = tf.where(status['value_valid'], total, tf.zeros([], dtype))
        d_total = tf.where(status['force_valid'], d_total, tf.zeros([], dtype))

        result = (
            t + 1,
            new_states,
            new_d_states,
            new_covariances,
            new_d_covariances,
            new_incoming_log_weights,
            new_d_incoming_log_weights,
            status,
            total,
            d_total,
        )
        if return_trace:
            step_record = {
                "time_index": t,
                "ancestor_indices": ancestor_indices,
                "program_valid": status["value_valid"] & status["force_valid"],
                # Expose already-computed stage checks without altering the value
                # or score. A cumulative flag alone cannot localize a failure.
                "ukf_predict_valid": tf.reduce_all(valid_predict),
                "ukf_update_valid": tf.reduce_all(valid_update),
                "callback_valid": tf.reduce_all(callback_valid),
                "reset_numerical_valid": (tf.reduce_all(valid_reset)
                                          if reset_policy == "contract_e"
                                          else tf.constant(True)),
                "predicted_covariances_finite": tf.reduce_all(tf.math.is_finite(predicted_covs)),
                "post_covariances_finite": tf.reduce_all(tf.math.is_finite(post_covs)),
                "flow_states_finite": tf.reduce_all(tf.math.is_finite(children)),
                "flow_tangents_finite": tf.reduce_all(tf.math.is_finite(d_children)),
                "pushed_covariance_precision_repair_count": pushed_covariance_precision_repair_count,
                "posterior_logits_finite": tf.reduce_all(tf.math.is_finite(logits)),
                "reset_states_finite": tf.reduce_all(tf.math.is_finite(new_states)),
                "reset_tangents_finite": tf.reduce_all(tf.math.is_finite(new_d_states)),
                "ancestry_valid": tf.reduce_all(ancestry_valid),
                "hilbert_tie_count": hilbert_ties,
                "state_map_saturation_rate": state_map_saturation,
                "ancestors": states,
                "anchors": anchors,
                "incoming_log_weights": step_incoming_log_weights,
                "d_incoming_log_weights": d_step_incoming_log_weights,
                "pre_flow": pre_flow,
                "d_pre_flow": d_pre_flow,
                "children": children,
                "d_children": d_children,
                "posterior_weights": step_weights,
                "d_posterior_weights": d_step_weights,
                "prior_observation_weights": prior_observation_weights,
                "d_prior_observation_weights": d_prior_observation_weights,
                "prior_observation_logits": prior_observation_logits,
                "d_prior_observation_logits": d_prior_observation_logits,
                "prior_observation_log_normalizer": prior_observation_normalizer,
                "d_prior_observation_log_normalizer": d_prior_observation_normalizer,
                "observation_log_density": observation_log,
                "d_observation_log_density": d_observation_log,
                "posterior_logits": logits,
                "d_posterior_logits": d_logits,
                "observation": observation,
                "predicted_covariances": predicted_covs,
                "d_predicted_covariances": d_predicted_covs,
                "post_covariances": post_covs,
                "post_means": _post_means,
                "d_post_means": _d_post_means,
                "d_post_covariances": d_post_covs,
                "covariances_after_reset": new_covariances,
                "d_covariances_after_reset": new_d_covariances,
                "reset_transport": reset_transport,
                "d_reset_transport": d_reset_transport,
                "states_after_reset": new_states,
                "d_states_after_reset": new_d_states,
                "outgoing_log_weights": new_incoming_log_weights,
                "d_outgoing_log_weights": new_d_incoming_log_weights,
            }
            step_record.update(status)
            step_record.update(higher_moment_record)
            step_record.update(post_reset_record)
            step_record.update(observation_record)
            return result, step_record
        return result


    initial_loop = (tf.constant(0, tf.int32), states, d_states, covariances,
                    d_covariances, incoming_log_weights, d_incoming_log_weights,
                    status, total, d_total)
    state_shapes = (tf.TensorShape([]), tf.TensorShape([None, dim]),
                    tf.TensorShape([None, dim]), tf.TensorShape([None, dim, dim]),
                    tf.TensorShape([None, dim, dim]), tf.TensorShape([None]),
                    tf.TensorShape([None]), tf.nest.map_structure(lambda _: tf.TensorShape([]), status),
                    tf.TensorShape([]), tf.TensorShape([]))
    if return_trace:
        # One traced numerical step; TensorArrays carry all diagnostic fields
        # through the time loop. Python callbacks must return their metadata,
        # never append loop tensors to a Python container outside this body.
        step_kernel = tf.function(time_loop_body, autograph=False,
                                  input_signature=tf.nest.map_structure(lambda v: tf.TensorSpec(v.shape, v.dtype), initial_loop))
        template = step_kernel.get_concrete_function().structured_outputs[1]
        buffers = tf.nest.map_structure(
            lambda value: tf.TensorArray(value.dtype, size=horizon,
                                         element_shape=value.shape), template)

        def traced_body(*args):
            result, record = step_kernel(*args[:-1])
            buffers = tf.nest.map_structure(lambda buf, value: buf.write(args[0], value),
                                            args[-1], record)
            return (*result, buffers)

        loop_result = tf.while_loop(
            lambda *args: args[0] < horizon, traced_body,
            (*initial_loop, buffers), maximum_iterations=horizon,
            parallel_iterations=1)
        stacked = tf.nest.map_structure(lambda buf: buf.stack(), loop_result[-1])
        total, d_total = loop_result[-3:-1]
        status = loop_result[-4]
        total = tf.where(status['value_valid'], total, tf.constant(float('-inf'),dtype))
        trace = stacked if _stacked_trace else tuple(
            tf.nest.map_structure(lambda value: value[index], stacked) for index in range(horizon))
        result = (total, d_total[None] if with_score else None, trace)
        return (*result, status) if return_status else result
    loop_result = tf.while_loop(
        time_loop_cond, time_loop_body, initial_loop,
        shape_invariants=state_shapes, maximum_iterations=horizon,
        parallel_iterations=1)
    total, d_total = loop_result[-2:]
    status = loop_result[-3]
    total = tf.where(status['value_valid'], total, tf.constant(float('-inf'),dtype))
    result = (total, d_total[None] if with_score else None)
    return (*result, status) if return_status else result


def canonical_value_and_analytical_score(
    model: NonlinearScoreModel,
    theta: Tensor,
    initial_states: Tensor,
    initial_covariances: Tensor,
    noises: Tensor,
    observations: Tensor,
    *,
    flow_substeps: int = 24,
    with_score: bool,
    return_trace: bool = False,
    return_status: bool = False,
    initial_state_tangent: Tensor | None = None,
    initial_covariance_tangent: Tensor | None = None,
    reset_policy: str = "none",
    reset_design: Tensor | None = None,
    reset_epsilon: float = 2.0,
    reset_sinkhorn_steps: int = 8,
    reset_balance_steps: int = 8,
    reset_ridge: float = 1.0e-5,
    correction_steps: int = 0,
    correction_strength: float = 0.2,
    correction_lm_damping: float = 1.0e-2,
    correction_lm_scale_floor: float = 1.0e-4,
    correction_trust_radius: float = 0.5,
    pairwise_steps: int = 0,
    pairwise_strength: float = 0.02,
    pairwise_rms_cap: float = 2.0,
    moment_safety: bool = False,
    coordinate_cap: float = 0.0,
    coordinate_cap_power: int = 8,
    coordinate_cap_identity_radius: float = 0.0,
    annealed_stages: int = 1,
    annealed_seed: int = 0,
    importance_weight_policy: str = "ancestor",
    ancestry_policy: str = "existing_one_to_one",
    process_ancestor_uniforms: Tensor | None = None,
    state_map_location: Tensor | None = None,
    state_map_scale: Tensor | None = None,
    hilbert_bits: int = 12,
    state_map_policy: str = "adaptive_empirical",
) -> (
    tuple[Tensor, Tensor | None]
    | tuple[Tensor, Tensor | None, tuple[dict[str, Tensor | int], ...]]
):
    """Registered canonical atom-program value and analytical total score.

    This wrapper deliberately offers no observation-factor substitution.  It
    invokes the shared executor with the model's actual observation density,
    preserving the canonical target and its default two-value return contract.
    ``reset_policy='none'`` remains a diagnostic slice; claim-bearing calls
    must explicitly select Contract-E and the required correction settings.

    Supplied initial-state and covariance tangents carry dependence of a
    parameterized initial law into the same analytical recursion. Omitting
    them declares fixed initial inputs; it does not differentiate their
    construction. Their direction must match the model tangent callbacks.
    """

    return _value_and_analytical_score_impl(
        model,
        theta,
        initial_states,
        initial_covariances,
        noises,
        observations,
        flow_substeps=flow_substeps,
        with_score=with_score,
        return_trace=return_trace,
        return_status=return_status,
        initial_state_tangent=initial_state_tangent,
        initial_covariance_tangent=initial_covariance_tangent,
        observation_factor_override=None,
        post_reset_transform=None,
        reset_policy=reset_policy,
        reset_design=reset_design,
        reset_epsilon=reset_epsilon,
        reset_sinkhorn_steps=reset_sinkhorn_steps,
        reset_balance_steps=reset_balance_steps,
        reset_ridge=reset_ridge,
        correction_steps=correction_steps,
        correction_strength=correction_strength,
        correction_lm_damping=correction_lm_damping,
        correction_lm_scale_floor=correction_lm_scale_floor,
        correction_trust_radius=correction_trust_radius,
        pairwise_steps=pairwise_steps,
        pairwise_strength=pairwise_strength,
        pairwise_rms_cap=pairwise_rms_cap,
        moment_safety=moment_safety,
        coordinate_cap=coordinate_cap,
        coordinate_cap_power=coordinate_cap_power,
        coordinate_cap_identity_radius=coordinate_cap_identity_radius,
        annealed_stages=annealed_stages,
        annealed_seed=annealed_seed,
        importance_weight_policy=importance_weight_policy,
        ancestry_policy=ancestry_policy,
        process_ancestor_uniforms=process_ancestor_uniforms,
        state_map_location=state_map_location,
        state_map_scale=state_map_scale,
        hilbert_bits=hilbert_bits,
        state_map_policy=state_map_policy,
    )


def make_analytical_score_program(
    model_builder: Callable[[Tensor, Tensor], NonlinearScoreModel],
    *,
    dtype: tf.DType,
    theta_shape: tuple[int, ...],
    initial_state_shape: tuple[int, int],
    horizon: int,
    observation_dimension: int,
    jit_compile: bool = True,
    **static_options,
):
    """Own a stable default-XLA boundary for one analytical score direction.

    ``model_builder(theta, direction)`` must be a pure builder: construct the
    callbacks from these symbolic operands and fixed configuration inside the
    graph. Do not return an external model with mutable direction cells. Python
    tracing is lazy; external mutable configuration is not snapshotted here.

    The returned function takes theta, direction, initial states/covariances,
    noises, observations, and initial-state/covariance directional tangents.
    Explicit zero tangents declare a fixed initial law. All supplied tangents
    must correspond to the same direction. Reset design and other static
    options declare fixed configuration, not parameter-dependent inputs.

    Trace formatting is a separate diagnostic boundary. This factory preserves
    the existing analytical finite program; it does not establish LEDH admission
    or make the no-reset diagnostic slice a likelihood estimator for T > 1.
    ``jit_compile=False`` is an explicit reference/debug exception.
    """
    if not callable(model_builder):
        raise TypeError("model_builder must build a model from theta and direction")
    if "return_trace" in static_options or "with_score" in static_options:
        raise ValueError("owned analytical score program returns value and score only")
    if "initial_state_tangent" in static_options or "initial_covariance_tangent" in static_options:
        raise ValueError("initial-law tangents must be dynamic program operands")
    if static_options.get("annealed_stages", 1) != 1:
        raise ValueError("owned analytical score program requires annealed_stages=1")
    dtype = tf.as_dtype(dtype)
    theta_spec = tf.TensorSpec(theta_shape, dtype)
    initial_spec = tf.TensorSpec(initial_state_shape, dtype)
    covariance_spec = tf.TensorSpec(
        [initial_state_shape[0], initial_state_shape[1], initial_state_shape[1]],
        dtype,
    )
    noise_spec = tf.TensorSpec(
        [horizon, initial_state_shape[0], initial_state_shape[1]],
        dtype,
    )
    observation_spec = tf.TensorSpec(
        [horizon, observation_dimension], dtype
    )

    @tf.function(
        input_signature=[
            theta_spec, theta_spec, initial_spec, covariance_spec,
            noise_spec, observation_spec, initial_spec, covariance_spec,
        ],
        jit_compile=jit_compile,
        autograph=False,
    )
    def program(theta, direction, initial_states, initial_covariances, noises,
                observations, initial_state_tangent, initial_covariance_tangent):
        model = model_builder(theta, direction)
        return canonical_value_and_analytical_score(
            model,
            theta,
            initial_states,
            initial_covariances,
            noises,
            observations,
            with_score=True,
            initial_state_tangent=initial_state_tangent,
            initial_covariance_tangent=initial_covariance_tangent,
            **static_options,
        )

    return program


def _flow_substep_body_impl(
    step_index: tf.Tensor,
    actual: Tensor,
    d_actual: Tensor,
    auxiliary: Tensor,
    d_auxiliary: Tensor,
    log_det: Tensor,
    d_log_det: Tensor,
    model: NonlinearScoreModel,
    prior_means: Tensor,
    d_prior_means: Tensor,
    predicted_covs: Tensor,
    d_predicted_covs: Tensor,
    observation: Tensor,
    observation_covariance: Tensor,
    d_observation_covariance: Tensor | None,
    r_inv: Tensor,
    d_r_inv: Tensor | None,
    substeps: tf.Tensor,
    eye: Tensor,
    eps: Tensor,
    value_alive: Tensor,
    force_alive: Tensor,
    affine_state: tuple[Tensor, Tensor] | None = None,
) -> tuple[tf.Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
    """Single flow substep with analytical tangent.

    Extracted body for tf.while_loop conversion (Phase 3.5.2).

    Returns:
        (step_index + 1, updated_actual, updated_d_actual, updated_auxiliary,
         updated_d_auxiliary, updated_log_det, updated_d_log_det)
    """
    dtype = actual.dtype
    lam = tf.cast(step_index + 1, dtype) / tf.cast(substeps, dtype)
    h_jac = model.observation_jacobian_fn(auxiliary)
    d_h_jac = (
        model.observation_jacobian_tangent_fn(auxiliary, d_auxiliary)
        if model.observation_jacobian_tangent_fn is not None
        else tf.zeros_like(h_jac)
    )
    php = tf.einsum("noi,nij,npj->nop", h_jac, predicted_covs, h_jac)
    d_php = (
        tf.einsum(
            "noi,nij,npj->nop",
            d_h_jac,
            predicted_covs,
            h_jac,
        )
        + tf.einsum(
            "noi,nij,npj->nop",
            h_jac,
            d_predicted_covs,
            h_jac,
        )
        + tf.einsum(
            "noi,nij,npj->nop",
            h_jac,
            predicted_covs,
            d_h_jac,
        )
    )
    innovation_valid, innovation_chol = safe_cholesky(lam * php + observation_covariance[None], "flow_innovation")
    ph_t = tf.einsum("nij,noj->nio", predicted_covs, h_jac)
    d_ph_t = tf.einsum("nij,noj->nio", d_predicted_covs, h_jac) + tf.einsum(
        "nij,noj->nio", predicted_covs, d_h_jac
    )
    k_lam = tf.linalg.matrix_transpose(
        small_matrix.cholesky_solve(innovation_chol, tf.linalg.matrix_transpose(ph_t))
    )
    d_s = lam * d_php
    if d_observation_covariance is not None:
        d_s = d_s + d_observation_covariance[None]
    term_one = tf.linalg.matrix_transpose(
        small_matrix.cholesky_solve(
            innovation_chol, tf.linalg.matrix_transpose(d_ph_t)
        )
    )
    k_ds = tf.einsum("nio,nop->nip", k_lam, d_s)
    term_two = tf.linalg.matrix_transpose(
        small_matrix.cholesky_solve(innovation_chol, tf.linalg.matrix_transpose(k_ds))
    )
    d_k_lam = term_one - term_two
    a_matrix = -0.5 * tf.einsum("nio,noj->nij", k_lam, h_jac)
    d_a_matrix = -0.5 * (
        tf.einsum("nio,noj->nij", d_k_lam, h_jac)
        + tf.einsum("nio,noj->nij", k_lam, d_h_jac)
    )

    h_val = model.observation_fn(auxiliary)
    d_h_val = model.observation_tangent_fn(auxiliary, d_auxiliary)
    residual_e = h_val - tf.einsum("noi,ni->no", h_jac, auxiliary)
    d_residual_e = (
        d_h_val
        - tf.einsum("noi,ni->no", d_h_jac, auxiliary)
        - tf.einsum("noi,ni->no", h_jac, d_auxiliary)
    )
    z_eff = observation[None, :] - residual_e
    d_z_eff = -d_residual_e
    r_inv_z_eff = tf.einsum("op,np->no", r_inv, z_eff)
    d_r_inv_z_eff = tf.einsum("op,np->no", r_inv, d_z_eff)
    if d_r_inv is not None:
        d_r_inv_z_eff = d_r_inv_z_eff + tf.einsum("op,np->no", d_r_inv, z_eff)
    phrz = tf.einsum("nio,no->ni", ph_t, r_inv_z_eff)
    d_phrz = tf.einsum("nio,no->ni", d_ph_t, r_inv_z_eff) + tf.einsum(
        "nio,no->ni", ph_t, d_r_inv_z_eff
    )
    a_phrz = tf.einsum("nij,nj->ni", a_matrix, phrz)
    d_a_phrz = tf.einsum("nij,nj->ni", d_a_matrix, phrz) + tf.einsum(
        "nij,nj->ni", a_matrix, d_phrz
    )
    a_mean = tf.einsum("nij,nj->ni", a_matrix, prior_means)
    d_a_mean = tf.einsum("nij,nj->ni", d_a_matrix, prior_means) + tf.einsum(
        "nij,nj->ni", a_matrix, d_prior_means
    )
    inner = phrz + lam * a_phrz + a_mean
    d_inner = d_phrz + lam * d_a_phrz + d_a_mean
    a_inner = tf.einsum("nij,nj->ni", a_matrix, inner)
    d_a_inner = tf.einsum("nij,nj->ni", d_a_matrix, inner) + tf.einsum(
        "nij,nj->ni", a_matrix, d_inner
    )
    b_vector = inner + 2.0 * lam * a_inner
    d_b_vector = d_inner + 2.0 * lam * d_a_inner

    new_actual = actual + eps * (
        tf.einsum("nij,nj->ni", a_matrix, actual) + b_vector
    )
    new_d_actual = d_actual + eps * (
        tf.einsum("nij,nj->ni", d_a_matrix, actual)
        + tf.einsum("nij,nj->ni", a_matrix, d_actual)
        + d_b_vector
    )
    new_auxiliary = auxiliary + eps * (
        tf.einsum("nij,nj->ni", a_matrix, auxiliary) + b_vector
    )
    new_d_auxiliary = d_auxiliary + eps * (
        tf.einsum("nij,nj->ni", d_a_matrix, auxiliary)
        + tf.einsum("nij,nj->ni", a_matrix, d_auxiliary)
        + d_b_vector
    )
    step_matrix = eye[None] + eps * a_matrix
    finite_matrix = tf.reduce_all(tf.math.is_finite(step_matrix),[-2,-1])
    q_factor, r_factor = tf.linalg.qr(tf.where(finite_matrix[:,None,None], step_matrix, eye[None]))
    factor_valid = finite_matrix & tf.reduce_all(tf.math.is_finite(r_factor),[-2,-1])
    factor_valid &= tf.reduce_all(tf.abs(tf.linalg.diag_part(r_factor)) > 0,axis=-1)
    r_factor = tf.where(factor_valid[:,None,None],r_factor,eye[None])
    new_log_det = log_det + tf.reduce_sum(
        tf.math.log(tf.abs(tf.linalg.diag_part(r_factor))), axis=1
    )
    q_transpose_d_a = tf.linalg.matmul(q_factor, d_a_matrix, transpose_a=True)
    solved_d_a = small_matrix.triangular_solve(r_factor, q_transpose_d_a, lower=False)
    new_d_log_det = d_log_det + eps * tf.linalg.trace(solved_d_a)

    value_alive &= innovation_valid & factor_valid
    value_alive &= tf.reduce_all(tf.math.is_finite(new_actual),axis=-1)
    value_alive &= tf.reduce_all(tf.math.is_finite(new_auxiliary),axis=-1) & tf.math.is_finite(new_log_det)
    force_alive &= value_alive & tf.reduce_all(tf.math.is_finite(new_d_actual),axis=-1)
    force_alive &= tf.reduce_all(tf.math.is_finite(new_d_auxiliary),axis=-1) & tf.math.is_finite(new_d_log_det)
    result = (
        step_index + 1,
        tf.where(value_alive[:,None],new_actual,tf.zeros_like(new_actual)),
        tf.where(force_alive[:,None],new_d_actual,tf.zeros_like(new_d_actual)),
        tf.where(value_alive[:,None],new_auxiliary,tf.zeros_like(new_auxiliary)),
        tf.where(force_alive[:,None],new_d_auxiliary,tf.zeros_like(new_d_auxiliary)),
        tf.where(value_alive,new_log_det,tf.zeros_like(new_log_det)),
        tf.where(force_alive,new_d_log_det,tf.zeros_like(new_d_log_det)),
        value_alive, force_alive,
    )
    if affine_state is not None:
        matrix, d_matrix = affine_state
        new_matrix = tf.linalg.matmul(step_matrix, matrix)
        new_d_matrix = (tf.linalg.matmul(eps*d_a_matrix, matrix)
                        + tf.linalg.matmul(step_matrix, d_matrix))
        return result + (new_matrix, new_d_matrix)
    return result


def _flow_substeps_with_tangent(
    model: NonlinearScoreModel,
    actual: Tensor,
    d_actual: Tensor,
    prior_means: Tensor,
    d_prior_means: Tensor,
    predicted_covs: Tensor,
    d_predicted_covs: Tensor,
    observation: Tensor,
    observation_covariance: Tensor,
    d_observation_covariance: Tensor | None,
    r_inv: Tensor,
    d_r_inv: Tensor | None,
    *,
    substeps: int,
    eye: Tensor,
    innovation_geometry=None,
    return_affine: bool = False,
) -> tuple[Tensor, Tensor, Tensor, Tensor]:
    """S3 substep loop with analytical tangent, shared by the base path
    and the annealed telescope's tempered stages (which pass P/k, R*k and
    the correspondingly scaled tangents/inverse). H is evaluated along
    the auxiliary path; its state dependence enters through the model
    jacobian at the moving anchor. Returns (post_flow, tangent, log_det,
    d_log_det)."""

    if innovation_geometry is not None:
        if return_affine:
            raise ValueError("affine proposal output requires full-state Gaussian flow")
        g = innovation_geometry
        anchors, d_anchors = prior_means, d_prior_means
        z, dz = g.coordinates(actual, d_actual, anchors, d_anchors)
        p, dp = g.project_covariance(predicted_covs, d_predicted_covs)

        def completed(z, dz):
            return g.complete(z, dz, anchors, d_anchors)

        def observation_value(z):
            x, _ = completed(z, tf.zeros_like(z))
            return model.observation_fn(x)

        def observation_tangent(z, dz):
            x, dx = completed(z, dz)
            return model.observation_tangent_fn(x, dx)

        def jacobian(z):
            x, _ = completed(z, tf.zeros_like(z))
            return tf.einsum("noi,ij->noj", model.observation_jacobian_fn(x), g.matrix)

        def jacobian_tangent(z, dz):
            x, dx = completed(z, dz)
            h = model.observation_jacobian_fn(x)
            dh = (tf.zeros_like(h) if model.observation_jacobian_tangent_fn is None
                  else model.observation_jacobian_tangent_fn(x, dx))
            return tf.einsum("noi,ij->noj", dh, g.matrix) + tf.einsum("noi,ij->noj", h, g.tangent)

        reduced_model = replace(model, observation_fn=observation_value,
            observation_tangent_fn=observation_tangent, observation_jacobian_fn=jacobian,
            observation_jacobian_tangent_fn=jacobian_tangent, innovation_matrix=None,
            innovation_matrix_tangent_fn=None)
        moved, d_moved, ld, dld, vv, fv = _flow_substeps_with_tangent(
            reduced_model, z, dz, tf.zeros_like(z), tf.zeros_like(z), p, dp,
            observation, observation_covariance, d_observation_covariance,
            r_inv, d_r_inv, substeps=substeps, eye=tf.eye(int(z.shape[-1]), dtype=z.dtype))
        x, dx = completed(moved, d_moved)
        return x, dx, ld, dld, vv & g.value_valid, fv & g.force_valid

    dtype = actual.dtype
    count = tf.shape(actual)[0]
    eps = tf.constant(1.0 / substeps, dtype=dtype)
    substeps_tensor = tf.constant(substeps, dtype=tf.int32)
    auxiliary, d_auxiliary = prior_means, d_prior_means
    log_det = tf.zeros([count], dtype)
    d_log_det = tf.zeros([count], dtype)

    # Phase 3.5.2: tf.while_loop conversion for substep loop
    def substep_cond(i, *_):
        return i < substeps_tensor

    def substep_body_wrapper(i, act, d_act, aux, d_aux, ld, d_ld, vv, fv, *affine):
        return _flow_substep_body_impl(
            i,
            act,
            d_act,
            aux,
            d_aux,
            ld,
            d_ld,
            model,
            prior_means,
            d_prior_means,
            predicted_covs,
            d_predicted_covs,
            observation,
            observation_covariance,
            d_observation_covariance,
            r_inv,
            d_r_inv,
            substeps_tensor,
            eye,
            eps, vv, fv,
            affine_state=affine if return_affine else None,
        )

    initial_loop_vars = (
        tf.constant(0, dtype=tf.int32),
        actual,
        d_actual,
        auxiliary,
        d_auxiliary,
        log_det,
        d_log_det,
        tf.ones([count],tf.bool), tf.ones([count],tf.bool),
    )

    if return_affine:
        initial_matrix = tf.broadcast_to(eye, [int(actual.shape[0]), int(actual.shape[1]), int(actual.shape[1])])
        initial_loop_vars += (initial_matrix, tf.zeros_like(initial_matrix))
    outputs = tf.while_loop(
        cond=substep_cond,
        body=substep_body_wrapper,
        loop_vars=initial_loop_vars,
    )

    _, actual, d_actual, auxiliary, d_auxiliary, log_det, d_log_det, value_valid, force_valid = outputs[:9]
    result = (actual, d_actual, log_det, d_log_det, value_valid, force_valid)
    if return_affine:
        return result + (auxiliary, d_auxiliary, outputs[9], outputs[10])
    return result


def _cholesky_forward_diff_local(chol: Tensor, d_matrix: Tensor) -> Tensor:
    inv_d = small_matrix.triangular_solve(chol, d_matrix)
    inv_d_inv_t = tf.linalg.matrix_transpose(
        small_matrix.triangular_solve(chol, tf.linalg.matrix_transpose(inv_d))
    )
    lower = tf.linalg.band_part(inv_d_inv_t, -1, 0)
    phi = lower - 0.5 * tf.linalg.diag(tf.linalg.diag_part(inv_d_inv_t))
    return tf.linalg.matmul(chol, phi)


__all__ = [
    "NonlinearScoreModel",
    "canonical_value_and_analytical_score",
    "make_analytical_score_program",
]
