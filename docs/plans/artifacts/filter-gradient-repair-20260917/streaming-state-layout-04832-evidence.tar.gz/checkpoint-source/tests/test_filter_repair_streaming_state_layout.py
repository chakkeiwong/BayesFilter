"""Diagnostic complete-filter state-layout intervention; no performance admission."""

import collections
import hashlib
import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path
from types import ModuleType

import numpy as np
import pytest
import tensorflow as tf

from bayesfilter.highdim import ledh_canonical_value_program_tf as current
from scripts.analyze_filter_repair_locator_optimized_hlo import computations
from scripts.filter_repair_os_memory_diagnostic import snapshot
from tests.test_filter_repair_ledh_seeded_cost import (
    _callbacks_with_frozen_constants,
    _sync,
)
from tests.test_filter_repair_ledh_streaming import _numeric, authorities

__all__ = ['authorities']
ROOT = Path(__file__).resolve().parents[1]
SOURCE = 'bayesfilter/highdim/ledh_canonical_value_program_tf.py'
BASELINE = 'ab31c1410'


@pytest.mark.parametrize('horizon,arm', [(t, arm) for t in (32, 128) for arm in ('vector', 'scalar')])
def test_streaming_state_layout(horizon, arm, authorities, request):
    assert os.environ['CUDA_VISIBLE_DEVICES'] == '-1'
    prior_source = subprocess.check_output(['git', 'show', BASELINE+':'+SOURCE], cwd=ROOT, text=True)
    prior = ModuleType('_diagnostic_vector_state_authority')
    sys.modules[prior.__name__] = prior
    exec(compile(prior_source, '<diagnostic-vector-state-authority>', 'exec'), prior.__dict__)  # noqa: S102 -- fixed Git comparator
    _, fixture, _ = authorities
    model = fixture._lgssm_model(13, horizon=horizon)
    callbacks = _callbacks_with_frozen_constants(fixture._callbacks_for_lgssm(model))
    observations = tf.constant(model['observations'], tf.float64)
    spec = tf.TensorSpec(observations.shape, observations.dtype)
    args = (observations, tf.constant([123], tf.uint32), tf.constant([17], tf.uint32))
    controls = {'flow_substeps': 3, 'sinkhorn_steps': 2, 'balance_steps': 2,
                'dual_cap_enabled': True, 'trust_region_enabled': True}
    chosen, other = (prior, current) if arm == 'vector' else (current, prior)
    directory = Path(request.config.getoption('xmlpath')).parent
    memory = {'before': snapshot()}
    started = time.perf_counter()
    owner = chosen.make_canonical_value_program(callbacks, spec, particle_count=64,
                                               seed_word_count=1, **controls)
    result = owner(*args)
    _sync(result)
    cold = time.perf_counter()-started
    memory['after_cold'] = snapshot()
    for _ in range(3):
        _sync(owner(*args))
    times = []
    for _ in range(30):
        started = time.perf_counter()
        replay = owner(*args)
        _sync(replay)
        times.append(time.perf_counter()-started)
    memory['after_warm'] = snapshot()
    assert bool(result['program_valid'])
    assert owner.experimental_get_tracing_count() == 1
    for key, value in result.items():
        np.testing.assert_array_equal(value, replay[key], err_msg=key)
    report = {'schema': 'filter_repair_streaming_state_layout.v1', 'horizon': horizon, 'arm': arm,
        'baseline_commit': BASELINE, 'baseline_source_sha256': hashlib.sha256(prior_source.encode()).hexdigest(),
        'candidate_source_sha256': hashlib.sha256((ROOT/SOURCE).read_bytes()).hexdigest(),
        'input_sha256': [hashlib.sha256(tf.io.serialize_tensor(x).numpy()).hexdigest() for x in args],
        'controls': controls, 'cold_seconds': cold, 'warm_seconds': times,
        'warm_median_seconds': statistics.median(times), 'memory': memory,
        'cpu_affinity': sorted(os.sched_getaffinity(0)), 'record': _numeric(result),
        'timing_excludes_comparator_and_hlo': True}
    (directory/'streaming-state-layout.json').write_text(json.dumps(report, indent=2)+'\n')
    (directory/'vector-state-source.py').write_text(prior_source)
    (directory/'scalar-state-source.py').write_bytes((ROOT/SOURCE).read_bytes())
    concrete = owner.get_concrete_function()
    assert concrete.function_def.attr['_XlaMustCompile'].b
    graph = concrete.graph.as_graph_def()
    nodes = [*graph.node, *(node for f in graph.library.function for node in f.node_def)]
    assert not {n.op for n in nodes} & {'PyFunc', 'PyFuncStateless', 'EagerPyFunc', 'XlaHostCompute'}
    hlo = owner.experimental_get_compiler_ir(*args)(stage='optimized_hlo')
    (directory/'state-layout-optimized.hlo.txt').write_text(hlo)
    counts = collections.Counter()
    parsed = computations(hlo.splitlines())
    for computation in parsed:
        counts.update(computation['opcodes'])
    report['graph'] = {'trace_count': 1, 'jit_compile': True,
        'hlo_sha256': hashlib.sha256(hlo.encode()).hexdigest(),
        'computation_count': len(parsed), 'global_unique_opcodes': dict(counts),
        'process_buffer_occurrences': hlo.count(f'f64[{horizon},64,2]')}
    assert report['graph']['process_buffer_occurrences'] == 0
    comparator = other.make_canonical_value_program(callbacks, spec, particle_count=64,
                                                    seed_word_count=1, **controls)
    checked = comparator(*args)
    assert set(checked) == set(result)
    for key, value in result.items():
        np.testing.assert_array_equal(value, checked[key], err_msg=key)
    report['complete_records_exact'] = True
    (directory/'streaming-state-layout.json').write_text(json.dumps(report, indent=2)+'\n')
    sys.modules.pop(prior.__name__, None)
