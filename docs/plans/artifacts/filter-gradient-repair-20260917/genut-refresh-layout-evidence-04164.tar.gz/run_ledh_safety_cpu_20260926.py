import json, subprocess
from pathlib import Path
ROOT=Path('/tmp/bayesfilter-filter-gradient-xla-validation-20260918'); PYTHON='/home/ubuntu/miniforge3/envs/tf-gpu/bin/python'
for group in ('ledh_safety_cpu','ledh_stages_f64_cpu','ledh_stages_f32_cpu','ledh_safety_consumers_cpu'):
 print(group,flush=True)
 p=subprocess.run([PYTHON,'scripts/run_filter_repair_campaign.py','test','--group',group,'--device','CPU','--test-timeout-seconds','300'],cwd=ROOT)
 if p.returncode: raise SystemExit(p.returncode)
print('complete')
