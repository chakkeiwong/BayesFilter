# SQMC active checkpoint — 2026-09-28 Hong Kong

## Start here

Work only in `/home/chakwong/BayesFilter-SQMC`, branch `sqmc-development`.
Verified HEAD: `f3995a06a467f16574f96bbc8a68ccbbc4e30dad`.
There are substantial uncommitted repairs, tests and results. Preserve them.
Read the applicable `AGENTS.md`/`CLAUDE.md`, then the
[detailed reset memo](sqmc-development-handoff-20260928.md) and
[active experiment plan](../plans/sqmc-expanded-comparison-20260926.md).
Do not reload the failed conversation or all historical plans.

## Question, stage and evidence

Compare likelihood and every analytical score coordinate with matched Kalman:
P44 d=3 at T=10,120; full A/Q d=3 and d=10 at T=2,10,120. Four routes;
N=1008 for P44 and N=1020 for full matrices. Show actual scores and absolute
errors, not relative-score headlines. No statistical ranking is established.

The [correctness repair program](../plans/sqmc-repair-master-program-20260925.md)
is complete within its stated local scope. The
[N1008 diagnostic](../benchmarks/sqmc-n1008-results-20260926.md) completed
72/72 finite cells at P44 d3 T2. The expanded ladder has **not started**.
Its full-d10 T2 pilot completed in 317.42 s: seven of eight final cells valid;
one inverse-CDF cell invalid. The pilot had only two paired data/filter cases.

The revised runner implements four Cartesian cases, corrected heuristic
comparisons, separate worker processes and richer validity/provenance records.
Post-repair checks: **41 CPU-only tests passed in 43.96 s**;
[preserved log](../plans/artifacts/sqmc-handoff-20260928/sqmc-expanded-focused-checks.log).
The rewritten runner has not received its final skeptical review or GPU check.
No matching expanded-runner or pytest process was found at handoff inspection.

## Exact next action and budget

First verify checkout, dirty state and effective writable roots. Review the
runner against the plan, then resolve budget accounting before any GPU launch.
The original 14-hour elapsed window began 2026-09-26 17:49:50 UTC and expired.
The total cap remains **12 GPU-hours inclusive of pilots, checks and retries**;
exact remaining use is not reconciled. The runner's 1,200 s reserve is an
assumption requiring verification. At most two infrastructure retries per unit.
The [fresh-agent prompt](sqmc-new-agent-prompt-20260928.md) proposes explicit
renewal of the elapsed window, without increasing the total compute cap.

After budget reconciliation: bounded GPU graph/XLA parity and cost check;
then the eight scopes in order, unique output roots, all raw score coordinates,
invalid-cell evidence, final completeness audit and result note. Stop for a
broken oracle/implementation or exhausted budget; an inaccurate candidate
alone does not cancel later requested scopes.

This old conversation is still writable only under `/home/chakwong/BayesFilter`
and temporary directories. Opening another folder did not update its policy.
Use a fresh VS Code conversation rooted in the SQMC worktree; verify the actual
permission profile before assuming that file, Git, network or GPU access works.

