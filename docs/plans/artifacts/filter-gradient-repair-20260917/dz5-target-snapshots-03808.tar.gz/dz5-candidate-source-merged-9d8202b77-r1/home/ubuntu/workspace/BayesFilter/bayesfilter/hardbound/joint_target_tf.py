"""Joint non-centered log posterior for the hard-bound model (eq. 56 chart).

Unknowns: theta (9 = 6 theta_bar components + 3 log noise scales) and raw
latents z = (x0_raw [8], eta_raw [T, 8]), all standard normal a priori.
States are reconstructed deterministically; the observation density is the
S1 or C1 map. Also provides the tiny K=1 gate model of the master program.
"""

from __future__ import annotations

from dataclasses import dataclass

import tensorflow as tf

from bayesfilter.hardbound.dns_curve_tf import DTYPE, yield_curve
from bayesfilter.hardbound import model_tf

_LOG2PI = tf.constant(1.8378770664093453, DTYPE)

# Priors (master program Sec. 2, frozen).
#
# For the identification audit, displaced +3 standard deviations from truth.
# Truth-centred values retained for reference:
#   PRIOR_THETA_MEAN_TRUTH = [0.02, -0.01, 0.005, 0.015, -0.008, 0.004]
#   PRIOR_LOG_NOISE_MEAN_TRUTH = [-7.600902459542082] * 3
#
# Under approximate Gaussian conjugacy, posterior_mean ≈
#   (var_ratio * truth + prior_mean) / (1 + var_ratio),
# so posterior shift ≈ prior_displacement / var_ratio.  At var_ratio 55-105
# for theta0-5, the shift is <3%; at var_ratio 2.0 for theta8, shift ~50%.
PRIOR_THETA_MEAN = tf.constant(
    [0.02 + 3*0.02, -0.01 + 3*0.02, 0.005 + 3*0.02,
     0.015 + 3*0.02, -0.008 + 3*0.02, 0.004 + 3*0.02], DTYPE)
PRIOR_THETA_SD = tf.constant([0.02] * 6, DTYPE)
PRIOR_LOG_NOISE_MEAN = tf.constant(
    [(-7.600902459542082 + 3*0.5)] * 3, DTYPE)  # log 5e-4 + 3 sd
PRIOR_LOG_NOISE_SD = tf.constant([0.5] * 3, DTYPE)

# Prior location/scale stacked in the 9-dim chart order (6 theta_bar, then 3
# log noise), for the non-centred parameter chart below.
PRIOR_PARAM_MEAN = tf.concat([PRIOR_THETA_MEAN, PRIOR_LOG_NOISE_MEAN], axis=0)
PRIOR_PARAM_SD = tf.concat([PRIOR_THETA_SD, PRIOR_LOG_NOISE_SD], axis=0)


def theta_from_raw(theta_raw):
    """Map the non-centred parameter chart to the natural chart.

    ``theta = prior_mean + prior_sd * theta_raw``, so ``theta_raw`` carries a
    standard normal prior and O(1) posterior scale. The Jacobian
    ``prod(prior_sd)`` is constant, hence only an additive constant in the log
    density, which MCMC ignores; ``joint_log_prob_raw_batched`` therefore omits
    it and still targets the same posterior.

    Motivation (master program Amendment A2): in the natural chart the
    per-coordinate posterior sd spans 1.9e4 over the 337-dim state, with
    theta_bar levels near 3e-5 against latent shock raws near 5.8e-1. Scaling
    by the prior sd removes the parameter-block contribution analytically.
    """
    theta_raw = tf.convert_to_tensor(theta_raw, DTYPE)
    return PRIOR_PARAM_MEAN + PRIOR_PARAM_SD * theta_raw


def raw_from_theta(theta):
    """Inverse of :func:`theta_from_raw`."""
    theta = tf.convert_to_tensor(theta, DTYPE)
    return (theta - PRIOR_PARAM_MEAN) / PRIOR_PARAM_SD


def _std_normal_logpdf_sum(x):
    return tf.reduce_sum(-0.5 * x * x - 0.5 * _LOG2PI)


def _affine_state_path(center, phi, initial, innovations):
    """Time-major affine recurrence, with dense tensor state and native loop."""
    horizon = tf.shape(innovations)[0]
    history = tf.TensorArray(initial.dtype, size=horizon, element_shape=initial.shape)
    def step(index, state, history):
        state = center + phi * (state - center) + innovations[index]
        return index + 1, state, history.write(index, state)
    _, _, history = tf.while_loop(
        lambda index, *_: index < horizon, step,
        (tf.constant(0), initial, history), maximum_iterations=horizon,
    )
    return history.stack()


def states_from_raws(theta_bar, x0_raw, eta_raw,
                     fix: model_tf.HardBoundFixture = model_tf.FIXTURE):
    """Deterministic state reconstruction in the non-centered chart."""
    phi = tf.constant(fix.phi_diag, DTYPE)
    q_sd = tf.sqrt(tf.constant(fix.q_diag, DTYPE))
    p0_sd = tf.sqrt(tf.constant(fix.p0_diag, DTYPE))
    theta_ext = tf.concat([theta_bar, tf.zeros([2], DTYPE)], axis=0)
    x0 = theta_ext + p0_sd * x0_raw
    etas = q_sd * eta_raw  # [T, 8]

    return _affine_state_path(theta_ext, phi, x0, etas)


def joint_log_prob(y, theta, x0_raw, eta_raw, target_id,
                   fix: model_tf.HardBoundFixture = model_tf.FIXTURE):
    """log p(theta, x0_raw, eta_raw | y) up to a constant."""
    theta = tf.convert_to_tensor(theta, DTYPE)
    theta_bar = theta[:6]
    log_noise = theta[6:9]
    noise_scales = tf.exp(log_noise)
    lp = _std_normal_logpdf_sum(x0_raw) + _std_normal_logpdf_sum(eta_raw)
    lp += tf.reduce_sum(
        -0.5 * ((theta_bar - PRIOR_THETA_MEAN) / PRIOR_THETA_SD) ** 2
        - tf.math.log(PRIOR_THETA_SD) - 0.5 * _LOG2PI)
    lp += tf.reduce_sum(
        -0.5 * ((log_noise - PRIOR_LOG_NOISE_MEAN) / PRIOR_LOG_NOISE_SD) ** 2
        - tf.math.log(PRIOR_LOG_NOISE_SD) - 0.5 * _LOG2PI)
    states = states_from_raws(theta_bar, x0_raw, eta_raw, fix)
    lp += tf.reduce_sum(model_tf.observation_log_density(
        y, states, noise_scales, target_id, fix))
    return lp


# ---------------------------------------------------------------------------
# K=1 gate model (master program Phase 2, binding specification):
# 1-D level factor, T=4, K=1, one maturity, hard bound at 0.
# Parameters: level mean mu_L (prior N(0.005, 0.02^2)) and log noise scale
# (prior N(log 5e-4, 0.5^2)). Latents: 5 raws.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class GateModel:
    phi: float = 0.9
    q_sd: float = 2e-3
    p0_sd: float = 5e-3
    maturity: float = 1.0
    lower_bound: float = 0.0
    horizon: int = 4
    prior_mu_mean: float = 0.005
    prior_mu_sd: float = 0.02
    prior_lognoise_mean: float = -7.600902459542082
    prior_lognoise_sd: float = 0.5


GATE = GateModel()


def gate_states_from_raws(mu, raws, gm: GateModel = GATE):
    x0 = mu + gm.p0_sd * raws[0]
    return _affine_state_path(mu, gm.phi, x0, gm.q_sd * raws[1:1 + gm.horizon])


def gate_observation_mean(states, gm: GateModel = GATE):
    # level-only factor: forward f(s; x) = x (constant loading 1), so the
    # K=1 Gauss-Legendre average of max(0, x) at any maturity is max(0, x).
    return tf.maximum(tf.constant(gm.lower_bound, DTYPE), states)


def gate_joint_log_prob(y, params, raws, gm: GateModel = GATE):
    """log p(mu, log_sd, raws | y) up to a constant. params: [2], raws: [5]."""
    mu, log_sd = params[0], params[1]
    sd = tf.exp(log_sd)
    lp = _std_normal_logpdf_sum(raws)
    lp += (-0.5 * ((mu - gm.prior_mu_mean) / gm.prior_mu_sd) ** 2
           - tf.math.log(tf.constant(gm.prior_mu_sd, DTYPE)) - 0.5 * _LOG2PI)
    lp += (-0.5 * ((log_sd - gm.prior_lognoise_mean)
                   / gm.prior_lognoise_sd) ** 2
           - tf.math.log(tf.constant(gm.prior_lognoise_sd, DTYPE))
           - 0.5 * _LOG2PI)
    states = gate_states_from_raws(mu, raws, gm)
    mean = gate_observation_mean(states, gm)
    z = (tf.convert_to_tensor(y, DTYPE) - mean) / sd
    lp += tf.reduce_sum(-0.5 * z * z - log_sd - 0.5 * _LOG2PI)
    return lp


# ---------------------------------------------------------------------------
# Natively batched targets for multi-chain HMC. No pfor/vectorized_map is
# used anywhere in this package (repository governance: pfor requires prior
# written approval); batching is explicit tensor broadcasting instead.
# ---------------------------------------------------------------------------

def joint_log_prob_batched(y, theta, x0_raw, eta_raw, target_id,
                           fix: model_tf.HardBoundFixture = model_tf.FIXTURE):
    """Chain-batched joint log prob.

    theta: [C, 9]; x0_raw: [C, 8]; eta_raw: [C, T, 8]; y: [T, 13].
    Returns [C].
    """
    theta = tf.convert_to_tensor(theta, DTYPE)
    theta_bar = theta[:, :6]
    log_noise = theta[:, 6:9]
    noise_scales = tf.exp(log_noise)

    lp = tf.reduce_sum(-0.5 * x0_raw * x0_raw - 0.5 * _LOG2PI, axis=-1)
    lp += tf.reduce_sum(-0.5 * eta_raw * eta_raw - 0.5 * _LOG2PI,
                        axis=[-2, -1])
    lp += tf.reduce_sum(
        -0.5 * ((theta_bar - PRIOR_THETA_MEAN) / PRIOR_THETA_SD) ** 2
        - tf.math.log(PRIOR_THETA_SD) - 0.5 * _LOG2PI, axis=-1)
    lp += tf.reduce_sum(
        -0.5 * ((log_noise - PRIOR_LOG_NOISE_MEAN) / PRIOR_LOG_NOISE_SD) ** 2
        - tf.math.log(PRIOR_LOG_NOISE_SD) - 0.5 * _LOG2PI, axis=-1)

    phi = tf.constant(fix.phi_diag, DTYPE)
    q_sd = tf.sqrt(tf.constant(fix.q_diag, DTYPE))
    p0_sd = tf.sqrt(tf.constant(fix.p0_diag, DTYPE))
    theta_ext = tf.concat(
        [theta_bar, tf.zeros_like(theta_bar[:, :2])], axis=-1)  # [C, 8]
    x = theta_ext + p0_sd * x0_raw
    etas = q_sd * eta_raw  # [C, T, 8]
    states = tf.transpose(_affine_state_path(
        theta_ext, phi, x, tf.transpose(etas, [1, 0, 2]),
    ), [1, 0, 2])

    mean = model_tf.observation_mean(states, target_id, fix)  # [C, T, 13]
    scales = model_tf.noise_scales_vector(noise_scales)  # [C, 13]
    z = (y[None, :, :] - mean) / scales[:, None, :]
    lp += tf.reduce_sum(
        -0.5 * z * z - tf.math.log(scales[:, None, :]) - 0.5 * _LOG2PI,
        axis=[-2, -1])
    return lp


def joint_log_prob_raw_batched(y, theta_raw, x0_raw, eta_raw, target_id,
                               fix: model_tf.HardBoundFixture = model_tf.FIXTURE):
    """``joint_log_prob_batched`` in the non-centred parameter chart.

    Same posterior as :func:`joint_log_prob_batched` up to the constant
    Jacobian of :func:`theta_from_raw`, so draws map back exactly via
    ``theta_from_raw(theta_raw)``.
    """
    return joint_log_prob_batched(y, theta_from_raw(theta_raw), x0_raw,
                                  eta_raw, target_id, fix)


def gate_joint_log_prob_batched(y, params, raws, gm: GateModel = GATE):
    """Chain-batched gate-model log prob. params: [C, 2]; raws: [C, 5]."""
    params = tf.convert_to_tensor(params, DTYPE)
    raws = tf.convert_to_tensor(raws, DTYPE)
    mu = params[:, 0]
    log_sd = params[:, 1]
    sd = tf.exp(log_sd)
    lp = tf.reduce_sum(-0.5 * raws * raws - 0.5 * _LOG2PI, axis=-1)
    lp += (-0.5 * ((mu - gm.prior_mu_mean) / gm.prior_mu_sd) ** 2
           - tf.math.log(tf.constant(gm.prior_mu_sd, DTYPE)) - 0.5 * _LOG2PI)
    lp += (-0.5 * ((log_sd - gm.prior_lognoise_mean)
                   / gm.prior_lognoise_sd) ** 2
           - tf.math.log(tf.constant(gm.prior_lognoise_sd, DTYPE))
           - 0.5 * _LOG2PI)
    x = mu + gm.p0_sd * raws[:, 0]
    y = tf.convert_to_tensor(y, DTYPE)
    def step(t, x, lp):
        x = mu + gm.phi * (x - mu) + gm.q_sd * raws[:, 1 + t]
        mean = tf.maximum(tf.constant(gm.lower_bound, DTYPE), x)
        z = (y[t] - mean) / sd
        lp += -0.5 * z * z - log_sd - 0.5 * _LOG2PI
        return t + 1, x, lp
    _, _, lp = tf.while_loop(
        lambda t, *_: t < gm.horizon, step,
        (tf.constant(0), x, lp), maximum_iterations=gm.horizon,
    )
    return lp
