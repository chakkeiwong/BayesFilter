"""Bounded serial cost continuation using the approved campaign runner."""
import argparse
import json
import math
import sys
from pathlib import Path

ROOT=Path('/tmp/bayesfilter-filter-gradient-xla-validation-20260918')
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT)]
import run_filter_repair_campaign as runner

frozen=runner.source_hashes()
plan=json.loads((ROOT/'docs/plans/filter_gradient_repair_ledger_20260917.json').read_text())['current_checkpoint']['c2_preparation_k1_allocation']

def launch(group,device,pair=0,timeout=900):
    runner.check_matrix_state(frozen)
    rows=[r for r in runner.records() if int(Path(r['result']).parent.name[4:])>plan['start_after_run']]
    done=[r for r in rows if r['key'][1]==group and r['key'][6]==pair and r['state']=='passed' and r['source_sha256']==frozen]
    if done:return done[-1]
    spent=sum(r.get('elapsed_seconds',r['timeout_seconds']) for r in rows if r['device']==device)
    if len(rows)>=plan['max_workers'] or spent+timeout>plan['max_seconds'][device]:
        raise RuntimeError('C2 K1 allocation exhausted before launch')
    args=argparse.Namespace(action='test',group=group,arm='after',fixture='covariance',jit='on',
        size=1,repeat=pair,device=device,test_timeout_seconds=timeout,test_gpu_index=3,gpu_preflight=None)
    code=runner.run_job(args)
    row=runner.latest_record()
    if code:raise RuntimeError(f"C2 worker failed: {row['log']}")
    return row

def compare(a,b,path=''):
    if isinstance(a,dict):
        assert a.keys()==b.keys(),path
        for key in a:compare(a[key],b[key],path+'/'+str(key))
    elif isinstance(a,list):
        assert len(a)==len(b),path
        for index,(x,y) in enumerate(zip(a,b,strict=True)):compare(x,y,path+'/'+str(index))
    elif isinstance(a,(bool,int,str)):
        assert a==b,(path,a,b)
    else:
        assert math.isfinite(a) and math.isfinite(b),path
        assert abs(a-b)<=1e-10+1e-10*abs(b),(path,a,b)

for pair in range(3):
    arms=('original','graph','xla');values={}
    for arm in arms[pair:]+arms[:pair]:
        row=launch(f'c2_preparation_k1_cost_{arm}_gpu','GPU',pair)
        values[arm]=json.loads((Path(row['result']).parent/'c2-k1-cost.json').read_text())
    for arm in ('original','graph'):
        for field in ('branch','diagnostics','value_score'):
            compare(values[arm]['full_record'][field],values['xla']['full_record'][field],field)
    print(json.dumps({'C2_K1_pair':pair,'numerical_comparison':'passed'}),flush=True)
launch('c2_preparation_k1_terminal_cpu','CPU',timeout=300)
