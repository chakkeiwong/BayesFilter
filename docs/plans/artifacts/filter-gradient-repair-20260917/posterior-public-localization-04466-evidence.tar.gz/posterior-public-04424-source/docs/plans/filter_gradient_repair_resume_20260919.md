# Filter and gradient repair resume checkpoint

Checkpoint after 04424, September 27. CPU exported initializer qualification
passes all 13 checks through 04422, including D5 two-factor records. GPU matrix
session 20148 is active; D1 04424 passes. Keep runtime, tests, runner and policy
sources frozen until that matrix ends. Existing curvature public tests were
restored byte-for-byte from 6bceb767e; the new exported initializer tests now live
in test_filter_repair_posterior_initializer_public.py.

Boundary 04423 proves compiler failure without target/eager fallback, bound-method
cache identity and Python owner/program/scope collection. Its wall diagnostic
comparison passes, but its Python trace log was incorrectly expected to record
eager execution. Fix that diagnostic to count physical calls with a resource;
preserve the failure. Then run original API and boundary checks before costs.
The runner lock correctly rejects concurrent matrices; no extra worker launched.

Charged through 04424: 90912.210295 CPU / 82481.066660 GPU seconds.
Remaining: 30.746608 CPU / 29.088593 GPU hours under
56 CPU / 52 GPU-hour caps. The latest 24 CPU hours are already included.
Enclosing reservation: 10,800 combined seconds and 96 CPU / 72 GPU workers.
All F01--F20 terminal findings remain open; main is unmerged. Latest pushed
checkpoint is 6bceb767e. Controlling plan:
filter_gradient_posterior_initializer_enclosing_20260927.md.
