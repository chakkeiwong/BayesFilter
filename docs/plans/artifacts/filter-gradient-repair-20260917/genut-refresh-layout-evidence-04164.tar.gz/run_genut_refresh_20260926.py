import json, subprocess
from pathlib import Path
ROOT=Path('/tmp/bayesfilter-filter-gradient-xla-validation-20260918')
PYTHON='/home/ubuntu/miniforge3/envs/tf-gpu/bin/python'
groups=[
 ('genut_transitive_f64_cpu','CPU'),('genut_transitive_f32_cpu','CPU'),
 ('genut_transitive_consumers_cpu','CPU'),
 ('genut_transitive_cost_native_graph_cpu','CPU'),
 ('genut_transitive_cost_native_xla_cpu','CPU'),
 ('genut_transitive_cost_native_graph_gpu','GPU'),
 ('genut_transitive_cost_native_xla_gpu','GPU'),
 ('genut_transitive_f64_gpu','GPU'),('genut_transitive_f32_gpu','GPU'),
 ('genut_transitive_consumers_gpu','GPU'),
]
for group,device in groups:
 print(group,flush=True)
 p=subprocess.run([PYTHON,'scripts/run_filter_repair_campaign.py','test','--group',group,'--device',device,'--test-timeout-seconds','300'],cwd=ROOT)
 records=sorted(Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917').glob('run-*/run.json'))
 d=json.loads(records[-1].read_text()); assert d['key'][1]==group,(group,d['key'])
 if p.returncode: raise SystemExit(p.returncode)
print('complete')
