"""Diagnostic healthy/rejected LEDH fixtures; no canonical admission authority."""

import hashlib
import json
from pathlib import Path

import numpy as np
import pytest
import tensorflow as tf

from bayesfilter.highdim.ledh_canonical_value_program_tf import (
    make_canonical_value_program,
)
from tests import test_filter_repair_ledh_value_native as native

authorities = native.authorities


@pytest.mark.parametrize('case,horizon,stages,cap,dual,expected_valid', [
    ('composed', 3, 3, 0.8, False, True),
    ('dual_trust', 3, 1, float('inf'), True, False),
    ('one_step', 1, 1, float('inf'), False, False),
])
def test_characterize_current_validity(
    authorities, request, case, horizon, stages, cap, dual, expected_valid
):
    baseline, fixture, baseline_sha = authorities
    model = fixture._lgssm_model(13, horizon=horizon)
    callbacks = fixture._callbacks_for_lgssm(model)
    observations = tf.constant(model['observations'], tf.float64)
    rng = np.random.default_rng(123)
    inputs = (tf.constant(rng.normal(size=(8, 2)), tf.float64),
        tf.constant(rng.normal(size=(horizon, 8, 2)), tf.float64),
        tf.constant(rng.uniform(size=(horizon, stages)), tf.float64))
    controls = {'flow_substeps': 3, 'temper_stages': stages, 'annealed_resampling': False,
        'flow_prior_cap': cap, 'sinkhorn_steps': 2, 'balance_steps': 2,
        'dual_cap_enabled': dual, 'trust_region_enabled': dual}
    program = make_canonical_value_program(callbacks,
        tf.TensorSpec(observations.shape, tf.float64), particle_count=8, **controls)
    reference = native._frozen_reference(baseline, callbacks, observations, inputs, controls)
    actual = program(observations, *inputs)
    report = {'case': case, 'baseline_sha256': baseline_sha,
        'flow_baseline_sha256': baseline._flow_source_sha256, 'controls': controls,
        'source_device': actual['value'].device, 'reference': {}, 'actual': {},
        'nonclaims': ['CPU reference only; rejected raw programs are not equivalent usable likelihoods.',
            'No registered-consumer, canonical LEDH, GPU, performance or scientific admission.']}
    for name, result in (('reference', reference), ('actual', actual)):
        report[name] = {key: value.numpy().tolist() for key, value in result.items() if key != 'model_id'}
    report['input_sha256'] = [hashlib.sha256(tensor.numpy().tobytes()).hexdigest()
        for tensor in (observations, *inputs)]
    destination = Path(request.config.getoption('xmlpath')).parent / f'ledh-validity-{case}.json'
    destination.write_text(json.dumps(report, indent=2) + '\n')
    assert bool(reference['numerical_valid']) is expected_valid
    assert bool(actual['numerical_valid']) is expected_valid
    assert bool(reference['program_valid']) and bool(actual['program_valid'])
    np.testing.assert_array_equal(actual['per_step_reset_valid'], reference['per_step_reset_valid'])
    if expected_valid:
        report['healthy_complete_record_errors'] = native._compare(actual, reference)
    report['raw_value_absolute_difference'] = abs(float(actual['value']) - float(reference['value']))
    report['passed'] = True
    destination.write_text(json.dumps(report, indent=2) + '\n')
