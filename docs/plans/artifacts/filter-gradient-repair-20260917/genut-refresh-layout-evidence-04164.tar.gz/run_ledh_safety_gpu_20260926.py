import subprocess
from pathlib import Path
ROOT=Path('/tmp/bayesfilter-filter-gradient-xla-validation-20260918'); PYTHON='/home/ubuntu/miniforge3/envs/tf-gpu/bin/python'
for group in ('ledh_safety_gpu','ledh_stages_f64_gpu','ledh_stages_f32_gpu','ledh_safety_consumers_gpu'):
 print(group,flush=True)
 p=subprocess.run([PYTHON,'scripts/run_filter_repair_campaign.py','test','--group',group,'--device','GPU','--test-timeout-seconds','300'],cwd=ROOT)
 if p.returncode: raise SystemExit(p.returncode)
print('complete')
