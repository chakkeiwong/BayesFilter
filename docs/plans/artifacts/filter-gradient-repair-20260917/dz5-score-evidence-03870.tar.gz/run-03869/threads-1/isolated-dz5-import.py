
import hashlib
import importlib
import json
import math
import os
import sys
import traceback
from pathlib import Path

BF = Path('/home/ubuntu/workspace/BayesFilter')
MF = Path('/home/ubuntu/workspace/MacroFinance-dz5-neutra')
OUT = Path('/tmp/dz5-output')
sys.path[:0] = [str(MF), str(BF)]
report = {'schema': 'filter_repair_dz5_snapshot_import.v1', 'passed': False,
    'role': 'isolated_CPU_import_and_fixture_reference_only',
    'target_evaluated': False, 'adapter_admitted': False,
    'nonclaims': ['No target, initializer, transition, timing or retained qualification.']}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def diagnostic_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: diagnostic_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [diagnostic_json(item) for item in value]
    return value

try:
    manifest = json.loads(Path('/tmp/dz5-source/manifest.json').read_text())
    report['snapshot_manifest_sha256'] = sha('/tmp/dz5-source/manifest.json')
    expected = {path: entry['sha256'] for path, entry in manifest['sources'].items()}
    assert all(sha(path) == digest for path, digest in expected.items())
    gpu = os.environ['CUDA_VISIBLE_DEVICES'] != '-1'
    assert os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] == 'true'
    import tensorflow as tf
    from bayesfilter.runtime.gpu_memory_policy import configure_tensorflow_gpu_memory_growth
    memory = configure_tensorflow_gpu_memory_growth(tf, require_gpu=gpu)
    devices = tf.config.list_physical_devices('GPU')
    assert len(devices) == (1 if gpu else 0)
    report.update(device='GPU' if gpu else 'CPU',
        trust_basis='owner_designated_managed_session_visible_gpu_trusted' if gpu else 'CPU_reference',
        physical_gpus=[device.name for device in devices])
    report.update(gpu_memory_policy=memory, tensorflow=tf.__version__,
        cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'])

    from bayesfilter_estimation import audit_sources, declared_source_closure
    from two_currency_double_zlb_credit_estimation import (
        TFP_SPECIAL, TFP_SPECIAL_SHA, credit_fixture_identity)
    from two_currency_double_zlb_credit_fixtures import credit_fixture
    from two_currency_double_zlb_credit_target import CREDIT_FILTER_CONTRACT
    importlib.import_module('bayesfilter_estimation_initialization')
    importlib.import_module('two_currency_double_zlb_credit_recovery')
    importlib.import_module('bayesfilter.inference.dense_initializer_seeded_tf')
    importlib.import_module('bayesfilter.inference.tensor_npz_archive')
    assert sha(TFP_SPECIAL) == TFP_SPECIAL_SHA
    fixture = credit_fixture('CDF', n_steps=96)
    identity = credit_fixture_identity(fixture)
    assert identity == 'e116fe853c8579369036ab2ce57724ba07544524d0920fa0a706d76714f75d8a'
    assert len(fixture.parameter_names) == 23 and fixture.observations.shape[0] == 96
    assert CREDIT_FILTER_CONTRACT == 'rectangular_srukf_full_rank_identity_prepared_cir_v2'
    closure = audit_sources(declared_source_closure((
        MF / 'scripts/prepare_dz5_cdf_proposal.py',
        BF / 'bayesfilter/runtime/runner.py')))
    assert all(expected.get(path) == digest for path, digest in closure.items())
    loaded, unexpected = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if not filename:
            continue
        path = Path(filename).resolve()
        named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
        owned = path.is_relative_to(BF) or path.is_relative_to(MF)
        if named or owned:
            digest = sha(path)
            loaded[name] = {'path': str(path), 'sha256': digest}
            if not owned or expected.get(str(path)) != digest:
                unexpected[name] = loaded[name]
    report.update(loaded_modules=loaded, unexpected_modules=unexpected,
        source_closure=closure, fixture_identity=identity,
        parameter_names=fixture.parameter_names, observation_shape=list(fixture.observations.shape),
        filter_contract=CREDIT_FILTER_CONTRACT, tfp_special_sha256=TFP_SPECIAL_SHA)
    assert not unexpected, unexpected
    mounts = {}
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        fields = line.split()
        if fields[4] in (str(BF), str(MF)):
            mounts[fields[4]] = fields[5].split(',')
    report['source_mount_options'] = mounts
    assert set(mounts) == {str(BF), str(MF)}
    assert all('ro' in options for options in mounts.values())
    assert all(sha(path) == digest for path, digest in expected.items())
    expected_sources = expected.copy()

    import numpy as np  # Independent diagnostic report only.
    from two_currency_double_zlb_credit_target import (
        build_credit_factor_model_and_derivatives, credit_fixed_branch)
    from bayesfilter.nonlinear.rectangular_srukf_tf import tf_rectangular_srukf_value_and_score
    tf.config.experimental.enable_op_determinism()
    tf.config.experimental.enable_tensor_float_32_execution(False)
    center, scale = np.asarray(fixture.parameter_truth), np.asarray(fixture.prior_scale)
    bank = np.concatenate((center[None], *(center + multiplier * step * np.diag(scale)
        for step in (1e-3, 5e-4) for multiplier in (-2, -1, 1, 2))))
    def evaluate(parameters):
        model, derivatives = build_credit_factor_model_and_derivatives(
            parameters, fixture, prepare_fixed_cir_points=True)
        observations = tf.constant(fixture.likelihood_observations()[:2], tf.float64)
        result = tf_rectangular_srukf_value_and_score(
            tf.broadcast_to(observations, [185, *observations.shape.as_list()]),
            model, derivatives, branch=credit_fixed_branch(fixture), jit_compile=False)
        return {'initial_mean': model.initial_mean, 'initial_factor': model.initial_factor,
            'd_initial_mean': derivatives.d_initial_mean, 'd_initial_factor': derivatives.d_initial_factor,
            'value': result.log_likelihood, 'score': result.score, 'mean': result.filtered_mean,
            'factor': result.filtered_factor, 'd_mean': result.d_filtered_mean,
            'd_factor': result.d_filtered_factor, 'valid': result.diagnostics['score_valid']}
    kernel = tf.function(evaluate, input_signature=[tf.TensorSpec([185, 23], tf.float64)],
        jit_compile=False, autograph=False)
    first = None
    summaries = []
    for repeat in range(3):
        current = {key: value.numpy() for key, value in kernel(tf.constant(bank)).items()}
        assert all(np.isfinite(value).all() for value in current.values())
        assert current['valid'].all()
        np.savez_compressed(OUT / f'replay-localization-{repeat}.npz', bank=bank, **current)
        if first is None:
            first = current
        else:
            summaries.append({key: {'changed_elements': int(np.count_nonzero(value != first[key])),
                'max_absolute_error': float(np.max(np.abs(value.astype(float) - first[key].astype(float))))}
                for key, value in current.items()})
    assert kernel.experimental_get_tracing_count() == 1
    report.update(role='CPU_graph_replay_localization_two_observations_not_oracle_qualification',
        threads=int(os.environ['TF_NUM_INTRAOP_THREADS']), target_evaluated=True,
        jit_compile=False, op_determinism_enabled=True, original_fixture_observations=96,
        evaluated_observations=2, batch=185, trace_count=1, replay_summaries=summaries)
    (OUT / 'dz5-replay-localization.json').write_text(json.dumps(report, indent=2) + '\n')
    # Re-audit all actual project imports after tracing numerical callbacks.
    unexpected, loaded_after = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            owned = path.is_relative_to(BF) or path.is_relative_to(MF)
            named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
            if owned or named:
                loaded_after[name] = {'path': str(path), 'sha256': sha(path)}
                if not owned or expected_sources.get(str(path)) != sha(path):
                    unexpected[name] = str(path)
    report['post_target_loaded_modules'] = loaded_after
    report['post_target_unexpected_modules'] = unexpected
    assert not unexpected, unexpected
    assert all(sha(path) == digest for path, digest in expected_sources.items())

    report['passed'] = True
except BaseException as error:
    report.update(error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
finally:
    (OUT / 'dz5-snapshot-import.json').write_text(json.dumps(diagnostic_json(report), indent=2, allow_nan=False)+'\n')
sys.exit(0 if report['passed'] else 1)
