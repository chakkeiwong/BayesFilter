# Remaining C2 preparation source review (uninstalled)

Follow the mixture unit; no numerical run or source install is authorized by
this draft alone. Keep the current mixture cost sources frozen.

Confirmed remaining numerical recurrences in
bayesfilter/highdim/c2_sv_frozen_proposal_apf_tf.py:
- _compile_c2_branch:967 feeds exact prefix weights into bootstrap, independent
  Gaussian/Hermite and transformed Student preparation. The public wrappers
  freeze proposal metadata, then closures use a Python time index to select a
  proposal object. A tf.function on the sampler does not enclose this feedback.
- compile_c2_dmis_proposal_branch:682 performs two ancestor draws, two proposal
  banks, crossed densities, weighted base masses and exact-prefix feedback.
  Preserve alpha, bank size, row ordering, error order and both seed sequences.
- stationary_gaussian_proposals:890 computes covariance/cholesky eagerly before
  constructing time-indexed objects. Shared numerical preparation should be an
  owner; repeated object/manifest construction is completed metadata only.
- transformed_student_proposals:517 computes model transition/process tensors
  eagerly and constructs transformed guides over time. Batch shared geometry
  and log-square transformation, preserving original per-date failure order;
  completed objects/hashes must bind actual computed tensors.

Do not replace the heterogeneous proposal list with tf.switch_case containing
one complete branch per date: that restores trace expansion proportional to
T. Pack time-indexed tensor parameters, keep one native recurrence body and
reuse the current proposal numerical authorities. Heterogeneous types, degrees,
ranks and defensive_nu need actual supported-call evidence before deciding a
static protocol. Independent wrapper permits only GaussianHermiteRetainedProposal
or FrozenGaussianStateProposal; there is no general arbitrary callback promise.

Hermite authority c2_gaussian_hermite_proposal_tf.py has native degree/axis
loops, core packing and retained sampler/density owners. Relevant methods:
reference_quadratic_form544; reference_log_density551; physical_log_density580;
sample_reference607; sample_physical657; compiled_sampler690. Existing random
inputs833 use ordinary-compatible FP64 Philox normal/uniform/gamma with original
seed offsets. Their parameterized equivalents can be enclosed without copying
mathematical bodies. A time-indexed tensor view must not invoke validating
artifact constructors inside tracing or mint public proposal identities.

Student proposal geometry already has a JIT owner, but public construction and
sampling entry paths require enclosing review. Preserve nu-dependent ordinary
Gamma streams and cross-density math. Its manifest/fingerprint/reporting loop
is distinct from a numerical time recurrence.

Before any edits, freeze complete originals385a348b9 for every public family,
including mixed supported proposal lists and original errors. Use identical
frozen recovered C2 inputs. Current K=1/mixed UKF tests do not close these paths.
Keep fixed/frozen APF in scope and adaptive iAPF/KDM deferred. No change to
analytical APF measure, algorithm classification, RNG or comparison bounds.

Concrete observed callers: tests/highdim/test_c2_sv_frozen_proposal_apf_tf.py
and test_c2_ukf_guided_tt_dmis_tf.py; run_c2_frozen_tt_proposal_apf_20260828.py
and run_c2_ukf_guided_defensive_tt_dmis_20260829.py use retained-TT, Gaussian
hint and stationary sequences, and explicit transformed-Student defensive
lists. The latter main runner calls independent retained proposals at567,
DMIS at573, hints at575 and stationary proposals at577. Existing tiny fixtures
are D2/T3 with rank-one degree-one TT cores, nonzero diagonal/triangular Gaussian
hints, Student nu5 internal retained floor, defensive nu8, seeds813/814/901.
Use these unchanged as original-freeze references before adding mixed-topology
and dynamic operand witnesses. Existing gradient checks use2e-7; direct density
recomposition2e-11 and generalized bank-mass checks2e-14 remain unchanged.

Potential design, requiring implementation review: shared internal tensor views
of existing proposal classes can reuse their methods without invoking public
host validators/fingerprinters while tracing. Do not copy sampler/density math
into a second algorithm. Pack per-time tensor values with static shape/type
metadata at the input boundary. Group real proposal topology (type/degree/ranks/
nu) rather than one function per date. Prefer one padded core shape when it
preserves original operation semantics under strict comparison. Heterogeneous
runtime theta/seed must not become cache keys. Any graph proportional to the
number of dates must be identified, including input packing, not hidden by only
inspecting the inner recurrence. Existing branch diagnostics have per-family
schemas and strings; return a tensor superset and serialize only the fields
for the actual static proposal type after completion.

Implementation review while bootstrap pilot runs: the next Gaussian branch
should pass means/cholesky/time-index arrays as live operands to the shared
native time owner. Reuse/move the existing Gaussian transform/log-density body,
not a second formula. Its model-owned cache key covers shape/configuration,
not proposal IDs; seed/theta/proposal values remain live. Preserve original
ordered time-index mismatch after initial branch validation with an ordered
tensor status, rather than moving every metadata check ahead of the first
observation check. Horizon one needs no transition loop at all (05448 traced
empty-scatter failure repaired by a static initial-only return in05449).

Stationary-Gaussian geometry needs a retained XLA owner returning chol/mean;
its time-indexed object construction then becomes completed metadata only.
Any floating-point change can alter each true proposal_id and branch/compiler
IDs. Comparators must recompute current IDs from actual bytes and compare
non-identity payload/settings, not force the old fingerprint. No caller may
stamp a historical hash to hide these expected identity changes. This issue
also applies to the transformed-Student proposal builder.

Heterogeneous Hermite kernels currently depend on Python-static nu including
math.lgamma constants. Do not silently swap those constants for tf.lgamma as
part of time packing. Options to review: parameterize the shared density with
a precomputed exact original normalizer, or static dispatch by distinct nu
configuration (record graph dependence on number of configurations). Different
ranks/degrees can be zero-embedded into a common packed shape algebraically,
but require explicit same-record/discrete-decision tests before acceptance.
A new per-date copied sampler branch is not an enclosing-control repair.
