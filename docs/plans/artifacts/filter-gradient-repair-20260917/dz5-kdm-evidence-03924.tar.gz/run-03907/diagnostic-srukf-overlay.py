def tf_rectangular_srukf_value_and_score(
    observations: tf.Tensor,
    model: TFRectangularSRUKFModel,
    derivatives: TFRectangularSRUKFDerivatives,
    branch: TFRectangularSRUKFFixedBranch,
    *,
    jit_compile: bool = True,
) -> TFRectangularSRUKFScoreResult:
    """Run a fixed-rank, fixed-chart rectangular SR-UKF score recursion."""
    observations = tf.convert_to_tensor(observations, tf.float64)
    if observations.shape.rank != 3 or observations.shape[0] != model.batch_dim or observations.shape[2] != model.observation_dim:
        raise ValueError("observations must be [B,T,M]")
    t_count = observations.shape[1]
    if t_count is None:
        raise ValueError("time dimension must be static")
    b, n, q = model.batch_dim, model.state_dim, model.process_dim
    p = derivatives.parameter_dim
    rs, rq = model.initial_factor.shape[2], model.process_factor.shape[2]
    if branch.predicted_rank <= 0 or branch.innovation_rank <= 0 or branch.filtered_rank <= 0:
        raise ValueError("score route requires positive fixed ranks")
    if len(branch.predicted_permutation) != n or len(branch.innovation_permutation) != model.observation_dim or len(branch.filtered_permutation) != n:
        raise ValueError("branch permutations must match state/observation dimensions")
    if model.initial_factor.shape.as_list() != [b, n, branch.filtered_rank]:
        raise ValueError("initial factor width must equal the fixed filtered rank")
    if derivatives.d_initial_factor.shape.as_list() != [b, p, n, branch.filtered_rank]:
        raise ValueError("initial factor derivative width must equal the fixed filtered rank")

    predicted_permutation = tf.constant(branch.predicted_permutation, tf.int32)
    innovation_permutation = tf.constant(branch.innovation_permutation, tf.int32)
    filtered_permutation = tf.constant(branch.filtered_permutation, tf.int32)

    @tf.function(input_signature=[tf.TensorSpec([b, p, None, n], tf.float64)] * 2,
        autograph=False, jit_compile=jit_compile, experimental_attributes={"_noinline": True})
    def ordered_binary_add(left, right):
        return left + right

    def run(obs: tf.Tensor):
        mean = model.initial_mean
        factor = model.initial_factor
        d_mean = derivatives.d_initial_mean
        d_factor = derivatives.d_initial_factor
        value = tf.zeros([b], tf.float64)
        score = tf.zeros([b, p], tf.float64)
        score_valid = tf.ones([b], tf.bool)
        minimum_pivot = tf.fill([b], tf.constant(float("inf"), tf.float64))
        maximum_chart_residual = tf.zeros([b], tf.float64)
        maximum_support_residual = tf.zeros([b], tf.float64)

        def body(t, mean, factor, d_mean, d_factor, value, score, score_valid, minimum_pivot, maximum_chart_residual, maximum_support_residual):
            augmented_mean = tf.concat([mean, tf.zeros([b, q], tf.float64)], axis=1)
            augmented_factor = _block_factor(factor, model.process_factor)
            d_augmented_mean = tf.concat([d_mean, tf.zeros([b, p, q], tf.float64)], axis=2)
            d_augmented_factor = _block_factor_derivative(d_factor, derivatives.d_process_factor)
            latent_rank = branch.filtered_rank + rq
            offsets, mean_weights, covariance_weights = tf_factor_srukf_dz5_rule(latent_rank)
            points = augmented_mean[:, None, :] + tf.einsum("rd,bkd->brk", offsets, augmented_factor)
            d_points = d_augmented_mean[:, :, None, :] + tf.einsum("rd,bpkd->bprk", offsets, d_augmented_factor)
            previous_points, process_points = points[:, :, :n], points[:, :, n:]
            d_previous_points, d_process_points = d_points[:, :, :, :n], d_points[:, :, :, n:]
            predicted_points, state_j, process_j, direct = _transition_value_and_derivatives(
                model, derivatives, previous_points, process_points)
            d_predicted_points = tf.ensure_shape(ordered_binary_add(
                ordered_binary_add(tf.einsum("brij,bprj->bpri", state_j, d_previous_points),
                    tf.einsum("brij,bprj->bpri", process_j, d_process_points)), direct),
                [b, p, 1 + 2 * latent_rank, n])
            predicted_mean = tf.einsum("r,brd->bd", mean_weights, predicted_points)
            d_predicted_mean = tf.einsum("r,bprd->bpd", mean_weights, d_predicted_points)
            state_stack = _stack(predicted_points, predicted_mean, covariance_weights)
            d_state_stack = _derivative_stack(d_predicted_points, d_predicted_mean, covariance_weights)
            predicted_factor, d_predicted_factor, state_diag = batched_fixed_pivot_rectangular_qr(
                state_stack,
                predicted_permutation,
                branch.predicted_rank,
                d_state_stack,
                residual_tolerance=branch.chart_tolerance,
                pivot_tolerance=branch.pivot_tolerance,
            )

            observation_points = tf.convert_to_tensor(model.observation_fn(predicted_points), tf.float64)
            d_observation_points = tf.einsum(
                "brij,bprj->bpri",
                tf.convert_to_tensor(derivatives.observation_state_jacobian_fn(predicted_points), tf.float64),
                d_predicted_points,
            ) + tf.convert_to_tensor(derivatives.d_observation_fn(predicted_points), tf.float64)
            predicted_observation = tf.einsum("r,brd->bd", mean_weights, observation_points)
            d_predicted_observation = tf.einsum("r,bprd->bpd", mean_weights, d_observation_points)
            y_stack = _stack(observation_points, predicted_observation, covariance_weights)
            dy_stack = _derivative_stack(d_observation_points, d_predicted_observation, covariance_weights)
            observation_stack = tf.concat([y_stack, model.observation_factor], axis=2)
            d_observation_stack = tf.concat([dy_stack, derivatives.d_observation_factor], axis=3)
            state_joint_stack = tf.concat([state_stack, tf.zeros([b, n, model.observation_factor.shape[2]], tf.float64)], axis=2)
            d_state_joint_stack = tf.concat([d_state_stack, tf.zeros([b, p, n, model.observation_factor.shape[2]], tf.float64)], axis=3)
            innovation = obs[:, t, :] - predicted_observation
            d_innovation = -d_predicted_observation
            inc, inc_score, increment, d_increment, new_factor, new_d_factor, update_diag = batched_fixed_support_qr_update(
                observation_stack,
                state_joint_stack,
                innovation,
                innovation_permutation,
                branch.innovation_rank,
                filtered_permutation,
                branch.filtered_rank,
                d_observation_stack,
                d_state_joint_stack,
                d_innovation,
                chart_tolerance=branch.chart_tolerance,
                pivot_tolerance=branch.pivot_tolerance,
                support_tolerance=branch.support_tolerance,
            )
            new_mean = predicted_mean + increment
            new_d_mean = d_predicted_mean + d_increment
            valid = tf.logical_and(state_diag["chart_valid"], update_diag["chart_valid"])
            valid = tf.logical_and(valid, update_diag["conditional_chart_valid"])
            valid = tf.logical_and(valid, update_diag["on_support"])
            return (
                t + 1, new_mean, new_factor, new_d_mean, new_d_factor,
                value + inc, score + inc_score, tf.logical_and(score_valid, valid),
                tf.minimum(minimum_pivot, tf.minimum(state_diag["minimum_chart_pivot"], tf.minimum(update_diag["minimum_chart_pivot"], update_diag["conditional_minimum_chart_pivot"]))),
                tf.maximum(maximum_chart_residual, tf.maximum(state_diag["chart_residual"], tf.maximum(update_diag["chart_residual"], update_diag["conditional_chart_residual"]))),
                tf.maximum(maximum_support_residual, update_diag["support_residual"]),
            )

        result = tf.while_loop(
            lambda t, *_: t < t_count,
            body,
            (tf.constant(0), mean, factor, d_mean, d_factor, value, score, score_valid, minimum_pivot, maximum_chart_residual, maximum_support_residual),
            parallel_iterations=1,
        )
        return result[1:]

    if jit_compile:
        run = tf.function(run, input_signature=[tf.TensorSpec(observations.shape, tf.float64)], jit_compile=True)
    mean, factor, d_mean, d_factor, value, score, score_valid, minimum_pivot, maximum_chart_residual, maximum_support_residual = run(observations)
    score = tf.where(score_valid[:, None], score, tf.fill(tf.shape(score), tf.constant(float("nan"), tf.float64)))
    return TFRectangularSRUKFScoreResult(
        value, score, mean, factor, d_mean, d_factor,
        {
            "value_only": tf.constant(False),
            "score_valid": score_valid,
            "branch_status_code": tf.cast(~score_valid, tf.int32),
            # Dynamic string selection is host reporting, never part of an
            # enclosing target/HMC XLA function. score_valid is authoritative.
            "branch_status": (
                tf.where(score_valid, tf.constant("fixed_branch_valid"), tf.constant("fixed_branch_invalid"))
                if tf.executing_eagerly() else tf.constant("read_score_valid_or_branch_status_code")
            ),
            "branch_identity": tf.constant(branch.identity),
            "factorization": tf.constant("direct_fixed_pivot_rectangular_qr"),
            "likelihood_measure": tf.constant("affine_support_gaussian_fixed_qr"),
            "minimum_chart_pivot": minimum_pivot,
            "maximum_chart_residual": maximum_chart_residual,
            "maximum_support_residual": maximum_support_residual,
            "jit_compile": tf.constant(bool(jit_compile)),
        },
    )
