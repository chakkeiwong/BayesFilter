def dual_cap_genut_primal(source: Tensor, weights: Tensor, reset_points: Tensor, *, diagonal_steps: int=4, diagonal_strength: float=0.2, diagonal_floor: float=1e-05, pairwise_steps: int=4, pairwise_strength: float=0.02, pairwise_floor: float=1e-05, pairwise_particle_rms_cap: float=2.0, coordinate_cap: float=0.98, coordinate_cap_power: int=8) -> dict[str, Tensor]:
    """Apply the existing reduced dual-cap correction without derivative work."""
    source = tf.convert_to_tensor(source)
    weights = tf.convert_to_tensor(weights, source.dtype)
    reset_points = tf.convert_to_tensor(reset_points, source.dtype)
    if source.shape != reset_points.shape:
        raise ValueError('source and reset cloud shapes must match')
    if source.shape.rank != 2 or source.shape[1] is None:
        raise ValueError('dual-cap primal requires a static rank-two state cloud')
    if weights.shape != (source.shape[0],):
        raise ValueError('dual-cap weights have the wrong shape')
    if diagonal_steps < 0 or diagonal_strength < 0.0 or diagonal_floor <= 0.0 or (pairwise_steps < 0) or (pairwise_strength < 0.0) or (pairwise_floor <= 0.0) or (pairwise_particle_rms_cap < 0.0) or (coordinate_cap <= 0.0) or (coordinate_cap >= 1.0) or (coordinate_cap_power < 2) or (coordinate_cap_power % 2 != 0):
        raise ValueError('invalid dual-cap controls')
    target_mean, target_covariance = _weighted_moments(source, weights)
    target_cholesky = tf.linalg.cholesky(target_covariance)
    source_standardized = _right_solve(target_cholesky, source - target_mean[None, :])
    target_skew = tf.reduce_sum(weights[:, None] * tf.pow(source_standardized, 3.0), axis=0)
    target_kurtosis = tf.reduce_sum(weights[:, None] * tf.pow(source_standardized, 4.0), axis=0)
    target_co_skew, target_co_kurtosis = _pair_moments(source_standardized, weights)
    standardized = _standardize_uniform(reset_points)

    def diagonal_body(index, current):
        corrected = _diagonal_iteration(current, target_skew, target_kurtosis, strength=diagonal_strength, floor=diagonal_floor)
        return (index + 1, corrected)
    _, standardized = tf.while_loop(lambda index, _current: index < diagonal_steps, diagonal_body, (tf.constant(0), standardized), parallel_iterations=1, maximum_iterations=max(diagonal_steps, 1))
    maximum_pre_cap_rms = tf.zeros([], source.dtype)
    maximum_post_cap_rms = tf.zeros([], source.dtype)
    minimum_radial_scale = tf.ones([], source.dtype)
    if source.shape[1] > 1:

        def pairwise_body(index, current, maximum_pre, maximum_post, minimum_scale):
            corrected, pre_rms, post_rms, scale = _pairwise_iteration(current, target_co_skew, target_co_kurtosis, strength=pairwise_strength, floor=pairwise_floor, particle_rms_cap=pairwise_particle_rms_cap)
            return (index + 1, corrected, tf.maximum(maximum_pre, pre_rms), tf.maximum(maximum_post, post_rms), tf.minimum(minimum_scale, scale))
        _, standardized, maximum_pre_cap_rms, maximum_post_cap_rms, minimum_radial_scale = tf.while_loop(lambda index, *_state: index < pairwise_steps, pairwise_body, (tf.constant(0), standardized, maximum_pre_cap_rms, maximum_post_cap_rms, minimum_radial_scale), parallel_iterations=1, maximum_iterations=max(pairwise_steps, 1))
    pre_coordinate_cap = standardized
    cap = tf.cast(coordinate_cap, source.dtype)
    power = tf.cast(coordinate_cap_power, source.dtype)
    scaled_power = tf.pow(pre_coordinate_cap / cap, power)
    denominator = tf.pow(1.0 + scaled_power, 1.0 / power)
    capped = pre_coordinate_cap / denominator
    cap_derivative = tf.pow(1.0 + scaled_power, -1.0 / power - 1.0)
    standardized = _standardize_uniform(capped)
    particles = target_mean[None, :] + tf.reduce_sum(standardized[:, None, :] * target_cholesky[None, :, :], axis=2)
    output_mean, output_covariance = _uniform_moments(particles)
    mean_residual = tf.reduce_max(tf.abs(output_mean - target_mean))
    covariance_residual = tf.reduce_max(tf.abs(output_covariance - target_covariance))
    valid = tf.reduce_all(tf.math.is_finite(particles)) & tf.math.is_finite(mean_residual) & tf.math.is_finite(covariance_residual) & (mean_residual <= tf.cast(0.0005, source.dtype)) & (covariance_residual <= tf.cast(0.005, source.dtype))
    return {'particles': particles, 'valid': valid, 'mean_residual': mean_residual, 'covariance_residual': covariance_residual, 'maximum_pairwise_pre_cap_particle_rms': maximum_pre_cap_rms, 'maximum_pairwise_post_cap_particle_rms': maximum_post_cap_rms, 'minimum_pairwise_particle_cap_scale': minimum_radial_scale, 'maximum_coordinatewise_pre_cap_absolute': tf.reduce_max(tf.abs(pre_coordinate_cap)), 'maximum_coordinatewise_post_cap_absolute': tf.reduce_max(tf.abs(capped)), 'mean_coordinatewise_cap_displacement': tf.reduce_mean(tf.abs(capped - pre_coordinate_cap)), 'fraction_coordinatewise_cap_active': tf.reduce_mean(tf.cast(tf.abs(capped - pre_coordinate_cap) > 1e-07, source.dtype)), 'minimum_coordinatewise_cap_derivative': tf.reduce_min(cap_derivative), 'diagnostic_pre_cap': pre_coordinate_cap, 'diagnostic_scaled_power': scaled_power, 'diagnostic_denominator': denominator, 'diagnostic_capped': capped, 'diagnostic_cap': cap, 'diagnostic_power': power, 'diagnostic_displacement': tf.abs(capped - pre_coordinate_cap), 'diagnostic_active': tf.abs(capped - pre_coordinate_cap) > 1e-07, 'diagnostic_threshold': tf.cast(1e-07, source.dtype)}
