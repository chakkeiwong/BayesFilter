"""HMC preparation stages, historical orchestration and compatibility readers.

Public tuners live in hmc_tuning_dispatch and use the shared candidate-set
controller. Initial geometry, bootstrap screening and windowed preparation live
in hmc_geometry, hmc_bootstrap and hmc_mass_adaptation. Imports here preserve
historical callers and serialized names. Presets and configuration translation
are implemented in hmc_configuration.
The retained Phase 5--8 selectors and single-kernel wrappers are historical
helpers, not independent public tuning authorities.
"""

from __future__ import annotations

import array
import dataclasses
import hashlib
import inspect
import json
import math
import os
import struct
import sys
import threading
import time
import uuid
import zipfile
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from numbers import Integral
from pathlib import Path
from typing import Any, Mapping

from bayesfilter.inference.hmc_preparation_common import (
    _validate_band,
    _validate_seed,
    _validate_step_repair_multiplier,
    _string_tuple,
    _mass_artifact_signature,
    _round_seed,
    _scalar_or_none,
    _seed_from_mapping,
    _bool_or_none,
    _int_or_none,
    _json_ready,
    _runtime_seconds_or_none,
    _telemetry_payload,
    _finite_number,
)

from bayesfilter.inference.hmc_bootstrap import (
    BOOTSTRAP_SCREEN_NONCLAIMS,
    RunFullChainFn,
    BootstrapProgressCallback,
    PrivateTuningDiagnosticCallback,
    _G2_BOOTSTRAP_ROUND_SEED_DERIVATION_SITE_ID,
    _G2_BOOTSTRAP_ROUND_SEED_GATE_SITE_ID,
    _G2_BOOTSTRAP_ROUND_SEED_INTERFACE_HOPS,
    HMCBootstrapScreenConfig,
    HMCBootstrapRepairRound,
    HMCBootstrapScreenResult,
    _BootstrapFixedMassLatentValueScoreAdapter,
    _build_bootstrap_fixed_mass_adapter,
    run_hmc_bootstrap_screen,
    _bootstrap_selected_kernel_payload,
    _bootstrap_acceptance_relation,
    _bootstrap_diagnostics_payload,
    _bootstrap_error_diagnostics,
    _bootstrap_leapfrog_payload,
    _bootstrap_repair_action,
    _bootstrap_repair_makes_effective_progress,
    _bootstrap_reusable_static_contract_payload,
    _bootstrap_screen_config,
    _bootstrap_update_repair_bracket,
    _classify_bootstrap_screen,
    _public_bootstrap_hard_veto_category,
    _repair_step_size,
    _resolve_bootstrap_target_scope,
    _validate_bootstrap_repair_bracket,
)

from bayesfilter.inference.hmc_geometry import (
    GEOMETRY_INITIALIZATION_NONCLAIMS,
    HMCGeometryInitializationConfig,
    HMCGeometryInitializationResult,
    _GEOMETRY_MAX_LEAPFROG,
    _GEOMETRY_MIN_LEAPFROG,
    _GeometryHint,
    _build_mass_artifact,
    _curvature_frequencies,
    _curvature_median,
    _curvature_report,
    _derive_seed,
    _hint_from_value,
    _identity_hint,
    _initial_step_size,
    _select_geometry_hint,
    _target_trajectory_length,
    _validate_matrix,
    _validate_max_leapfrog_steps,
    _validate_position,
    _validate_spd,
    initialize_hmc_kernel_geometry,
)

from bayesfilter.inference.batched_value_score import (
    _call_mapping_with_batch_rank_bridge,
    _call_value_score_with_batch_rank_bridge,
)

from bayesfilter.hmc_route_contract import (
    HMC_TOP_LEVEL_SELECTION_STAGE,
    HMC_WINDOWED_MASS_STAGE,
    LEGACY_JOINT_L_EPSILON_ALGORITHM_ID,
    LEGACY_OPERATIONAL_FIXED_TRAJECTORY_ALGORITHM_ID,
    LEGACY_SEGMENTED_WINDOWED_MASS_ALGORITHM_ID,
    ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID,
    OPERATIONAL_WINDOWED_WARMUP_ALGORITHM_ID,
    HMCAlgorithmRouteDecision,
    require_hmc_artifact_authority_route,
    require_hmc_algorithm_route,
    windowed_algorithm_for_selection_algorithm,
)
from bayesfilter.hmc_ordinary_selection_policy import (
    ORDINARY_BROAD_FIXED_METRIC_POLICY_ID,
    ORDINARY_BROAD_MAX_LEAPFROG_STEPS,
    ORDINARY_BROAD_PRIMARY_L_GRID,
    ordinary_broad_refinement_l_values,
)
from bayesfilter.hmc_budget_contract import (
    BROAD_FIXED_METRIC_OPERATIONAL_ROUTE,
    HMCOperationalStatisticalWorkPolicy,
    JOINT_L_EPSILON_OPERATIONAL_ROUTE,
    OPERATIONAL_HMC_BUDGET_POLICY_ID,
    build_private_resolved_hmc_work_manifest,
    build_public_hmc_work_manifest,
    joint_l_epsilon_grid_work_bound,
    reconcile_executed_hmc_work,
    validate_executed_hmc_work_reconciliation,
    validate_private_resolved_hmc_work_manifest,
    validate_public_hmc_work_manifest,
)
from bayesfilter.inference.hmc import (
    FixedSizeHMCChunkConfig,
    FixedSizeHMCChunkRunResult,
    FullChainHMCConfig,
    FullChainHMCRunResult,
    PrecomputedMassArtifact,
    SequentialRHatCheckpointWriterConfig,
    SequentialRHatHMCVerificationConfig,
    assert_sequential_rhat_checkpoint_public_reference_safe,
    build_fixed_size_hmc_chunk_runner,
    build_reusable_full_chain_tfp_hmc_runner,
    build_sequential_rhat_hmc_verifier,
    program_signature,
    run_full_chain_tfp_hmc,
    stable_adapter_signature,
    write_sequential_rhat_boundary_handoff_checkpoint,
    write_sequential_rhat_pre_verification_handoff_checkpoint,
)
from bayesfilter.inference.hmc_artifact_identity import mass_artifact_signature
from bayesfilter.inference.hmc_diagnostics import screen_hmc_diagnostics
from bayesfilter.inference.hmc_budget_ladder import (
    FixedMassHMCTuningBudgetCallbackResult,
    FixedMassHMCTuningBudgetLadderConfig,
    FixedMassHMCTuningBudgetLadderResult,
    _build_fixed_mass_hmc_adapter,
    run_fixed_mass_hmc_tuning_budget_ladder,
)
from bayesfilter.inference.hmc_tuning import (
    HMCTuningPolicy,
    WindowedMassAdaptationConfig,
    WindowedMassAdaptationResult,
    run_windowed_mass_adaptation_diagnostic,
)
from bayesfilter.inference.hmc_coordinates import (
    AffineCoordinateTransform,
    WarmupTrajectoryPolicy,
    transform_from_precomputed_mass_artifact,
)
from bayesfilter.inference.hmc_warmup import (
    G2PreboundarySeedUseRegistry,
    OPERATIONAL_WARMUP_NONCLAIMS,
    OperationalWindowedWarmupCloseout,
    OperationalWindowedWarmupResult,
    PHASE7_ENGINEERING_PROBE_BANK_POLICY_ID,
    Phase7EngineeringProbeBankConfig,
    _G2_BOOTSTRAP_ROUND_SEED_INTERFACE_HOPS_CONTRACT,
    _G2P4BoundaryActionTracker,
    _G2SeedRegistryError,
    _G2_PREBOUNDARY_SHARED_INVALIDITY_ATTRIBUTE,
    _G2_SEED_GATE_SEMANTIC_CONTRACTS,
    _G2_WINDOWED_STAGE_SEED_INTERFACE_HOPS_CONTRACT,
    _PHASE7_ENGINEERING_PROBE_DIAGNOSTIC_ATTRIBUTE,
    _compose_base_transform_with_nested_estimate,
    _phase7_engineering_probe_target_signature,
    compose_operational_transform_in_base_coordinates,
    engineering_probe_bank_qualification_payload_from_exception,
    g2_preboundary_shared_invalidity_exception,
    g2_preboundary_shared_invalidity_payload_from_exception,
    g2_seed_private_evidence_from_exception,
    run_operational_windowed_warmup,
    start_bank_qualification_payload_from_exception,
    _base_adapter_signature,
    _validate_start_bank_qualification_payload,
)

from bayesfilter.inference.hmc_verification import (
    HMCAcceptanceEvidence,
    HMCAcceptancePolicy,
    _all_close,
    _all_finite,
    _float64_tensor,
    _is_boolean_scalar,
    evaluate_hmc_acceptance_evidence,
    hmc_acceptance_evidence_from_payload,
)
from bayesfilter.inference.hmc_kernel_selection import (
    BoundedFixedTrajectorySelectionResult,
    FixedTrajectorySelection,
    candidate_handoff_policy_payload,
    paired_candidate_seed,
    private_start_bank_content_signature,
    run_bounded_operational_fixed_trajectory_selection,
)
from bayesfilter.inference.hmc_tuning_state import (
    aggregate_bracketed_step_repair,
    aggregate_step_repair,
)
from bayesfilter.inference.posterior_adapter import (
    ValueScoreCapability,
    value_score_capability,
)
from bayesfilter.inference.tuning_contract import (
    HMC_TUNING_ORDINARY_RHAT_THRESHOLD,
    HMCTuningRunnerBinding,
)
from bayesfilter.runtime import stable_config_hash
from bayesfilter.inference.hmc_tuning_checkpoint import HMCTuningCampaignCheckpoint

from bayesfilter.inference.hmc_configuration import (
    _OPERATIONAL_EVIDENCE_POLICY_INITIAL_ONLY,
    _OPERATIONAL_EVIDENCE_POLICY_ONE_DOUBLING,
    _OPERATIONAL_EVIDENCE_POLICIES,
    _OPERATIONAL_CANDIDATE_HANDOFF_POLICY_STRICT,
    _OPERATIONAL_CANDIDATE_HANDOFF_POLICY_SCHEMA,
    _OPERATIONAL_VERIFICATION_BRACKET_POLICY_SINGLE_REPAIR,
    _OPERATIONAL_VERIFICATION_BRACKET_POLICY_ONE_LOG_MIDPOINT,
    _OPERATIONAL_VERIFICATION_BRACKET_POLICIES,
    ORDINARY_SHARED_EPSILON_SCREEN_POLICY_ID,
    ORDINARY_LEGACY_JOINT_L_EPSILON_POLICY_ID,
    ORDINARY_ENGINEERING_JOINT_L_EPSILON_POLICY_ID,
    _ORDINARY_RUNTIME_BACKEND_POLICY_ID,
    _PHASE7_MAX_ATTEMPTS_CAP,
    _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE,
    _HANDOFF_SCREEN_POLICIES,
    _PUBLIC_TERMINAL_PHASE6_REPAIR_SCREEN_MAX_RESULTS,
    _HANDOFF_SCREEN_POLICY_PHASE23_NOMINATION_ONLY,
    resolve_ordinary_hmc_selection_policy,
    _ordinary_selection_policy_payload,
    _validated_operational_verification_bracket_policy,
    _operational_verification_starts_per_outer_attempt,
    _validated_operational_candidate_handoff_policy,
    HMCGeometryScaledBudgetTimingPolicy,
    _geometry_scaled_budget_timing_policy,
    _geometry_policy_eigenvalues,
    _geometry_policy_condition_number,
    _geometry_policy_effective_dimension,
    _geometry_policy_regularization_counts,
    _attempt_budget_policy_from_payload,
    _validate_handoff_screen_policy,
    _validate_trajectory_window_multiplier,
    _validate_trajectory_window_multipliers,
    _validate_positive_int_or_none,
    HMCTuneVerifyRepairLoopConfig,
    HMCKernelTuningConfig,
    _public_tuning_forbidden_fields,
    _public_tuning_preset_role,
    _public_geometry_config,
    _public_bootstrap_config,
    _public_loop_config,
    _public_budget_policy_factory,
    _HMCAttemptBudgetPolicy,
    _default_attempt_budget_policy,
    _phase7_attempt_seed,
    _staged_timeout_stage_budget,
    _phase7_windowed_stage_config,
    _fixed_mass_step_upper_bound,
)


from bayesfilter.inference.hmc_mass_adaptation import (
    _G2_WINDOWED_STAGE_SEED_DERIVATION_SITE_ID,
    _G2_WINDOWED_STAGE_SEED_GATE_SITE_ID,
    _G2_WINDOWED_STAGE_SEED_INTERFACE_HOPS,
    _OPERATIONAL_WARMUP_DEFAULT_REUSABLE_RUNNER_BUILDER,
    _METRIC_UPDATE_REQUIREMENTS,
    _NO_OPERATIONAL_METRIC_UPDATE_REPAIR_TRIGGER,
    _ENGINEERING_PROBE_BOUNDARY_PUBLIC_KEYS,
    WINDOWED_MASS_STAGE_NONCLAIMS,
    FIXED_MASS_STEP_STAGE_NONCLAIMS,
    TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    STAGED_TIMEOUT_POLICY_STAGE_NAMES,
    _WINDOWED_STAGE_API_DISCARD_STEPS,
    _FIXED_MASS_STAGE_TUNE_NUM_RESULTS,
    _WINDOWED_MASS_PUBLIC_TIMEOUT_RESERVE_S,
    _WINDOWED_MASS_PUBLIC_TIMEOUT_RESOURCE_STATUS,
    _WINDOWED_MASS_PUBLIC_TIMEOUT_RESOURCE_ROLE,
    _WINDOWED_MASS_PUBLIC_TIMEOUT_REPAIR_TRIGGER,
    _WINDOWED_MASS_SEGMENT_SIZE,
    _OPERATIONAL_WARMUP_SEGMENT_SIZE,
    _WINDOWED_MASS_SEGMENT_SOFT_DEADLINE_SAFETY_MULTIPLIER,
    _WINDOWED_MASS_SEGMENT_SOFT_DEADLINE_RECENT_WINDOW,
    LoopProgressCallback,
    _validate_metric_update_requirement,
    _validate_engineering_probe_covariance_multiplier,
    _engineering_probe_config_public_payload,
    _engineering_probe_seed_signature,
    _engineering_probe_seed_public_payload,
    _engineering_probe_seed_report_public_payload,
    _engineering_probe_diagnostic_config_public_payload,
    _engineering_probe_windowed_config_public_payload,
    _engineering_probe_windowed_mass_result_public_payload,
    _engineering_probe_operational_closeout_public_payload,
    _engineering_probe_timeout_diagnostics_public_payload,
    _engineering_probe_stage_diagnostics_public_payload,
    _engineering_probe_reasonable_epsilon_public_payload,
    _engineering_probe_operational_window_public_payload,
    _engineering_probe_operational_warmup_public_payload,
    HMCStagedTimeoutPolicy,
    _default_staged_timeout_policy_stage_budgets,
    _default_staged_timeout_policy_stage_budget_provenance,
    _validate_staged_timeout_policy_or_none,
    _validate_nonnegative_perf_counter_or_none,
    _validate_staged_timeout_enlargement_rounds,
    _bootstrap_geometry_preflight_kernel_payload,
    _bootstrap_hard_vetoes,
    _bootstrap_preflight_passed,
    _active_bootstrap_handoff_kernel_payload,
    _active_bootstrap_handoff_kernel_hash,
    _phase7_windowed_mass_seed_kernel_payload,
    HMCWindowedMassStageConfig,
    HMCWindowedMassStageResult,
    _operational_windowed_mass_capture,
    _run_p4_windowed_boundary_attempt,
    run_hmc_windowed_mass_stage,
    _resolve_windowed_stage_target_scope,
    _validate_windowed_stage_inputs,
    _emit_windowed_mass_progress,
    _staged_timeout_round,
    _staged_timeout_public_state,
    _staged_timeout_public_payload_for_config,
    _windowed_mass_public_timeout_state,
    _windowed_mass_public_timeout_preflight,
    _windowed_mass_next_segment_soft_deadline_preflight,
    _phase4_latent_adapter_for_step_stage,
    _phase4_adapted_mass_artifact,
    _phase7_verification_runtime_context,
    _phase7_verification_initial_state,
    build_operational_fixed_mass_hmc_adapter,
    _windowed_mass_stage_internal_config,
    _windowed_stage_initial_mass_artifact,
    _windowed_stage_draw_capture_policy,
    _windowed_stage_diagnostic_run_config,
    _windowed_stage_chunk_run_config,
    _windowed_stage_valid_rows,
    _windowed_stage_acceptance_capture,
    _windowed_stage_per_draw_trace,
    _windowed_stage_segmented_capture_payload,
    _windowed_stage_capture_payload,
    _with_windowed_stage_timing_metadata,
    _windowed_stage_public_timeout_capture,
    _windowed_stage_error_capture,
    _p4_boundary_scalar_capture,
    _p4_unavailable_invalidity_payload,
    _p4_boundary_capture_from_exception,
    _classify_windowed_stage_capture,
    _valid_draw_matrix,
    _valid_trace_vector,
    _acceptance_trace_is_default_like,
    _windowed_stage_acceptance_has_runtime_decision_support,
    _windowed_stage_acceptance_policy_filled_or_default,
    _windowed_stage_runtime_evidence,
    _metadata_marks_fixture_or_synthetic,
    _windowed_stage_diagnostics,
    _warmup_draw_provenance,
    _acceptance_telemetry_provenance,
    _ceil_div,
    _tensor_to_numpy,
    _trace_array_or_none,
)



_G2_PUBLIC_P4_SOURCE_COVERAGE_SCHEMA = (
    "bayesfilter.hmc_g2_public_p4_runtime_source_coverage.v1"
)
_G2_SOURCE_FILE_BY_SITE_PREFIX = {
    "hmc": "hmc.py",
    "hmc_coordinates": "hmc_coordinates.py",
    "hmc_kernel_tuning": "hmc_kernel_tuning.py",
    "hmc_warmup": "hmc_warmup.py",
}
_G2_REGISTRY_KEY_TEMPLATES = {
    "hmc_warmup.run_operational_windowed_warmup.initial_epsilon_seed_gate.v1": (
        "operational_warmup/reasonable_epsilon/initial"
    ),
    "hmc_warmup.run_operational_windowed_warmup.segment_seed_gate.v1": (
        "operational_warmup/window/<window>/segment/<segment>"
    ),
    "hmc_warmup.run_operational_windowed_warmup.metric_seed_gate.v1": (
        "operational_warmup/metric_boundary/<window>"
    ),
    "hmc_warmup.find_reasonable_epsilon.proposal_seed_gate.v2": (
        "operational_warmup/<context>/<index>/proposal/<proposal>"
    ),
    "hmc_warmup.build_phase7_engineering_probe_bank.p4_seed_gate.v1": (
        "p4/engineering_probe"
    ),
    _G2_BOOTSTRAP_ROUND_SEED_GATE_SITE_ID: "bootstrap/round/<round>",
    _G2_WINDOWED_STAGE_SEED_GATE_SITE_ID: "phase4/stage",
}





def _g2_source_file_for_site(site_id: str) -> str:
    if str(site_id).startswith((
        "hmc_kernel_tuning.run_hmc_bootstrap_screen.",
        "hmc_kernel_tuning._bootstrap_screen_config.",
    )):
        return "hmc_bootstrap.py"
    if str(site_id).startswith((
        "hmc_kernel_tuning._run_p4_windowed_boundary_attempt.",
        "hmc_kernel_tuning._windowed_stage_diagnostic_run_config.",
        "hmc_kernel_tuning._operational_windowed_mass_capture.",
    )):
        return "hmc_mass_adaptation.py"
    prefix = str(site_id).split(".", 1)[0]
    try:
        return _G2_SOURCE_FILE_BY_SITE_PREFIX[prefix]
    except KeyError as exc:
        raise ValueError(f"unknown G2 source-site prefix: {prefix}") from exc


def _public_p4_seed_source_coverage_payload() -> Mapping[str, Any]:
    """Bind the public P4-E registry to its complete active source closure."""

    contracts: dict[str, Mapping[str, Any]] = {}
    source_filenames: set[str] = set()
    for gate_id, semantic in sorted(_G2_SEED_GATE_SEMANTIC_CONTRACTS.items()):
        derivation_id = str(semantic["derivation_site_id"])
        owner_file = str(semantic["owner_file"])
        source_filenames.add(owner_file)
        owner_source = f"bayesfilter/inference/{owner_file}"
        contracts[derivation_id] = {
            "site_id": derivation_id,
            "source_path": owner_source,
            "owner_qualname": str(semantic["derivation_owner_qualname"]),
            "site_kind": "derivation",
            "terminal_consumer": None,
            "registry_key_template": None,
            "upstream_gate_site_id": None,
        }
        contracts[gate_id] = {
            "site_id": gate_id,
            "source_path": owner_source,
            "owner_qualname": str(semantic["owner_qualname"]),
            "site_kind": "terminal_consumption_gate",
            "terminal_consumer": str(semantic["terminal_consumer"]),
            "registry_key_template": _G2_REGISTRY_KEY_TEMPLATES[gate_id],
            "upstream_gate_site_id": None,
        }
        for hop_id in semantic["interface_hop_site_ids"]:
            hop_file = _g2_source_file_for_site(str(hop_id))
            source_filenames.add(hop_file)
            contracts[str(hop_id)] = {
                "site_id": str(hop_id),
                "source_path": f"bayesfilter/inference/{hop_file}",
                "owner_qualname": "read_only_seed_pass_through",
                "site_kind": "read_only_pass_through",
                "terminal_consumer": None,
                "registry_key_template": None,
                "upstream_gate_site_id": gate_id,
            }
    if set(contracts) != {
        str(site_id)
        for semantic in _G2_SEED_GATE_SEMANTIC_CONTRACTS.values()
        for site_id in (
            semantic["derivation_site_id"],
            *semantic["interface_hop_site_ids"],
        )
    } | set(_G2_SEED_GATE_SEMANTIC_CONTRACTS):
        raise RuntimeError("public P4 source coverage is incomplete")
    source_root = Path(__file__).resolve().parent
    source_files = tuple(
        {
            "path": f"bayesfilter/inference/{filename}",
            "sha256": hashlib.sha256((source_root / filename).read_bytes()).hexdigest(),
        }
        for filename in sorted(source_filenames)
    )
    return {
        "schema": _G2_PUBLIC_P4_SOURCE_COVERAGE_SCHEMA,
        "source_files": source_files,
        "source_site_contracts": {
            site_id: contracts[site_id] for site_id in sorted(contracts)
        },
    }


def _build_public_p4_seed_use_registry() -> G2PreboundarySeedUseRegistry:
    coverage = _public_p4_seed_source_coverage_payload()
    encoded = json.dumps(
        coverage,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
    return G2PreboundarySeedUseRegistry(
        source_coverage_artifact_sha256=hashlib.sha256(encoded).hexdigest(),
        source_site_contracts=coverage["source_site_contracts"],
    )


_OPERATIONAL_CANDIDATE_HANDOFF_POLICY_MIXED = (
    "mixed_evidence_requires_fresh_verification"
)
_OPERATIONAL_CANDIDATE_HANDOFF_POLICY_CANDIDATE_LOCAL_MIXED = (
    "candidate_local_mixed_evidence_requires_fresh_verification"
)

# These identifiers describe executable epsilon/L policies.  The broad policy
# is the sole public ordinary policy.  The remaining identifiers are retained
# only to classify historical and lower-level diagnostic payloads.
_ORDINARY_RUNTIME_NUMPY_POLICY_BLOCKER = (
    "ordinary_runtime_numpy_policy_pending"
)


_PHASE5_CANDIDATE_HANDOFF_NONCLAIMS = (
    "private Phase 5 candidate handoff only",
    "verification order is scheduling metadata only",
    "no Phase 7 verification claim",
    "no posterior convergence claim",
    "no sampler superiority claim",
    "no default-readiness claim",
    "no GPU or XLA readiness claim",
)

_PHASE7_FIXED_KERNEL_VERIFICATION_NONCLAIMS = (
    "private Phase 7 fixed-kernel verification handoff only",
    "verification is a kernel handoff screen only",
    "no posterior convergence claim",
    "no sampler superiority claim",
    "no default-readiness claim",
    "no GPU or XLA readiness claim",
)

_PHASE7_DIRECT_CANDIDATE_SEED_POLICY = (
    "bayesfilter.phase7_direct_candidate_seed.v1"
)
_PHASE7_HISTORICAL_PHASE6_SEED_POLICY = (
    "bayesfilter.phase7_historical_phase6_seed.v1"
)
_PHASE7_OPERATIONAL_SELECTION_SEED_POLICY = (
    "bayesfilter.phase7_operational_selection_verification_seed.v2"
)
_PHASE7_OPERATIONAL_REPAIR_SEED_POLICY = (
    "bayesfilter.phase7_operational_repair_verification_seed.v2"
)
_PHASE7_OPERATIONAL_BRACKET_MIDPOINT_SEED_POLICY = (
    "bayesfilter.phase7_operational_bracket_midpoint_verification_seed.v1"
)
_PHASE7_OPERATIONAL_EVIDENCE_EXTENSION_SEED_POLICY = (
    "bayesfilter.phase7_operational_evidence_extension_seed.v2"
)
_PHASE5_BROAD_FIXED_METRIC_ALGORITHM = ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID
_PHASE5_JOINT_L_EPSILON_ALGORITHM = LEGACY_JOINT_L_EPSILON_ALGORITHM_ID
_PHASE5_DIRECT_GRID_ALGORITHMS = frozenset(
    {
        _PHASE5_BROAD_FIXED_METRIC_ALGORITHM,
        _PHASE5_JOINT_L_EPSILON_ALGORITHM,
    }
)
_PHASE7_DIRECT_QUEUE_MAX_STARTS = 2

FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS = (
    "selected Phase 5 epsilon/L-pair handoff screen only",
    "phase 4 adapted mass is frozen during handoff screening",
    "phase 5 selected step and leapfrog count are frozen during handoff screening",
    "does not perform a second frozen-epsilon leapfrog search after direct Phase 5 selection",
    "not fresh final verification",
    "no posterior convergence claim",
    "no sampler superiority claim",
    "no default-readiness claim",
    "no GPU or XLA readiness claim",
)


HMC_KERNEL_TUNING_PUBLIC_NONCLAIMS = (
    "BayesFilter one-call HMC kernel tuning only",
    "final frozen kernel is a handoff artifact only",
    "tuning screens do not establish posterior convergence",
    "no posterior convergence claim",
    "no sampler superiority claim",
    "no default-readiness claim",
    "no external-client scientific claim",
    "no GPU readiness claim",
    "XLA execution, when requested, is runtime selection only",
)

HMC_START_BANK_DIAGNOSTIC_NONCLAIMS = (
    "discarded start-bank diagnostic only",
    "qualification scalars are explanatory only",
    "no mass-matrix handoff claim",
    "no fixed-mass step tuning claim",
    "no trajectory tuning claim",
    "no final-kernel claim",
    "no retained-sampling claim",
    "no posterior convergence claim",
    "no sampler superiority claim",
    "no default-readiness claim",
    "no GPU or XLA readiness claim",
)





def _default_staged_timeout_policy() -> HMCStagedTimeoutPolicy:
    return HMCGeometryScaledBudgetTimingPolicy().staged_timeout_policy()


RETAINED_FROZEN_KERNEL_REPLAY_NONCLAIMS = (
    "BayesFilter retained frozen-kernel adapter reconstruction only",
    "replays a previously verified adapter stack without running HMC",
    "no posterior convergence claim",
    "no sampler superiority claim",
    "no default-readiness claim",
    "no external-client scientific claim",
    "no GPU or XLA readiness claim",
)

REPLAY_ROLE_MECHANICS_ONLY = "mechanics_only"
REPLAY_ROLE_CLAIM_BEARING_RETAINED = "claim_bearing_retained"

_FIXED_MASS_STAGE_TEST_BUDGET_SCHEDULE = (3, 6, 12)
_FIXED_MASS_STAGE_SCREEN_NUM_RESULTS = 4
_FIXED_MASS_STAGE_SCREEN_BURNIN_STEPS = 1
_FROZEN_STEP_TRAJECTORY_CANDIDATE_OFFSETS = (-2, -1, 0, 1, 2)
_FROZEN_STEP_TRAJECTORY_CENTER_SLACK = 10
_FROZEN_STEP_TRAJECTORY_REPAIR_NEIGHBORHOOD_OFFSETS = (-4, -3, -2, -1, 0, 1, 2, 3, 4)
_JOINT_L_EPSILON_INITIAL_OFFSETS = (-4, -2, -1, 0, 1, 2, 4)
_JOINT_L_EPSILON_FINAL_LOCAL_OFFSETS = (-2, -1, 0, 1, 2)
_JOINT_L_EPSILON_MAX_EDGE_REPAIR_ROUNDS = 2
_FROZEN_STEP_TRAJECTORY_ORDER_ASCENDING = "ascending_clamped_l"
_FROZEN_STEP_TRAJECTORY_ORDER_HIGH_ACCEPTANCE_REPAIR = (
    "directional_high_acceptance_prioritize_longer_in_window"
)
_FROZEN_STEP_TRAJECTORY_ORDER_LOW_ACCEPTANCE_REPAIR = (
    "directional_low_acceptance_prioritize_shorter_in_window"
)
_FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RESERVE_S = 60.0
_PHASE7_PUBLIC_TIMEOUT_BEFORE_WINDOWED_MASS_HARD_VETO = (
    "phase7_public_timeout_before_windowed_mass"
)
_PHASE7_PUBLIC_TIMEOUT_BEFORE_WINDOWED_MASS_REPAIR_TRIGGER = (
    "phase7_public_timeout_before_windowed_mass"
)
_PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO = (
    "phase7_public_timeout_before_windowed_mass"
)
_PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_REPAIR_TRIGGER = (
    "phase7_public_timeout_before_windowed_mass"
)
_FIXED_MASS_STEP_PUBLIC_TIMEOUT_HARD_VETO = (
    "fixed_mass_step_public_timeout_soft_deadline"
)
_FIXED_MASS_STEP_PUBLIC_TIMEOUT_REPAIR_TRIGGER = (
    "fixed_mass_step_public_timeout_closeout_before_next_candidate"
)
_FIXED_MASS_STEP_PUBLIC_TIMEOUT_BUDGET_INCOMPLETE_ROLE = (
    "fixed_mass_step_budget_incomplete_non_promoting"
)
_FIXED_MASS_STEP_PUBLIC_TIMEOUT_BUDGET_INCOMPLETE_REPAIR_TRIGGER = (
    "fixed_mass_step_budget_incomplete_after_selected_pair_progress"
)
_FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_SAFETY_MULTIPLIER = 1.25
_FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RECENT_WINDOW = 3
_FIXED_MASS_STEP_SOFT_DEADLINE_SAFETY_MULTIPLIER = 1.25
_FIXED_MASS_STEP_SOFT_DEADLINE_RECENT_WINDOW = 3
_FROZEN_STEP_TRAJECTORY_SCREEN_NUM_RESULTS = 4
_FROZEN_STEP_TRAJECTORY_SCREEN_BURNIN_STEPS = 1
_SERIOUS_TUNING_MIN_RUN_BUDGET = 1000
_SERIOUS_TUNING_DIMENSION_FACTOR = 20
_SERIOUS_TUNING_MAX_INITIAL_BUDGET = 5000
_SERIOUS_TUNING_MAX_TUNE_BUDGET = 10000
_PHASE7_BASE_MAX_ATTEMPTS = 5
_PHASE7_EXTENDED_ATTEMPT_STALLED = (
    "phase7_extended_attempt_stalled_no_meaningful_progress"
)
_PUBLIC_TUNING_PROGRESS_FILENAME = "hmc_kernel_tuning_progress.json"
_PHASE7_VERIFICATION_ACCEPTANCE_BUDGET_BLOCKED = (
    "verification_acceptance_budget_blocked"
)
_PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER = (
    "phase6_trajectory_acceptance_outside_pass_band"
)
_PHASE6_HANDOFF_SCREEN_POLICY_ROLE = "handoff_screen_repair_trigger_non_promoting"
_TRAJECTORY_WINDOW_POLICY_ROLE = "engineering_viability_gate_non_scientific"
_PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER = (
    "verification_acceptance_outside_pass_band"
)
_PHASE7_VERIFY_ONLY_BUDGET_SATURATED = (
    "verification_only_rhat_cap_budget_saturated_no_repair_slot"
)
_PHASE7_REPAIR_HANDOFF_BUDGET_EXHAUSTED = (
    "phase7_repair_handoff_budget_exhausted_no_attempt_slot"
)
_PHASE7_TERMINAL_PHASE6_REPAIR_SLOT_EXHAUSTED = (
    "phase7_terminal_phase6_repair_slot_exhausted"
)
_PHASE7_VERIFICATION_ACCEPTANCE_RETRY_PRE_PHASE6_MIN_RESERVES = 1.0






def _phase23_nomination_policy_active(policy: str) -> bool:
    return str(policy) == _HANDOFF_SCREEN_POLICY_PHASE23_NOMINATION_ONLY


def _trajectory_window_class_penalty(relation: Any) -> int:
    relation_name = str(relation)
    if relation_name == "inside_trajectory_window":
        return 0
    if relation_name in {"below_trajectory_window", "above_trajectory_window"}:
        return 1
    return 2






def _trajectory_window_bounds(
    target_trajectory: float,
    *,
    lower_multiplier: float,
    upper_multiplier: float,
) -> tuple[float, float]:
    target = float(target_trajectory)
    if not math.isfinite(target) or target <= 0.0:
        raise ValueError("target trajectory length must be positive and finite")
    lower, upper = _validate_trajectory_window_multipliers(
        lower_multiplier,
        upper_multiplier,
    )
    return target * lower, target * upper


def _trajectory_window_relation(
    trajectory_length: float,
    *,
    tau_min: float,
    tau_max: float,
) -> str:
    tau = float(trajectory_length)
    if not math.isfinite(tau) or tau <= 0.0:
        return "invalid_trajectory_length"
    lower = float(tau_min)
    upper = float(tau_max)
    if tau < lower:
        return "below_trajectory_window"
    if tau > upper:
        return "above_trajectory_window"
    return "inside_trajectory_window"


def _trajectory_window_payload(
    *,
    step_size: float,
    num_leapfrog_steps: int,
    target_trajectory_length: float,
    lower_multiplier: float,
    upper_multiplier: float,
    max_leapfrog_steps: int,
) -> Mapping[str, Any]:
    step = float(step_size)
    leapfrog = int(num_leapfrog_steps)
    if not math.isfinite(step) or step <= 0.0:
        raise ValueError("trajectory window step_size must be positive and finite")
    if leapfrog <= 0:
        raise ValueError("trajectory window num_leapfrog_steps must be positive")
    max_l = _validate_max_leapfrog_steps(max_leapfrog_steps)
    tau_min, tau_max = _trajectory_window_bounds(
        float(target_trajectory_length),
        lower_multiplier=float(lower_multiplier),
        upper_multiplier=float(upper_multiplier),
    )
    tau = step * leapfrog
    relation = _trajectory_window_relation(tau, tau_min=tau_min, tau_max=tau_max)
    return {
        "trajectory_length": tau,
        "trajectory_window": (tau_min, tau_max),
        "trajectory_window_lower_multiplier": float(lower_multiplier),
        "trajectory_window_upper_multiplier": float(upper_multiplier),
        "trajectory_window_relation": relation,
        "trajectory_target_ratio": tau / float(target_trajectory_length),
        "minimum_step_size_for_tau_floor": tau_min / max_l,
        "max_leapfrog_steps": max_l,
        "leapfrog_at_max": leapfrog == max_l,
        "leapfrog_exceeds_max": leapfrog > max_l,
        "required_leapfrog_for_tau_floor": math.ceil(tau_min / step),
        "tau_floor_feasible_at_step": math.ceil(tau_min / step) <= max_l,
    }

FixedMassScreenCallback = Callable[
    [Mapping[str, Any], Any, Mapping[str, Any]],
    Any,
]
TrajectoryScreenCallback = Callable[[Mapping[str, Any], Any, Mapping[str, Any]], Any]
VerificationCallback = Callable[[Mapping[str, Any], Any, Mapping[str, Any]], Any]




def _bootstrap_repair_triggers(bootstrap: "HMCBootstrapScreenResult") -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            str(trigger)
            for round_result in bootstrap.rounds
            for trigger in round_result.repair_triggers
        )
    )


@dataclass(frozen=True)
class HMCFixedMassStepStageConfig:
    """Policy-level config for Phase 5 fixed-mass step tuning.

    ``algorithm_id`` carries the already selected top-level route into Phase 5;
    it does not let a caller supply a grid. The caller does not supply the
    budget schedule, tune/screen draw counts, burn-in counts, step size,
    leapfrog count, trajectory grid, or candidate grid. Phase 5 owns those
    mechanics and records them in the result.
    """

    algorithm_id: str = ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID
    target_accept_prob: float = 0.70
    acceptance_band: tuple[float, float] = (0.65, 0.75)
    repair_band: tuple[float, float] = (0.55, 0.85)
    step_repair_factor: float = 2.0
    step_repair_min_directional_factor: float = 1.25
    step_repair_high_acceptance_directional_factor: float | None = None
    step_repair_high_acceptance_ladder_max_factor: float | None = None
    repair_nonfinite_proposal_screen: bool = False
    trajectory_window_lower_multiplier: float = 0.3
    trajectory_window_upper_multiplier: float = 3.0
    handoff_screen_policy: str = _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE
    seed: tuple[int, int] = (20260621, 5)
    chain_execution_mode: str = "tf_function"
    use_xla: bool = False
    target_scope: str | None = None
    target_status_trace_policy: str = "none"
    mass_policy: str = "windowed_adaptive"
    public_timeout_budget_s: float | None = None
    public_timeout_started_perf_counter_s: float | None = None
    staged_timeout_policy: HMCStagedTimeoutPolicy | None = None
    staged_timeout_global_started_perf_counter_s: float | None = None
    staged_timeout_stage_started_perf_counter_s: float | None = None
    staged_timeout_enlargement_rounds: Mapping[str, int] | None = None
    incall_progress_heartbeat_s: float | None = None
    source: str = "bayesfilter.inference.hmc_kernel_tuning.fixed_mass_step_stage"

    def __post_init__(self) -> None:
        algorithm_id = str(self.algorithm_id)
        # This pure mapping is also the authoritative membership check for
        # top-level selection identities accepted by the lower-level stage.
        windowed_algorithm_for_selection_algorithm(algorithm_id)
        object.__setattr__(self, "algorithm_id", algorithm_id)
        target = float(self.target_accept_prob)
        if not math.isfinite(target) or not 0.0 < target < 1.0:
            raise ValueError("target_accept_prob must be finite and in (0, 1)")
        object.__setattr__(self, "target_accept_prob", target)
        object.__setattr__(
            self,
            "acceptance_band",
            _validate_band(self.acceptance_band, name="acceptance_band"),
        )
        repair_band = _validate_band(self.repair_band, name="repair_band")
        if repair_band[0] > self.acceptance_band[0] or repair_band[1] < self.acceptance_band[1]:
            raise ValueError("repair_band must contain acceptance_band")
        object.__setattr__(self, "repair_band", repair_band)
        object.__setattr__(
            self,
            "step_repair_factor",
            _validate_step_repair_multiplier(
                self.step_repair_factor,
                name="step_repair_factor",
            ),
        )
        min_directional_factor = _validate_step_repair_multiplier(
            self.step_repair_min_directional_factor,
            name="step_repair_min_directional_factor",
        )
        if min_directional_factor > 2.0:
            raise ValueError("step_repair_min_directional_factor must be at most 2")
        object.__setattr__(
            self,
            "step_repair_min_directional_factor",
            min_directional_factor,
        )
        high_factor = (
            self.step_repair_factor
            if self.step_repair_high_acceptance_directional_factor is None
            else self.step_repair_high_acceptance_directional_factor
        )
        object.__setattr__(
            self,
            "step_repair_high_acceptance_directional_factor",
            _validate_step_repair_multiplier(
                high_factor,
                name="step_repair_high_acceptance_directional_factor",
            ),
        )
        high_ladder_max = (
            high_factor
            if self.step_repair_high_acceptance_ladder_max_factor is None
            else self.step_repair_high_acceptance_ladder_max_factor
        )
        high_ladder_max = _validate_step_repair_multiplier(
            high_ladder_max,
            name="step_repair_high_acceptance_ladder_max_factor",
        )
        if high_ladder_max < high_factor:
            raise ValueError(
                "step_repair_high_acceptance_ladder_max_factor must be at least "
                "step_repair_high_acceptance_directional_factor"
            )
        object.__setattr__(
            self,
            "step_repair_high_acceptance_ladder_max_factor",
            high_ladder_max,
        )
        object.__setattr__(
            self,
            "repair_nonfinite_proposal_screen",
            bool(self.repair_nonfinite_proposal_screen),
        )
        lower, upper = _validate_trajectory_window_multipliers(
            self.trajectory_window_lower_multiplier,
            self.trajectory_window_upper_multiplier,
        )
        object.__setattr__(self, "trajectory_window_lower_multiplier", lower)
        object.__setattr__(self, "trajectory_window_upper_multiplier", upper)
        object.__setattr__(
            self,
            "handoff_screen_policy",
            _validate_handoff_screen_policy(self.handoff_screen_policy),
        )
        object.__setattr__(self, "seed", _validate_seed(self.seed))
        mode = str(self.chain_execution_mode)
        if mode not in {"tf_function", "eager"}:
            raise ValueError("chain_execution_mode must be 'tf_function' or 'eager'")
        if self.use_xla and mode != "tf_function":
            raise ValueError("XLA HMC requires chain_execution_mode='tf_function'")
        object.__setattr__(self, "chain_execution_mode", mode)
        object.__setattr__(self, "use_xla", bool(self.use_xla))
        if self.target_scope is not None:
            scope = str(self.target_scope)
            if not scope:
                raise ValueError("target_scope must be non-empty when provided")
            object.__setattr__(self, "target_scope", scope)
        target_status_policy = str(self.target_status_trace_policy)
        if target_status_policy not in {"none", "per_chain_step"}:
            raise ValueError(
                "target_status_trace_policy must be 'none' or 'per_chain_step'"
            )
        object.__setattr__(self, "target_status_trace_policy", target_status_policy)
        mass_policy = str(self.mass_policy)
        if mass_policy not in {"windowed_adaptive", "fixed_identity"}:
            raise ValueError(
                "mass_policy must be 'windowed_adaptive' or 'fixed_identity'"
            )
        object.__setattr__(self, "mass_policy", mass_policy)
        timeout_budget = (
            None
            if self.public_timeout_budget_s is None
            else float(self.public_timeout_budget_s)
        )
        if timeout_budget is not None and (
            not math.isfinite(timeout_budget) or timeout_budget <= 0.0
        ):
            raise ValueError("public_timeout_budget_s must be positive and finite")
        object.__setattr__(self, "public_timeout_budget_s", timeout_budget)
        timeout_started = (
            None
            if self.public_timeout_started_perf_counter_s is None
            else float(self.public_timeout_started_perf_counter_s)
        )
        if timeout_started is not None and (
            not math.isfinite(timeout_started) or timeout_started < 0.0
        ):
            raise ValueError(
                "public_timeout_started_perf_counter_s must be finite and non-negative"
            )
        object.__setattr__(
            self,
            "public_timeout_started_perf_counter_s",
            timeout_started,
        )
        object.__setattr__(
            self,
            "staged_timeout_policy",
            _validate_staged_timeout_policy_or_none(self.staged_timeout_policy),
        )
        object.__setattr__(
            self,
            "staged_timeout_global_started_perf_counter_s",
            _validate_nonnegative_perf_counter_or_none(
                self.staged_timeout_global_started_perf_counter_s,
                name="staged_timeout_global_started_perf_counter_s",
            ),
        )
        object.__setattr__(
            self,
            "staged_timeout_stage_started_perf_counter_s",
            _validate_nonnegative_perf_counter_or_none(
                self.staged_timeout_stage_started_perf_counter_s,
                name="staged_timeout_stage_started_perf_counter_s",
            ),
        )
        object.__setattr__(
            self,
            "staged_timeout_enlargement_rounds",
            _validate_staged_timeout_enlargement_rounds(
                self.staged_timeout_enlargement_rounds
            ),
        )
        heartbeat = (
            None
            if self.incall_progress_heartbeat_s is None
            else float(self.incall_progress_heartbeat_s)
        )
        if heartbeat is not None and (not math.isfinite(heartbeat) or heartbeat <= 0.0):
            raise ValueError("incall_progress_heartbeat_s must be positive and finite")
        object.__setattr__(self, "incall_progress_heartbeat_s", heartbeat)
        source = str(self.source)
        if not source:
            raise ValueError("source must be non-empty")
        object.__setattr__(self, "source", source)

    def payload(self) -> Mapping[str, Any]:
        return {
            "algorithm_id": self.algorithm_id,
            "target_accept_prob": self.target_accept_prob,
            "acceptance_band": self.acceptance_band,
            "repair_band": self.repair_band,
            "step_repair_factor": self.step_repair_factor,
            "step_repair_min_directional_factor": (
                self.step_repair_min_directional_factor
            ),
            "step_repair_high_acceptance_directional_factor": (
                self.step_repair_high_acceptance_directional_factor
            ),
            "step_repair_high_acceptance_ladder_max_factor": (
                self.step_repair_high_acceptance_ladder_max_factor
            ),
            "repair_nonfinite_proposal_screen": self.repair_nonfinite_proposal_screen,
            "trajectory_window_lower_multiplier": (
                self.trajectory_window_lower_multiplier
            ),
            "trajectory_window_upper_multiplier": (
                self.trajectory_window_upper_multiplier
            ),
            "handoff_screen_policy": self.handoff_screen_policy,
            "seed": self.seed,
            "chain_execution_mode": self.chain_execution_mode,
            "use_xla": self.use_xla,
            "target_scope": self.target_scope,
            "target_status_trace_policy": self.target_status_trace_policy,
            "mass_policy": self.mass_policy,
            "public_timeout_budget_s": self.public_timeout_budget_s,
            "public_timeout_started_perf_counter_s": (
                self.public_timeout_started_perf_counter_s
            ),
            "incall_progress_heartbeat_s": self.incall_progress_heartbeat_s,
            "source": self.source,
        }


@dataclass(frozen=True)
class _HMCPhase5CandidateSourceContext:
    """Immutable upstream lineage for the private Phase 5 candidate batch."""

    schema_runtime_version: str
    phase5_config_hash: str
    target_scope: str
    target_dimension: int
    windowed_stage_artifact_hash: str
    selected_bootstrap_kernel_hash: str
    adapter_signature: str
    phase4_hmc_adapter_signature: str
    ladder_adapter_signature: str
    ladder_hmc_adapter_signature: str
    adapted_mass_artifact_signature: str
    handoff_screen_policy: str
    nonclaims: tuple[str, ...] = _PHASE5_CANDIDATE_HANDOFF_NONCLAIMS
    private_handoff_only: bool = True

    def __post_init__(self) -> None:
        for name in (
            "schema_runtime_version",
            "phase5_config_hash",
            "target_scope",
            "windowed_stage_artifact_hash",
            "selected_bootstrap_kernel_hash",
            "adapter_signature",
            "phase4_hmc_adapter_signature",
            "ladder_adapter_signature",
            "ladder_hmc_adapter_signature",
            "adapted_mass_artifact_signature",
        ):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"{name} must be non-empty")
            object.__setattr__(self, name, value)
        dimension = int(self.target_dimension)
        if dimension <= 0:
            raise ValueError("target_dimension must be positive")
        object.__setattr__(self, "target_dimension", dimension)
        object.__setattr__(
            self,
            "handoff_screen_policy",
            _validate_handoff_screen_policy(self.handoff_screen_policy),
        )
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("candidate source context nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self.private_handoff_only is not True:
            raise ValueError("candidate source context must remain private")

    def payload(self) -> Mapping[str, Any]:
        return {
            "schema_runtime_version": self.schema_runtime_version,
            "phase5_config_hash": self.phase5_config_hash,
            "target_scope": self.target_scope,
            "target_dimension": self.target_dimension,
            "windowed_stage_artifact_hash": self.windowed_stage_artifact_hash,
            "selected_bootstrap_kernel_hash": self.selected_bootstrap_kernel_hash,
            "adapter_signature": self.adapter_signature,
            "phase4_hmc_adapter_signature": self.phase4_hmc_adapter_signature,
            "ladder_adapter_signature": self.ladder_adapter_signature,
            "ladder_hmc_adapter_signature": self.ladder_hmc_adapter_signature,
            "adapted_mass_artifact_signature": self.adapted_mass_artifact_signature,
            "handoff_screen_policy": self.handoff_screen_policy,
            "nonclaims": self.nonclaims,
            "private_handoff_only": self.private_handoff_only,
        }


@dataclass(frozen=True)
class _HMCPhase5CandidateRecord:
    """One normalized Phase 5 candidate with source-complete private lineage."""

    source_candidate_schema: str
    batch_ordinal: int
    source_round_index: int
    source_grid_stage: str
    source_round_candidate_index: int
    num_leapfrog_steps: int
    handoff_screen_policy: str
    ladder_final_status: str
    ladder_passed: bool
    selected_round_index: int | None
    selected_budget: int | None
    selected_step_size: float | None
    selected_step_size_observed: bool
    selected_step_size_finite: bool
    selected_step_hash: str | None
    screen_acceptance_rate: float | None
    screen_acceptance_observed: bool
    screen_acceptance_finite: bool
    trajectory_length: float | None
    trajectory_length_observed: bool
    trajectory_length_finite: bool
    trajectory_window_relation: str
    hard_vetoes: tuple[str, ...]
    continuation_vetoes: tuple[str, ...]
    repair_triggers: tuple[str, ...]
    viable: bool
    nomination_eligible: bool
    nomination_role: str
    handoff_eligible: bool
    ladder_artifact_hash: str | None
    repair_config_hash: str | None
    ladder_adapter_signature: str | None
    ladder_hmc_adapter_signature: str | None
    ladder_mass_artifact_signature: str | None
    ladder_target_scope: str | None
    ladder_target_dimension: int | None
    candidate_error_type: str | None
    nonclaims: tuple[str, ...] = _PHASE5_CANDIDATE_HANDOFF_NONCLAIMS
    private_handoff_only: bool = True
    record_hash: str = ""

    @property
    def source_key(self) -> tuple[int, str, int]:
        return (
            self.source_round_index,
            self.source_grid_stage,
            self.source_round_candidate_index,
        )

    def __post_init__(self) -> None:
        if int(self.batch_ordinal) < 0:
            raise ValueError("batch_ordinal must be non-negative")
        object.__setattr__(self, "batch_ordinal", int(self.batch_ordinal))
        object.__setattr__(self, "source_round_index", int(self.source_round_index))
        object.__setattr__(
            self,
            "source_round_candidate_index",
            int(self.source_round_candidate_index),
        )
        leapfrog = int(self.num_leapfrog_steps)
        if leapfrog <= 0:
            raise ValueError("candidate num_leapfrog_steps must be positive")
        object.__setattr__(self, "num_leapfrog_steps", leapfrog)
        for name in (
            "source_candidate_schema",
            "source_grid_stage",
            "ladder_final_status",
            "trajectory_window_relation",
            "nomination_role",
        ):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"{name} must be non-empty")
            object.__setattr__(self, name, value)
        object.__setattr__(
            self,
            "handoff_screen_policy",
            _validate_handoff_screen_policy(self.handoff_screen_policy),
        )
        for name in ("hard_vetoes", "continuation_vetoes", "repair_triggers"):
            object.__setattr__(
                self,
                name,
                tuple(str(item) for item in getattr(self, name)),
            )
        for name in (
            "selected_step_hash",
            "ladder_artifact_hash",
            "repair_config_hash",
            "ladder_adapter_signature",
            "ladder_hmc_adapter_signature",
            "ladder_mass_artifact_signature",
            "ladder_target_scope",
            "candidate_error_type",
        ):
            value = getattr(self, name)
            object.__setattr__(self, name, None if value is None else str(value))
        selected_round = (
            None if self.selected_round_index is None else int(self.selected_round_index)
        )
        selected_budget = None if self.selected_budget is None else int(self.selected_budget)
        ladder_dimension = (
            None
            if self.ladder_target_dimension is None
            else int(self.ladder_target_dimension)
        )
        object.__setattr__(self, "selected_round_index", selected_round)
        object.__setattr__(self, "selected_budget", selected_budget)
        object.__setattr__(self, "ladder_target_dimension", ladder_dimension)
        for name in (
            "ladder_passed",
            "selected_step_size_observed",
            "selected_step_size_finite",
            "screen_acceptance_observed",
            "screen_acceptance_finite",
            "trajectory_length_observed",
            "trajectory_length_finite",
            "viable",
            "nomination_eligible",
            "handoff_eligible",
        ):
            object.__setattr__(self, name, bool(getattr(self, name)))
        for value_name, observed_name, finite_name in (
            (
                "selected_step_size",
                "selected_step_size_observed",
                "selected_step_size_finite",
            ),
            (
                "screen_acceptance_rate",
                "screen_acceptance_observed",
                "screen_acceptance_finite",
            ),
            (
                "trajectory_length",
                "trajectory_length_observed",
                "trajectory_length_finite",
            ),
        ):
            value = getattr(self, value_name)
            observed = getattr(self, observed_name)
            finite = getattr(self, finite_name)
            if not observed:
                if value is not None or finite:
                    raise ValueError(f"unobserved {value_name} must be None/nonfinite")
            elif finite:
                if value is None or not math.isfinite(float(value)):
                    raise ValueError(f"finite {value_name} requires a finite value")
                object.__setattr__(self, value_name, float(value))
            elif value is not None:
                raise ValueError(f"observed nonfinite {value_name} must normalize to None")
        if self.handoff_eligible:
            if (
                not self.ladder_passed
                or not self.selected_step_size_finite
                or self.selected_step_hash is None
                or self.ladder_artifact_hash is None
                or self.ladder_adapter_signature is None
                or self.ladder_hmc_adapter_signature is None
                or self.ladder_mass_artifact_signature is None
                or self.ladder_target_scope is None
                or self.ladder_target_dimension is None
            ):
                raise ValueError("handoff-eligible candidate lacks verifier lineage")
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("candidate record nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self.private_handoff_only is not True:
            raise ValueError("candidate record must remain private")
        expected_hash = stable_config_hash(self.payload())
        record_hash = str(self.record_hash)
        if record_hash and record_hash != expected_hash:
            raise ValueError("candidate record hash mismatch")
        object.__setattr__(self, "record_hash", expected_hash)

    def payload(self) -> Mapping[str, Any]:
        return {
            "source_candidate_schema": self.source_candidate_schema,
            "batch_ordinal": self.batch_ordinal,
            "source_round_index": self.source_round_index,
            "source_grid_stage": self.source_grid_stage,
            "source_round_candidate_index": self.source_round_candidate_index,
            "source_key": self.source_key,
            "num_leapfrog_steps": self.num_leapfrog_steps,
            "handoff_screen_policy": self.handoff_screen_policy,
            "ladder_final_status": self.ladder_final_status,
            "ladder_passed": self.ladder_passed,
            "selected_round_index": self.selected_round_index,
            "selected_budget": self.selected_budget,
            "selected_step_size": self.selected_step_size,
            "selected_step_size_observed": self.selected_step_size_observed,
            "selected_step_size_finite": self.selected_step_size_finite,
            "selected_step_hash": self.selected_step_hash,
            "screen_acceptance_rate": self.screen_acceptance_rate,
            "screen_acceptance_observed": self.screen_acceptance_observed,
            "screen_acceptance_finite": self.screen_acceptance_finite,
            "trajectory_length": self.trajectory_length,
            "trajectory_length_observed": self.trajectory_length_observed,
            "trajectory_length_finite": self.trajectory_length_finite,
            "trajectory_window_relation": self.trajectory_window_relation,
            "hard_vetoes": self.hard_vetoes,
            "continuation_vetoes": self.continuation_vetoes,
            "repair_triggers": self.repair_triggers,
            "viable": self.viable,
            "nomination_eligible": self.nomination_eligible,
            "nomination_role": self.nomination_role,
            "handoff_eligible": self.handoff_eligible,
            "ladder_artifact_hash": self.ladder_artifact_hash,
            "repair_config_hash": self.repair_config_hash,
            "ladder_adapter_signature": self.ladder_adapter_signature,
            "ladder_hmc_adapter_signature": self.ladder_hmc_adapter_signature,
            "ladder_mass_artifact_signature": self.ladder_mass_artifact_signature,
            "ladder_target_scope": self.ladder_target_scope,
            "ladder_target_dimension": self.ladder_target_dimension,
            "candidate_error_type": self.candidate_error_type,
            "nonclaims": self.nonclaims,
            "private_handoff_only": self.private_handoff_only,
        }


@dataclass(frozen=True)
class _HMCPhase5CandidateSignalRecord:
    role: str
    code: str
    source_batch_ordinal: int

    def __post_init__(self) -> None:
        role = str(self.role)
        if role not in {"hard_veto", "continuation_veto", "repair_trigger"}:
            raise ValueError("invalid candidate signal role")
        code = str(self.code)
        if not code:
            raise ValueError("candidate signal code must be non-empty")
        ordinal = int(self.source_batch_ordinal)
        if ordinal < 0:
            raise ValueError("candidate signal ordinal must be non-negative")
        object.__setattr__(self, "role", role)
        object.__setattr__(self, "code", code)
        object.__setattr__(self, "source_batch_ordinal", ordinal)

    def payload(self) -> Mapping[str, Any]:
        return {
            "role": self.role,
            "code": self.code,
            "source_batch_ordinal": self.source_batch_ordinal,
        }


@dataclass(frozen=True)
class _HMCPhase5CandidateBatchHandoff:
    """Private immutable Phase 5 batch consumed by later BayesFilter phases."""

    source_context: _HMCPhase5CandidateSourceContext
    candidate_records: tuple[_HMCPhase5CandidateRecord, ...]
    signal_records: tuple[_HMCPhase5CandidateSignalRecord, ...]
    final_status: str
    selected_batch_ordinal: int | None
    selected_record_hash: str | None
    repair_batch_ordinal: int | None
    repair_record_hash: str | None
    verification_order_seed: tuple[int, ...]
    nonclaims: tuple[str, ...] = _PHASE5_CANDIDATE_HANDOFF_NONCLAIMS
    private_handoff_only: bool = True
    handoff_hash: str = ""

    def __post_init__(self) -> None:
        if not isinstance(self.source_context, _HMCPhase5CandidateSourceContext):
            raise TypeError("candidate batch source_context has invalid type")
        records = tuple(self.candidate_records)
        signals = tuple(self.signal_records)
        if not records:
            raise ValueError("candidate batch requires at least one completed candidate")
        if not all(isinstance(item, _HMCPhase5CandidateRecord) for item in records):
            raise TypeError("candidate batch contains an invalid candidate record")
        if not all(isinstance(item, _HMCPhase5CandidateSignalRecord) for item in signals):
            raise TypeError("candidate batch contains an invalid signal record")
        object.__setattr__(self, "candidate_records", records)
        object.__setattr__(self, "signal_records", signals)
        final_status = str(self.final_status)
        if final_status not in {
            "passed",
            "repair_or_retry",
            "budget_exhausted",
            "hard_veto",
        }:
            raise ValueError("invalid Phase 5 candidate batch final status")
        object.__setattr__(self, "final_status", final_status)
        for name in ("selected_batch_ordinal", "repair_batch_ordinal"):
            value = getattr(self, name)
            object.__setattr__(self, name, None if value is None else int(value))
        for name in ("selected_record_hash", "repair_record_hash"):
            value = getattr(self, name)
            object.__setattr__(self, name, None if value is None else str(value))
        object.__setattr__(
            self,
            "verification_order_seed",
            tuple(int(item) for item in self.verification_order_seed),
        )
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("candidate batch nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self.private_handoff_only is not True:
            raise ValueError("candidate batch must remain private")
        expected_hash = stable_config_hash(self.payload())
        handoff_hash = str(self.handoff_hash)
        if handoff_hash and handoff_hash != expected_hash:
            raise ValueError("candidate batch handoff hash mismatch")
        object.__setattr__(self, "handoff_hash", expected_hash)

    @property
    def candidate_count(self) -> int:
        return len(self.candidate_records)

    @property
    def handoff_eligible_count(self) -> int:
        return sum(record.handoff_eligible for record in self.candidate_records)

    def flattened_codes(self, role: str) -> tuple[str, ...]:
        return tuple(
            dict.fromkeys(
                signal.code for signal in self.signal_records if signal.role == role
            )
        )

    def payload(self) -> Mapping[str, Any]:
        return {
            "schema": "bayesfilter.hmc_phase5_candidate_batch_handoff.v1",
            "source_context": self.source_context.payload(),
            "candidate_records": tuple(
                {**record.payload(), "record_hash": record.record_hash}
                for record in self.candidate_records
            ),
            "signal_records": tuple(signal.payload() for signal in self.signal_records),
            "final_status": self.final_status,
            "candidate_count": self.candidate_count,
            "handoff_eligible_count": self.handoff_eligible_count,
            "selected_reference": None
            if self.selected_batch_ordinal is None
            else (self.selected_batch_ordinal, self.selected_record_hash),
            "repair_reference": None
            if self.repair_batch_ordinal is None
            else (self.repair_batch_ordinal, self.repair_record_hash),
            "verification_order_seed": self.verification_order_seed,
            "nonclaims": self.nonclaims,
            "private_handoff_only": self.private_handoff_only,
        }


@dataclass(frozen=True, repr=False)
class _HMCPhase7DirectCandidateQueuePlan:
    """Private, pre-draw identity/seed/allocation contract for one attempt."""

    phase5_status: str
    fixed_mass_step_stage_artifact_hash: str
    candidate_batch_hash: str
    candidate_identities: tuple[tuple[int, int, str, int], ...]
    candidate_record_hashes: tuple[str, ...]
    verification_seeds: tuple[tuple[int, int], ...]
    verification_num_results: int
    verification_num_burnin_steps: int
    maximum_candidate_starts: int = _PHASE7_DIRECT_QUEUE_MAX_STARTS
    private_handoff_only: bool = True
    plan_hash: str = ""

    def __post_init__(self) -> None:
        status = str(self.phase5_status)
        if status not in {"passed", "repair_or_retry"}:
            raise ValueError("direct candidate queue requires a verifiable Phase 5 status")
        object.__setattr__(self, "phase5_status", status)
        for name in (
            "fixed_mass_step_stage_artifact_hash",
            "candidate_batch_hash",
        ):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"{name} must be non-empty")
            object.__setattr__(self, name, value)
        identities = tuple(
            (int(item[0]), int(item[1]), str(item[2]), int(item[3]))
            for item in self.candidate_identities
        )
        if not identities or len(set(identities)) != len(identities):
            raise ValueError("direct candidate queue identities must be non-empty and unique")
        if any(not identity[2] for identity in identities):
            raise ValueError("direct candidate queue grid stage must be non-empty")
        object.__setattr__(self, "candidate_identities", identities)
        record_hashes = tuple(str(item) for item in self.candidate_record_hashes)
        if (
            len(record_hashes) != len(identities)
            or any(not item for item in record_hashes)
            or len(set(record_hashes)) != len(record_hashes)
        ):
            raise ValueError("direct candidate queue record hashes are invalid")
        object.__setattr__(self, "candidate_record_hashes", record_hashes)
        seeds = tuple(_validate_seed(seed) for seed in self.verification_seeds)
        if len(seeds) != len(identities):
            raise ValueError("direct candidate queue seed count mismatch")
        if len(set(seeds)) != len(seeds):
            raise ValueError("direct candidate verification seed collision")
        object.__setattr__(self, "verification_seeds", seeds)
        for name in (
            "verification_num_results",
            "verification_num_burnin_steps",
            "maximum_candidate_starts",
        ):
            value = int(getattr(self, name))
            if value <= 0:
                raise ValueError(f"{name} must be positive")
            object.__setattr__(self, name, value)
        if self.maximum_candidate_starts != _PHASE7_DIRECT_QUEUE_MAX_STARTS:
            raise ValueError("direct candidate queue start cap is fixed at two")
        if self.private_handoff_only is not True:
            raise ValueError("direct candidate queue plan must remain private")
        expected_hash = stable_config_hash(self.payload())
        plan_hash = str(self.plan_hash)
        if plan_hash and plan_hash != expected_hash:
            raise ValueError("direct candidate queue plan hash mismatch")
        object.__setattr__(self, "plan_hash", expected_hash)

    @property
    def candidate_count(self) -> int:
        return len(self.candidate_identities)

    @property
    def allocated_start_count(self) -> int:
        return min(self.candidate_count, self.maximum_candidate_starts)

    def payload(self) -> Mapping[str, Any]:
        return {
            "schema": "bayesfilter.hmc_phase7_direct_candidate_queue_plan.v1",
            "phase5_status": self.phase5_status,
            "fixed_mass_step_stage_artifact_hash": (
                self.fixed_mass_step_stage_artifact_hash
            ),
            "candidate_batch_hash": self.candidate_batch_hash,
            "candidate_identities": self.candidate_identities,
            "candidate_record_hashes": self.candidate_record_hashes,
            "verification_seeds": self.verification_seeds,
            "candidate_count": self.candidate_count,
            "verification_num_results": self.verification_num_results,
            "verification_num_burnin_steps": self.verification_num_burnin_steps,
            "maximum_candidate_starts": self.maximum_candidate_starts,
            "allocated_start_count": self.allocated_start_count,
            "total_result_cap": (
                self.maximum_candidate_starts * self.verification_num_results
            ),
            "total_burnin_cap": (
                self.maximum_candidate_starts * self.verification_num_burnin_steps
            ),
            "unused_quota_carries_across_attempts": False,
            "private_handoff_only": self.private_handoff_only,
        }

    def __repr__(self) -> str:
        return (
            "_HMCPhase7DirectCandidateQueuePlan("
            f"phase5_status={self.phase5_status!r}, "
            f"candidate_count={self.candidate_count}, "
            f"maximum_candidate_starts={self.maximum_candidate_starts}, "
            "private_handoff_only=True)"
        )


@dataclass(frozen=True, repr=False)
class _HMCPhase7FixedKernelVerificationInput:
    """Immutable source-normalized mechanics and lineage for one verifier call."""

    source_kind: str
    attempt_index: int
    target_scope: str
    target_dimension: int
    windowed_stage_artifact_hash: str
    adapted_mass_artifact_signature: str
    fixed_mass_step_stage_artifact_hash: str
    candidate_batch_hash: str | None
    candidate_identity: tuple[int, int, str, int] | None
    candidate_record_hash: str | None
    operational_selection_signature: str | None
    operational_candidate_signature: str | None
    trajectory_stage_artifact_hash: str | None
    selected_step_hash: str
    step_size: float
    num_leapfrog_steps: int
    adapter_signature: str
    phase4_adapter_signature: str
    verification_hmc_adapter_signature: str
    verification_seed: tuple[int, int]
    seed_policy: str
    coordinate_signature: str | None
    metric_signature: str | None
    trajectory_signature: str | None
    start_bank_signature: str | None
    nonclaims: tuple[str, ...] = _PHASE7_FIXED_KERNEL_VERIFICATION_NONCLAIMS
    private_handoff_only: bool = True
    input_hash: str = ""

    def __post_init__(self) -> None:
        source_kind = str(self.source_kind)
        if source_kind not in {
            "direct_phase5_candidate",
            "operational_selection_v2",
            "historical_phase6",
        }:
            raise ValueError("invalid Phase 7 verification source kind")
        object.__setattr__(self, "source_kind", source_kind)
        attempt_index = int(self.attempt_index)
        if attempt_index < 0:
            raise ValueError("Phase 7 verification attempt index must be non-negative")
        object.__setattr__(self, "attempt_index", attempt_index)
        dimension = int(self.target_dimension)
        if dimension <= 0:
            raise ValueError("Phase 7 verification target dimension must be positive")
        object.__setattr__(self, "target_dimension", dimension)
        for name in (
            "target_scope",
            "windowed_stage_artifact_hash",
            "adapted_mass_artifact_signature",
            "fixed_mass_step_stage_artifact_hash",
            "selected_step_hash",
            "adapter_signature",
            "phase4_adapter_signature",
            "verification_hmc_adapter_signature",
            "seed_policy",
        ):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"{name} must be non-empty")
            object.__setattr__(self, name, value)
        step = float(self.step_size)
        if not math.isfinite(step) or step <= 0.0:
            raise ValueError("Phase 7 verification step size must be positive and finite")
        object.__setattr__(self, "step_size", step)
        leapfrog = int(self.num_leapfrog_steps)
        if leapfrog <= 0:
            raise ValueError("Phase 7 verification L must be positive")
        object.__setattr__(self, "num_leapfrog_steps", leapfrog)
        object.__setattr__(self, "verification_seed", _validate_seed(self.verification_seed))
        for name in (
            "candidate_batch_hash",
            "candidate_record_hash",
            "operational_selection_signature",
            "operational_candidate_signature",
            "trajectory_stage_artifact_hash",
            "coordinate_signature",
            "metric_signature",
            "trajectory_signature",
            "start_bank_signature",
        ):
            value = getattr(self, name)
            object.__setattr__(self, name, None if value is None else str(value))
        identity = self.candidate_identity
        if identity is not None:
            if len(tuple(identity)) != 4:
                raise ValueError("candidate identity must contain four components")
            normalized_identity = (
                int(identity[0]),
                int(identity[1]),
                str(identity[2]),
                int(identity[3]),
            )
            if normalized_identity[0] < 0 or not normalized_identity[2]:
                raise ValueError("candidate identity is invalid")
            object.__setattr__(self, "candidate_identity", normalized_identity)
        if source_kind == "direct_phase5_candidate":
            if (
                self.candidate_batch_hash is None
                or self.candidate_record_hash is None
                or self.candidate_identity is None
            ):
                raise ValueError("direct Phase 5 verification requires candidate lineage")
            if self.trajectory_stage_artifact_hash is not None:
                raise ValueError("direct Phase 5 verification forbids Phase 6 lineage")
            if self.seed_policy != _PHASE7_DIRECT_CANDIDATE_SEED_POLICY:
                raise ValueError("direct Phase 5 verification seed policy mismatch")
            if any(
                value is not None
                for value in (
                    self.operational_selection_signature,
                    self.operational_candidate_signature,
                    self.coordinate_signature,
                    self.metric_signature,
                    self.trajectory_signature,
                    self.start_bank_signature,
                )
            ):
                raise ValueError("direct Phase 5 verification forbids operational lineage")
        elif source_kind == "operational_selection_v2":
            if (
                self.operational_selection_signature is None
                or self.operational_candidate_signature is None
                or self.coordinate_signature is None
                or self.metric_signature is None
                or self.trajectory_signature is None
                or self.start_bank_signature is None
            ):
                raise ValueError("operational verification requires selection lineage")
            if any(
                value is not None
                for value in (
                    self.candidate_batch_hash,
                    self.candidate_identity,
                    self.candidate_record_hash,
                    self.trajectory_stage_artifact_hash,
                )
            ):
                raise ValueError("operational verification forbids v1 candidate/Phase 6 lineage")
            if self.seed_policy not in {
                _PHASE7_OPERATIONAL_SELECTION_SEED_POLICY,
                _PHASE7_OPERATIONAL_REPAIR_SEED_POLICY,
                _PHASE7_OPERATIONAL_BRACKET_MIDPOINT_SEED_POLICY,
                _PHASE7_OPERATIONAL_EVIDENCE_EXTENSION_SEED_POLICY,
            }:
                raise ValueError("operational verification seed policy mismatch")
        else:
            if self.trajectory_stage_artifact_hash is None:
                raise ValueError("historical verification requires Phase 6 lineage")
            if any(
                value is not None
                for value in (
                    self.candidate_batch_hash,
                    self.candidate_identity,
                    self.candidate_record_hash,
                    self.operational_selection_signature,
                    self.operational_candidate_signature,
                    self.coordinate_signature,
                    self.metric_signature,
                    self.trajectory_signature,
                    self.start_bank_signature,
                )
            ):
                raise ValueError("historical verification forbids direct candidate lineage")
            if self.seed_policy != _PHASE7_HISTORICAL_PHASE6_SEED_POLICY:
                raise ValueError("historical Phase 6 verification seed policy mismatch")
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("Phase 7 verification nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self.private_handoff_only is not True:
            raise ValueError("Phase 7 verification input must remain private")
        expected_hash = stable_config_hash(self.payload())
        input_hash = str(self.input_hash)
        if input_hash and input_hash != expected_hash:
            raise ValueError("Phase 7 verification input hash mismatch")
        object.__setattr__(self, "input_hash", expected_hash)

    @property
    def source_identity(self) -> Mapping[str, Any]:
        if self.source_kind == "direct_phase5_candidate":
            return {
                "source_kind": self.source_kind,
                "candidate_batch_hash": self.candidate_batch_hash,
                "candidate_identity": self.candidate_identity,
                "candidate_record_hash": self.candidate_record_hash,
            }
        if self.source_kind == "operational_selection_v2":
            return {
                "source_kind": self.source_kind,
                "operational_selection_signature": (
                    self.operational_selection_signature
                ),
                "operational_candidate_signature": (
                    self.operational_candidate_signature
                ),
                "coordinate_signature": self.coordinate_signature,
                "metric_signature": self.metric_signature,
                "trajectory_signature": self.trajectory_signature,
                "start_bank_signature": self.start_bank_signature,
            }
        return {
            "source_kind": self.source_kind,
            "trajectory_stage_artifact_hash": self.trajectory_stage_artifact_hash,
        }

    def payload(self) -> Mapping[str, Any]:
        return {
            "schema": "bayesfilter.hmc_phase7_fixed_kernel_verification_input.v1",
            "source_kind": self.source_kind,
            "attempt_index": self.attempt_index,
            "target_scope": self.target_scope,
            "target_dimension": self.target_dimension,
            "windowed_stage_artifact_hash": self.windowed_stage_artifact_hash,
            "adapted_mass_artifact_signature": self.adapted_mass_artifact_signature,
            "fixed_mass_step_stage_artifact_hash": (
                self.fixed_mass_step_stage_artifact_hash
            ),
            "candidate_batch_hash": self.candidate_batch_hash,
            "candidate_identity": self.candidate_identity,
            "candidate_record_hash": self.candidate_record_hash,
            "operational_selection_signature": self.operational_selection_signature,
            "operational_candidate_signature": self.operational_candidate_signature,
            "trajectory_stage_artifact_hash": self.trajectory_stage_artifact_hash,
            "selected_step_hash": self.selected_step_hash,
            "step_size": self.step_size,
            "num_leapfrog_steps": self.num_leapfrog_steps,
            "adapter_signature": self.adapter_signature,
            "phase4_adapter_signature": self.phase4_adapter_signature,
            "verification_hmc_adapter_signature": (
                self.verification_hmc_adapter_signature
            ),
            "verification_seed": self.verification_seed,
            "seed_policy": self.seed_policy,
            "coordinate_signature": self.coordinate_signature,
            "metric_signature": self.metric_signature,
            "trajectory_signature": self.trajectory_signature,
            "start_bank_signature": self.start_bank_signature,
            "nonclaims": self.nonclaims,
            "private_handoff_only": self.private_handoff_only,
        }

    def __repr__(self) -> str:
        return (
            "_HMCPhase7FixedKernelVerificationInput("
            f"source_kind={self.source_kind!r}, attempt_index={self.attempt_index}, "
            f"target_dimension={self.target_dimension}, private_handoff_only=True)"
        )


@dataclass(frozen=True, repr=False)
class _HMCPhase7FixedKernelVerificationOutcome:
    """Private role-separated result from the shared Phase 7 verifier core."""

    verification_input: _HMCPhase7FixedKernelVerificationInput = dataclasses.field(
        repr=False
    )
    verification_config_payload: Mapping[str, Any] | None = dataclasses.field(
        repr=False
    )
    diagnostics: Mapping[str, Any] = dataclasses.field(repr=False)
    callback_result: FixedMassHMCTuningBudgetCallbackResult = dataclasses.field(
        repr=False
    )
    final_status: str
    diagnostic_role: str
    hard_vetoes: tuple[str, ...]
    continuation_scope: str
    repair_triggers: tuple[str, ...]
    repair_evidence: Mapping[str, Any] | None = dataclasses.field(
        default=None,
        repr=False,
    )
    nonclaims: tuple[str, ...] = _PHASE7_FIXED_KERNEL_VERIFICATION_NONCLAIMS
    private_handoff_only: bool = True

    def __post_init__(self) -> None:
        if not isinstance(
            self.verification_input,
            _HMCPhase7FixedKernelVerificationInput,
        ):
            raise TypeError("verification_input has invalid type")
        config_payload = (
            None
            if self.verification_config_payload is None
            else dict(self.verification_config_payload)
        )
        object.__setattr__(self, "verification_config_payload", config_payload)
        object.__setattr__(self, "diagnostics", dict(self.diagnostics))
        if not isinstance(
            self.callback_result,
            FixedMassHMCTuningBudgetCallbackResult,
        ):
            raise TypeError("callback_result has invalid type")
        status = str(self.final_status)
        if status not in {
            "passed",
            "hard_veto",
            "repair_or_retry",
            "budget_exhausted",
        }:
            raise ValueError("invalid Phase 7 verification status")
        object.__setattr__(self, "final_status", status)
        role = str(self.diagnostic_role)
        if not role:
            raise ValueError("Phase 7 verification diagnostic role must be non-empty")
        object.__setattr__(self, "diagnostic_role", role)
        object.__setattr__(self, "hard_vetoes", _string_tuple(self.hard_vetoes))
        object.__setattr__(
            self,
            "repair_triggers",
            _string_tuple(self.repair_triggers),
        )
        scope = str(self.continuation_scope)
        if scope not in {
            "passed",
            "candidate_local_hard_veto",
            "candidate_local_cost_stop",
            "candidate_local_promotion_veto",
            "shared_continuation_veto",
            "repair_or_retry",
        }:
            raise ValueError("invalid Phase 7 verification continuation scope")
        if status == "passed" and scope != "passed":
            raise ValueError("passed verification requires passed scope")
        if status == "repair_or_retry" and scope != "repair_or_retry":
            raise ValueError("repair verification requires repair scope")
        if status == "budget_exhausted" and scope not in {
            "candidate_local_cost_stop",
            "candidate_local_promotion_veto",
        }:
            raise ValueError(
                "nonpromoting verification requires a candidate-local scope"
            )
        if status == "hard_veto" and scope not in {
            "candidate_local_hard_veto",
            "shared_continuation_veto",
        }:
            raise ValueError("hard-veto verification requires a veto scope")
        object.__setattr__(self, "continuation_scope", scope)
        repair_evidence = (
            None if self.repair_evidence is None else dict(self.repair_evidence)
        )
        object.__setattr__(self, "repair_evidence", repair_evidence)
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("Phase 7 verification outcome nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self.private_handoff_only is not True:
            raise ValueError("Phase 7 verification outcome must remain private")

    def historical_tuple(self) -> tuple[
        Mapping[str, Any] | None,
        Mapping[str, Any],
        FixedMassHMCTuningBudgetCallbackResult,
        str,
        str,
        tuple[str, ...],
        tuple[str, ...],
    ]:
        return (
            self.verification_config_payload,
            self.diagnostics,
            self.callback_result,
            self.final_status,
            self.diagnostic_role,
            self.hard_vetoes,
            self.repair_triggers,
        )

    def __repr__(self) -> str:
        return (
            "_HMCPhase7FixedKernelVerificationOutcome("
            f"source_kind={self.verification_input.source_kind!r}, "
            f"final_status={self.final_status!r}, "
            f"continuation_scope={self.continuation_scope!r}, "
            "private_handoff_only=True)"
        )


def _phase7_direct_queue_acceptance_conflict(
    candidate_results: Sequence[Mapping[str, Any]], repair_directions: Sequence[str],
) -> bool:
    """Preserve disagreement within chains as well as between candidates."""
    return len(set(repair_directions)) > 1 or any(
        isinstance(result.get("acceptance_evidence"), Mapping)
        and result["acceptance_evidence"].get("acceptance_decision") == "inconclusive_conflict"
        for result in candidate_results
    )


@dataclass(frozen=True, repr=False)
class _HMCPhase7DirectCandidateQueueResult:
    """Private aggregate preserving per-candidate states without public leakage."""

    plan: _HMCPhase7DirectCandidateQueuePlan = dataclasses.field(repr=False)
    candidate_results: tuple[Mapping[str, Any], ...] = dataclasses.field(repr=False)
    representative_outcome: _HMCPhase7FixedKernelVerificationOutcome | None = (
        dataclasses.field(default=None, repr=False)
    )
    admitted_outcome: _HMCPhase7FixedKernelVerificationOutcome | None = (
        dataclasses.field(default=None, repr=False)
    )
    repair_outcome: _HMCPhase7FixedKernelVerificationOutcome | None = (
        dataclasses.field(default=None, repr=False)
    )
    repair_directions: tuple[str, ...] = ()
    final_status: str = "architecture_blocked"
    diagnostic_role: str = "architecture_blocked"
    hard_vetoes: tuple[str, ...] = ()
    repair_triggers: tuple[str, ...] = ()
    timeout_closeout: Mapping[str, Any] | None = dataclasses.field(
        default=None,
        repr=False,
    )
    private_handoff_only: bool = True

    def __post_init__(self) -> None:
        if not isinstance(self.plan, _HMCPhase7DirectCandidateQueuePlan):
            raise TypeError("direct queue result plan has invalid type")
        results = tuple(dict(item) for item in self.candidate_results)
        if len(results) != self.plan.candidate_count:
            raise ValueError("direct queue result count mismatch")
        expected_identities = self.plan.candidate_identities
        observed_identities = tuple(
            tuple(item.get("candidate_identity", ())) for item in results
        )
        if observed_identities != expected_identities:
            raise ValueError("direct queue result identity order mismatch")
        allowed_states = {
            "passed",
            "repair_or_retry",
            "candidate_local_hard_veto",
            "candidate_local_cost_stop",
            "candidate_local_promotion_veto",
            "shared_continuation_veto",
            "not_run",
        }
        if any(str(item.get("state")) not in allowed_states for item in results):
            raise ValueError("direct queue result contains an invalid candidate state")
        started_count = sum(item.get("started") is True for item in results)
        if started_count > self.plan.maximum_candidate_starts:
            raise ValueError("direct queue result exceeded its start cap")
        object.__setattr__(self, "candidate_results", results)
        for name in ("representative_outcome", "admitted_outcome", "repair_outcome"):
            value = getattr(self, name)
            if value is not None and not isinstance(
                value,
                _HMCPhase7FixedKernelVerificationOutcome,
            ):
                raise TypeError(f"{name} has invalid type")
        status = str(self.final_status)
        if status not in {
            "passed",
            "repair_or_retry",
            "hard_veto",
            "budget_exhausted",
            "architecture_blocked",
        }:
            raise ValueError("direct queue result status is invalid")
        object.__setattr__(self, "final_status", status)
        role = str(self.diagnostic_role)
        if not role:
            raise ValueError("direct queue diagnostic role must be non-empty")
        object.__setattr__(self, "diagnostic_role", role)
        object.__setattr__(self, "hard_vetoes", _string_tuple(self.hard_vetoes))
        object.__setattr__(
            self,
            "repair_triggers",
            _string_tuple(self.repair_triggers),
        )
        directions = tuple(sorted(set(str(item) for item in self.repair_directions)))
        if any(item not in {"lower_epsilon", "higher_epsilon"} for item in directions):
            raise ValueError("direct queue repair direction is invalid")
        observed_directions = tuple(
            sorted(
                {
                    str(item.get("repair_direction"))
                    for item in results
                    if item.get("repair_direction") is not None
                }
            )
        )
        if directions != observed_directions:
            raise ValueError("direct queue repair directions do not match candidate evidence")
        object.__setattr__(self, "repair_directions", directions)
        closeout = None if self.timeout_closeout is None else dict(self.timeout_closeout)
        object.__setattr__(self, "timeout_closeout", closeout)
        if status == "passed" and self.admitted_outcome is None:
            raise ValueError("passed direct queue requires an admitted outcome")
        if status == "repair_or_retry" and self.repair_outcome is None:
            raise ValueError("repairing direct queue requires a finite repair outcome")
        conflict = _phase7_direct_queue_acceptance_conflict(results, directions)
        conflict_trigger = "verification_acceptance_inconclusive_conflict"
        if conflict and status == "repair_or_retry" and (
            role != "verification_acceptance_conflict"
            or conflict_trigger not in self.repair_triggers
        ):
            raise ValueError("direct queue repair conflict is not classified truthfully")
        if not conflict and (
            role == "verification_acceptance_conflict"
            or conflict_trigger in self.repair_triggers
        ):
            raise ValueError("direct queue claims a repair conflict without supporting acceptance evidence")
        if status == "hard_veto" and not self.hard_vetoes:
            raise ValueError("hard-veto direct queue requires a shared veto")
        if self.private_handoff_only is not True:
            raise ValueError("direct queue result must remain private")

    @property
    def started_count(self) -> int:
        return sum(item.get("started") is True for item in self.candidate_results)

    @property
    def not_run_count(self) -> int:
        return sum(item.get("state") == "not_run" for item in self.candidate_results)

    @property
    def cost_stopped_count(self) -> int:
        return sum(
            item.get("state") == "candidate_local_cost_stop"
            for item in self.candidate_results
        )

    @property
    def promotion_vetoed_count(self) -> int:
        return sum(
            item.get("state") == "candidate_local_promotion_veto"
            for item in self.candidate_results
        )

    @property
    def repair_direction_conflict(self) -> bool:
        return self.final_status == "repair_or_retry" and _phase7_direct_queue_acceptance_conflict(
            self.candidate_results, self.repair_directions,
        )

    def private_diagnostics(self) -> Mapping[str, Any]:
        representative = self.representative_outcome
        diagnostics = {} if representative is None else dict(representative.diagnostics)
        return {
            **diagnostics,
            "phase7_direct_candidate_queue": {
                "schema": "bayesfilter.hmc_phase7_direct_candidate_queue_result.v2",
                "plan_hash": self.plan.plan_hash,
                "candidate_batch_hash": self.plan.candidate_batch_hash,
                "verification_seed_policy": _PHASE7_DIRECT_CANDIDATE_SEED_POLICY,
                "seed_map_precomputed": True,
                "candidate_results": self.candidate_results,
                "candidate_count": self.plan.candidate_count,
                "started_count": self.started_count,
                "not_run_count": self.not_run_count,
                "cost_stopped_count": self.cost_stopped_count,
                "promotion_vetoed_count": self.promotion_vetoed_count,
                "repair_directions": self.repair_directions,
                "repair_direction_conflict": self.repair_direction_conflict,
                "maximum_candidate_starts": self.plan.maximum_candidate_starts,
                "unused_start_quota": max(
                    0,
                    self.plan.maximum_candidate_starts - self.started_count,
                ),
                "timeout_closeout": self.timeout_closeout,
                "private_handoff_only": True,
            },
            "phase7_direct_candidate_queue_active": True,
            "reports_posterior_convergence": False,
        }

    def __repr__(self) -> str:
        return (
            "_HMCPhase7DirectCandidateQueueResult("
            f"final_status={self.final_status!r}, "
            f"started_count={self.started_count}, "
            f"not_run_count={self.not_run_count}, "
            "private_handoff_only=True)"
        )


@dataclass(frozen=True, repr=False)
class _HMCPhase7FixedKernelVerificationExecution:
    """Execution-mode output consumed once by the shared Phase 7 finalizer."""

    verification_config_payload: Mapping[str, Any] | None
    diagnostics: Mapping[str, Any]
    callback_result: FixedMassHMCTuningBudgetCallbackResult
    runner_error: Exception | None
    runner_error_origin: str | None
    callback_error: Exception | None
    observed_step_size: Any
    observed_num_leapfrog_steps: Any

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "verification_config_payload",
            None
            if self.verification_config_payload is None
            else dict(self.verification_config_payload),
        )
        object.__setattr__(self, "diagnostics", dict(self.diagnostics))
        if not isinstance(
            self.callback_result,
            FixedMassHMCTuningBudgetCallbackResult,
        ):
            raise TypeError("verification execution callback_result has invalid type")
        origin = self.runner_error_origin
        if origin not in {None, "runner", "checkpoint"}:
            raise ValueError("invalid verification runner error origin")
        if (self.runner_error is None) != (origin is None):
            raise ValueError("verification runner error and origin must be paired")


@dataclass(frozen=True)
class HMCFixedMassStepStageResult:
    """Phase 5 fixed-mass step handoff; not trajectory or posterior evidence."""

    config: HMCFixedMassStepStageConfig
    windowed_stage_artifact_hash: str
    selected_bootstrap_kernel_hash: str
    adapter_signature: str
    phase4_hmc_adapter_signature: str
    ladder_adapter_signature: str
    ladder_hmc_adapter_signature: str
    adapted_mass_artifact_payload: Mapping[str, Any]
    adapted_mass_artifact_signature: str
    initial_step_size: float
    fixed_num_leapfrog_steps: int
    target_dimension: int
    final_status: str
    diagnostic_role: str
    hard_vetoes: tuple[str, ...]
    repair_triggers: tuple[str, ...]
    diagnostics: Mapping[str, Any]
    budget_ladder_config_payload: Mapping[str, Any] | None
    budget_ladder_result: FixedMassHMCTuningBudgetLadderResult | None
    selected_step_payload: Mapping[str, Any] | None
    selected_step_hash: str | None
    repair_step_payload: Mapping[str, Any] | None
    repair_step_hash: str | None
    frozen_mass_invariant: Mapping[str, Any]
    seed_report: Mapping[str, Any]
    diagnostic_roles: Mapping[str, str]
    nonclaims: tuple[str, ...] = FIXED_MASS_STEP_STAGE_NONCLAIMS
    _candidate_batch_handoff: _HMCPhase5CandidateBatchHandoff | None = (
        dataclasses.field(default=None, repr=False, compare=False)
    )
    _operational_selection: FixedTrajectorySelection | None = dataclasses.field(
        default=None,
        repr=False,
        compare=False,
    )
    _operational_selection_loop: BoundedFixedTrajectorySelectionResult | None = (
        dataclasses.field(default=None, repr=False, compare=False)
    )
    _operational_private_work_manifest: Mapping[str, Any] | None = dataclasses.field(
        default=None,
        repr=False,
        compare=False,
    )
    _operational_public_work_manifest: Mapping[str, Any] | None = dataclasses.field(
        default=None,
        repr=False,
        compare=False,
    )
    private_runner_cache_handoff: Mapping[str, Any] = field(
        default_factory=dict,
        repr=False,
        compare=False,
    )

    def __post_init__(self) -> None:
        for name in (
            "windowed_stage_artifact_hash",
            "selected_bootstrap_kernel_hash",
            "adapter_signature",
            "phase4_hmc_adapter_signature",
            "ladder_adapter_signature",
            "ladder_hmc_adapter_signature",
            "adapted_mass_artifact_signature",
            "final_status",
            "diagnostic_role",
        ):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"{name} must be non-empty")
            object.__setattr__(self, name, value)
        initial_step = float(self.initial_step_size)
        if not math.isfinite(initial_step) or initial_step <= 0.0:
            raise ValueError("initial_step_size must be positive and finite")
        object.__setattr__(self, "initial_step_size", initial_step)
        leapfrog = int(self.fixed_num_leapfrog_steps)
        if leapfrog <= 0:
            raise ValueError("fixed_num_leapfrog_steps must be positive")
        object.__setattr__(self, "fixed_num_leapfrog_steps", leapfrog)
        dimension = int(self.target_dimension)
        if dimension <= 0:
            raise ValueError("target_dimension must be positive")
        object.__setattr__(self, "target_dimension", dimension)
        object.__setattr__(self, "hard_vetoes", _string_tuple(self.hard_vetoes))
        object.__setattr__(self, "repair_triggers", _string_tuple(self.repair_triggers))
        object.__setattr__(
            self,
            "adapted_mass_artifact_payload",
            dict(self.adapted_mass_artifact_payload),
        )
        object.__setattr__(self, "diagnostics", dict(self.diagnostics))
        config_payload = (
            None
            if self.budget_ladder_config_payload is None
            else dict(self.budget_ladder_config_payload)
        )
        object.__setattr__(self, "budget_ladder_config_payload", config_payload)
        selected_payload = (
            None if self.selected_step_payload is None else dict(self.selected_step_payload)
        )
        object.__setattr__(self, "selected_step_payload", selected_payload)
        selected_hash = None if self.selected_step_hash is None else str(self.selected_step_hash)
        object.__setattr__(self, "selected_step_hash", selected_hash)
        repair_payload = (
            None if self.repair_step_payload is None else dict(self.repair_step_payload)
        )
        object.__setattr__(self, "repair_step_payload", repair_payload)
        repair_hash = None if self.repair_step_hash is None else str(self.repair_step_hash)
        object.__setattr__(self, "repair_step_hash", repair_hash)
        object.__setattr__(self, "frozen_mass_invariant", dict(self.frozen_mass_invariant))
        object.__setattr__(self, "seed_report", dict(self.seed_report))
        object.__setattr__(self, "diagnostic_roles", dict(self.diagnostic_roles))
        object.__setattr__(
            self,
            "private_runner_cache_handoff",
            dict(self.private_runner_cache_handoff),
        )
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self._candidate_batch_handoff is not None and not isinstance(
            self._candidate_batch_handoff,
            _HMCPhase5CandidateBatchHandoff,
        ):
            raise TypeError("_candidate_batch_handoff has invalid type")
        operational_selection = self._operational_selection
        if operational_selection is not None and not isinstance(
            operational_selection,
            FixedTrajectorySelection,
        ):
            raise TypeError("_operational_selection has invalid type")
        if operational_selection is not None and self._candidate_batch_handoff is not None:
            raise ValueError("operational and historical Phase 5 authorities are exclusive")
        operational_loop = self._operational_selection_loop
        if operational_loop is not None and not isinstance(
            operational_loop, BoundedFixedTrajectorySelectionResult
        ):
            raise TypeError("_operational_selection_loop has invalid type")
        if operational_loop is not None and operational_selection is None:
            raise ValueError("operational selection loop lost its terminal selection")
        if (
            operational_loop is not None
            and operational_loop.selection.signature != operational_selection.signature
        ):
            raise ValueError("operational selection loop terminal lineage mismatch")
        phase5_algorithm = self.diagnostics.get("algorithm")
        route_marker = self.diagnostics.get("operational_route_marker")
        broad_route_declared = (
            self.diagnostics.get("operational_broad_fixed_metric_route") is True
        )
        joint_route_declared = (
            self.diagnostics.get("operational_joint_l_epsilon_route") is True
        )
        per_l_route_declared = bool(
            self.diagnostics.get("operational_per_l_epsilon_route") is True
            or broad_route_declared
            or joint_route_declared
        )
        expected_route_marker = (
            BROAD_FIXED_METRIC_OPERATIONAL_ROUTE
            if phase5_algorithm == _PHASE5_BROAD_FIXED_METRIC_ALGORITHM
            else (
                JOINT_L_EPSILON_OPERATIONAL_ROUTE
                if phase5_algorithm == _PHASE5_JOINT_L_EPSILON_ALGORITHM
                else None
            )
        )
        generic_operational_route = bool(
            per_l_route_declared
            and expected_route_marker is not None
            and route_marker == expected_route_marker
        )
        if broad_route_declared and joint_route_declared:
            raise ValueError("broad and compatibility joint routes are exclusive")
        if broad_route_declared and phase5_algorithm != _PHASE5_BROAD_FIXED_METRIC_ALGORITHM:
            raise ValueError("broad route marker/algorithm mismatch")
        if joint_route_declared and phase5_algorithm != _PHASE5_JOINT_L_EPSILON_ALGORITHM:
            raise ValueError("compatibility joint route marker/algorithm mismatch")
        if per_l_route_declared and not generic_operational_route:
            raise ValueError("operational per-L route marker/algorithm mismatch")
        if generic_operational_route and (
            operational_selection is not None or operational_loop is not None
        ):
            raise ValueError("generic operational route cannot carry legacy selection authority")
        private_work_manifest = (
            None
            if self._operational_private_work_manifest is None
            else dict(self._operational_private_work_manifest)
        )
        public_work_manifest = (
            None
            if self._operational_public_work_manifest is None
            else dict(
                validate_public_hmc_work_manifest(
                    self._operational_public_work_manifest
                )
            )
        )
        if (private_work_manifest is None) != (public_work_manifest is None):
            raise ValueError("operational public/private work manifests must be paired")
        if private_work_manifest is not None:
            if operational_loop is None and not generic_operational_route:
                raise ValueError("operational private work manifest lost its selection")
            public_manifest_hash = str(
                self.diagnostics.get("public_work_manifest_hash", "")
            )
            if public_work_manifest["manifest_hash"] != public_manifest_hash:
                raise ValueError("operational public work manifest hash changed")
            if (
                generic_operational_route
                and public_work_manifest.get("route_marker") != route_marker
            ):
                raise ValueError("generic operational manifest route marker mismatch")
            private_work_manifest = dict(
                validate_private_resolved_hmc_work_manifest(
                    private_work_manifest,
                    expected_public_manifest_hash=public_manifest_hash,
                )
            )
            reconciliation = validate_executed_hmc_work_reconciliation(
                self.diagnostics.get("executed_work_reconciliation", {}),
                expected_public_manifest_hash=public_manifest_hash,
                public_manifest=public_work_manifest,
            )
            if reconciliation["reconciliation_hash"] != self.diagnostics.get(
                "executed_work_reconciliation", {}
            ).get("reconciliation_hash"):
                raise ValueError("operational work reconciliation changed")
        object.__setattr__(
            self,
            "_operational_private_work_manifest",
            private_work_manifest,
        )
        object.__setattr__(
            self,
            "_operational_public_work_manifest",
            public_work_manifest,
        )
        if self.final_status == "passed":
            if self.hard_vetoes:
                raise ValueError("passed fixed-mass step stage cannot have hard vetoes")
            if operational_selection is None:
                if self.budget_ladder_result is None or not self.budget_ladder_result.passed:
                    raise ValueError("passed fixed-mass step stage requires passed ladder")
            elif operational_selection.disposition != "representative_selected":
                raise ValueError("passed operational Phase 5 requires a selected representative")
            if self.selected_step_payload is None or self.selected_step_hash is None:
                raise ValueError("passed fixed-mass step stage requires selected step")
            if self.repair_step_payload is not None or self.repair_step_hash is not None:
                raise ValueError("passed fixed-mass step stage cannot have repair step")
        elif self.repair_step_payload is not None or self.repair_step_hash is not None:
            if self.repair_step_payload is None or self.repair_step_hash is None:
                raise ValueError("repair step payload/hash must be paired")
            if self.selected_step_payload is not None or self.selected_step_hash is not None:
                raise ValueError("repair step cannot also populate selected step")
            if stable_config_hash(self.repair_step_payload) != self.repair_step_hash:
                raise ValueError("repair step hash mismatch")

    @property
    def passed(self) -> bool:
        return self.final_status == "passed"

    @property
    def selected_step_size(self) -> float | None:
        if self.selected_step_payload is None:
            return None
        return float(self.selected_step_payload["step_size"])

    @property
    def repair_step_size(self) -> float | None:
        if self.repair_step_payload is None:
            return None
        return float(self.repair_step_payload["step_size"])

    @property
    def artifact_hash(self) -> str:
        return stable_config_hash(self.payload())

    def private_evidence_ledger(self) -> Mapping[str, Any] | None:
        """Return aggregate operational evidence through a private-only API."""

        if self._operational_selection_loop is not None:
            return self._operational_selection_loop.private_evidence_ledger()
        if not (
            self.diagnostics.get("operational_per_l_epsilon_route") is True
            and self.diagnostics.get("operational_route_marker")
            in {
                BROAD_FIXED_METRIC_OPERATIONAL_ROUTE,
                JOINT_L_EPSILON_OPERATIONAL_ROUTE,
            }
        ):
            return None

        handoff = self._candidate_batch_handoff
        if handoff is None:
            raise ValueError(
                "generic operational route requires a private candidate batch"
            )
        candidates = tuple(self.diagnostics.get("candidates", ()))
        if len(candidates) != handoff.candidate_count:
            raise ValueError("generic private ledger candidate count mismatch")

        ladder_records: list[Mapping[str, Any]] = []
        ladder_round_count = 0
        tune_call_count = 0
        screen_call_count = 0
        repair_screen_call_count = 0
        for candidate in candidates:
            if not isinstance(candidate, Mapping):
                raise TypeError("generic private ledger candidate is not a mapping")
            ladder_payload = candidate.get("ladder_payload")
            if not isinstance(ladder_payload, Mapping):
                # Error candidates have no ladder object; preserve their
                # identity and failure record without fabricating work.
                ladder_records.append(
                    {
                        "round_index": int(candidate.get("round_index", 0)),
                        "grid_stage": str(candidate.get("grid_stage", "")),
                        "candidate_index": int(candidate.get("candidate_index", -1)),
                        "num_leapfrog_steps": int(
                            candidate.get("num_leapfrog_steps", 0)
                        ),
                        "ladder_artifact_hash": candidate.get("ladder_artifact_hash"),
                        "ladder_final_status": candidate.get("ladder_final_status"),
                        "run_error_type": candidate.get("run_error_type"),
                        "run_error_message": candidate.get("run_error_message"),
                        "ladder_present": False,
                    }
                )
                continue
            rounds = tuple(ladder_payload.get("rounds", ()))
            ladder_round_count += len(rounds)
            for round_payload in rounds:
                if not isinstance(round_payload, Mapping):
                    continue
                tune_payload = round_payload.get("tune_config_payload")
                screen_payload = round_payload.get("screen_config_payload")
                if isinstance(tune_payload, Mapping):
                    tune_call_count += 1
                if isinstance(screen_payload, Mapping):
                    screen_call_count += 1
                    if tune_payload is None:
                        repair_screen_call_count += 1
            ladder_records.append(
                {
                    "round_index": int(candidate.get("round_index", 0)),
                    "grid_stage": str(candidate.get("grid_stage", "")),
                    "candidate_index": int(candidate.get("candidate_index", -1)),
                    "num_leapfrog_steps": int(
                        candidate.get("num_leapfrog_steps", 0)
                    ),
                    "ladder_artifact_hash": candidate.get("ladder_artifact_hash"),
                    "ladder_final_status": candidate.get("ladder_final_status"),
                    "ladder_passed": bool(candidate.get("ladder_passed")),
                    "selected_round_index": candidate.get("selected_round_index"),
                    "selected_budget": candidate.get("selected_budget"),
                    "selected_step_size": candidate.get("selected_step_size"),
                    "screen_acceptance_rate": candidate.get("screen_acceptance_rate"),
                    "trajectory_length": candidate.get("trajectory_length"),
                    "trajectory_window_relation": candidate.get(
                        "trajectory_window_relation"
                    ),
                    "hard_vetoes": tuple(candidate.get("hard_vetoes", ())),
                    "continuation_vetoes": tuple(
                        candidate.get("continuation_vetoes", ())
                    ),
                    "repair_triggers": tuple(candidate.get("repair_triggers", ())),
                    "ladder_payload": dict(ladder_payload),
                    "ladder_present": True,
                }
            )

        policy = _validated_operational_candidate_handoff_policy(
            self.diagnostics.get(
                "operational_candidate_handoff_policy",
                _OPERATIONAL_CANDIDATE_HANDOFF_POLICY_STRICT,
            )
        )
        reconciliation = self.diagnostics.get("executed_work_reconciliation")
        if reconciliation is not None and not isinstance(reconciliation, Mapping):
            raise ValueError("generic private ledger reconciliation is invalid")
        start_lineage = self.diagnostics.get("operational_start_bank_lineage")
        if start_lineage is not None and not isinstance(start_lineage, Mapping):
            raise ValueError("generic private ledger start-bank lineage is invalid")
        return {
            "schema": "bayesfilter.hmc_fixed_trajectory_private_evidence_ledger.v1",
            "candidate_handoff_policy": candidate_handoff_policy_payload(policy),
            "handoff_screen_policy": self.config.handoff_screen_policy,
            "bounded_selection_signature": self.artifact_hash,
            "terminal_disposition": self.final_status,
            "candidate_batch_handoff_hash": handoff.handoff_hash,
            "candidate_batch_handoff": handoff.payload(),
            "candidate_batch_count": handoff.candidate_count,
            "candidate_batch_handoff_eligible_count": handoff.handoff_eligible_count,
            "verification_order_seed": handoff.verification_order_seed,
            "round_summaries": tuple(
                dict(item) for item in self.diagnostics.get("round_summaries", ())
            ),
            "candidate_ladders": tuple(ladder_records),
            "source_bank_lineage": None
            if start_lineage is None
            else dict(start_lineage),
            "manifest_lineage": {
                "route_marker": self.diagnostics.get("operational_route_marker"),
                "public_manifest_hash": self.diagnostics.get(
                    "public_work_manifest_hash"
                ),
                "private_manifest_hash": self.diagnostics.get(
                    "private_work_manifest_hash"
                ),
                "reconciliation_hash": None
                if reconciliation is None
                else reconciliation.get("reconciliation_hash"),
            },
            "aggregate_counts": {
                "candidate_count": len(candidates),
                "viable_candidate_count": int(
                    self.diagnostics.get("viable_candidate_count", 0)
                ),
                "nomination_candidate_count": int(
                    self.diagnostics.get("nomination_candidate_count", 0)
                ),
                "run_error_count": len(
                    tuple(self.diagnostics.get("candidate_run_errors", ()))
                ),
                "ladder_count": sum(
                    1 for record in ladder_records if record.get("ladder_present")
                ),
                "ladder_round_count": ladder_round_count,
                "tune_call_count": tune_call_count,
                "screen_call_count": screen_call_count,
                "repair_screen_call_count": repair_screen_call_count,
            },
            "executed_work_reconciliation": None
            if reconciliation is None
            else dict(reconciliation),
            "private_handoff_only": True,
            "raw_samples_exposed": False,
            "raw_start_bank_exposed": False,
            "stochastic_ranking_performed": False,
            "explanatory_intervals_are_promotion_criteria": False,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
        }

    def payload(self) -> Mapping[str, Any]:
        return {
            "schema": "bayesfilter.hmc_fixed_mass_step_stage.v1",
            "config": self.config.payload(),
            "windowed_stage_artifact_hash": self.windowed_stage_artifact_hash,
            "selected_bootstrap_kernel_hash": self.selected_bootstrap_kernel_hash,
            "adapter_signature": self.adapter_signature,
            "phase4_hmc_adapter_signature": self.phase4_hmc_adapter_signature,
            "ladder_adapter_signature": self.ladder_adapter_signature,
            "ladder_hmc_adapter_signature": self.ladder_hmc_adapter_signature,
            "adapted_mass_artifact_payload": self.adapted_mass_artifact_payload,
            "adapted_mass_artifact_signature": self.adapted_mass_artifact_signature,
            "initial_step_size": self.initial_step_size,
            "fixed_num_leapfrog_steps": self.fixed_num_leapfrog_steps,
            "target_dimension": self.target_dimension,
            "final_status": self.final_status,
            "diagnostic_role": self.diagnostic_role,
            "hard_vetoes": self.hard_vetoes,
            "repair_triggers": self.repair_triggers,
            "diagnostics": self.diagnostics,
            "budget_ladder_config_payload": self.budget_ladder_config_payload,
            "budget_ladder_result": None
            if self.budget_ladder_result is None
            else self.budget_ladder_result.payload(),
            "selected_step_payload": self.selected_step_payload,
            "selected_step_hash": self.selected_step_hash,
            "selected_step_size": self.selected_step_size,
            "repair_step_hash": self.repair_step_hash,
            "repair_step_available": self.repair_step_payload is not None,
            "repair_step_payload_exposed": False,
            "operational_selection_summary": None
            if self._operational_selection is None
            else {
                "schema": "bayesfilter.hmc_fixed_trajectory_selection_summary.v4",
                "selection_signature": self._operational_selection.signature,
                "disposition": self._operational_selection.disposition,
                "candidate_count": len(self._operational_selection.candidate_results),
                "replication_count_per_candidate": 3,
                "representative_signature": (
                    self._operational_selection.representative_signature
                ),
                "candidate_retune_failures": tuple(
                    item.payload()
                    for item in self._operational_selection.candidate_retune_failures
                ),
                "candidate_retune_failure_count": len(
                    self._operational_selection.candidate_retune_failures
                ),
                "retune_failure_scope": (
                    self._operational_selection.retune_failure_scope
                ),
                "retune_failure_reasons": (
                    self._operational_selection.retune_failure_reasons
                ),
                "retune_candidate_signature": (
                    self._operational_selection.retune_candidate_signature
                ),
                "raw_start_bank_exposed": False,
                "raw_samples_exposed": False,
                "candidate_mechanics_exposed": False,
                "stochastic_ranking_performed": False,
            },
            "operational_selection_repair_summary": None
            if self._operational_selection_loop is None
            else {
                "schema": "bayesfilter.hmc_bounded_selection_repair_summary.v2",
                "loop_signature": self._operational_selection_loop.signature,
                "attempt_count": len(self._operational_selection_loop.attempts),
                "max_attempts": self._operational_selection_loop.max_attempts,
                "terminal_disposition": (
                    self._operational_selection_loop.terminal_disposition
                ),
                "repair_count": len(
                    self._operational_selection_loop.repair_direction_history
                ),
                "repair_direction_history": (
                    self._operational_selection_loop.repair_direction_history
                ),
                "empirical_bracket_available": all(
                    item is not None
                    for item in self._operational_selection_loop.final_bracket
                ),
                "selection_repair_loop_exercised": len(
                    self._operational_selection_loop.attempts
                ) > 1,
                "repair_loop_validated": False,
                "step_veto_recovery_count": (
                    self._operational_selection_loop.step_veto_recovery_count
                ),
                "raw_step_history_exposed": False,
                "raw_start_bank_exposed": False,
                "raw_samples_exposed": False,
            },
            "operational_work_manifest_summary": None
            if self._operational_private_work_manifest is None
            else {
                "policy_id": self.diagnostics.get("operational_budget_policy_id"),
                "policy_hash": self.diagnostics.get("operational_budget_policy_hash"),
                "public_manifest_hash": self._operational_private_work_manifest.get(
                    "public_manifest_hash"
                ),
                "private_manifest_hash": self._operational_private_work_manifest.get(
                    "private_manifest_hash"
                ),
                "resolved_candidate_count": self._operational_private_work_manifest.get(
                    "resolved_candidate_count"
                ),
                "executed_work_reconciliation": self.diagnostics.get(
                    "executed_work_reconciliation"
                ),
                "accounting_scope": "through_fixed_mass_selection",
                "fresh_verification_accounted": False,
                "private_hmc_mechanics_exposed": False,
                "aggregate_counts_public_safe": True,
            },
            "frozen_mass_invariant": self.frozen_mass_invariant,
            "seed_report": self.seed_report,
            "diagnostic_roles": self.diagnostic_roles,
            "passed": self.passed,
            "reports_trajectory_tuning": False,
            "reports_fresh_final_verification": False,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
            "reports_gpu_or_xla_readiness": False,
            "nonclaims": self.nonclaims,
        }


def _phase5_candidate_batch_handoff(
    result: HMCFixedMassStepStageResult,
) -> _HMCPhase5CandidateBatchHandoff | None:
    """Return the validated private Phase 5 candidate batch, when one exists."""

    if not isinstance(result, HMCFixedMassStepStageResult):
        raise TypeError("result must be HMCFixedMassStepStageResult")
    handoff = result._candidate_batch_handoff
    candidate_count = int(result.diagnostics.get("candidate_count", 0))
    if handoff is None:
        if result._operational_selection is not None:
            # Operational v3 candidates live in the typed selection authority;
            # their diagnostic count does not imply a legacy v1 candidate batch.
            return None
        if candidate_count != 0:
            raise ValueError("completed Phase 5 candidates require a private handoff")
        is_current_joint = (
            result.diagnostics.get("algorithm") in _PHASE5_DIRECT_GRID_ALGORITHMS
        )
        historical_compatibility = (
            result.diagnostics.get("historical_phase5_compatibility_fixture") is True
            and not is_current_joint
        )
        if (
            result.final_status == "passed" or result.repair_step_payload is not None
        ) and not historical_compatibility:
            raise ValueError("selected or repair Phase 5 state requires a private handoff")
        return None
    if not isinstance(handoff, _HMCPhase5CandidateBatchHandoff):
        raise TypeError("invalid private Phase 5 candidate handoff")
    _validate_phase5_candidate_batch_handoff(result, handoff)
    return handoff


def _phase5_candidate_source_key(
    candidate: Mapping[str, Any],
) -> tuple[int, str, int]:
    return (
        int(candidate["round_index"]),
        str(candidate["grid_stage"]),
        int(candidate["candidate_index"]),
    )


def _phase5_normalize_optional_number(
    source: Mapping[str, Any],
    key: str,
) -> tuple[float | None, bool, bool]:
    raw_value = source.get(key)
    if raw_value is None:
        return None, False, False
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return None, True, False
    if not math.isfinite(value):
        return None, True, False
    return value, True, True


def _phase5_candidate_ladders_by_source(
    rounds: Sequence[Mapping[str, Any]],
) -> Mapping[tuple[int, str, int], FixedMassHMCTuningBudgetLadderResult]:
    ladders_by_source: dict[
        tuple[int, str, int], FixedMassHMCTuningBudgetLadderResult
    ] = {}
    for round_payload in rounds:
        expected_round_index = int(round_payload["round_index"])
        expected_grid_stage = str(round_payload["grid_stage"])
        ladders = round_payload.get("ladders_by_candidate_index", {})
        if not isinstance(ladders, Mapping):
            raise ValueError("Phase 5 round ladder mapping is unavailable")
        for candidate in tuple(round_payload.get("candidates", ())):
            if not isinstance(candidate, Mapping):
                raise TypeError("Phase 5 candidate must be a mapping")
            source_key = _phase5_candidate_source_key(candidate)
            if source_key[:2] != (expected_round_index, expected_grid_stage):
                raise ValueError("Phase 5 candidate source does not match its round")
            if source_key in ladders_by_source:
                raise ValueError("duplicate Phase 5 candidate source key")
            ladder = ladders.get(source_key[2])
            if ladder is None:
                if candidate.get("run_error_type") is None:
                    raise ValueError("completed Phase 5 candidate lost ladder provenance")
                continue
            if not isinstance(ladder, FixedMassHMCTuningBudgetLadderResult):
                raise TypeError("Phase 5 candidate ladder has invalid type")
            ladders_by_source[source_key] = ladder
    return ladders_by_source


def _phase5_ladder_target_scope(
    ladder: FixedMassHMCTuningBudgetLadderResult,
) -> str:
    for payload in (ladder.selected_config_payload, ladder.repair_config_payload):
        if isinstance(payload, Mapping) and payload.get("target_scope") is not None:
            return str(payload["target_scope"])
    return str(ladder.config.target_scope)


def _phase5_candidate_record(
    *,
    batch_ordinal: int,
    candidate: Mapping[str, Any],
    ladder: FixedMassHMCTuningBudgetLadderResult | None,
    handoff_screen_policy: str,
) -> _HMCPhase5CandidateRecord:
    source_key = _phase5_candidate_source_key(candidate)
    candidate_policy = _validate_handoff_screen_policy(
        candidate.get("handoff_screen_policy")
    )
    if candidate_policy != handoff_screen_policy:
        raise ValueError("Phase 5 candidate handoff policy mismatch")
    selected_step, selected_observed, selected_finite = (
        _phase5_normalize_optional_number(candidate, "selected_step_size")
    )
    acceptance, acceptance_observed, acceptance_finite = (
        _phase5_normalize_optional_number(candidate, "screen_acceptance_rate")
    )
    trajectory, trajectory_observed, trajectory_finite = (
        _phase5_normalize_optional_number(candidate, "trajectory_length")
    )
    if ladder is None:
        if candidate.get("run_error_type") is None:
            raise ValueError("non-error candidate requires ladder provenance")
        ladder_artifact_hash = None
        selected_step_hash = None
        repair_config_hash = None
        ladder_adapter_signature = None
        ladder_hmc_adapter_signature = None
        ladder_mass_artifact_signature = None
        ladder_target_scope = None
        ladder_target_dimension = None
    else:
        ladder_artifact_hash = str(ladder.artifact_hash)
        if stable_config_hash(ladder.payload()) != ladder_artifact_hash:
            raise ValueError("Phase 5 ladder artifact hash mismatch")
        source_ladder_hash = candidate.get("ladder_artifact_hash")
        if source_ladder_hash is None or str(source_ladder_hash) != ladder_artifact_hash:
            raise ValueError("Phase 5 candidate ladder lineage mismatch")
        selected_step_hash = ladder.selected_config_hash
        repair_config_hash = ladder.repair_config_hash
        ladder_adapter_signature = ladder.adapter_signature
        ladder_hmc_adapter_signature = ladder.hmc_adapter_signature
        ladder_mass_artifact_signature = ladder.mass_artifact_signature
        ladder_target_scope = _phase5_ladder_target_scope(ladder)
        ladder_target_dimension = ladder.target_dimension
        if bool(candidate.get("ladder_passed")) != bool(ladder.passed):
            raise ValueError("Phase 5 candidate ladder pass state mismatch")
        if str(candidate.get("ladder_final_status")) != str(ladder.final_status):
            raise ValueError("Phase 5 candidate ladder status mismatch")
        if selected_finite:
            if ladder.selected_round is None or ladder.selected_round.tuned_step_size is None:
                raise ValueError("Phase 5 selected step lost ladder source")
            if float(selected_step) != float(ladder.selected_round.tuned_step_size):
                raise ValueError("Phase 5 selected step does not match its ladder")
    handoff_eligible = bool(
        candidate.get("viable")
        if handoff_screen_policy == _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE
        else candidate.get("nomination_eligible")
    )
    return _HMCPhase5CandidateRecord(
        source_candidate_schema=str(candidate.get("schema", "")),
        batch_ordinal=int(batch_ordinal),
        source_round_index=source_key[0],
        source_grid_stage=source_key[1],
        source_round_candidate_index=source_key[2],
        num_leapfrog_steps=int(candidate["num_leapfrog_steps"]),
        handoff_screen_policy=handoff_screen_policy,
        ladder_final_status=str(candidate.get("ladder_final_status", "")),
        ladder_passed=bool(candidate.get("ladder_passed")),
        selected_round_index=candidate.get("selected_round_index"),
        selected_budget=candidate.get("selected_budget"),
        selected_step_size=selected_step,
        selected_step_size_observed=selected_observed,
        selected_step_size_finite=selected_finite,
        selected_step_hash=selected_step_hash,
        screen_acceptance_rate=acceptance,
        screen_acceptance_observed=acceptance_observed,
        screen_acceptance_finite=acceptance_finite,
        trajectory_length=trajectory,
        trajectory_length_observed=trajectory_observed,
        trajectory_length_finite=trajectory_finite,
        trajectory_window_relation=str(
            candidate.get("trajectory_window_relation", "unavailable")
        ),
        hard_vetoes=tuple(str(item) for item in candidate.get("hard_vetoes", ())),
        continuation_vetoes=tuple(
            str(item) for item in candidate.get("continuation_vetoes", ())
        ),
        repair_triggers=tuple(
            str(item) for item in candidate.get("repair_triggers", ())
        ),
        viable=bool(candidate.get("viable")),
        nomination_eligible=bool(candidate.get("nomination_eligible")),
        nomination_role=str(candidate.get("nomination_role", "")),
        handoff_eligible=handoff_eligible,
        ladder_artifact_hash=ladder_artifact_hash,
        repair_config_hash=repair_config_hash,
        ladder_adapter_signature=ladder_adapter_signature,
        ladder_hmc_adapter_signature=ladder_hmc_adapter_signature,
        ladder_mass_artifact_signature=ladder_mass_artifact_signature,
        ladder_target_scope=ladder_target_scope,
        ladder_target_dimension=ladder_target_dimension,
        candidate_error_type=candidate.get("run_error_type"),
    )


def _phase5_candidate_signal_records(
    records: Sequence[_HMCPhase5CandidateRecord],
) -> tuple[_HMCPhase5CandidateSignalRecord, ...]:
    signals: list[_HMCPhase5CandidateSignalRecord] = []
    seen: set[tuple[str, str, int]] = set()
    for record in records:
        for role, codes in (
            ("hard_veto", record.hard_vetoes),
            ("continuation_veto", record.continuation_vetoes),
            ("repair_trigger", record.repair_triggers),
        ):
            for code in codes:
                key = (role, code, record.batch_ordinal)
                if key in seen:
                    continue
                seen.add(key)
                signals.append(
                    _HMCPhase5CandidateSignalRecord(
                        role=role,
                        code=code,
                        source_batch_ordinal=record.batch_ordinal,
                    )
                )
    return tuple(signals)


def _phase5_candidate_reference(
    records: Sequence[_HMCPhase5CandidateRecord],
    source_key: tuple[int, str, int] | None,
) -> tuple[int | None, str | None]:
    if source_key is None:
        return None, None
    matches = [record for record in records if record.source_key == source_key]
    if len(matches) != 1:
        raise ValueError("Phase 5 candidate reference is ambiguous or missing")
    record = matches[0]
    return record.batch_ordinal, record.record_hash


def _phase5_verification_order_seed(
    records: Sequence[_HMCPhase5CandidateRecord],
    *,
    selected_batch_ordinal: int | None,
) -> tuple[int, ...]:
    eligible = [record.batch_ordinal for record in records if record.handoff_eligible]
    if selected_batch_ordinal is None:
        return tuple(eligible)
    if selected_batch_ordinal not in eligible:
        raise ValueError("selected Phase 5 candidate is not handoff eligible")
    return (selected_batch_ordinal, *(
        ordinal for ordinal in eligible if ordinal != selected_batch_ordinal
    ))


def _build_phase5_candidate_batch_handoff(
    *,
    result: HMCFixedMassStepStageResult,
    rounds: Sequence[Mapping[str, Any]],
    candidates: Sequence[Mapping[str, Any]],
    target_scope: str,
    selected_source_key: tuple[int, str, int] | None,
    repair_source_key: tuple[int, str, int] | None,
) -> _HMCPhase5CandidateBatchHandoff | None:
    candidate_items = tuple(candidates)
    if not candidate_items:
        return None
    ladders_by_source = _phase5_candidate_ladders_by_source(rounds)
    policy = _validate_handoff_screen_policy(result.config.handoff_screen_policy)
    records = tuple(
        _phase5_candidate_record(
            batch_ordinal=batch_ordinal,
            candidate=candidate,
            ladder=ladders_by_source.get(_phase5_candidate_source_key(candidate)),
            handoff_screen_policy=policy,
        )
        for batch_ordinal, candidate in enumerate(candidate_items)
    )
    selected_ordinal, selected_hash = _phase5_candidate_reference(
        records,
        selected_source_key,
    )
    repair_ordinal, repair_hash = _phase5_candidate_reference(
        records,
        repair_source_key,
    )
    source_context = _HMCPhase5CandidateSourceContext(
        schema_runtime_version="bayesfilter.hmc_phase5_candidate_batch_handoff.v1",
        phase5_config_hash=stable_config_hash(result.config.payload()),
        target_scope=str(target_scope),
        target_dimension=result.target_dimension,
        windowed_stage_artifact_hash=result.windowed_stage_artifact_hash,
        selected_bootstrap_kernel_hash=result.selected_bootstrap_kernel_hash,
        adapter_signature=result.adapter_signature,
        phase4_hmc_adapter_signature=result.phase4_hmc_adapter_signature,
        ladder_adapter_signature=result.ladder_adapter_signature,
        ladder_hmc_adapter_signature=result.ladder_hmc_adapter_signature,
        adapted_mass_artifact_signature=result.adapted_mass_artifact_signature,
        handoff_screen_policy=policy,
    )
    handoff = _HMCPhase5CandidateBatchHandoff(
        source_context=source_context,
        candidate_records=records,
        signal_records=_phase5_candidate_signal_records(records),
        final_status=result.final_status,
        selected_batch_ordinal=selected_ordinal,
        selected_record_hash=selected_hash,
        repair_batch_ordinal=repair_ordinal,
        repair_record_hash=repair_hash,
        verification_order_seed=_phase5_verification_order_seed(
            records,
            selected_batch_ordinal=selected_ordinal,
        ),
    )
    _validate_phase5_candidate_batch_handoff(result, handoff)
    return handoff


def _validate_phase5_candidate_batch_handoff(
    result: HMCFixedMassStepStageResult,
    handoff: _HMCPhase5CandidateBatchHandoff,
) -> None:
    records = handoff.candidate_records
    if handoff.handoff_hash != stable_config_hash(handoff.payload()):
        raise ValueError("candidate batch handoff hash mismatch")
    if any(record.record_hash != stable_config_hash(record.payload()) for record in records):
        raise ValueError("candidate batch record hash mismatch")
    if tuple(record.batch_ordinal for record in records) != tuple(range(len(records))):
        raise ValueError("candidate batch ordinals must be contiguous")
    source_keys = tuple(record.source_key for record in records)
    if len(set(source_keys)) != len(source_keys):
        raise ValueError("candidate batch source keys must be unique")
    if int(result.diagnostics.get("candidate_count", -1)) != len(records):
        raise ValueError("candidate batch count does not match Phase 5 diagnostics")
    context = handoff.source_context
    expected_context = {
        "phase5_config_hash": stable_config_hash(result.config.payload()),
        "target_dimension": result.target_dimension,
        "windowed_stage_artifact_hash": result.windowed_stage_artifact_hash,
        "selected_bootstrap_kernel_hash": result.selected_bootstrap_kernel_hash,
        "adapter_signature": result.adapter_signature,
        "phase4_hmc_adapter_signature": result.phase4_hmc_adapter_signature,
        "ladder_adapter_signature": result.ladder_adapter_signature,
        "ladder_hmc_adapter_signature": result.ladder_hmc_adapter_signature,
        "adapted_mass_artifact_signature": result.adapted_mass_artifact_signature,
        "handoff_screen_policy": result.config.handoff_screen_policy,
    }
    for name, expected in expected_context.items():
        if getattr(context, name) != expected:
            raise ValueError(f"candidate batch source context mismatch: {name}")
    if (
        result.config.target_scope is not None
        and context.target_scope != result.config.target_scope
    ):
        raise ValueError("candidate batch source context mismatch: target_scope")
    for record in records:
        if record.ladder_artifact_hash is None:
            continue
        if (
            record.ladder_mass_artifact_signature
            != context.adapted_mass_artifact_signature
            or record.ladder_target_scope != context.target_scope
            or record.ladder_target_dimension != context.target_dimension
        ):
            raise ValueError("candidate ladder lineage does not match batch context")
    expected_signals = _phase5_candidate_signal_records(records)
    if handoff.signal_records != expected_signals:
        raise ValueError("candidate batch signal provenance mismatch")
    expected_order = _phase5_verification_order_seed(
        records,
        selected_batch_ordinal=handoff.selected_batch_ordinal,
    )
    if handoff.verification_order_seed != expected_order:
        raise ValueError("candidate batch verification order mismatch")
    if handoff.final_status != result.final_status:
        raise ValueError("candidate batch final status mismatch")

    def referenced_record(
        ordinal: int | None,
        record_hash: str | None,
        role: str,
    ) -> _HMCPhase5CandidateRecord | None:
        if ordinal is None:
            if record_hash is not None:
                raise ValueError(f"{role} record hash requires an ordinal")
            return None
        if ordinal not in range(len(records)):
            raise ValueError(f"{role} candidate ordinal is out of range")
        record = records[ordinal]
        if record_hash != record.record_hash:
            raise ValueError(f"{role} candidate record hash mismatch")
        return record

    selected = referenced_record(
        handoff.selected_batch_ordinal,
        handoff.selected_record_hash,
        "selected",
    )
    repair = referenced_record(
        handoff.repair_batch_ordinal,
        handoff.repair_record_hash,
        "repair",
    )
    if result.final_status == "passed":
        if selected is None or repair is not None:
            raise ValueError("passed Phase 5 handoff requires selected-only reference")
        if not selected.handoff_eligible or selected.hard_vetoes or selected.continuation_vetoes:
            raise ValueError("selected Phase 5 candidate is not a valid handoff")
        if selected.num_leapfrog_steps != result.fixed_num_leapfrog_steps:
            raise ValueError("selected Phase 5 candidate leapfrog mismatch")
        if selected.selected_step_size != result.selected_step_size:
            raise ValueError("selected Phase 5 candidate step mismatch")
        if selected.selected_step_hash != result.selected_step_hash:
            raise ValueError("selected Phase 5 candidate step hash mismatch")
        selected_ladder_hash = result.diagnostics.get("selected_ladder_artifact_hash")
        if selected.ladder_artifact_hash != selected_ladder_hash:
            raise ValueError("selected Phase 5 candidate ladder mismatch")
        if (
            result.budget_ladder_result is None
            or selected.ladder_artifact_hash
            != result.budget_ladder_result.artifact_hash
        ):
            raise ValueError("selected Phase 5 candidate representative ladder mismatch")
        if (
            selected.ladder_adapter_signature != context.ladder_adapter_signature
            or selected.ladder_hmc_adapter_signature
            != context.ladder_hmc_adapter_signature
        ):
            raise ValueError("selected Phase 5 candidate adapter lineage mismatch")
    else:
        if selected is not None:
            raise ValueError("non-passed Phase 5 handoff cannot select a candidate")
        if result.final_status == "repair_or_retry" and result.repair_step_payload is not None:
            if repair is None:
                raise ValueError("Phase 5 repair handoff lost candidate provenance")
            if repair.repair_config_hash != result.repair_step_hash:
                raise ValueError("Phase 5 repair candidate hash mismatch")
            if (
                result.budget_ladder_result is None
                or repair.ladder_artifact_hash
                != result.budget_ladder_result.artifact_hash
            ):
                raise ValueError("Phase 5 repair representative ladder mismatch")
            if (
                repair.ladder_adapter_signature != context.ladder_adapter_signature
                or repair.ladder_hmc_adapter_signature
                != context.ladder_hmc_adapter_signature
            ):
                raise ValueError("Phase 5 repair adapter lineage mismatch")
            if repair.num_leapfrog_steps != int(
                result.repair_step_payload["num_leapfrog_steps"]
            ):
                raise ValueError("Phase 5 repair candidate leapfrog mismatch")
        elif repair is not None:
            raise ValueError("Phase 5 status cannot carry a repair reference")


@dataclass(frozen=True)
class HMCFrozenStepTrajectoryStageConfig:
    """Policy-level config for Phase 6 frozen-step trajectory tuning.

    The caller does not supply candidate leapfrog counts, leapfrog bounds,
    trajectory grids, target trajectory length, step size, mass windows, warmup
    budgets, or tuning budget schedules. Those mechanics are internal
    BayesFilter policy and are recorded only as diagnostic telemetry.
    """

    target_accept_prob: float = 0.70
    acceptance_band: tuple[float, float] = (0.65, 0.75)
    max_leapfrog_steps: int = _GEOMETRY_MAX_LEAPFROG
    trajectory_window_lower_multiplier: float = 0.3
    trajectory_window_upper_multiplier: float = 3.0
    handoff_screen_policy: str = _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE
    seed: tuple[int, int] = (20260621, 6)
    chain_execution_mode: str = "tf_function"
    use_xla: bool = False
    target_scope: str | None = None
    target_status_trace_policy: str = "none"
    mass_policy: str = "windowed_adaptive"
    public_timeout_budget_s: float | None = None
    public_timeout_started_perf_counter_s: float | None = None
    staged_timeout_policy: HMCStagedTimeoutPolicy | None = None
    staged_timeout_global_started_perf_counter_s: float | None = None
    staged_timeout_stage_started_perf_counter_s: float | None = None
    staged_timeout_enlargement_rounds: Mapping[str, int] | None = None
    source: str = "bayesfilter.inference.hmc_kernel_tuning.frozen_step_trajectory_stage"

    def __post_init__(self) -> None:
        target = float(self.target_accept_prob)
        if not math.isfinite(target) or not 0.0 < target < 1.0:
            raise ValueError("target_accept_prob must be finite and in (0, 1)")
        object.__setattr__(self, "target_accept_prob", target)
        object.__setattr__(
            self,
            "acceptance_band",
            _validate_band(self.acceptance_band, name="acceptance_band"),
        )
        object.__setattr__(
            self,
            "max_leapfrog_steps",
            _validate_max_leapfrog_steps(self.max_leapfrog_steps),
        )
        lower, upper = _validate_trajectory_window_multipliers(
            self.trajectory_window_lower_multiplier,
            self.trajectory_window_upper_multiplier,
        )
        object.__setattr__(self, "trajectory_window_lower_multiplier", lower)
        object.__setattr__(self, "trajectory_window_upper_multiplier", upper)
        object.__setattr__(
            self,
            "handoff_screen_policy",
            _validate_handoff_screen_policy(self.handoff_screen_policy),
        )
        object.__setattr__(self, "seed", _validate_seed(self.seed))
        mode = str(self.chain_execution_mode)
        if mode not in {"tf_function", "eager"}:
            raise ValueError("chain_execution_mode must be 'tf_function' or 'eager'")
        if self.use_xla and mode != "tf_function":
            raise ValueError("XLA HMC requires chain_execution_mode='tf_function'")
        object.__setattr__(self, "chain_execution_mode", mode)
        object.__setattr__(self, "use_xla", bool(self.use_xla))
        if self.target_scope is not None:
            scope = str(self.target_scope)
            if not scope:
                raise ValueError("target_scope must be non-empty when provided")
            object.__setattr__(self, "target_scope", scope)
        target_status_policy = str(self.target_status_trace_policy)
        if target_status_policy not in {"none", "per_chain_step"}:
            raise ValueError(
                "target_status_trace_policy must be 'none' or 'per_chain_step'"
            )
        object.__setattr__(self, "target_status_trace_policy", target_status_policy)
        mass_policy = str(self.mass_policy)
        if mass_policy not in {"windowed_adaptive", "fixed_identity"}:
            raise ValueError(
                "mass_policy must be 'windowed_adaptive' or 'fixed_identity'"
            )
        object.__setattr__(self, "mass_policy", mass_policy)
        timeout_budget = (
            None
            if self.public_timeout_budget_s is None
            else float(self.public_timeout_budget_s)
        )
        if timeout_budget is not None and (
            not math.isfinite(timeout_budget) or timeout_budget <= 0.0
        ):
            raise ValueError("public_timeout_budget_s must be positive and finite")
        object.__setattr__(self, "public_timeout_budget_s", timeout_budget)
        timeout_started = (
            None
            if self.public_timeout_started_perf_counter_s is None
            else float(self.public_timeout_started_perf_counter_s)
        )
        if timeout_started is not None and (
            not math.isfinite(timeout_started) or timeout_started < 0.0
        ):
            raise ValueError(
                "public_timeout_started_perf_counter_s must be finite and non-negative"
            )
        object.__setattr__(
            self,
            "public_timeout_started_perf_counter_s",
            timeout_started,
        )
        object.__setattr__(
            self,
            "staged_timeout_policy",
            _validate_staged_timeout_policy_or_none(self.staged_timeout_policy),
        )
        object.__setattr__(
            self,
            "staged_timeout_global_started_perf_counter_s",
            _validate_nonnegative_perf_counter_or_none(
                self.staged_timeout_global_started_perf_counter_s,
                name="staged_timeout_global_started_perf_counter_s",
            ),
        )
        object.__setattr__(
            self,
            "staged_timeout_stage_started_perf_counter_s",
            _validate_nonnegative_perf_counter_or_none(
                self.staged_timeout_stage_started_perf_counter_s,
                name="staged_timeout_stage_started_perf_counter_s",
            ),
        )
        object.__setattr__(
            self,
            "staged_timeout_enlargement_rounds",
            _validate_staged_timeout_enlargement_rounds(
                self.staged_timeout_enlargement_rounds
            ),
        )
        source = str(self.source)
        if not source:
            raise ValueError("source must be non-empty")
        object.__setattr__(self, "source", source)

    def payload(self) -> Mapping[str, Any]:
        return {
            "target_accept_prob": self.target_accept_prob,
            "acceptance_band": self.acceptance_band,
            "max_leapfrog_steps": self.max_leapfrog_steps,
            "trajectory_window_lower_multiplier": self.trajectory_window_lower_multiplier,
            "trajectory_window_upper_multiplier": self.trajectory_window_upper_multiplier,
            "handoff_screen_policy": self.handoff_screen_policy,
            "seed": self.seed,
            "chain_execution_mode": self.chain_execution_mode,
            "use_xla": self.use_xla,
            "target_scope": self.target_scope,
            "target_status_trace_policy": self.target_status_trace_policy,
            "mass_policy": self.mass_policy,
            "public_timeout_budget_s": self.public_timeout_budget_s,
            "public_timeout_started_perf_counter_s": self.public_timeout_started_perf_counter_s,
            "staged_timeout_policy": None
            if self.staged_timeout_policy is None
            else self.staged_timeout_policy.payload(),
            "staged_timeout_global_started_perf_counter_s": (
                self.staged_timeout_global_started_perf_counter_s
            ),
            "staged_timeout_stage_started_perf_counter_s": (
                self.staged_timeout_stage_started_perf_counter_s
            ),
            "staged_timeout_enlargement_rounds": None
            if self.staged_timeout_enlargement_rounds is None
            else dict(self.staged_timeout_enlargement_rounds),
            "source": self.source,
        }


@dataclass(frozen=True)
class HMCFrozenStepTrajectoryStageResult:
    """Phase 6 frozen-step trajectory handoff; not final verification evidence."""

    config: HMCFrozenStepTrajectoryStageConfig
    geometry_artifact_hash: str
    bootstrap_artifact_hash: str
    windowed_stage_artifact_hash: str
    fixed_mass_step_stage_artifact_hash: str
    selected_bootstrap_kernel_hash: str
    selected_step_hash: str
    adapter_signature: str
    phase4_hmc_adapter_signature: str
    phase5_ladder_hmc_adapter_signature: str
    trajectory_hmc_adapter_signature: str
    adapted_mass_artifact_payload: Mapping[str, Any]
    adapted_mass_artifact_signature: str
    frozen_step_size: float
    fixed_bootstrap_num_leapfrog_steps: int
    target_dimension: int
    candidate_generation: Mapping[str, Any]
    candidate_results: tuple[Mapping[str, Any], ...]
    selected_candidate_index: int | None
    selected_trajectory_payload: Mapping[str, Any] | None
    selected_trajectory_hash: str | None
    final_status: str
    diagnostic_role: str
    hard_vetoes: tuple[str, ...]
    repair_triggers: tuple[str, ...]
    diagnostics: Mapping[str, Any]
    frozen_mass_invariant: Mapping[str, Any]
    frozen_step_invariant: Mapping[str, Any]
    seed_report: Mapping[str, Any]
    diagnostic_roles: Mapping[str, str]
    nonclaims: tuple[str, ...] = FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS

    def __post_init__(self) -> None:
        for name in (
            "geometry_artifact_hash",
            "bootstrap_artifact_hash",
            "windowed_stage_artifact_hash",
            "fixed_mass_step_stage_artifact_hash",
            "selected_bootstrap_kernel_hash",
            "selected_step_hash",
            "adapter_signature",
            "phase4_hmc_adapter_signature",
            "phase5_ladder_hmc_adapter_signature",
            "trajectory_hmc_adapter_signature",
            "adapted_mass_artifact_signature",
            "final_status",
            "diagnostic_role",
        ):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"{name} must be non-empty")
            object.__setattr__(self, name, value)
        step = float(self.frozen_step_size)
        if not math.isfinite(step) or step <= 0.0:
            raise ValueError("frozen_step_size must be positive and finite")
        object.__setattr__(self, "frozen_step_size", step)
        fixed_l = int(self.fixed_bootstrap_num_leapfrog_steps)
        if fixed_l <= 0:
            raise ValueError("fixed_bootstrap_num_leapfrog_steps must be positive")
        object.__setattr__(self, "fixed_bootstrap_num_leapfrog_steps", fixed_l)
        dimension = int(self.target_dimension)
        if dimension <= 0:
            raise ValueError("target_dimension must be positive")
        object.__setattr__(self, "target_dimension", dimension)
        object.__setattr__(
            self,
            "adapted_mass_artifact_payload",
            dict(self.adapted_mass_artifact_payload),
        )
        object.__setattr__(self, "candidate_generation", dict(self.candidate_generation))
        candidates = tuple(dict(item) for item in self.candidate_results)
        if not candidates and self.final_status != "hard_veto":
            raise ValueError(
                "frozen-step trajectory stage requires completed candidates "
                "unless returning a hard-veto closeout"
            )
        object.__setattr__(self, "candidate_results", candidates)
        selected = (
            None if self.selected_candidate_index is None else int(self.selected_candidate_index)
        )
        if selected is not None and selected not in range(len(candidates)):
            raise ValueError("selected_candidate_index must refer to a candidate")
        object.__setattr__(self, "selected_candidate_index", selected)
        selected_payload = (
            None
            if self.selected_trajectory_payload is None
            else dict(self.selected_trajectory_payload)
        )
        object.__setattr__(self, "selected_trajectory_payload", selected_payload)
        selected_hash = (
            None
            if self.selected_trajectory_hash is None
            else str(self.selected_trajectory_hash)
        )
        object.__setattr__(self, "selected_trajectory_hash", selected_hash)
        object.__setattr__(self, "hard_vetoes", _string_tuple(self.hard_vetoes))
        object.__setattr__(self, "repair_triggers", _string_tuple(self.repair_triggers))
        object.__setattr__(self, "diagnostics", dict(self.diagnostics))
        object.__setattr__(self, "frozen_mass_invariant", dict(self.frozen_mass_invariant))
        object.__setattr__(self, "frozen_step_invariant", dict(self.frozen_step_invariant))
        object.__setattr__(self, "seed_report", dict(self.seed_report))
        object.__setattr__(self, "diagnostic_roles", dict(self.diagnostic_roles))
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self.final_status == "passed":
            if self.hard_vetoes:
                raise ValueError("passed trajectory stage cannot have hard vetoes")
            if selected is None or selected_payload is None or selected_hash is None:
                raise ValueError("passed trajectory stage requires selected payload")
            selected_classification = candidates[selected].get("classification")
            if selected_classification != "passed_screen" and not (
                selected_classification == "nomination_screen"
                and _phase23_nomination_policy_active(
                    self.config.handoff_screen_policy
                )
            ):
                raise ValueError(
                    "selected trajectory candidate must have passed or be an "
                    "opt-in Phase 23 nomination screen"
                )

    @property
    def passed(self) -> bool:
        return self.final_status == "passed"

    @property
    def selected_candidate(self) -> Mapping[str, Any] | None:
        if self.selected_candidate_index is None:
            return None
        return self.candidate_results[self.selected_candidate_index]

    @property
    def selected_num_leapfrog_steps(self) -> int | None:
        candidate = self.selected_candidate
        return None if candidate is None else int(candidate["num_leapfrog_steps"])

    @property
    def selected_trajectory_length(self) -> float | None:
        candidate = self.selected_candidate
        return None if candidate is None else float(candidate["trajectory_length"])

    @property
    def artifact_hash(self) -> str:
        return stable_config_hash(self.payload())

    def payload(self) -> Mapping[str, Any]:
        return {
            "schema": "bayesfilter.hmc_frozen_step_trajectory_stage.v1",
            "config": self.config.payload(),
            "geometry_artifact_hash": self.geometry_artifact_hash,
            "bootstrap_artifact_hash": self.bootstrap_artifact_hash,
            "windowed_stage_artifact_hash": self.windowed_stage_artifact_hash,
            "fixed_mass_step_stage_artifact_hash": self.fixed_mass_step_stage_artifact_hash,
            "selected_bootstrap_kernel_hash": self.selected_bootstrap_kernel_hash,
            "selected_step_hash": self.selected_step_hash,
            "adapter_signature": self.adapter_signature,
            "phase4_hmc_adapter_signature": self.phase4_hmc_adapter_signature,
            "phase5_ladder_hmc_adapter_signature": self.phase5_ladder_hmc_adapter_signature,
            "trajectory_hmc_adapter_signature": self.trajectory_hmc_adapter_signature,
            "adapted_mass_artifact_payload": self.adapted_mass_artifact_payload,
            "adapted_mass_artifact_signature": self.adapted_mass_artifact_signature,
            "frozen_step_size": self.frozen_step_size,
            "fixed_bootstrap_num_leapfrog_steps": self.fixed_bootstrap_num_leapfrog_steps,
            "target_dimension": self.target_dimension,
            "candidate_generation": self.candidate_generation,
            "candidate_results": self.candidate_results,
            "selected_candidate_index": self.selected_candidate_index,
            "selected_candidate": self.selected_candidate,
            "selected_num_leapfrog_steps": self.selected_num_leapfrog_steps,
            "selected_trajectory_length": self.selected_trajectory_length,
            "selected_trajectory_payload": self.selected_trajectory_payload,
            "selected_trajectory_hash": self.selected_trajectory_hash,
            "final_status": self.final_status,
            "diagnostic_role": self.diagnostic_role,
            "hard_vetoes": self.hard_vetoes,
            "repair_triggers": self.repair_triggers,
            "diagnostics": self.diagnostics,
            "frozen_mass_invariant": self.frozen_mass_invariant,
            "frozen_step_invariant": self.frozen_step_invariant,
            "seed_report": self.seed_report,
            "diagnostic_roles": self.diagnostic_roles,
            "passed": self.passed,
            "reports_trajectory_tuning": self.passed,
            "reports_fresh_final_verification": False,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
            "reports_gpu_or_xla_readiness": False,
            "candidate_mechanics_are_diagnostic_telemetry_only": True,
            "nonclaims": self.nonclaims,
        }




@dataclass(frozen=True)
class HMCTuneVerifyRepairAttempt:
    """One Phase 7 tune-verify attempt and its private budget state."""

    attempt_index: int
    budget_policy_payload: Mapping[str, Any]
    incoming_state_payload: Mapping[str, Any] | None
    windowed_stage: HMCWindowedMassStageResult | None
    fixed_mass_step_stage: HMCFixedMassStepStageResult | None
    frozen_step_trajectory_stage: HMCFrozenStepTrajectoryStageResult | None
    verification_config_payload: Mapping[str, Any] | None
    verification_diagnostics: Mapping[str, Any]
    verification_callback_result: FixedMassHMCTuningBudgetCallbackResult
    final_status: str
    diagnostic_role: str
    hard_vetoes: tuple[str, ...]
    repair_triggers: tuple[str, ...]
    handoff_state_payload: Mapping[str, Any] | None

    def __post_init__(self) -> None:
        object.__setattr__(self, "attempt_index", int(self.attempt_index))
        object.__setattr__(
            self,
            "budget_policy_payload",
            dict(self.budget_policy_payload),
        )
        incoming = (
            None
            if self.incoming_state_payload is None
            else dict(self.incoming_state_payload)
        )
        object.__setattr__(self, "incoming_state_payload", incoming)
        config_payload = (
            None
            if self.verification_config_payload is None
            else dict(self.verification_config_payload)
        )
        object.__setattr__(self, "verification_config_payload", config_payload)
        object.__setattr__(
            self,
            "verification_diagnostics",
            dict(self.verification_diagnostics),
        )
        object.__setattr__(self, "final_status", str(self.final_status))
        object.__setattr__(self, "diagnostic_role", str(self.diagnostic_role))
        object.__setattr__(self, "hard_vetoes", _string_tuple(self.hard_vetoes))
        object.__setattr__(self, "repair_triggers", _string_tuple(self.repair_triggers))
        handoff = (
            None
            if self.handoff_state_payload is None
            else dict(self.handoff_state_payload)
        )
        object.__setattr__(self, "handoff_state_payload", handoff)
        if self.final_status == "passed":
            if self.hard_vetoes:
                raise ValueError("passed Phase 7 attempt cannot have hard vetoes")
            diagnostics = self.verification_diagnostics
            if diagnostics.get("sequential_rhat_verification") is True:
                if diagnostics.get("rhat_role") != "tuning_explanatory_only":
                    raise ValueError(
                        "passed ordinary attempt requires tuning_explanatory_only "
                        "R-hat role"
                    )
                if diagnostics.get("passed") is not True:
                    raise ValueError(
                        "passed Phase 7 attempt requires passed sequential verifier"
                    )
                # R-hat is retained as an explanatory diagnostic.  It is not a
                # tuning or fixed-kernel handoff gate; acceptance evidence,
                # finite target health, and the retained-draw minimum are the
                # verifier's admission criteria.
                if diagnostics.get("verification_min_retained_pass_gate_satisfied") is not True:
                    raise ValueError(
                        "passed Phase 7 attempt requires the minimum retained-draw gate"
                    )
                if diagnostics.get("cap_hit") is not False:
                    raise ValueError("passed Phase 7 attempt cannot report a verification cap hit")

    @property
    def passed(self) -> bool:
        return self.final_status == "passed"

    def payload(self) -> Mapping[str, Any]:
        return {
            "attempt_index": self.attempt_index,
            "budget_policy": self.budget_policy_payload,
            "incoming_state": self.incoming_state_payload,
            "windowed_stage": None
            if self.windowed_stage is None
            else self.windowed_stage.payload(),
            "fixed_mass_step_stage": None
            if self.fixed_mass_step_stage is None
            else self.fixed_mass_step_stage.payload(),
            "frozen_step_trajectory_stage": None
            if self.frozen_step_trajectory_stage is None
            else self.frozen_step_trajectory_stage.payload(),
            "verification_config_payload": self.verification_config_payload,
            "verification_diagnostics": self.verification_diagnostics,
            "verification_callback_result": self.verification_callback_result.payload(),
            "final_status": self.final_status,
            "diagnostic_role": self.diagnostic_role,
            "hard_vetoes": self.hard_vetoes,
            "repair_triggers": self.repair_triggers,
            "handoff_state": self.handoff_state_payload,
            "passed": self.passed,
        }


@dataclass(frozen=True)
class HMCTuneVerifyRepairLoopResult:
    """Phase 7 frozen-kernel handoff after tune/verify/repair."""

    config: HMCTuneVerifyRepairLoopConfig
    geometry_artifact_hash: str
    bootstrap_artifact_hash: str
    adapter_signature: str
    target_dimension: int
    attempts: tuple[HMCTuneVerifyRepairAttempt, ...]
    final_status: str
    diagnostic_role: str
    hard_vetoes: tuple[str, ...]
    repair_triggers: tuple[str, ...]
    final_kernel_payload: Mapping[str, Any] | None
    final_kernel_hash: str | None
    seed_report: Mapping[str, Any]
    diagnostic_roles: Mapping[str, str]
    terminal_budget_guard_payload: Mapping[str, Any] | None = None
    nonclaims: tuple[str, ...] = TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS

    def __post_init__(self) -> None:
        for name in (
            "geometry_artifact_hash",
            "bootstrap_artifact_hash",
            "adapter_signature",
            "final_status",
            "diagnostic_role",
        ):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"{name} must be non-empty")
            object.__setattr__(self, name, value)
        dimension = int(self.target_dimension)
        if dimension <= 0:
            raise ValueError("target_dimension must be positive")
        object.__setattr__(self, "target_dimension", dimension)
        attempts = tuple(self.attempts)
        if not attempts:
            raise ValueError("Phase 7 loop requires at least one attempt")
        object.__setattr__(self, "attempts", attempts)
        object.__setattr__(self, "hard_vetoes", _string_tuple(self.hard_vetoes))
        object.__setattr__(self, "repair_triggers", _string_tuple(self.repair_triggers))
        final_payload = (
            None if self.final_kernel_payload is None else dict(self.final_kernel_payload)
        )
        object.__setattr__(self, "final_kernel_payload", final_payload)
        final_hash = None if self.final_kernel_hash is None else str(self.final_kernel_hash)
        object.__setattr__(self, "final_kernel_hash", final_hash)
        object.__setattr__(self, "seed_report", dict(self.seed_report))
        object.__setattr__(self, "diagnostic_roles", dict(self.diagnostic_roles))
        terminal_guard = (
            None
            if self.terminal_budget_guard_payload is None
            else dict(self.terminal_budget_guard_payload)
        )
        object.__setattr__(self, "terminal_budget_guard_payload", terminal_guard)
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self.final_status == "passed":
            if self.hard_vetoes:
                raise ValueError("passed Phase 7 loop cannot have hard vetoes")
            if final_payload is None or final_hash is None:
                raise ValueError("passed Phase 7 loop requires final kernel")
            if stable_config_hash(final_payload) != final_hash:
                raise ValueError("final kernel hash mismatch")
            if not attempts[-1].passed:
                raise ValueError("passed Phase 7 loop requires a passed final attempt")
        if self.final_status in {
            "repair_or_retry",
            "budget_exhausted",
            "architecture_blocked",
            "hard_veto",
        }:
            if final_payload is not None or final_hash is not None:
                raise ValueError("non-passed Phase 7 loop cannot emit final kernel")

    @property
    def passed(self) -> bool:
        return self.final_status == "passed"

    @property
    def artifact_hash(self) -> str:
        return stable_config_hash(self.payload(include_final_mass_arrays=True))

    def private_evidence_ledger(self) -> Mapping[str, Any]:
        """Collect private Phase 5 evidence without changing serialized payloads."""

        attempt_ledgers = tuple(
            {
                "attempt_index": attempt.attempt_index,
                "fixed_mass_step_stage_artifact_hash": (
                    attempt.fixed_mass_step_stage.artifact_hash
                ),
                "evidence_ledger": ledger,
            }
            for attempt in self.attempts
            if attempt.fixed_mass_step_stage is not None
            and (
                ledger := attempt.fixed_mass_step_stage.private_evidence_ledger()
            )
            is not None
        )
        return {
            "schema": "bayesfilter.hmc_tune_verify_private_evidence_ledger.v1",
            "loop_artifact_hash": self.artifact_hash,
            "candidate_handoff_policy": (
                self.config.operational_candidate_handoff_policy
            ),
            "attempts": attempt_ledgers,
            "attempt_count": len(attempt_ledgers),
            "private_handoff_only": True,
            "raw_samples_exposed": False,
            "raw_start_bank_exposed": False,
        }

    def payload(self, *, include_final_mass_arrays: bool = True) -> Mapping[str, Any]:
        final_kernel_payload = self.final_kernel_payload
        if final_kernel_payload is not None and not include_final_mass_arrays:
            final_kernel_payload = _public_final_kernel_summary_from_private_payload(
                final_kernel_payload,
                config=self.config,
                phase7_final_kernel_hash=self.final_kernel_hash,
            )
        resolved_policy = _public_resolved_policy_payload(
            self.config,
            output_path_enabled=False,
            config_variant="ordinary_phase7_loop",
        )
        return {
            "schema": "bayesfilter.hmc_tune_verify_repair_loop.v1",
            "config": self.config.payload(),
            "resolved_policy": resolved_policy,
            "geometry_artifact_hash": self.geometry_artifact_hash,
            "bootstrap_artifact_hash": self.bootstrap_artifact_hash,
            "adapter_signature": self.adapter_signature,
            "target_dimension": self.target_dimension,
            "attempts": tuple(attempt.payload() for attempt in self.attempts),
            "attempt_count": len(self.attempts),
            "budget_history": tuple(
                attempt.budget_policy_payload for attempt in self.attempts
            ),
            "final_status": self.final_status,
            "diagnostic_role": self.diagnostic_role,
            "hard_vetoes": self.hard_vetoes,
            "repair_triggers": self.repair_triggers,
            "final_kernel_payload": final_kernel_payload,
            "final_kernel_hash": self.final_kernel_hash,
            "seed_report": self.seed_report,
            "diagnostic_roles": self.diagnostic_roles,
            "terminal_budget_guard": self.terminal_budget_guard_payload,
            "passed": self.passed,
            "budget_exhausted_is_non_promoting": self.final_status == "budget_exhausted",
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
            "reports_default_readiness": False,
            "reports_external_client_scientific_claim": False,
            "reports_gpu_or_xla_readiness": False,
            "nonclaims": self.nonclaims,
        }




@dataclass(frozen=True)
class HMCKernelTuningResult:
    """Public one-call HMC kernel tuning result and frozen-kernel handoff gate."""

    config: HMCKernelTuningConfig
    adapter_signature: str
    target_dimension: int
    geometry: HMCGeometryInitializationResult | None
    bootstrap: HMCBootstrapScreenResult | None
    tune_verify_repair_loop: HMCTuneVerifyRepairLoopResult | None
    final_status: str
    diagnostic_role: str
    hard_vetoes: tuple[str, ...]
    repair_triggers: tuple[str, ...]
    final_kernel_payload: Mapping[str, Any] | None
    final_kernel_hash: str | None
    artifact_path: str | None
    diagnostic_roles: Mapping[str, str]
    nonclaims: tuple[str, ...] = HMC_KERNEL_TUNING_PUBLIC_NONCLAIMS
    phase7_early_closeout_public_summary: Mapping[str, Any] | None = None
    failure_diagnostics: Mapping[str, Any] | None = None
    runner_binding_payload: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.config, HMCKernelTuningConfig):
            raise TypeError("config must be HMCKernelTuningConfig")
        signature = str(self.adapter_signature)
        if not signature:
            raise ValueError("adapter_signature must be non-empty")
        object.__setattr__(self, "adapter_signature", signature)
        dimension = int(self.target_dimension)
        if dimension <= 0:
            raise ValueError("target_dimension must be positive")
        object.__setattr__(self, "target_dimension", dimension)
        status = str(self.final_status)
        if not status:
            raise ValueError("final_status must be non-empty")
        role = str(self.diagnostic_role)
        if not role:
            raise ValueError("diagnostic_role must be non-empty")
        object.__setattr__(self, "final_status", status)
        object.__setattr__(self, "diagnostic_role", role)
        object.__setattr__(self, "hard_vetoes", _string_tuple(self.hard_vetoes))
        object.__setattr__(self, "repair_triggers", _string_tuple(self.repair_triggers))
        final_payload = (
            None if self.final_kernel_payload is None else dict(self.final_kernel_payload)
        )
        final_hash = None if self.final_kernel_hash is None else str(self.final_kernel_hash)
        object.__setattr__(self, "final_kernel_payload", final_payload)
        object.__setattr__(self, "final_kernel_hash", final_hash)
        artifact = None if self.artifact_path is None else str(self.artifact_path)
        object.__setattr__(self, "artifact_path", artifact)
        object.__setattr__(self, "diagnostic_roles", dict(self.diagnostic_roles))
        early_closeout = (
            None
            if self.phase7_early_closeout_public_summary is None
            else dict(self.phase7_early_closeout_public_summary)
        )
        object.__setattr__(
            self,
            "phase7_early_closeout_public_summary",
            early_closeout,
        )
        failure_diagnostics = (
            None
            if self.failure_diagnostics is None
            else dict(self.failure_diagnostics)
        )
        object.__setattr__(self, "failure_diagnostics", failure_diagnostics)
        runner_binding_payload = (
            None
            if self.runner_binding_payload is None
            else dict(self.runner_binding_payload)
        )
        if runner_binding_payload is not None:
            if not str(runner_binding_payload.get("runner_identity", "")):
                raise ValueError("runner_binding_payload requires runner_identity")
            binding_hash = str(runner_binding_payload.get("binding_hash", ""))
            if len(binding_hash) != 64:
                raise ValueError("runner_binding_payload requires a SHA-256 binding_hash")
            if runner_binding_payload.get("artifact_authority") is not False:
                raise ValueError("chain runner binding cannot own tuning authority")
        object.__setattr__(self, "runner_binding_payload", runner_binding_payload)
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)
        if self.geometry is not None:
            if self.geometry.adapter_signature != signature:
                raise ValueError("geometry adapter signature mismatch")
            if self.geometry.target_dimension != dimension:
                raise ValueError("geometry target dimension mismatch")
        if self.bootstrap is not None:
            if self.geometry is None:
                raise ValueError("bootstrap result requires geometry result")
            if self.bootstrap.adapter_signature != signature:
                raise ValueError("bootstrap adapter signature mismatch")
            if self.bootstrap.target_dimension != dimension:
                raise ValueError("bootstrap target dimension mismatch")
            if self.bootstrap.geometry_artifact_hash != self.geometry.artifact_hash:
                raise ValueError("bootstrap geometry artifact mismatch")
        if self.tune_verify_repair_loop is not None:
            if early_closeout is not None:
                raise ValueError("early closeout cannot coexist with Phase 7 loop")
            if self.bootstrap is None:
                raise ValueError("loop result requires bootstrap result")
            if self.tune_verify_repair_loop.adapter_signature != signature:
                raise ValueError("loop adapter signature mismatch")
            if self.tune_verify_repair_loop.target_dimension != dimension:
                raise ValueError("loop target dimension mismatch")
            if (
                self.tune_verify_repair_loop.bootstrap_artifact_hash
                != self.bootstrap.artifact_hash
            ):
                raise ValueError("loop bootstrap artifact mismatch")
        if status == "passed":
            if self.hard_vetoes:
                raise ValueError("passed public tuning result cannot have hard vetoes")
            if early_closeout is not None:
                raise ValueError("passed public tuning result cannot have early closeout")
            if self.tune_verify_repair_loop is None or not self.tune_verify_repair_loop.passed:
                raise ValueError("passed public tuning result requires passed Phase 7 loop")
            if final_payload is None or final_hash is None:
                raise ValueError("passed public tuning result requires final kernel")
            if stable_config_hash(final_payload) != final_hash:
                raise ValueError("public final kernel hash mismatch")
        elif final_payload is not None or final_hash is not None:
            raise ValueError("non-passed public tuning result cannot emit final kernel")

    @property
    def passed(self) -> bool:
        return self.final_status == "passed"

    @property
    def final_frozen_kernel_handoff(self) -> Mapping[str, Any] | None:
        return self.final_kernel_payload

    @property
    def artifact_hash(self) -> str:
        return stable_config_hash(self.payload(include_internal_diagnostics=True))

    def private_evidence_ledger(self) -> Mapping[str, Any] | None:
        """Return the private operational evidence ledger, when Phase 7 ran."""

        if self.tune_verify_repair_loop is None:
            return None
        return self.tune_verify_repair_loop.private_evidence_ledger()

    def payload(self, *, include_internal_diagnostics: bool = True) -> Mapping[str, Any]:
        resolved_policy = _public_resolved_policy_payload(
            self.config,
            output_path_enabled=self.artifact_path is not None,
            config_variant="ordinary_hmc",
        )
        return {
            "schema": "bayesfilter.hmc_kernel_tuning_result.v1",
            "config": self.config.payload(),
            "resolved_policy": resolved_policy,
            "adapter_signature": self.adapter_signature,
            "target_dimension": self.target_dimension,
            "geometry_artifact_hash": None
            if self.geometry is None
            else self.geometry.artifact_hash,
            "bootstrap_artifact_hash": None
            if self.bootstrap is None
            else self.bootstrap.artifact_hash,
            "loop_artifact_hash": None
            if self.tune_verify_repair_loop is None
            else self.tune_verify_repair_loop.artifact_hash,
            "geometry": None
            if self.geometry is None or not include_internal_diagnostics
            else self.geometry.payload(include_mass_arrays=False),
            "bootstrap": None
            if self.bootstrap is None or not include_internal_diagnostics
            else self.bootstrap.payload(),
            "tune_verify_repair_loop": None
            if self.tune_verify_repair_loop is None or not include_internal_diagnostics
            else self.tune_verify_repair_loop.payload(include_final_mass_arrays=False),
            "final_status": self.final_status,
            "diagnostic_role": self.diagnostic_role,
            "hard_vetoes": self.hard_vetoes,
            "repair_triggers": self.repair_triggers,
            "final_kernel_payload": self.final_kernel_payload,
            "final_kernel_hash": self.final_kernel_hash,
            "artifact_path": self.artifact_path,
            "diagnostic_roles": self.diagnostic_roles,
            "phase7_early_closeout_public_summary": (
                self.phase7_early_closeout_public_summary
            ),
            "failure_diagnostics": self.failure_diagnostics,
            "runner_binding_payload": self.runner_binding_payload,
            "passed": self.passed,
            "smoke_result_is_contract_only": self.config.is_smoke,
            "final_kernel_requires_phase7_pass": True,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
            "reports_default_readiness": False,
            "reports_external_client_scientific_claim": False,
            "reports_gpu_or_xla_readiness": False,
            "nonclaims": self.nonclaims,
        }


@dataclass(frozen=True)
class HMCStartBankDiagnosticResult:
    """Bounded stop-at-start-bank result; never a kernel handoff."""

    config: HMCKernelTuningConfig
    adapter_signature: str
    target_dimension: int
    geometry_artifact_hash: str | None
    bootstrap_artifact_hash: str | None
    bootstrap_final_status: str | None
    bootstrap_screen_count: int
    attempt_budget_summary: Mapping[str, Any] | None
    windowed_stage_config_payload: Mapping[str, Any] | None
    start_bank_qualification: Mapping[str, Any] | None
    start_bank_qualification_sha256: str | None
    final_status: str
    diagnostic_role: str
    hard_vetoes: tuple[str, ...]
    repair_triggers: tuple[str, ...]
    private_event_count: int
    private_event_hash: str | None
    artifact_path: str
    failure_diagnostics: Mapping[str, Any] | None = None
    nonclaims: tuple[str, ...] = HMC_START_BANK_DIAGNOSTIC_NONCLAIMS

    def __post_init__(self) -> None:
        if not isinstance(self.config, HMCKernelTuningConfig):
            raise TypeError("config must be HMCKernelTuningConfig")
        if self.config.preset != "diagnostic":
            raise ValueError("start-bank diagnostic requires preset='diagnostic'")
        signature = str(self.adapter_signature)
        if not signature:
            raise ValueError("adapter_signature must be non-empty")
        object.__setattr__(self, "adapter_signature", signature)
        dimension = int(self.target_dimension)
        if dimension <= 0:
            raise ValueError("target_dimension must be positive")
        object.__setattr__(self, "target_dimension", dimension)
        for name in ("geometry_artifact_hash", "bootstrap_artifact_hash"):
            value = getattr(self, name)
            if value is not None:
                normalized = str(value)
                if not normalized:
                    raise ValueError(f"{name} must be non-empty when present")
                object.__setattr__(self, name, normalized)
        bootstrap_status = (
            None
            if self.bootstrap_final_status is None
            else str(self.bootstrap_final_status)
        )
        if bootstrap_status == "":
            raise ValueError("bootstrap_final_status must be non-empty when present")
        object.__setattr__(self, "bootstrap_final_status", bootstrap_status)
        screen_count = int(self.bootstrap_screen_count)
        if screen_count < 0:
            raise ValueError("bootstrap_screen_count must be non-negative")
        object.__setattr__(self, "bootstrap_screen_count", screen_count)
        object.__setattr__(
            self,
            "attempt_budget_summary",
            None
            if self.attempt_budget_summary is None
            else dict(self.attempt_budget_summary),
        )
        object.__setattr__(
            self,
            "windowed_stage_config_payload",
            None
            if self.windowed_stage_config_payload is None
            else dict(self.windowed_stage_config_payload),
        )
        qualification = self.start_bank_qualification
        qualification_hash = self.start_bank_qualification_sha256
        if qualification is None:
            if qualification_hash is not None:
                raise ValueError("missing qualification cannot have a SHA256")
            normalized_qualification = None
        else:
            normalized_qualification, expected_hash = (
                _canonical_start_bank_qualification(qualification)
            )
            if str(qualification_hash) != expected_hash:
                raise ValueError("start-bank qualification SHA256 mismatch")
            for scope in normalized_qualification["scopes"].values():
                if int(scope["dimension"]) != dimension:
                    raise ValueError("start-bank qualification dimension mismatch")
            qualification_hash = expected_hash
        object.__setattr__(
            self,
            "start_bank_qualification",
            normalized_qualification,
        )
        object.__setattr__(
            self,
            "start_bank_qualification_sha256",
            qualification_hash,
        )
        status = str(self.final_status)
        role = str(self.diagnostic_role)
        if not status or not role:
            raise ValueError("final_status and diagnostic_role must be non-empty")
        object.__setattr__(self, "final_status", status)
        object.__setattr__(self, "diagnostic_role", role)
        object.__setattr__(self, "hard_vetoes", _string_tuple(self.hard_vetoes))
        object.__setattr__(
            self,
            "repair_triggers",
            _string_tuple(self.repair_triggers),
        )
        event_count = int(self.private_event_count)
        if event_count not in {0, 1}:
            raise ValueError("private_event_count must be zero or one")
        event_hash = (
            None if self.private_event_hash is None else str(self.private_event_hash)
        )
        boundary_observed = normalized_qualification is not None
        if boundary_observed != (event_count == 1 and bool(event_hash)):
            raise ValueError(
                "qualification and private start-bank event must coexist exactly"
            )
        if status == "diagnostic_boundary_reached":
            if not boundary_observed or self.hard_vetoes:
                raise ValueError(
                    "valid start-bank boundary requires one qualification and no veto"
                )
            shadow_failure = normalized_qualification["scopes"][
                "shadow_all_windows"
            ]["failure_code"]
            if str(shadow_failure).startswith("shadow_"):
                raise ValueError("valid boundary result cannot contain shadow failure")
        object.__setattr__(self, "private_event_count", event_count)
        object.__setattr__(self, "private_event_hash", event_hash)
        artifact_path = str(self.artifact_path)
        if not artifact_path:
            raise ValueError("artifact_path must be non-empty")
        object.__setattr__(self, "artifact_path", artifact_path)
        object.__setattr__(
            self,
            "failure_diagnostics",
            None
            if self.failure_diagnostics is None
            else dict(self.failure_diagnostics),
        )
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("nonclaims must be non-empty")
        object.__setattr__(self, "nonclaims", nonclaims)

    @property
    def diagnostic_valid(self) -> bool:
        return self.final_status == "diagnostic_boundary_reached"

    @property
    def artifact_hash(self) -> str:
        return stable_config_hash(self.payload())

    def payload(self) -> Mapping[str, Any]:
        return {
            "schema": "bayesfilter.hmc_start_bank_diagnostic_result.v1",
            "config": self.config.payload(),
            "config_hash": stable_config_hash(self.config.payload()),
            "adapter_signature": self.adapter_signature,
            "target_dimension": self.target_dimension,
            "geometry_artifact_hash": self.geometry_artifact_hash,
            "bootstrap_artifact_hash": self.bootstrap_artifact_hash,
            "bootstrap_final_status": self.bootstrap_final_status,
            "bootstrap_screen_count": self.bootstrap_screen_count,
            "attempt_index": 0,
            "attempt_budget_summary": self.attempt_budget_summary,
            "windowed_stage_config_payload": self.windowed_stage_config_payload,
            "start_bank_qualification": self.start_bank_qualification,
            "start_bank_qualification_sha256": (
                self.start_bank_qualification_sha256
            ),
            "final_status": self.final_status,
            "diagnostic_role": self.diagnostic_role,
            "hard_vetoes": self.hard_vetoes,
            "repair_triggers": self.repair_triggers,
            "private_event_count": self.private_event_count,
            "private_event_hash": self.private_event_hash,
            "artifact_path": self.artifact_path,
            "failure_diagnostics": self.failure_diagnostics,
            "diagnostic_valid": self.diagnostic_valid,
            "post_boundary_stage_counts": {
                "semantic_mass_diagnostic": 0,
                "fixed_mass_step": 0,
                "trajectory_selection": 0,
                "fresh_verification": 0,
                "final_kernel_construction": 0,
                "retained_sampling": 0,
            },
            "final_kernel_payload": None,
            "final_kernel_hash": None,
            "retained_samples_written": False,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
            "reports_default_readiness": False,
            "reports_gpu_or_xla_readiness": False,
            "nonclaims": self.nonclaims,
        }


@dataclass(frozen=True)
class RetainedFrozenKernelAdapterReplayResult:
    """BayesFilter-owned replay of a verified retained fixed-kernel adapter.

    The final adapted mass is defined in the latent coordinate system of the
    Phase 4/bootstrap fixed-mass adapter, not in the base model coordinates.
    This result preserves that two-transform lineage so model repositories do
    not have to reconstruct HMC/filtering mechanics locally.
    """

    adapter: Any
    adapted_mass_artifact: PrecomputedMassArtifact
    contract: Mapping[str, Any]
    final_kernel_payload: Mapping[str, Any]
    nonclaims: tuple[str, ...] = RETAINED_FROZEN_KERNEL_REPLAY_NONCLAIMS

    def __post_init__(self) -> None:
        if not isinstance(self.adapted_mass_artifact, PrecomputedMassArtifact):
            raise TypeError("adapted_mass_artifact must be PrecomputedMassArtifact")
        contract = dict(self.contract)
        final_payload = dict(self.final_kernel_payload)
        replay_role = str(
            contract.get("replay_role", REPLAY_ROLE_MECHANICS_ONLY)
        )
        if replay_role not in {
            REPLAY_ROLE_MECHANICS_ONLY,
            REPLAY_ROLE_CLAIM_BEARING_RETAINED,
        }:
            raise ValueError("replay contract has an unknown replay_role")
        claim_bearing = contract.get("claim_bearing_artifact_authority", False)
        if not isinstance(claim_bearing, bool):
            raise ValueError(
                "replay contract claim_bearing_artifact_authority must be Boolean"
            )
        if claim_bearing != (
            replay_role == REPLAY_ROLE_CLAIM_BEARING_RETAINED
        ):
            raise ValueError("replay role and claim-bearing authority disagree")
        contract["replay_role"] = replay_role
        contract["claim_bearing_artifact_authority"] = claim_bearing
        final_signature = str(contract.get("final_hmc_adapter_signature", ""))
        if not final_signature:
            raise ValueError("replay contract missing final_hmc_adapter_signature")
        if stable_adapter_signature(self.adapter) != final_signature:
            raise ValueError("replay adapter signature does not match contract")
        mass_signature = str(contract.get("adapted_mass_artifact_signature", ""))
        if not mass_signature:
            raise ValueError("replay contract missing adapted mass signature")
        if _mass_artifact_signature(self.adapted_mass_artifact) != mass_signature:
            raise ValueError("adapted mass signature does not match contract")
        nonclaims = tuple(str(item) for item in self.nonclaims)
        if not nonclaims:
            raise ValueError("nonclaims must be non-empty")
        object.__setattr__(self, "contract", contract)
        object.__setattr__(self, "final_kernel_payload", final_payload)
        object.__setattr__(self, "nonclaims", nonclaims)

    def payload(self) -> Mapping[str, Any]:
        return {
            "schema": "bayesfilter.retained_frozen_kernel_adapter_replay_result.v1",
            "contract": self.contract,
            "replay_role": self.contract["replay_role"],
            "claim_bearing_artifact_authority": self.contract[
                "claim_bearing_artifact_authority"
            ],
            "final_kernel_payload": {
                "public_handoff_schema": self.final_kernel_payload.get(
                    "public_handoff_schema"
                ),
                "target_scope": self.final_kernel_payload.get("target_scope"),
                "target_dimension": self.final_kernel_payload.get("target_dimension"),
                "fresh_fixed_kernel_verification_passed": self.final_kernel_payload.get(
                    "fresh_fixed_kernel_verification_passed"
                ),
                "adapted_mass_artifact_signature": self.final_kernel_payload.get(
                    "adapted_mass_artifact_signature"
                ),
                "phase7_final_kernel_hash": self.final_kernel_payload.get(
                    "phase7_final_kernel_hash"
                ),
            },
            "private_mass_arrays_publicized": False,
            "hmc_or_tuning_invoked": False,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
            "reports_default_readiness": False,
            "reports_external_client_scientific_claim": False,
            "reports_gpu_or_xla_readiness": False,
            "nonclaims": self.nonclaims,
        }

    @property
    def step_size(self) -> float:
        value = self.final_kernel_payload.get("step_size")
        if value is None:
            raise ValueError("replay handoff is missing selected step size")
        return float(value)

    @property
    def num_leapfrog_steps(self) -> int:
        value = self.final_kernel_payload.get("num_leapfrog_steps")
        if value is None:
            raise ValueError("replay handoff is missing selected leapfrog count")
        return int(value)


def _validated_retained_replay_header(
    *,
    adapter: Any,
    tuning_payload: Mapping[str, Any],
    target_scope: str | None,
) -> tuple[str, int, Mapping[str, Any], Mapping[str, Any], str]:
    if not isinstance(tuning_payload, Mapping):
        raise TypeError("tuning_payload must be a mapping")
    if tuning_payload.get("schema") != "bayesfilter.hmc_kernel_tuning_result.v1":
        raise ValueError("tuning payload schema mismatch")
    if tuning_payload.get("passed") is not True or tuning_payload.get(
        "final_status"
    ) != "passed":
        raise ValueError("retained frozen-kernel replay requires passed tuning payload")
    if tuning_payload.get("hard_vetoes"):
        raise ValueError("retained frozen-kernel replay rejects hard-vetoed tuning payload")
    adapter_signature = stable_adapter_signature(adapter)
    if str(tuning_payload.get("adapter_signature", "")) != adapter_signature:
        raise ValueError("tuning payload adapter signature mismatch")
    dimension = int(tuning_payload.get("target_dimension", 0))
    if dimension <= 0:
        raise ValueError("tuning payload target_dimension must be positive")
    if int(getattr(adapter, "parameter_dim", dimension)) != dimension:
        raise ValueError("adapter parameter_dim does not match tuning payload")

    config_payload = _required_mapping(tuning_payload, "config")
    final_kernel_payload = _replay_final_kernel_payload(tuning_payload)
    if final_kernel_payload.get("fresh_fixed_kernel_verification_passed") is not True:
        raise ValueError("final kernel verification did not pass")
    scope = _resolve_replay_target_scope(
        adapter=adapter,
        config_payload=config_payload,
        final_kernel_payload=final_kernel_payload,
        target_scope=target_scope,
    )
    return (
        adapter_signature,
        dimension,
        config_payload,
        final_kernel_payload,
        scope,
    )


def _build_retained_frozen_kernel_hmc_adapter_from_validated_geometry(
    *,
    adapter: Any,
    tuning_payload: Mapping[str, Any],
    geometry: HMCGeometryInitializationResult,
    adapter_signature: str,
    dimension: int,
    final_kernel_payload: Mapping[str, Any],
    scope: str,
) -> RetainedFrozenKernelAdapterReplayResult:
    geometry_payload = _required_mapping(tuning_payload, "geometry")
    if geometry.artifact_hash != str(tuning_payload.get("geometry_artifact_hash", "")):
        raise ValueError("reconstructed geometry artifact hash mismatch")
    if geometry.mass_artifact_signature != str(
        geometry_payload.get("mass_artifact_signature", "")
    ):
        raise ValueError("reconstructed geometry mass signature mismatch")

    bootstrap_payload = _required_mapping(tuning_payload, "bootstrap")
    phase4_adapter = _build_bootstrap_fixed_mass_adapter(
        adapter=adapter,
        mass_artifact=geometry.mass_artifact,
        mass_signature=geometry.mass_artifact_signature,
        target_scope=scope,
        nonclaims=FIXED_MASS_STEP_STAGE_NONCLAIMS,
    )
    phase4_signature = stable_adapter_signature(phase4_adapter)
    expected_phase4_signature = _expected_phase4_adapter_signature(
        bootstrap_payload=bootstrap_payload,
        tuning_payload=tuning_payload,
    )
    if phase4_signature != expected_phase4_signature:
        raise ValueError("reconstructed Phase 4 HMC adapter signature mismatch")

    adapted_mass_payload = _required_mapping(
        final_kernel_payload,
        "adapted_mass_artifact_payload",
    )
    adapted_mass = PrecomputedMassArtifact.from_payload(
        adapted_mass_payload,
        expected_adapter_signature=phase4_signature,
        expected_dim=dimension,
    )
    adapted_mass_signature = _mass_artifact_signature(adapted_mass)
    if adapted_mass_signature != str(
        final_kernel_payload.get("adapted_mass_artifact_signature", "")
    ):
        raise ValueError("reconstructed adapted mass signature mismatch")

    final_adapter = _build_fixed_mass_hmc_adapter(
        adapter=phase4_adapter,
        mass_artifact=adapted_mass,
        mass_signature=adapted_mass_signature,
        target_scope=scope,
    )
    final_signature = stable_adapter_signature(final_adapter)
    expected_final_signature = _expected_final_adapter_signature(tuning_payload)
    if final_signature != expected_final_signature:
        raise ValueError("reconstructed final HMC adapter signature mismatch")

    contract = {
        "schema": "bayesfilter.retained_frozen_kernel_adapter_replay_contract.v1",
        "replay_role": REPLAY_ROLE_MECHANICS_ONLY,
        "claim_bearing_artifact_authority": False,
        "base_adapter_signature": adapter_signature,
        "geometry_artifact_hash": geometry.artifact_hash,
        "geometry_mass_artifact_signature": geometry.mass_artifact_signature,
        "phase4_hmc_adapter_signature": phase4_signature,
        "adapted_mass_parent_adapter_signature": adapted_mass.adapter_signature,
        "adapted_mass_artifact_signature": adapted_mass_signature,
        "final_hmc_adapter_signature": final_signature,
        "target_scope": scope,
        "target_dimension": dimension,
        "final_kernel_hash": tuning_payload.get("final_kernel_hash"),
        "hmc_or_tuning_invoked": False,
        "replay_owned_by_bayesfilter": True,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
    }
    return RetainedFrozenKernelAdapterReplayResult(
        adapter=final_adapter,
        adapted_mass_artifact=adapted_mass,
        contract=contract,
        final_kernel_payload=final_kernel_payload,
    )


def build_retained_frozen_kernel_hmc_adapter_from_tuning_payload(
    *,
    adapter: Any,
    tuning_payload: Mapping[str, Any],
    initial_position: Any,
    initial_covariance: Any | None = None,
    negative_hessian: Any | None = None,
    parameter_scales: Any | None = None,
    target_scope: str | None = None,
) -> RetainedFrozenKernelAdapterReplayResult:
    """Rebuild a mechanics-only adapter stack verified by one-call tuning.

    This compatibility helper performs no HMC execution and grants no retained
    or posterior authority.  Claim-adjacent consumers must use the explicit
    claim-bearing replay API, which validates the resolved-policy blockers
    before reconstruction.
    """

    (
        adapter_signature,
        dimension,
        _config_payload,
        final_kernel_payload,
        scope,
    ) = _validated_retained_replay_header(
        adapter=adapter,
        tuning_payload=tuning_payload,
        target_scope=target_scope,
    )
    geometry_payload = _required_mapping(tuning_payload, "geometry")
    geometry_config_payload = _required_mapping(geometry_payload, "config")
    geometry = initialize_hmc_kernel_geometry(
        adapter=adapter,
        initial_position=initial_position,
        config=_geometry_config_from_payload(geometry_config_payload),
        negative_hessian=negative_hessian,
        initial_covariance=initial_covariance,
        parameter_scales=parameter_scales,
    )
    return _build_retained_frozen_kernel_hmc_adapter_from_validated_geometry(
        adapter=adapter,
        tuning_payload=tuning_payload,
        geometry=geometry,
        adapter_signature=adapter_signature,
        dimension=dimension,
        final_kernel_payload=final_kernel_payload,
        scope=scope,
    )


def build_retained_frozen_kernel_hmc_adapter_from_tuning_result(
    *,
    adapter: Any,
    tuning_result: "HMCKernelTuningResult",
    initial_position: Any,
    initial_covariance: Any | None = None,
    negative_hessian: Any | None = None,
    parameter_scales: Any | None = None,
    target_scope: str | None = None,
) -> RetainedFrozenKernelAdapterReplayResult:
    """Replay passed tuning mechanics without granting retained authority.

    The result object retains the private in-memory phase handoffs needed to
    rebuild the verified adapter.  The helper assembles that private payload
    inside BayesFilter, then delegates validation and reconstruction to the
    mechanics-only compatibility boundary above.  Callers never need to
    assemble step size, trajectory, or mass-array fields themselves.
    """

    if not isinstance(tuning_result, HMCKernelTuningResult):
        raise TypeError("tuning_result must be HMCKernelTuningResult")
    if not tuning_result.passed:
        raise ValueError("retained frozen-kernel replay requires passed tuning result")
    if tuning_result.geometry is None or tuning_result.bootstrap is None:
        raise ValueError("passed tuning result is missing geometry or bootstrap")
    loop = tuning_result.tune_verify_repair_loop
    if loop is None or not loop.passed or loop.final_kernel_payload is None:
        raise ValueError("passed tuning result is missing private Phase 7 handoff")
    resolved_policy = _public_resolved_policy_payload(
        tuning_result.config,
        output_path_enabled=tuning_result.artifact_path is not None,
        config_variant="ordinary_hmc",
    )
    private_payload = {
        "schema": "bayesfilter.hmc_kernel_tuning_result.v1",
        "config": tuning_result.config.payload(),
        "resolved_policy": resolved_policy,
        "adapter_signature": tuning_result.adapter_signature,
        "target_dimension": tuning_result.target_dimension,
        "geometry_artifact_hash": tuning_result.geometry.artifact_hash,
        "bootstrap_artifact_hash": tuning_result.bootstrap.artifact_hash,
        "loop_artifact_hash": loop.artifact_hash,
        "geometry": tuning_result.geometry.payload(include_mass_arrays=True),
        "bootstrap": tuning_result.bootstrap.payload(),
        "tune_verify_repair_loop": loop.payload(include_final_mass_arrays=True),
        "final_status": tuning_result.final_status,
        "diagnostic_role": tuning_result.diagnostic_role,
        "hard_vetoes": tuning_result.hard_vetoes,
        "repair_triggers": tuning_result.repair_triggers,
        "final_kernel_payload": loop.final_kernel_payload,
        "final_kernel_hash": loop.final_kernel_hash,
        "passed": True,
    }
    if any(
        value is not None
        for value in (initial_covariance, negative_hessian, parameter_scales)
    ):
        return build_retained_frozen_kernel_hmc_adapter_from_tuning_payload(
            adapter=adapter,
            tuning_payload=private_payload,
            initial_position=initial_position,
            initial_covariance=initial_covariance,
            negative_hessian=negative_hessian,
            parameter_scales=parameter_scales,
            target_scope=target_scope,
        )

    import tensorflow as tf

    try:
        supplied_position = tf.convert_to_tensor(initial_position, dtype=tf.float64)
        bound_position = tf.convert_to_tensor(
            tuning_result.geometry.mass_artifact.position,
            dtype=tf.float64,
        )
    except (TypeError, ValueError) as exc:
        raise ValueError("replay initial position must be a numeric vector") from exc
    if (
        supplied_position.shape.rank != 1
        or bound_position.shape.rank != 1
        or supplied_position.shape != bound_position.shape
    ):
        raise ValueError("replay initial position does not match result-bound geometry")
    try:
        tf.debugging.assert_all_finite(
            supplied_position,
            "replay initial position must be finite",
        )
        tf.debugging.assert_equal(supplied_position, bound_position)
    except tf.errors.InvalidArgumentError as exc:
        raise ValueError(
            "replay initial position does not match result-bound geometry"
        ) from exc
    (
        adapter_signature,
        dimension,
        _config_payload,
        final_kernel_payload,
        scope,
    ) = _validated_retained_replay_header(
        adapter=adapter,
        tuning_payload=private_payload,
        target_scope=target_scope,
    )
    return _build_retained_frozen_kernel_hmc_adapter_from_validated_geometry(
        adapter=adapter,
        tuning_payload=private_payload,
        geometry=tuning_result.geometry,
        adapter_signature=adapter_signature,
        dimension=dimension,
        final_kernel_payload=final_kernel_payload,
        scope=scope,
    )


def _require_claim_bearing_tuning_policy(
    tuning_payload: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Validate the policy gate required before claim-bearing replay.

    Serialized authority fields are evidence, not authority by themselves.
    Once a caller presents an apparently clear policy, recompute the ordinary
    epsilon/L policy from the repository-owned configuration payload and
    compare the two descriptions before allowing reconstruction.  This keeps
    a caller-edited blocker list from turning a mechanics artifact into a
    claim-bearing handoff.
    """

    resolved = tuning_payload.get("resolved_policy")
    if not isinstance(resolved, Mapping):
        raise ValueError(
            "claim-bearing replay requires a resolved_policy; "
            "payload is historical or mechanics-only"
        )
    blockers = resolved.get("claim_bearing_blockers")
    if not isinstance(blockers, (tuple, list)):
        raise ValueError(
            "claim-bearing replay requires an explicit claim_bearing_blockers list"
        )
    normalized = tuple(str(item) for item in blockers if str(item))
    primary = resolved.get("claim_bearing_blocker")
    if normalized or (primary not in (None, "")):
        observed = normalized or (str(primary),)
        raise ValueError(
            "claim-bearing replay is blocked by: " + ", ".join(observed)
        )
    if resolved.get("claim_bearing_artifact_authority") is not True:
        raise ValueError(
            "claim-bearing replay requires claim_bearing_artifact_authority=True"
        )

    config_payload = tuning_payload.get("config")
    if not isinstance(config_payload, Mapping):
        # Durable mechanics artifacts use a distinct name so that their
        # policy inputs cannot be confused with the outer replay envelope.
        config_payload = tuning_payload.get("tuning_config")
    if not isinstance(config_payload, Mapping):
        raise ValueError(
            "claim-bearing replay requires repository-owned tuning_config; "
            "policy fields alone cannot grant authority"
        )
    # Pre-migration artifacts remain blocked even if someone removes their old
    # blocker list. Both descriptions must bind the repaired TF/TFP backend;
    # subsequent geometry, kernel and target checks still govern actual replay.
    if any(payload.get("runtime_backend_policy") != _ORDINARY_RUNTIME_BACKEND_POLICY_ID
           for payload in (config_payload, resolved)):
        raise ValueError(
            "claim-bearing replay backend identity is historical or mismatched: "
            + _ORDINARY_RUNTIME_NUMPY_POLICY_BLOCKER
        )
    algorithm_id = str(config_payload.get("algorithm_id", ""))
    if not algorithm_id:
        raise ValueError(
            "claim-bearing replay requires a non-empty tuning configuration "
            "algorithm_id"
        )
    engineering_bank = config_payload.get("engineering_probe_bank")
    if not isinstance(engineering_bank, Mapping) or not isinstance(
        engineering_bank.get("configured"), bool
    ):
        raise ValueError(
            "claim-bearing replay requires an explicit engineering-probe "
            "configuration flag"
        )
    expected_ordinary_policy = resolve_ordinary_hmc_selection_policy(
        algorithm_id,
        engineering_probe_covariance_multiplier_configured=bool(
            engineering_bank["configured"]
        ),
    )
    configured_policy = config_payload.get("ordinary_selection_policy")
    if not isinstance(configured_policy, Mapping) or stable_config_hash(
        configured_policy
    ) != stable_config_hash(expected_ordinary_policy):
        raise ValueError(
            "claim-bearing replay ordinary_selection_policy does not match "
            "the repository-owned tuning configuration"
        )
    resolved_ordinary_policy = resolved.get("ordinary_selection_policy")
    if not isinstance(resolved_ordinary_policy, Mapping) or stable_config_hash(
        resolved_ordinary_policy
    ) != stable_config_hash(expected_ordinary_policy):
        raise ValueError(
            "claim-bearing replay resolved_policy does not match the "
            "repository-owned tuning configuration"
        )
    expected_blockers = tuple(
        dict.fromkeys(
            tuple(
                str(item)
                for item in expected_ordinary_policy.get("claim_bearing_blockers", ())
                if str(item)
            )
        )
    )
    if normalized != expected_blockers:
        observed = ", ".join(normalized) if normalized else "<empty>"
        expected = ", ".join(expected_blockers) if expected_blockers else "<empty>"
        raise ValueError(
            "claim-bearing replay blocker list does not match repository "
            f"policy (observed {observed}; expected {expected})"
        )
    expected_primary = expected_blockers[0] if expected_blockers else None
    if primary not in (None, "") and str(primary) != expected_primary:
        raise ValueError(
            "claim-bearing replay primary blocker does not match repository policy"
        )
    if resolved.get("algorithm_id") != algorithm_id:
        raise ValueError(
            "claim-bearing replay resolved_policy algorithm_id does not match "
            "the tuning configuration"
        )
    if expected_blockers:
        raise ValueError(
            "claim-bearing replay is blocked by repository policy: "
            + ", ".join(expected_blockers)
        )
    return resolved


def _with_replay_role(
    replay: RetainedFrozenKernelAdapterReplayResult,
    *,
    role: str,
    claim_bearing: bool,
) -> RetainedFrozenKernelAdapterReplayResult:
    if claim_bearing != (role == REPLAY_ROLE_CLAIM_BEARING_RETAINED):
        raise ValueError("requested replay role and authority disagree")
    return dataclasses.replace(
        replay,
        contract={
            **dict(replay.contract),
            "replay_role": role,
            "claim_bearing_artifact_authority": bool(claim_bearing),
        },
    )


def build_mechanics_only_frozen_kernel_hmc_adapter_from_tuning_payload(
    **kwargs: Any,
) -> RetainedFrozenKernelAdapterReplayResult:
    """Explicit name for the non-claiming compatibility replay path."""

    return build_retained_frozen_kernel_hmc_adapter_from_tuning_payload(**kwargs)


def build_mechanics_only_frozen_kernel_hmc_adapter_from_tuning_result(
    **kwargs: Any,
) -> RetainedFrozenKernelAdapterReplayResult:
    """Explicit name for in-memory mechanics-only replay."""

    return build_retained_frozen_kernel_hmc_adapter_from_tuning_result(**kwargs)


def build_claim_bearing_retained_frozen_kernel_hmc_adapter_from_tuning_payload(
    **kwargs: Any,
) -> RetainedFrozenKernelAdapterReplayResult:
    """Replay only a policy-cleared serialized tuning result.

    The current ordinary route intentionally fails this check because its
    backend and shared-epsilon blockers remain active.  This entry point is a
    fail-closed boundary for a future reviewed claim-bearing route.
    """

    tuning_payload = kwargs.get("tuning_payload")
    if not isinstance(tuning_payload, Mapping):
        raise TypeError("tuning_payload must be a mapping")
    _require_claim_bearing_tuning_policy(tuning_payload)
    replay = build_retained_frozen_kernel_hmc_adapter_from_tuning_payload(**kwargs)
    return _with_replay_role(
        replay,
        role=REPLAY_ROLE_CLAIM_BEARING_RETAINED,
        claim_bearing=True,
    )


def build_claim_bearing_retained_frozen_kernel_hmc_adapter_from_tuning_result(
    **kwargs: Any,
) -> RetainedFrozenKernelAdapterReplayResult:
    """Replay only a policy-cleared in-memory tuning result."""

    tuning_result = kwargs.get("tuning_result")
    if not isinstance(tuning_result, HMCKernelTuningResult):
        raise TypeError("tuning_result must be HMCKernelTuningResult")
    _require_claim_bearing_tuning_policy(
        tuning_result.payload(include_internal_diagnostics=False)
    )
    replay = build_retained_frozen_kernel_hmc_adapter_from_tuning_result(**kwargs)
    return _with_replay_role(
        replay,
        role=REPLAY_ROLE_CLAIM_BEARING_RETAINED,
        claim_bearing=True,
    )


ADMITTED_KERNEL_MECHANICS_SCHEMA = (
    "bayesfilter.admitted_hmc_kernel_replay_artifact.v1"
)
_ADMITTED_KERNEL_MECHANICS_PAYLOAD_SCHEMA = (
    "bayesfilter.admitted_hmc_kernel_mechanics.v1"
)


def admitted_kernel_mechanics_payload_from_tuning_result(
    *,
    adapter: Any,
    tuning_result: "HMCKernelTuningResult",
    initial_position: Any,
    target_signature: str,
    target_scope: str,
    execution: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Extract the transition mechanics needed for durable kernel replay.

    Tuning lineage (bootstrap/window/Phase 7 artifact hashes and run-specific
    diagnostics) is deliberately excluded from this payload.  The mass arrays
    and adapter signatures are retained because they define the actual
    transition, while the ordinary artifact hash protects the persisted JSON
    from accidental edits.
    """

    replay = build_mechanics_only_frozen_kernel_hmc_adapter_from_tuning_result(
        adapter=adapter,
        tuning_result=tuning_result,
        initial_position=initial_position,
        target_scope=target_scope,
    )
    if tuning_result.geometry is None:
        raise ValueError("passed tuning result is missing geometry")
    base_signature = stable_adapter_signature(adapter)
    initial_mass = tuning_result.geometry.mass_artifact
    initial_mass_signature = _mass_artifact_signature(initial_mass)
    adapted_mass_signature = _mass_artifact_signature(replay.adapted_mass_artifact)
    resolved_policy = _public_resolved_policy_payload(
        tuning_result.config,
        output_path_enabled=tuning_result.artifact_path is not None,
        config_variant="ordinary_hmc",
    )
    mechanics = {
        "schema": _ADMITTED_KERNEL_MECHANICS_PAYLOAD_SCHEMA,
        "replay_role": REPLAY_ROLE_MECHANICS_ONLY,
        "authority_status": "mechanics_only_nonclaiming",
        "claim_bearing_artifact_authority": False,
        "claim_bearing_blockers": tuple(
            resolved_policy.get("claim_bearing_blockers", ())
        ),
        "resolved_policy": dict(resolved_policy),
        # Preserve the repository-owned inputs used to derive the policy.  A
        # future claim-bearing consumer can recompute the policy instead of
        # trusting a caller-edited blocker list.
        "tuning_config": dict(tuning_result.config.payload()),
        "target_signature": str(target_signature),
        "target_scope": str(target_scope),
        "target_dimension": int(tuning_result.target_dimension),
        "base_adapter_signature": base_signature,
        "phase4_hmc_adapter_signature": replay.contract[
            "phase4_hmc_adapter_signature"
        ],
        "final_hmc_adapter_signature": replay.contract[
            "final_hmc_adapter_signature"
        ],
        "mass_policy": str(tuning_result.config.mass_policy),
        "initial_mass_artifact_signature": initial_mass_signature,
        "adapted_mass_artifact_signature": adapted_mass_signature,
        "initial_mass_artifact_payload": initial_mass.to_payload(include_arrays=True),
        "adapted_mass_artifact_payload": replay.adapted_mass_artifact.to_payload(
            include_arrays=True
        ),
        "step_size": float(replay.step_size),
        "num_leapfrog_steps": int(replay.num_leapfrog_steps),
        "target_accept_prob": float(tuning_result.config.target_accept_prob),
        "acceptance_band": tuple(
            float(item) for item in tuning_result.config.acceptance_band
        ),
        "execution": dict(execution),
    }
    if not mechanics["target_signature"] or not mechanics["target_scope"]:
        raise ValueError("admitted kernel target identity must be non-empty")
    loop = tuning_result.tune_verify_repair_loop
    return {
        "schema": ADMITTED_KERNEL_MECHANICS_SCHEMA,
        "mechanics": mechanics,
        "mechanics_sha256": stable_config_hash(mechanics),
        "tuning_provenance": {
            "geometry_artifact_hash": tuning_result.geometry.artifact_hash,
            "bootstrap_artifact_hash": (
                None
                if tuning_result.bootstrap is None
                else tuning_result.bootstrap.artifact_hash
            ),
            "loop_artifact_hash": None if loop is None else loop.artifact_hash,
            "public_final_kernel_hash": tuning_result.final_kernel_hash,
            "tuning_artifact_path": tuning_result.artifact_path,
            "role": "explanatory_provenance_only_not_replay_admission",
        },
    }


def admitted_kernel_mechanics_payload_from_serialized_tuning_payload(
    *,
    adapter: Any,
    tuning_payload: Mapping[str, Any],
    initial_position: Any,
    target_signature: str,
    target_scope: str,
    execution: Mapping[str, Any],
    source_artifact_path: str,
    source_artifact_sha256: str,
) -> Mapping[str, Any]:
    """Migrate a passed serialized private tuning result into replay mechanics.

    Historical public handoffs redact the mechanics required for replay, but
    the in-process result payload preserves the passed attempt's stage
    handoffs. This function accepts only the fixed-identity route and rebuilds
    both retained adapter transforms before issuing a mechanics artifact.
    """

    if not isinstance(tuning_payload, Mapping):
        raise TypeError("serialized tuning payload must be a mapping")
    if tuning_payload.get("schema") != "bayesfilter.hmc_kernel_tuning_result.v1":
        raise ValueError("serialized tuning payload schema mismatch")
    if tuning_payload.get("passed") is not True or tuning_payload.get(
        "final_status"
    ) != "passed":
        raise ValueError("serialized tuning payload did not pass")
    if tuning_payload.get("hard_vetoes"):
        raise ValueError("serialized tuning payload has hard vetoes")

    dimension = int(tuning_payload.get("target_dimension", 0))
    if dimension <= 0 or int(getattr(adapter, "parameter_dim", -1)) != dimension:
        raise ValueError("serialized tuning target dimension mismatch")
    base_signature = stable_adapter_signature(adapter)
    if tuning_payload.get("adapter_signature") != base_signature:
        raise ValueError("serialized tuning base adapter signature mismatch")
    config = _required_mapping(tuning_payload, "config")
    if config.get("mass_policy") != "fixed_identity":
        raise ValueError("serialized tuning migration requires fixed identity mass")
    if config.get("target_scope") != str(target_scope):
        raise ValueError("serialized tuning target scope mismatch")

    position_values = tuple(float(item) for item in initial_position)
    if len(position_values) != dimension or any(value != 0.0 for value in position_values):
        raise ValueError("fixed-identity migration requires a zero initial position")
    identity = tuple(
        tuple(1.0 if row == column else 0.0 for column in range(dimension))
        for row in range(dimension)
    )
    geometry = _required_mapping(tuning_payload, "geometry")
    geometry_mass_payload = _required_mapping(geometry, "mass_artifact_payload")
    if geometry_mass_payload.get("covariance_source") != "identity":
        raise ValueError("serialized geometry is not the fixed identity geometry")
    initial_mass = PrecomputedMassArtifact(
        position=position_values,
        covariance=identity,
        factor=identity,
        adapter_signature=str(geometry_mass_payload.get("adapter_signature", "")),
        position_role=str(geometry_mass_payload.get("position_role", "")),
        covariance_source=str(geometry_mass_payload.get("covariance_source", "")),
        matrix_used_for_square_root=str(
            geometry_mass_payload.get("matrix_used_for_square_root", "")
        ),
        factor_orientation=str(
            geometry_mass_payload.get("factor_orientation", "row_right_transpose")
        ),
        source=str(geometry_mass_payload.get("source", "")),
        eigen_summary=geometry_mass_payload.get("eigen_summary"),
        precision_eigen_summary=geometry_mass_payload.get(
            "precision_eigen_summary"
        ),
        regularization_report=geometry_mass_payload.get("regularization_report"),
        log_jacobian_convention=str(
            geometry_mass_payload.get("log_jacobian_convention", "constant_omitted")
        ),
        nonclaims=tuple(geometry_mass_payload.get("nonclaims", ())),
    )
    if initial_mass.adapter_signature != base_signature:
        raise ValueError("serialized geometry adapter signature mismatch")
    initial_mass_signature = _mass_artifact_signature(initial_mass)
    if initial_mass_signature != geometry.get("mass_artifact_signature"):
        raise ValueError("reconstructed fixed identity geometry signature mismatch")

    bootstrap = _required_mapping(tuning_payload, "bootstrap")
    phase4_adapter = _build_bootstrap_fixed_mass_adapter(
        adapter=adapter,
        mass_artifact=initial_mass,
        mass_signature=initial_mass_signature,
        target_scope=str(target_scope),
        nonclaims=FIXED_MASS_STEP_STAGE_NONCLAIMS,
    )
    phase4_signature = stable_adapter_signature(phase4_adapter)
    if bootstrap.get("hmc_adapter_signature") != phase4_signature:
        raise ValueError("serialized bootstrap adapter signature mismatch")

    loop = _required_mapping(tuning_payload, "tune_verify_repair_loop")
    attempts = loop.get("attempts")
    if not isinstance(attempts, Sequence) or isinstance(attempts, (str, bytes)):
        raise ValueError("serialized tuning loop is missing attempts")
    passed_attempts = tuple(
        attempt
        for attempt in attempts
        if isinstance(attempt, Mapping)
        and attempt.get("passed") is True
        and attempt.get("final_status") == "passed"
    )
    if len(passed_attempts) != 1:
        raise ValueError("serialized tuning migration requires one passed attempt")
    attempt = passed_attempts[0]
    windowed = _required_mapping(attempt, "windowed_stage")
    fixed_step = _required_mapping(attempt, "fixed_mass_step_stage")
    handoff = _required_mapping(attempt, "handoff_state")
    for label, stage in (("windowed", windowed), ("fixed-step", fixed_step)):
        stage_mass_policy = stage.get("mass_policy", _required_mapping(stage, "config").get("mass_policy"))
        if stage.get("passed") is not True or stage_mass_policy != "fixed_identity":
            raise ValueError(f"serialized {label} stage did not preserve fixed identity")
    phase4_candidates = (
        bootstrap.get("hmc_adapter_signature"),
        windowed.get("hmc_adapter_signature"),
        fixed_step.get("phase4_hmc_adapter_signature"),
    )
    if any(candidate != phase4_signature for candidate in phase4_candidates):
        raise ValueError("serialized Phase 4 adapter signatures disagree")

    adapted_mass_payload = _required_mapping(
        fixed_step, "adapted_mass_artifact_payload"
    )
    adapted_mass = PrecomputedMassArtifact.from_payload(
        adapted_mass_payload,
        expected_adapter_signature=phase4_signature,
        expected_dim=dimension,
    )
    adapted_mass_signature = _mass_artifact_signature(adapted_mass)
    expected_mass_signatures = (
        windowed.get("adapted_mass_artifact_signature"),
        fixed_step.get("adapted_mass_artifact_signature"),
        handoff.get("mass_artifact_signature"),
        _required_mapping(tuning_payload, "final_kernel_payload").get(
            "adapted_mass_artifact_signature"
        ),
    )
    if any(value != adapted_mass_signature for value in expected_mass_signatures):
        raise ValueError("serialized adapted mass signatures disagree")
    if adapted_mass_signature != windowed.get("initial_mass_artifact_signature"):
        raise ValueError("serialized fixed identity mass mutated")

    selected_step = _required_mapping(fixed_step, "selected_step_payload")
    step_size = float(selected_step.get("step_size", float("nan")))
    leapfrogs = int(selected_step.get("num_leapfrog_steps", 0))
    if not math.isfinite(step_size) or step_size <= 0.0 or leapfrogs <= 0:
        raise ValueError("serialized selected kernel mechanics are invalid")
    if float(fixed_step.get("selected_step_size", float("nan"))) != step_size:
        raise ValueError("serialized selected step size mismatch")
    if int(fixed_step.get("fixed_num_leapfrog_steps", 0)) != leapfrogs:
        raise ValueError("serialized selected leapfrog count mismatch")
    if float(handoff.get("selected_step_size", float("nan"))) != step_size:
        raise ValueError("serialized handoff step size mismatch")
    if int(handoff.get("selected_num_leapfrog_steps", 0)) != leapfrogs:
        raise ValueError("serialized handoff leapfrog count mismatch")
    for required_flag in (
        "final_kernel_handoff_complete",
        "mass_handoff_complete",
        "step_handoff_complete",
        "required_private_handoff_complete",
    ):
        if handoff.get(required_flag) is not True:
            raise ValueError(f"serialized handoff is incomplete: {required_flag}")

    final_adapter = _build_fixed_mass_hmc_adapter(
        adapter=phase4_adapter,
        mass_artifact=adapted_mass,
        mass_signature=adapted_mass_signature,
        target_scope=str(target_scope),
    )
    final_signature = stable_adapter_signature(final_adapter)
    final_signature_candidates = (
        fixed_step.get("ladder_hmc_adapter_signature"),
        selected_step.get("hmc_adapter_signature"),
    )
    if any(value != final_signature for value in final_signature_candidates):
        raise ValueError("serialized final adapter signatures disagree")

    target_accept_prob = float(config.get("target_accept_prob", float("nan")))
    acceptance_band = tuple(float(item) for item in config.get("acceptance_band", ()))
    if not math.isfinite(target_accept_prob) or len(acceptance_band) != 2:
        raise ValueError("serialized acceptance policy is invalid")
    public_final = _required_mapping(tuning_payload, "final_kernel_payload")
    if (
        float(public_final.get("target_accept_prob", float("nan")))
        != target_accept_prob
        or tuple(float(item) for item in public_final.get("acceptance_band", ()))
        != acceptance_band
        or public_final.get("fresh_fixed_kernel_verification_passed") is not True
    ):
        raise ValueError("serialized public acceptance handoff mismatch")

    resolved_policy = tuning_payload.get("resolved_policy")
    if not isinstance(resolved_policy, Mapping):
        # Old serialized payloads remain readable only as historical mechanics
        # diagnostics.  They cannot silently acquire claim-bearing authority.
        resolved_policy = {
            "schema": "bayesfilter.hmc_resolved_tuning_policy.historical_missing.v1",
            "claim_bearing_artifact_authority": False,
            "claim_bearing_blockers": ("missing_resolved_policy",),
            "claim_bearing_blocker": "missing_resolved_policy",
            "authority_status": "historical_diagnostic_only",
        }
    mechanics = {
        "schema": _ADMITTED_KERNEL_MECHANICS_PAYLOAD_SCHEMA,
        "replay_role": REPLAY_ROLE_MECHANICS_ONLY,
        "authority_status": "mechanics_only_nonclaiming",
        "claim_bearing_artifact_authority": False,
        "claim_bearing_blockers": tuple(
            resolved_policy.get("claim_bearing_blockers", ())
        ),
        "resolved_policy": dict(resolved_policy),
        # Preserve the source configuration for a future authority check;
        # legacy payloads remain mechanics-only when this field is absent.
        "tuning_config": dict(config),
        "target_signature": str(target_signature),
        "target_scope": str(target_scope),
        "target_dimension": dimension,
        "base_adapter_signature": base_signature,
        "phase4_hmc_adapter_signature": phase4_signature,
        "final_hmc_adapter_signature": final_signature,
        "mass_policy": "fixed_identity",
        "initial_mass_artifact_payload": initial_mass.to_payload(include_arrays=True),
        "adapted_mass_artifact_payload": adapted_mass.to_payload(include_arrays=True),
        "step_size": step_size,
        "num_leapfrog_steps": leapfrogs,
        "target_accept_prob": target_accept_prob,
        "acceptance_band": acceptance_band,
        "execution": dict(execution),
    }
    return {
        "schema": ADMITTED_KERNEL_MECHANICS_SCHEMA,
        "mechanics": mechanics,
        "mechanics_sha256": stable_config_hash(mechanics),
        "tuning_provenance": {
            "source_artifact_path": str(source_artifact_path),
            "source_artifact_sha256": str(source_artifact_sha256),
            "geometry_artifact_hash": tuning_payload.get("geometry_artifact_hash"),
            "bootstrap_artifact_hash": tuning_payload.get("bootstrap_artifact_hash"),
            "loop_artifact_hash": tuning_payload.get("loop_artifact_hash"),
            "public_final_kernel_hash": tuning_payload.get("final_kernel_hash"),
            "passed_attempt_index": int(attempt.get("attempt_index", -1)),
            "selected_step_hash": fixed_step.get("selected_step_hash"),
            "verification_acceptance_rate": handoff.get(
                "verification_acceptance_rate"
            ),
            "role": "explanatory_provenance_only_not_replay_admission",
        },
    }


def build_retained_frozen_kernel_hmc_adapter_from_mechanics_payload(
    *,
    adapter: Any,
    mechanics_payload: Mapping[str, Any],
    initial_position: Any,
    target_signature: str,
    target_scope: str,
    execution: Mapping[str, Any],
    target_accept_prob: float,
    acceptance_band: tuple[float, float],
    _expected_replay_role: str = REPLAY_ROLE_MECHANICS_ONLY,
) -> RetainedFrozenKernelAdapterReplayResult:
    """Rebuild a mechanics-only adapter without invoking the tuner.

    The underscored role argument is used only by the explicit
    claim-bearing wrapper below.  Ordinary callers must consume this function
    as mechanics-only and cannot infer posterior or scientific authority from
    its return value.
    """

    if not isinstance(mechanics_payload, Mapping):
        raise TypeError("mechanics_payload must be a mapping")
    if mechanics_payload.get("schema") != ADMITTED_KERNEL_MECHANICS_SCHEMA:
        raise ValueError("admitted kernel mechanics schema mismatch")
    observed_hash = mechanics_payload.get("mechanics_sha256")
    mechanics = dict(_required_mapping(mechanics_payload, "mechanics"))
    if mechanics.get("schema") != _ADMITTED_KERNEL_MECHANICS_PAYLOAD_SCHEMA:
        raise ValueError("admitted kernel mechanics payload schema mismatch")
    if observed_hash != stable_config_hash(mechanics):
        raise ValueError("admitted kernel mechanics fingerprint mismatch")
    expected_role = str(_expected_replay_role)
    if expected_role not in {
        REPLAY_ROLE_MECHANICS_ONLY,
        REPLAY_ROLE_CLAIM_BEARING_RETAINED,
    }:
        raise ValueError("unknown expected replay role")
    observed_role = mechanics.get("replay_role")
    if observed_role != expected_role:
        raise ValueError("admitted kernel replay role mismatch")
    observed_claim = mechanics.get("claim_bearing_artifact_authority")
    expected_claim = expected_role == REPLAY_ROLE_CLAIM_BEARING_RETAINED
    if observed_claim is not expected_claim:
        raise ValueError("admitted kernel replay authority role mismatch")
    if expected_claim:
        _require_claim_bearing_tuning_policy(mechanics)
    elif observed_claim is not False:
        raise ValueError("mechanics-only replay must not claim artifact authority")
    for key, expected in (
        ("target_signature", str(target_signature)),
        ("target_scope", str(target_scope)),
        ("target_dimension", int(getattr(adapter, "parameter_dim", -1))),
    ):
        if mechanics.get(key) != expected:
            raise ValueError(f"admitted kernel {key} mismatch")
    if dict(mechanics.get("execution", {})) != dict(execution):
        raise ValueError("admitted kernel execution settings mismatch")
    if float(mechanics.get("target_accept_prob", float("nan"))) != float(target_accept_prob):
        raise ValueError("admitted kernel target acceptance mismatch")
    observed_band = tuple(float(item) for item in mechanics.get("acceptance_band", ()))
    if observed_band != tuple(float(item) for item in acceptance_band):
        raise ValueError("admitted kernel acceptance band mismatch")
    mass_policy = str(mechanics.get("mass_policy", ""))
    if mass_policy not in {"fixed_identity", "windowed_adaptive"}:
        raise ValueError("admitted kernel mass policy mismatch")
    step_size = float(mechanics.get("step_size", float("nan")))
    leapfrogs = int(mechanics.get("num_leapfrog_steps", 0))
    if not math.isfinite(step_size) or step_size <= 0.0:
        raise ValueError("admitted kernel step size must be positive and finite")
    if leapfrogs <= 0:
        raise ValueError("admitted kernel leapfrog count must be positive")
    base_signature = stable_adapter_signature(adapter)
    if mechanics.get("base_adapter_signature") != base_signature:
        raise ValueError("admitted kernel base adapter signature mismatch")
    position = initial_position
    position_shape = getattr(position, "shape", None)
    if tuple(position_shape or ()) != (int(mechanics["target_dimension"]),):
        raise ValueError("admitted kernel initial position shape mismatch")
    initial_mass = PrecomputedMassArtifact.from_payload(
        _required_mapping(mechanics, "initial_mass_artifact_payload"),
        expected_adapter_signature=base_signature,
        expected_dim=int(mechanics["target_dimension"]),
    )
    if any(
        float(left) != float(right)
        for left, right in zip(position, initial_mass.position)
    ):
        raise ValueError("admitted kernel initial position mismatch")
    initial_mass_signature = _mass_artifact_signature(initial_mass)
    expected_initial_mass_signature = mechanics.get(
        "initial_mass_artifact_signature"
    )
    if (
        expected_initial_mass_signature is not None
        and expected_initial_mass_signature != initial_mass_signature
    ):
        raise ValueError("admitted kernel initial mass signature mismatch")
    phase4_adapter = _build_bootstrap_fixed_mass_adapter(
        adapter=adapter,
        mass_artifact=initial_mass,
        mass_signature=initial_mass_signature,
        target_scope=str(target_scope),
        nonclaims=FIXED_MASS_STEP_STAGE_NONCLAIMS,
    )
    if stable_adapter_signature(phase4_adapter) != mechanics[
        "phase4_hmc_adapter_signature"
    ]:
        raise ValueError("admitted kernel Phase 4 adapter signature mismatch")
    adapted_mass = PrecomputedMassArtifact.from_payload(
        _required_mapping(mechanics, "adapted_mass_artifact_payload"),
        expected_adapter_signature=str(mechanics["phase4_hmc_adapter_signature"]),
        expected_dim=int(mechanics["target_dimension"]),
    )
    adapted_mass_signature = _mass_artifact_signature(adapted_mass)
    expected_adapted_mass_signature = mechanics.get(
        "adapted_mass_artifact_signature"
    )
    if (
        expected_adapted_mass_signature is not None
        and expected_adapted_mass_signature != adapted_mass_signature
    ):
        raise ValueError("admitted kernel adapted mass signature mismatch")
    final_adapter = _build_fixed_mass_hmc_adapter(
        adapter=phase4_adapter,
        mass_artifact=adapted_mass,
        mass_signature=adapted_mass_signature,
        target_scope=str(target_scope),
    )
    final_signature = stable_adapter_signature(final_adapter)
    if final_signature != mechanics["final_hmc_adapter_signature"]:
        raise ValueError("admitted kernel final adapter signature mismatch")
    final_kernel_payload = dict(mechanics)
    return RetainedFrozenKernelAdapterReplayResult(
        adapter=final_adapter,
        adapted_mass_artifact=adapted_mass,
        contract={
            "schema": "bayesfilter.retained_frozen_kernel_adapter_replay_contract.v1",
            "replay_role": expected_role,
            "claim_bearing_artifact_authority": expected_claim,
            "base_adapter_signature": base_signature,
            "mass_policy": mass_policy,
            "geometry_mass_artifact_signature": initial_mass_signature,
            "phase4_hmc_adapter_signature": mechanics[
                "phase4_hmc_adapter_signature"
            ],
            "adapted_mass_artifact_signature": adapted_mass_signature,
            "final_hmc_adapter_signature": final_signature,
            "target_scope": str(target_scope),
            "target_dimension": int(mechanics["target_dimension"]),
            "hmc_or_tuning_invoked": False,
            "replay_owned_by_bayesfilter": True,
        },
        final_kernel_payload=final_kernel_payload,
    )


def build_claim_bearing_retained_frozen_kernel_hmc_adapter_from_mechanics_payload(
    **kwargs: Any,
) -> RetainedFrozenKernelAdapterReplayResult:
    """Replay a mechanics artifact only after its claim policy is cleared."""

    mechanics_payload = kwargs.get("mechanics_payload")
    if not isinstance(mechanics_payload, Mapping):
        raise TypeError("mechanics_payload must be a mapping")
    mechanics = mechanics_payload.get("mechanics")
    if not isinstance(mechanics, Mapping):
        raise ValueError("claim-bearing replay requires mechanics mapping")
    _require_claim_bearing_tuning_policy(mechanics)
    call_kwargs = dict(kwargs)
    # Keep the private role selector owned by this boundary. A caller cannot
    # downgrade a claim-bearing request with a conflicting value.
    call_kwargs.pop("_expected_replay_role", None)
    replay = build_retained_frozen_kernel_hmc_adapter_from_mechanics_payload(
        **call_kwargs,
        _expected_replay_role=REPLAY_ROLE_CLAIM_BEARING_RETAINED,
    )
    return replay


def _required_mapping(payload: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    value = payload.get(key)
    if not isinstance(value, Mapping):
        raise ValueError(f"retained frozen-kernel replay missing mapping: {key}")
    return value


def _replay_final_kernel_payload(tuning_payload: Mapping[str, Any]) -> Mapping[str, Any]:
    loop = _required_mapping(tuning_payload, "tune_verify_repair_loop")
    loop_payload = loop.get("final_kernel_payload")
    if isinstance(loop_payload, Mapping):
        return loop_payload
    top_level_payload = _required_mapping(tuning_payload, "final_kernel_payload")
    if top_level_payload.get("public_handoff_schema") == (
        "bayesfilter.hmc_public_frozen_kernel_handoff.v1"
    ):
        raise ValueError(
            "retained frozen-kernel replay requires private final kernel payload; "
            "public handoff alone is not replayable"
        )
    return top_level_payload


def _geometry_config_from_payload(
    payload: Mapping[str, Any],
) -> HMCGeometryInitializationConfig:
    return HMCGeometryInitializationConfig(
        geometry_scaling_c=float(payload.get("geometry_scaling_c", 0.5)),
        stability_guard=float(payload.get("stability_guard", 0.8)),
        covariance_jitter=float(payload.get("covariance_jitter", 1.0e-9)),
        eigenvalue_floor=(
            None
            if payload.get("eigenvalue_floor") is None
            else float(payload.get("eigenvalue_floor"))
        ),
        max_condition_number=(
            None
            if payload.get("max_condition_number") is None
            else float(payload.get("max_condition_number"))
        ),
        max_leapfrog_steps=int(
            payload.get("max_leapfrog_steps", _GEOMETRY_MAX_LEAPFROG)
        ),
        allow_geometry_fallback=bool(payload.get("allow_geometry_fallback", False)),
        position_role=str(payload.get("position_role", "initial_position")),
        negative_hessian_source=str(
            payload.get("negative_hessian_source", "negative_hessian")
        ),
        mass_policy=str(payload.get("mass_policy", "windowed_adaptive")),
        seed=tuple(int(item) for item in payload.get("seed", (20260621, 2))),
        source=str(payload.get("source", "bayesfilter.inference.hmc_kernel_tuning.geometry")),
    )


def _resolve_replay_target_scope(
    *,
    adapter: Any,
    config_payload: Mapping[str, Any],
    final_kernel_payload: Mapping[str, Any],
    target_scope: str | None,
) -> str:
    capability = value_score_capability(adapter)
    candidates = [
        target_scope,
        final_kernel_payload.get("target_scope"),
        config_payload.get("target_scope"),
        capability.target_scope,
    ]
    scope: str | None = None
    for candidate in candidates:
        if candidate is None:
            continue
        text = str(candidate)
        if not text:
            raise ValueError("retained frozen-kernel replay target_scope must be non-empty")
        if scope is None:
            scope = text
        elif scope != text:
            raise ValueError("retained frozen-kernel replay target_scope mismatch")
    if scope is None:
        raise ValueError("retained frozen-kernel replay requires target_scope")
    return scope


def _expected_phase4_adapter_signature(
    *,
    bootstrap_payload: Mapping[str, Any],
    tuning_payload: Mapping[str, Any],
) -> str:
    candidates: list[str] = []
    value = bootstrap_payload.get("hmc_adapter_signature")
    if value:
        candidates.append(str(value))
    for attempt in _replay_attempts(tuning_payload):
        for stage_name in (
            "windowed_stage",
            "fixed_mass_step_stage",
            "frozen_step_trajectory_stage",
        ):
            stage = attempt.get(stage_name)
            if not isinstance(stage, Mapping):
                continue
            for key in ("hmc_adapter_signature", "phase4_hmc_adapter_signature"):
                value = stage.get(key)
                if value:
                    candidates.append(str(value))
    return _single_replay_signature(
        candidates,
        label="Phase 4 HMC adapter signature",
    )


def _expected_final_adapter_signature(tuning_payload: Mapping[str, Any]) -> str:
    final_kernel = _replay_final_kernel_payload(tuning_payload)
    direct_signature = final_kernel.get("verification_hmc_adapter_signature")
    trajectory_candidates: list[str] = []
    fallback_candidates: list[str] = []
    for attempt in _replay_attempts(tuning_payload):
        trajectory = attempt.get("frozen_step_trajectory_stage")
        if isinstance(trajectory, Mapping) and trajectory.get("trajectory_hmc_adapter_signature"):
            trajectory_candidates.append(str(trajectory["trajectory_hmc_adapter_signature"]))
        fixed_mass = attempt.get("fixed_mass_step_stage")
        if isinstance(fixed_mass, Mapping) and fixed_mass.get("ladder_hmc_adapter_signature"):
            fallback_candidates.append(str(fixed_mass["ladder_hmc_adapter_signature"]))
        diagnostics = attempt.get("verification_diagnostics")
        if isinstance(diagnostics, Mapping):
            route = diagnostics.get("runner_route_summary")
            if isinstance(route, Mapping):
                for contract in route.get("distinct_static_runner_contracts", ()):
                    if not isinstance(contract, Mapping):
                        continue
                    static_payload = contract.get("static_contract_payload")
                    if isinstance(static_payload, Mapping) and static_payload.get(
                        "hmc_adapter_signature"
                    ):
                        fallback_candidates.append(str(static_payload["hmc_adapter_signature"]))
    candidates = trajectory_candidates or fallback_candidates
    if direct_signature:
        candidates = [str(direct_signature), *fallback_candidates]
    return _single_replay_signature(
        candidates,
        label="final HMC adapter signature",
    )


def _replay_attempts(tuning_payload: Mapping[str, Any]) -> tuple[Mapping[str, Any], ...]:
    loop = _required_mapping(tuning_payload, "tune_verify_repair_loop")
    attempts = loop.get("attempts")
    if not isinstance(attempts, Sequence) or isinstance(attempts, (str, bytes)):
        raise ValueError("retained frozen-kernel replay missing Phase 7 attempts")
    records = tuple(item for item in attempts if isinstance(item, Mapping))
    if not records:
        raise ValueError("retained frozen-kernel replay requires at least one attempt")
    passed = tuple(item for item in records if item.get("passed") is True)
    return passed if passed else records


def _single_replay_signature(candidates: Sequence[str], *, label: str) -> str:
    values = tuple(dict.fromkeys(str(item) for item in candidates if str(item)))
    if not values:
        raise ValueError(f"retained frozen-kernel replay missing {label}")
    if len(values) != 1:
        raise ValueError(f"retained frozen-kernel replay inconsistent {label}")
    return values[0]


def run_hmc_fixed_mass_step_stage(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
    windowed_stage: HMCWindowedMassStageResult,
    config: HMCFixedMassStepStageConfig | None = None,
    screen_callback: FixedMassScreenCallback | None = None,
    run_full_chain: RunFullChainFn = run_full_chain_tfp_hmc,
    _attempt_budget_policy: "_HMCAttemptBudgetPolicy" | None = None,
    _attempt_state: "_HMCPhaseAttemptState" | None = None,
    _progress_callback: LoopProgressCallback | None = None,
    _attempt_index: int | None = None,
    _max_leapfrog_steps: int = _GEOMETRY_MAX_LEAPFROG,
    _private_diagnostic_callback: PrivateTuningDiagnosticCallback | None = None,
    _repair_verification_reserved: bool = False,
    _selection_max_attempts: int = 1,
    _candidate_handoff_policy: str = _OPERATIONAL_CANDIDATE_HANDOFF_POLICY_STRICT,
) -> HMCFixedMassStepStageResult:
    """Run Phase 5 fixed-mass step tuning from a passed Phase 4 handoff.

    Phase 5 freezes the Phase 4 adapted mass and checked post-warmup start bank.
    The canonical ordinary route tunes epsilon independently over the complete
    broad primary L grid, then over one survivor-midpoint refinement grid. The
    shared-epsilon selector, P4-E anchor-offset grid, and legacy joint grid are
    retained only behind explicit lower-level compatibility identities.
    """

    cfg = HMCFixedMassStepStageConfig() if config is None else config
    if not isinstance(cfg, HMCFixedMassStepStageConfig):
        raise TypeError("config must be HMCFixedMassStepStageConfig")
    if not isinstance(geometry, HMCGeometryInitializationResult):
        raise TypeError("geometry must be HMCGeometryInitializationResult")
    if not isinstance(bootstrap, HMCBootstrapScreenResult):
        raise TypeError("bootstrap must be HMCBootstrapScreenResult")
    if not isinstance(windowed_stage, HMCWindowedMassStageResult):
        raise TypeError("windowed_stage must be HMCWindowedMassStageResult")
    _validate_fixed_mass_step_stage_inputs(
        adapter=adapter,
        geometry=geometry,
        bootstrap=bootstrap,
        windowed_stage=windowed_stage,
        config=cfg,
    )
    target_scope = _resolve_fixed_mass_step_stage_target_scope(adapter, cfg)
    max_leapfrog_steps = _validate_max_leapfrog_steps(_max_leapfrog_steps)
    selected_kernel = _mass_window_seed_kernel_from_windowed_stage(
        windowed_stage,
        bootstrap=bootstrap,
        geometry=geometry,
    )
    adapted_mass = _phase4_adapted_mass_artifact(windowed_stage)
    initial_step = _fixed_mass_step_initial_step(
        windowed_stage,
        attempt_state=_attempt_state,
    )
    qualified_step_size_upper_bound = _fixed_mass_step_upper_bound(windowed_stage)
    target_trajectory = float(geometry.target_trajectory_length)
    # Every Phase 5 policy consumes the same frozen Phase 4 metric coordinates.
    phase4_adapter = _phase4_latent_adapter_for_step_stage(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        target_scope=target_scope,
    )
    operational_warmup = windowed_stage.operational_warmup_result
    use_engineering_probe_route = bool(
        operational_warmup is not None
        and operational_warmup.private_start_bank_policy_id
        == PHASE7_ENGINEERING_PROBE_BANK_POLICY_ID
    )
    canonical_broad_route = bool(
        operational_warmup is not None
        and cfg.algorithm_id == ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID
        and not use_engineering_probe_route
    )
    legacy_shared_epsilon_route = bool(
        operational_warmup is not None
        and cfg.algorithm_id == LEGACY_OPERATIONAL_FIXED_TRAJECTORY_ALGORITHM_ID
        and not use_engineering_probe_route
    )
    use_operational_grid_route = bool(
        canonical_broad_route or use_engineering_probe_route
    )
    if (
        canonical_broad_route
        and max_leapfrog_steps != ORDINARY_BROAD_MAX_LEAPFROG_STEPS
    ):
        raise ValueError(
            "canonical ordinary Phase 5 requires the complete broad L grid "
            f"through {ORDINARY_BROAD_MAX_LEAPFROG_STEPS}"
        )
    if (
        cfg.algorithm_id
        in {
            ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID,
            LEGACY_OPERATIONAL_FIXED_TRAJECTORY_ALGORITHM_ID,
        }
        and operational_warmup is None
    ):
        raise ValueError(
            "operational Phase 5 selection requires an operational warmup result"
        )
    anchor_l = _joint_l_epsilon_anchor_l(
        selected_kernel=selected_kernel,
        attempt_state=_attempt_state,
        final_step_size=initial_step if use_engineering_probe_route else None,
        target_trajectory_length=(
            target_trajectory if use_engineering_probe_route else None
        ),
        max_leapfrog_steps=max_leapfrog_steps,
    )
    if use_operational_grid_route and not (
        run_full_chain is run_full_chain_tfp_hmc
        or isinstance(run_full_chain, HMCTuningRunnerBinding)
    ):
        raise ValueError(
            "operational Phase 5 requires the default TF/TFP runner or a "
            "repository-issued HMCTuningRunnerBinding"
        )
    if legacy_shared_epsilon_route:
        return _run_operational_fixed_mass_step_stage(
            adapter=adapter,
            geometry=geometry,
            bootstrap=bootstrap,
            windowed_stage=windowed_stage,
            config=cfg,
            target_scope=target_scope,
            phase4_adapter=phase4_adapter,
            adapted_mass=adapted_mass,
            initial_step=initial_step,
            anchor_l=anchor_l,
            max_leapfrog_steps=max_leapfrog_steps,
            attempt_budget_policy=_attempt_budget_policy,
            attempt_state=_attempt_state,
            repair_verification_reserved=_repair_verification_reserved,
            selection_max_attempts=_selection_max_attempts,
            candidate_handoff_policy=_candidate_handoff_policy,
            run_full_chain=run_full_chain,
        )
    if use_operational_grid_route:
        _validated_operational_candidate_handoff_policy(_candidate_handoff_policy)
    ladder_result: FixedMassHMCTuningBudgetLadderResult | None = None
    hard_vetoes: list[str] = []
    before_signature = _mass_artifact_signature(adapted_mass)
    progress_attempt_index = (
        int(_attempt_budget_policy.attempt_index)
        if _attempt_index is None and _attempt_budget_policy is not None
        else None if _attempt_index is None else int(_attempt_index)
    )
    progress_attempt = 0 if progress_attempt_index is None else progress_attempt_index
    operational_start_lineage: Mapping[str, Any] | None = None
    operational_factory_state = {"call_count": 0}
    if use_operational_grid_route:
        # Every operational broad/P4-E ladder starts from a fresh copy of the
        # checked Phase 4 post-warmup bank. The zero-state factory remains only
        # for the explicitly legacy joint-grid compatibility route.
        final_adapter = _build_fixed_mass_hmc_adapter(
            adapter=phase4_adapter,
            mass_artifact=adapted_mass,
            mass_signature=before_signature,
            target_scope=target_scope,
        )
        final_adapter_signature = stable_adapter_signature(final_adapter)
        start_bank, operational_start_lineage = _phase7_verification_initial_state(
            windowed_stage=windowed_stage,
            phase4_adapter=phase4_adapter,
            verification_adapter=final_adapter,
            verification_hmc_signature=final_adapter_signature,
        )
        if operational_start_lineage.get("frozen_post_warmup_bank_consumed") is not True:
            raise ValueError("operational Phase 5 did not consume the frozen start bank")
        initial_state_factory = _operational_fixed_mass_initial_state_factory(
            start_bank,
            expected_signature=str(operational_start_lineage["active_signature"]),
            transform_signature=str(
                operational_start_lineage["final_transform_signature"]
            ),
            call_state=operational_factory_state,
        )
    else:
        initial_state_factory = _fixed_mass_step_initial_state_factory(
            adapted_mass.dimension
        )
    joint_rounds: list[Mapping[str, Any]] = []
    joint_candidates: list[Mapping[str, Any]] = []
    joint_candidate_elapsed_s: list[float] = []
    fixed_mass_stage_start = time.perf_counter()
    round_index = 0
    current_anchor_l = int(anchor_l)
    final_round: Mapping[str, Any] | None = None
    selected_candidate: Mapping[str, Any] | None = None
    selected_ladder: FixedMassHMCTuningBudgetLadderResult | None = None
    selected_edge_direction: str | None = None
    refinement_round: Mapping[str, Any] | None = None
    broad_refinement_l_values: tuple[int, ...] = ()
    broad_primary_complete = False
    public_timeout_closeout: Mapping[str, Any] | None = None
    previous_edge_direction: str | None = None
    previous_selected_l: int | None = None
    joint_runner_cache: dict[str, Any] = {}
    joint_runner_contract_payloads: dict[str, Mapping[str, Any]] = {}

    def execute_grid_round(
        *,
        grid_stage: str,
        grid_values: Sequence[int],
        round_anchor_l: int,
    ) -> Mapping[str, Any]:
        return _run_joint_l_epsilon_grid_round(
            adapter=phase4_adapter,
            adapted_mass=adapted_mass,
            initial_state_factory=initial_state_factory,
            config=cfg,
            initial_step=initial_step,
            qualified_step_size_upper_bound=qualified_step_size_upper_bound,
            target_scope=target_scope,
            target_trajectory=target_trajectory,
            anchor_l=round_anchor_l,
            max_leapfrog_steps=max_leapfrog_steps,
            round_index=round_index,
            grid_stage=grid_stage,
            grid_values=grid_values,
            fixed_mass_stage_start_perf_counter_s=fixed_mass_stage_start,
            completed_candidate_elapsed_s=joint_candidate_elapsed_s,
            screen_callback=screen_callback,
            run_full_chain=run_full_chain,
            attempt_budget_policy=_attempt_budget_policy,
            attempt_state=_attempt_state,
            progress_callback=_progress_callback,
            progress_attempt_index=progress_attempt,
            private_diagnostic_callback=_private_diagnostic_callback,
            shared_runner_cache=joint_runner_cache,
            shared_runner_contract_payloads=joint_runner_contract_payloads,
        )

    if canonical_broad_route:
        primary_round = execute_grid_round(
            grid_stage="broad_primary",
            grid_values=ORDINARY_BROAD_PRIMARY_L_GRID,
            round_anchor_l=int(anchor_l),
        )
        joint_rounds.append(primary_round)
        primary_candidates = tuple(primary_round["candidates"])
        joint_candidates.extend(primary_candidates)
        if isinstance(primary_round.get("public_timeout_closeout"), Mapping):
            public_timeout_closeout = dict(primary_round["public_timeout_closeout"])
        broad_primary_complete = bool(
            public_timeout_closeout is None
            and len(primary_candidates) == len(ORDINARY_BROAD_PRIMARY_L_GRID)
        )
        if broad_primary_complete:
            survivor_field = (
                "nomination_eligible"
                if _phase23_nomination_policy_active(cfg.handoff_screen_policy)
                else "viable"
            )
            primary_survivors = tuple(
                int(candidate["num_leapfrog_steps"])
                for candidate in primary_candidates
                if candidate.get(survivor_field) is True
            )
            broad_refinement_l_values = ordinary_broad_refinement_l_values(
                primary_survivors
            )
            if broad_refinement_l_values:
                round_index = 1
                refinement_round = execute_grid_round(
                    grid_stage="survivor_midpoint_refinement",
                    grid_values=broad_refinement_l_values,
                    round_anchor_l=int(anchor_l),
                )
                joint_rounds.append(refinement_round)
                joint_candidates.extend(tuple(refinement_round["candidates"]))
                if isinstance(
                    refinement_round.get("public_timeout_closeout"), Mapping
                ):
                    public_timeout_closeout = dict(
                        refinement_round["public_timeout_closeout"]
                    )
        selected_index = _select_joint_l_epsilon_candidate(
            joint_candidates,
            target_accept_prob=cfg.target_accept_prob,
            target_trajectory=target_trajectory,
            handoff_screen_policy=cfg.handoff_screen_policy,
        )
        if selected_index is not None:
            selected_candidate = joint_candidates[selected_index]
            selected_ladder = _phase5_candidate_ladders_by_source(
                joint_rounds
            ).get(_phase5_candidate_source_key(selected_candidate))
            if selected_ladder is None:
                raise ValueError("broad Phase 5 selection lost ladder provenance")
        selected_edge_direction = None
    else:
        for edge_round in range(_JOINT_L_EPSILON_MAX_EDGE_REPAIR_ROUNDS + 1):
            grid_values = _joint_l_epsilon_grid_values(
                anchor_l=current_anchor_l,
                max_leapfrog_steps=max_leapfrog_steps,
                offsets=_JOINT_L_EPSILON_INITIAL_OFFSETS,
            )
            round_payload = execute_grid_round(
                grid_stage="initial" if edge_round == 0 else "edge_repair",
                grid_values=grid_values,
                round_anchor_l=current_anchor_l,
            )
            joint_rounds.append(round_payload)
            joint_candidates.extend(tuple(round_payload["candidates"]))
            selected_candidate = round_payload["selected_candidate"]
            selected_ladder = round_payload["selected_ladder"]
            selected_edge_direction = round_payload["edge_direction"]
            if isinstance(round_payload.get("public_timeout_closeout"), Mapping):
                public_timeout_closeout = dict(round_payload["public_timeout_closeout"])
                break
            if selected_candidate is None:
                break
            selected_l = int(selected_candidate["num_leapfrog_steps"])
            if selected_edge_direction is None:
                break
            if (
                previous_edge_direction is not None
                and selected_edge_direction != previous_edge_direction
            ):
                break
            if previous_selected_l is not None and selected_l == previous_selected_l:
                break
            if edge_round >= _JOINT_L_EPSILON_MAX_EDGE_REPAIR_ROUNDS:
                break
            step = max(
                1,
                max(abs(int(offset)) for offset in _JOINT_L_EPSILON_INITIAL_OFFSETS),
            )
            current_anchor_l = (
                max(_GEOMETRY_MIN_LEAPFROG, selected_l - step)
                if selected_edge_direction == "lower"
                else min(max_leapfrog_steps, selected_l + step)
            )
            previous_edge_direction = selected_edge_direction
            previous_selected_l = selected_l
            round_index += 1
        if selected_candidate is not None and public_timeout_closeout is None:
            local_anchor_l = int(selected_candidate["num_leapfrog_steps"])
            local_grid = _joint_l_epsilon_grid_values(
                anchor_l=local_anchor_l,
                max_leapfrog_steps=max_leapfrog_steps,
                offsets=_JOINT_L_EPSILON_FINAL_LOCAL_OFFSETS,
            )
            round_index += 1
            final_round = execute_grid_round(
                grid_stage="final_local",
                grid_values=local_grid,
                round_anchor_l=local_anchor_l,
            )
            joint_rounds.append(final_round)
            joint_candidates.extend(tuple(final_round["candidates"]))
            selected_candidate = final_round["selected_candidate"]
            selected_ladder = final_round["selected_ladder"]
            selected_edge_direction = final_round["edge_direction"]
            if isinstance(final_round.get("public_timeout_closeout"), Mapping):
                public_timeout_closeout = dict(final_round["public_timeout_closeout"])
    after_signature = _mass_artifact_signature(adapted_mass)
    frozen_mass_invariant = _fixed_mass_step_frozen_mass_invariant(
        before_signature,
        after_signature,
    )
    ladder_result = selected_ladder
    repair_ladder, repair_ladder_source_key = (
        _select_joint_l_epsilon_repair_ladder_with_source(
        joint_rounds,
        target_accept_prob=cfg.target_accept_prob,
        target_trajectory=target_trajectory,
        )
    )
    candidate_hard_vetoes = tuple(
        dict.fromkeys(
            str(item)
            for candidate in joint_candidates
            for item in candidate.get("hard_vetoes", ())
        )
    )
    candidate_continuation_vetoes = tuple(
        dict.fromkeys(
            str(item)
            for candidate in joint_candidates
            for item in candidate.get("continuation_vetoes", ())
        )
    )
    candidate_repair_triggers = tuple(
        dict.fromkeys(
            str(item)
            for candidate in joint_candidates
            for item in candidate.get("repair_triggers", ())
        )
    )
    viable_candidates = tuple(
        candidate for candidate in joint_candidates if candidate.get("viable") is True
    )
    nomination_candidates = tuple(
        candidate
        for candidate in joint_candidates
        if candidate.get("nomination_eligible") is True
    )
    handoff_candidates = (
        nomination_candidates
        if _phase23_nomination_policy_active(cfg.handoff_screen_policy)
        else viable_candidates
    )
    selected_pair_progress_before_closeout = bool(handoff_candidates)
    budget_incomplete_closeout = bool(
        public_timeout_closeout is not None
        and selected_pair_progress_before_closeout
        and str(public_timeout_closeout.get("grid_stage"))
        in {"edge_repair", "final_local", "survivor_midpoint_refinement"}
    )
    if public_timeout_closeout is not None:
        timeout_payload = dict(public_timeout_closeout)
        timeout_payload["selected_pair_progress_before_closeout"] = (
            selected_pair_progress_before_closeout
        )
        timeout_payload["budget_incomplete"] = budget_incomplete_closeout
        timeout_payload["budget_incomplete_scope"] = (
            (
                "edge_or_final_local_after_selected_pair_progress"
                if timeout_payload.get("grid_stage") in {"edge_repair", "final_local"}
                else "survivor_midpoint_refinement_after_selected_pair_progress"
            )
            if budget_incomplete_closeout
            else "pre_candidate_or_no_selected_pair_progress"
        )
        if budget_incomplete_closeout:
            timeout_payload.pop("hard_veto", None)
            timeout_payload["diagnostic_role"] = (
                _FIXED_MASS_STEP_PUBLIC_TIMEOUT_BUDGET_INCOMPLETE_ROLE
            )
            timeout_payload["repair_trigger"] = (
                _FIXED_MASS_STEP_PUBLIC_TIMEOUT_BUDGET_INCOMPLETE_REPAIR_TRIGGER
            )
        public_timeout_closeout = timeout_payload
    if not frozen_mass_invariant["passed"]:
        hard_vetoes.append("fixed_mass_step_mass_signature_mutated")
    if public_timeout_closeout is not None and not budget_incomplete_closeout:
        hard_vetoes.append(_FIXED_MASS_STEP_PUBLIC_TIMEOUT_HARD_VETO)
    if hard_vetoes:
        final_status = "hard_veto"
    elif budget_incomplete_closeout:
        final_status = "budget_exhausted"
    elif selected_candidate is not None and ladder_result is not None and ladder_result.passed:
        final_status = "passed"
    elif candidate_continuation_vetoes and not handoff_candidates:
        final_status = "hard_veto"
        hard_vetoes = list(
            dict.fromkeys(
                [
                    *hard_vetoes,
                    "fixed_mass_step_continuation_veto",
                    *candidate_continuation_vetoes,
                ]
            )
        )
    elif candidate_hard_vetoes and not handoff_candidates and not repair_ladder:
        final_status = "hard_veto"
        hard_vetoes = list(dict.fromkeys([*hard_vetoes, *candidate_hard_vetoes]))
    else:
        final_status = "repair_or_retry"
    hard_vetoes = list(dict.fromkeys(str(item) for item in hard_vetoes))
    continuation_vetoes = candidate_continuation_vetoes
    repair_triggers = tuple(
        dict.fromkeys(
            [
                *candidate_repair_triggers,
                *(
                    (
                        (
                            _FIXED_MASS_STEP_PUBLIC_TIMEOUT_BUDGET_INCOMPLETE_REPAIR_TRIGGER,
                        )
                        if budget_incomplete_closeout
                        else (_FIXED_MASS_STEP_PUBLIC_TIMEOUT_REPAIR_TRIGGER,)
                    )
                    if public_timeout_closeout is not None
                    else (
                        ()
                        if final_status == "passed"
                        else ("joint_l_epsilon_no_viable_pair",)
                    )
                ),
            ]
        )
    )
    diagnostic_role = (
        "fixed_mass_step_stage_handoff_only"
        if final_status == "passed"
        else (
            _FIXED_MASS_STEP_PUBLIC_TIMEOUT_BUDGET_INCOMPLETE_ROLE
            if final_status == "budget_exhausted"
            else ("repair_trigger" if final_status == "repair_or_retry" else "hard_veto")
        )
    )
    selected_payload = None
    selected_hash = None
    repair_payload = None
    repair_hash = None
    if final_status == "passed" and ladder_result is not None and ladder_result.passed:
        selected_payload = ladder_result.selected_config_payload
        selected_hash = ladder_result.selected_config_hash
    elif repair_ladder is not None and final_status == "repair_or_retry":
        repair_payload = repair_ladder.repair_config_payload
        repair_hash = repair_ladder.repair_config_hash
    representative_ladder = ladder_result if ladder_result is not None else repair_ladder
    representative_budget_config_payload = (
        None
        if representative_ladder is None
        else {
            **representative_ladder.config.payload(),
            "fixed_metric_selection_algorithm": (
                _PHASE5_BROAD_FIXED_METRIC_ALGORITHM
                if canonical_broad_route
                else _PHASE5_JOINT_L_EPSILON_ALGORITHM
            ),
            "representative_selected_ladder": ladder_result is representative_ladder,
        }
    )
    joint_round_summaries = tuple(dict(round_payload["summary"]) for round_payload in joint_rounds)
    joint_run_errors = tuple(
        error
        for round_payload in joint_rounds
        for error in tuple(round_payload.get("run_errors", ()))
    )
    operational_public_work_manifest: Mapping[str, Any] | None = None
    operational_private_work_manifest: Mapping[str, Any] | None = None
    operational_work_reconciliation: Mapping[str, Any] | None = None
    phase5_algorithm_id = (
        _PHASE5_BROAD_FIXED_METRIC_ALGORITHM
        if canonical_broad_route
        else _PHASE5_JOINT_L_EPSILON_ALGORITHM
    )
    ordinary_selection_policy = resolve_ordinary_hmc_selection_policy(
        cfg.algorithm_id,
        engineering_probe_covariance_multiplier_configured=(
            use_engineering_probe_route
        ),
    )
    if use_operational_grid_route:
        operational = windowed_stage.operational_warmup_result
        if operational is None:
            raise ValueError("operational joint route lost its warmup result")
        # These are the exact values consumed by
        # ``_fixed_mass_step_stage_ladder_config`` below.  Do not derive them
        # from the legacy operational selector fields: doing so makes the
        # public bound disagree with the calls that actually ran.
        operational_tune_budgets = (
            _FIXED_MASS_STAGE_TEST_BUDGET_SCHEDULE
            if _attempt_budget_policy is None
            else tuple(_attempt_budget_policy.phase5_tune_budgets)
        )
        operational_tune_results = _FIXED_MASS_STAGE_TUNE_NUM_RESULTS
        operational_screen_results = (
            _FIXED_MASS_STAGE_SCREEN_NUM_RESULTS
            if _attempt_budget_policy is None
            else int(_attempt_budget_policy.phase5_screen_num_results)
        )
        operational_screen_burnin = (
            _FIXED_MASS_STAGE_SCREEN_BURNIN_STEPS
            if _attempt_budget_policy is None
            else int(_attempt_budget_policy.phase5_screen_burnin_steps)
        )
        operational_final_adaptation = (
            operational_tune_budgets[-1]
        )
        operational_verification_results = (
            64
            if _attempt_budget_policy is None
            else int(_attempt_budget_policy.operational_verification_num_results)
        )
        operational_verification_burnin = (
            16
            if _attempt_budget_policy is None
            else int(_attempt_budget_policy.operational_verification_num_burnin_steps)
        )
        operational_verification_starts = (
            2
            if _attempt_budget_policy is None
            else int(
                _attempt_budget_policy.operational_verification_starts_per_outer_attempt
            )
        )
        operational_policy = HMCOperationalStatisticalWorkPolicy(
            initial_candidate_results=operational_screen_results,
            candidate_burnin_steps=operational_screen_burnin,
            evidence_extension_checkpoints=(),
            exact_l_tune_adaptation_steps=operational_final_adaptation,
            fresh_verification_results=operational_verification_results,
            fresh_verification_burnin_steps=operational_verification_burnin,
            fresh_verification_starts_per_outer_attempt=operational_verification_starts,
            policy_id=(
                OPERATIONAL_HMC_BUDGET_POLICY_ID
                if _attempt_budget_policy is None
                else str(_attempt_budget_policy.operational_budget_policy_id)
            ),
        )
        operational_public_work_manifest = build_public_hmc_work_manifest(
            target_dimension=geometry.target_dimension,
            metric_adaptation_steps=(int(operational.config.warmup_steps),),
            selection_attempts_per_outer_attempt=(1,),
            max_leapfrog_steps=max_leapfrog_steps,
            policy=operational_policy,
            algorithm_id=phase5_algorithm_id,
            run_class="runtime_resolved_attempt",
            route_marker=(
                BROAD_FIXED_METRIC_OPERATIONAL_ROUTE
                if canonical_broad_route
                else JOINT_L_EPSILON_OPERATIONAL_ROUTE
            ),
            per_l_tune_budget_schedule=operational_tune_budgets,
            per_l_tune_num_results=operational_tune_results,
            per_l_screen_num_results=operational_screen_results,
            per_l_screen_num_burnin_steps=operational_screen_burnin,
        )
        resolved_candidates = tuple(
            {
                "round_index": int(candidate.get("round_index", 0)),
                "grid_stage": str(candidate.get("grid_stage", "")),
                "candidate": dict(candidate),
            }
            for candidate in joint_candidates
        )
        operational_private_work_manifest = build_private_resolved_hmc_work_manifest(
            public_manifest=operational_public_work_manifest,
            resolved_candidates=resolved_candidates,
        )
        candidate_transitions = sum(
            _joint_l_epsilon_ladder_transition_count(ladder)
            for round_payload in joint_rounds
            for ladder in tuple(
                round_payload.get("ladders_by_candidate_index", {}).values()
            )
            if isinstance(ladder, FixedMassHMCTuningBudgetLadderResult)
        )
        operational_work_reconciliation = reconcile_executed_hmc_work(
            public_manifest=operational_public_work_manifest,
            executed_work={
                "initial_candidate_batched_transitions": candidate_transitions,
                "extension_candidate_batched_transitions": 0,
                "exact_l_tune_batched_transitions": 0,
            },
        )
    diagnostics = {
        "passed": final_status == "passed",
        "algorithm": phase5_algorithm_id,
        "ordinary_selection_policy": dict(ordinary_selection_policy),
        "promoted_default": bool(canonical_broad_route),
        "operational_non_promoting_candidate_route": bool(
            use_engineering_probe_route
        ),
        "operational_per_l_epsilon_route": bool(use_operational_grid_route),
        "operational_broad_fixed_metric_route": bool(canonical_broad_route),
        "operational_joint_l_epsilon_route": bool(use_engineering_probe_route),
        "operational_route_marker": (
            (
                BROAD_FIXED_METRIC_OPERATIONAL_ROUTE
                if canonical_broad_route
                else JOINT_L_EPSILON_OPERATIONAL_ROUTE
            )
            if use_operational_grid_route
            else None
        ),
        "operational_candidate_handoff_policy": (
            _candidate_handoff_policy if use_operational_grid_route else None
        ),
        "operational_runner_route": (
            "default_tf_tfp_runner"
            if run_full_chain is run_full_chain_tfp_hmc
            else "typed_hmc_tuning_runner_binding"
        ),
        "handoff_screen_policy": cfg.handoff_screen_policy,
        "bootstrap_l_is_anchor_not_fixed_policy": True,
        "initial_anchor_l": int(anchor_l),
        "broad_primary_l_grid": (
            ORDINARY_BROAD_PRIMARY_L_GRID if canonical_broad_route else ()
        ),
        "broad_primary_complete": (
            broad_primary_complete if canonical_broad_route else None
        ),
        "broad_refinement_l_values": (
            broad_refinement_l_values if canonical_broad_route else ()
        ),
        "broad_refinement_round_ran": refinement_round is not None,
        "broad_refinement_rounds": 1 if refinement_round is not None else 0,
        "per_l_epsilon_tuning": True,
        "shared_epsilon_across_l": False,
        "selected_num_leapfrog_steps": None
        if selected_candidate is None
        else int(selected_candidate["num_leapfrog_steps"]),
        "selected_step_size": None
        if selected_candidate is None
        else selected_candidate.get("selected_step_size"),
        "selected_acceptance_rate": None
        if selected_candidate is None
        else selected_candidate.get("screen_acceptance_rate"),
        "selected_ladder_artifact_hash": None
        if ladder_result is None
        else ladder_result.artifact_hash,
        "edge_repair_round_count": sum(
            1 for summary in joint_round_summaries if summary["grid_stage"] == "edge_repair"
        ),
        "selected_at_grid_edge_after_final_round": selected_edge_direction is not None,
        "final_local_grid_ran": final_round is not None,
        "round_summaries": joint_round_summaries,
        "candidate_count": len(joint_candidates),
        "viable_candidate_count": len(viable_candidates),
        "nomination_candidate_count": len(nomination_candidates),
        "candidates": tuple(joint_candidates),
        "candidate_run_errors": joint_run_errors,
        "public_timeout_closeout": None
        if public_timeout_closeout is None
        else dict(public_timeout_closeout),
        "public_timeout_closeout_required": public_timeout_closeout is not None,
        "public_timeout_budget_incomplete": budget_incomplete_closeout,
        "selected_pair_progress_before_timeout_closeout": (
            selected_pair_progress_before_closeout
            if public_timeout_closeout is not None
            else False
        ),
        "completed_candidate_elapsed_count": len(joint_candidate_elapsed_s),
        "operational_start_bank_lineage": None
        if operational_start_lineage is None
        else dict(operational_start_lineage),
        "operational_start_bank_factory_call_count": int(
            operational_factory_state.get("call_count", 0)
        ),
        "operational_start_bank_factory_validated": (
            operational_start_lineage is None
            or operational_factory_state.get("call_count", 0) > 0
        ),
        "operational_budget_policy_id": None
        if operational_public_work_manifest is None
        else operational_public_work_manifest.get("policy_id"),
        "operational_budget_policy_hash": None
        if operational_public_work_manifest is None
        else operational_public_work_manifest.get("policy_hash"),
        "public_work_manifest_hash": None
        if operational_public_work_manifest is None
        else operational_public_work_manifest.get("manifest_hash"),
        "private_work_manifest_hash": None
        if operational_private_work_manifest is None
        else operational_private_work_manifest.get("private_manifest_hash"),
        "executed_work_reconciliation": operational_work_reconciliation,
        "hard_vetoes_from_ladder": candidate_hard_vetoes,
        "continuation_vetoes_from_ladder": continuation_vetoes,
        "repair_triggers_from_ladder": candidate_repair_triggers,
        "hard_vetoes": tuple(hard_vetoes),
        "continuation_vetoes": continuation_vetoes,
        "repair_triggers": repair_triggers,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
    }
    result = HMCFixedMassStepStageResult(
        config=cfg,
        windowed_stage_artifact_hash=windowed_stage.artifact_hash,
        selected_bootstrap_kernel_hash=windowed_stage.selected_bootstrap_kernel_hash,
        adapter_signature=windowed_stage.adapter_signature,
        phase4_hmc_adapter_signature=windowed_stage.hmc_adapter_signature,
        ladder_adapter_signature=(
            "fixed_mass_step_ladder_unavailable"
            if representative_ladder is None
            else representative_ladder.adapter_signature
        ),
        ladder_hmc_adapter_signature=(
            "fixed_mass_step_ladder_hmc_unavailable"
            if representative_ladder is None
            else representative_ladder.hmc_adapter_signature
        ),
        adapted_mass_artifact_payload=adapted_mass.to_payload(include_arrays=True),
        adapted_mass_artifact_signature=before_signature,
        initial_step_size=initial_step,
        fixed_num_leapfrog_steps=(
            int(anchor_l)
            if selected_candidate is None
            else int(selected_candidate["num_leapfrog_steps"])
        ),
        target_dimension=windowed_stage.target_dimension,
        final_status=final_status,
        diagnostic_role=diagnostic_role,
        hard_vetoes=tuple(hard_vetoes),
        repair_triggers=repair_triggers,
        diagnostics=diagnostics,
        budget_ladder_config_payload=representative_budget_config_payload,
        budget_ladder_result=representative_ladder,
        selected_step_payload=selected_payload,
        selected_step_hash=selected_hash,
        repair_step_payload=repair_payload,
        repair_step_hash=repair_hash,
        frozen_mass_invariant=frozen_mass_invariant,
        seed_report={
            "windowed_stage_seed": windowed_stage.seed_report.get("windowed_stage_seed"),
            "fixed_mass_stage_root_seed": cfg.seed,
            "fixed_mass_tune_seed_base": _derive_seed(cfg.seed, stage_index=0),
            "fixed_mass_screen_seed_base": _derive_seed(cfg.seed, stage_index=1),
            "seed_owner": "BayesFilter",
        },
        diagnostic_roles={
            "frozen_mass_invariant": "hard_veto",
            "fresh_fixed_kernel_screen": "step_handoff_promotion_only",
            "tune_acceptance": "tuning_diagnostic_only",
            "screen_acceptance": "promotion_or_repair_or_hard_veto",
            "callback_hard_veto": "hard_veto",
            "callback_continuation_veto": "continuation_veto",
            "callback_promotion_veto": "repair_trigger",
            "runtime": "explanatory_or_hard_veto_when_missing",
        },
        private_runner_cache_handoff={
            "source": "fixed_mass_step_private_runner_cache_handoff",
            "runner_cache": joint_runner_cache,
            "runner_contract_payloads": joint_runner_contract_payloads,
            "dynamic_num_leapfrog_steps": True,
            "handoff_role": "trajectory_compile_reuse_only",
            "public_payload_excludes_live_runner_objects": True,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
        },
        _operational_private_work_manifest=operational_private_work_manifest,
        _operational_public_work_manifest=operational_public_work_manifest,
    )
    selected_source_key = (
        _phase5_candidate_source_key(selected_candidate)
        if final_status == "passed" and selected_candidate is not None
        else None
    )
    repair_source_key = (
        repair_ladder_source_key
        if final_status == "repair_or_retry" and repair_payload is not None
        else None
    )
    candidate_handoff = _build_phase5_candidate_batch_handoff(
        result=result,
        rounds=joint_rounds,
        candidates=joint_candidates,
        target_scope=target_scope,
        selected_source_key=selected_source_key,
        repair_source_key=repair_source_key,
    )
    result = dataclasses.replace(
        result,
        _candidate_batch_handoff=candidate_handoff,
    )
    _phase5_candidate_batch_handoff(result)
    return result


def _run_operational_fixed_mass_step_stage(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
    windowed_stage: HMCWindowedMassStageResult,
    config: HMCFixedMassStepStageConfig,
    target_scope: str,
    phase4_adapter: Any,
    adapted_mass: PrecomputedMassArtifact,
    initial_step: float,
    anchor_l: int,
    max_leapfrog_steps: int,
    attempt_budget_policy: "_HMCAttemptBudgetPolicy | None",
    attempt_state: "_HMCPhaseAttemptState | None",
    repair_verification_reserved: bool,
    selection_max_attempts: int,
    candidate_handoff_policy: str,
    run_full_chain: RunFullChainFn,
) -> HMCFixedMassStepStageResult:
    """Run R5 from the frozen operational bank, never historical latent zero."""

    operational = windowed_stage.operational_warmup_result
    if operational is None:
        raise ValueError("operational Phase 5 requires operational warmup")
    if run_full_chain is not run_full_chain_tfp_hmc:
        raise ValueError("operational Phase 5 requires the real TF/TFP runner")
    mass_signature = _mass_artifact_signature(adapted_mass)
    final_adapter = _build_fixed_mass_hmc_adapter(
        adapter=phase4_adapter,
        mass_artifact=adapted_mass,
        mass_signature=mass_signature,
        target_scope=target_scope,
    )
    final_adapter_signature = stable_adapter_signature(final_adapter)
    start_bank, start_summary = _phase7_verification_initial_state(
        windowed_stage=windowed_stage,
        phase4_adapter=phase4_adapter,
        verification_adapter=final_adapter,
        verification_hmc_signature=final_adapter_signature,
    )
    if start_summary.get("frozen_post_warmup_bank_consumed") is not True:
        raise ValueError("operational Phase 5 did not consume the frozen start bank")
    active_start_bank_signature = str(start_summary.get("active_signature", ""))
    if not active_start_bank_signature:
        raise ValueError("operational Phase 5 active start-bank signature is missing")
    screen_results = (
        64
        if attempt_budget_policy is None
        else int(attempt_budget_policy.operational_screen_num_results)
    )
    screen_burnin = (
        16
        if attempt_budget_policy is None
        else int(attempt_budget_policy.operational_screen_num_burnin_steps)
    )
    final_adaptation = (
        64
        if attempt_budget_policy is None
        else int(attempt_budget_policy.operational_exact_l_tune_adaptation_steps)
    )
    extension_checkpoints = (
        ()
        if attempt_budget_policy is None
        else attempt_budget_policy.operational_evidence_extension_checkpoints
    )
    selection_attempts = int(selection_max_attempts)
    if selection_attempts <= 0 or selection_attempts > 5:
        raise ValueError("operational selection attempt budget must lie inside [1, 5]")
    if selection_attempts > 1 and not repair_verification_reserved:
        raise ValueError("multi-attempt operational selection requires repair reservation")
    selection_loop = run_bounded_operational_fixed_trajectory_selection(
        adapter=final_adapter,
        private_start_bank=start_bank,
        private_start_bank_signature=active_start_bank_signature,
        coordinate_signature=operational.final_kernel_state.transform.signature,
        metric_signature=operational.final_kernel_state.momentum_metric.signature,
        anchor_l=anchor_l,
        max_leapfrog_steps=max_leapfrog_steps,
        initial_step_size=initial_step,
        root_seed=config.seed,
        target_scope=target_scope,
        acceptance_policy=HMCAcceptancePolicy(
            target=config.target_accept_prob,
            practical_region=config.acceptance_band,
            repair_region=config.repair_band,
        ),
        max_attempts=selection_attempts,
        repair_factor=config.step_repair_factor,
        screen_num_results=screen_results,
        screen_num_burnin_steps=screen_burnin,
        final_tune_adaptation_steps=final_adaptation,
        evidence_extension_checkpoints=extension_checkpoints,
        chain_execution_mode=config.chain_execution_mode,
        use_xla=config.use_xla,
        target_status_trace_policy=config.target_status_trace_policy,
        run_full_chain=run_full_chain,
        candidate_handoff_policy=candidate_handoff_policy,
    )
    selection = selection_loop.selection
    representative = selection.representative
    selected_payload = None
    selected_hash = None
    repair_payload = None
    repair_hash = None
    hard_vetoes: tuple[str, ...] = ()
    repair_triggers: tuple[str, ...] = ()
    final_status = "repair_or_retry"
    diagnostic_role = "repair_trigger"
    if selection.disposition == "representative_selected":
        if representative is None or representative.exact_l_retuned_step_size is None:
            raise ValueError("operational selection lost its exact-L representative")
        selected_payload = {
            "schema": "bayesfilter.hmc_operational_exact_l_step.v2",
            "step_size": representative.exact_l_retuned_step_size,
            "num_leapfrog_steps": representative.candidate.num_leapfrog_steps,
            "selection_signature": selection.signature,
            "candidate_signature": representative.candidate.signature,
            "exact_l_retune_signature": representative.exact_l_retune_signature,
            "coordinate_signature": representative.candidate.coordinate_signature,
            "metric_signature": representative.candidate.metric_signature,
            "start_bank_signature": representative.candidate.start_bank_signature,
            "private_handoff_only": True,
        }
        selected_hash = stable_config_hash(selected_payload)
        final_status = "passed"
        diagnostic_role = "operational_fixed_trajectory_handoff_only"
    elif selection.disposition == "shared_invalidity":
        final_status = "hard_veto"
        diagnostic_role = "shared_invalidity"
        hard_vetoes = ("operational_candidate_shared_invalidity",)
    elif selection.disposition == "candidate_retune_failed":
        final_status = "budget_exhausted"
        diagnostic_role = "candidate_retune_failed_non_promoting"
        repair_triggers = ("operational_candidate_retune_failed",)
    elif selection_loop.terminal_disposition == "candidate_set_exhausted":
        final_status = "budget_exhausted"
        diagnostic_role = "candidate_set_exhausted"
        repair_triggers = ("operational_candidate_set_exhausted",)
    elif selection_loop.terminal_disposition in {
        "inconclusive_conflict",
        "inconclusive_resonance",
        "inconclusive_trajectory",
        "inconclusive_evidence",
        "inconclusive_stalled_or_oscillating",
        "budget_exhausted_valid",
    }:
        final_status = "budget_exhausted"
        diagnostic_role = selection_loop.terminal_disposition
        repair_triggers = (
            f"operational_candidate_{selection_loop.terminal_disposition}",
        )
    else:
        raise AssertionError("operational selection returned an unknown disposition")
    selected_l = (
        anchor_l
        if representative is None
        else representative.candidate.num_leapfrog_steps
    )
    operational_policy = HMCOperationalStatisticalWorkPolicy(
        initial_candidate_results=screen_results,
        candidate_burnin_steps=screen_burnin,
        evidence_extension_checkpoints=extension_checkpoints,
        exact_l_tune_adaptation_steps=final_adaptation,
        fresh_verification_results=(
            64
            if attempt_budget_policy is None
            else int(attempt_budget_policy.operational_verification_num_results)
        ),
        fresh_verification_burnin_steps=(
            16
            if attempt_budget_policy is None
            else int(
                attempt_budget_policy.operational_verification_num_burnin_steps
            )
        ),
        fresh_verification_starts_per_outer_attempt=(
            2
            if attempt_budget_policy is None
            else int(
                attempt_budget_policy.operational_verification_starts_per_outer_attempt
            )
        ),
        policy_id=(
            OPERATIONAL_HMC_BUDGET_POLICY_ID
            if attempt_budget_policy is None
            else str(attempt_budget_policy.operational_budget_policy_id)
        ),
    )
    public_work_manifest = build_public_hmc_work_manifest(
        target_dimension=geometry.target_dimension,
        metric_adaptation_steps=(
            int(
                operational.config.warmup_steps
                if attempt_budget_policy is None
                else attempt_budget_policy.phase4_warmup_steps
            ),
        ),
        selection_attempts_per_outer_attempt=(selection_attempts,),
        max_leapfrog_steps=max_leapfrog_steps,
        policy=operational_policy,
        algorithm_id=LEGACY_OPERATIONAL_FIXED_TRAJECTORY_ALGORITHM_ID,
        run_class="runtime_resolved_attempt",
    )
    resolved_candidates = tuple(
        {
            "selection_attempt_index": attempt.attempt_index,
            "candidate": candidate.candidate.payload(),
        }
        for attempt in selection_loop.attempts
        for candidate in attempt.selection.candidate_results
    )
    private_work_manifest = build_private_resolved_hmc_work_manifest(
        public_manifest=public_work_manifest,
        resolved_candidates=resolved_candidates,
    )
    initial_candidate_transitions = sum(
        len(attempt.initial_replication_seeds)
        * (screen_results + screen_burnin)
        for attempt in selection_loop.attempts
    )
    extension_candidate_transitions = sum(
        len(extension.slots) * (extension.checkpoint + screen_burnin)
        for attempt in selection_loop.attempts
        for extension in attempt.evidence_extensions
    )
    exact_l_tune_transitions = sum(
        len(attempt.exact_l_retune_seeds)
        * (final_adaptation + operational_policy.exact_l_tune_result_steps)
        for attempt in selection_loop.attempts
    )
    executed_work_reconciliation = reconcile_executed_hmc_work(
        public_manifest=public_work_manifest,
        executed_work={
            "initial_candidate_batched_transitions": initial_candidate_transitions,
            "extension_candidate_batched_transitions": (
                extension_candidate_transitions
            ),
            "exact_l_tune_batched_transitions": exact_l_tune_transitions,
        },
    )
    diagnostics = {
        "passed": final_status == "passed",
        "algorithm": LEGACY_OPERATIONAL_FIXED_TRAJECTORY_ALGORITHM_ID,
        "ordinary_selection_policy": dict(
            resolve_ordinary_hmc_selection_policy(
                LEGACY_OPERATIONAL_FIXED_TRAJECTORY_ALGORITHM_ID
            )
        ),
        "promoted_default": False,
        "candidate_count": len(selection.candidate_results),
        "replication_count_per_candidate": 3,
        "selection_disposition": selection.disposition,
        "selection_signature": selection.signature,
        "selection_loop_signature": selection_loop.signature,
        "selection_attempt_count": len(selection_loop.attempts),
        "selection_attempt_budget": selection_loop.max_attempts,
        "operational_budget_policy_id": (
            OPERATIONAL_HMC_BUDGET_POLICY_ID
            if attempt_budget_policy is None
            else attempt_budget_policy.operational_budget_policy_id
        ),
        "operational_budget_policy_hash": (
            HMCOperationalStatisticalWorkPolicy().policy_hash
            if attempt_budget_policy is None
            else attempt_budget_policy.operational_budget_policy_hash
        ),
        "selection_initial_results": screen_results,
        "selection_burnin_steps": screen_burnin,
        "selection_evidence_extension_checkpoints": extension_checkpoints,
        "exact_l_tune_adaptation_steps": final_adaptation,
        "public_work_manifest_hash": public_work_manifest["manifest_hash"],
        "private_work_manifest_hash": private_work_manifest[
            "private_manifest_hash"
        ],
        "executed_work_reconciliation": executed_work_reconciliation,
        "selection_terminal_disposition": selection_loop.terminal_disposition,
        "selection_retune_failure_scope": selection.retune_failure_scope,
        "selection_retune_failure_reasons": selection.retune_failure_reasons,
        "selection_retune_candidate_signature": selection.retune_candidate_signature,
        "selection_candidate_retune_failures": tuple(
            item.payload() for item in selection.candidate_retune_failures
        ),
        "selection_candidate_retune_failure_count": len(
            selection.candidate_retune_failures
        ),
        "selection_repair_count": len(selection_loop.repair_direction_history),
        "selection_step_veto_recovery_count": (
            selection_loop.step_veto_recovery_count
        ),
        "selection_repair_direction_history": (
            selection_loop.repair_direction_history
        ),
        "selection_empirical_bracket_available": all(
            item is not None for item in selection_loop.final_bracket
        ),
        "representative_signature": selection.representative_signature,
        "selected_num_leapfrog_steps": selected_l if representative is not None else None,
        "selected_step_size": None
        if representative is None
        else representative.exact_l_retuned_step_size,
        "frozen_start_bank_consumed": True,
        "frozen_start_bank_signature": active_start_bank_signature,
        "frozen_start_bank_source_signature": (
            operational.private_start_bank_signature
        ),
        "candidate_seed_domain": "candidate_selection",
        "exact_l_retune_seed_domain": "exact_final_l_epsilon_tune",
        "independent_verification_seed_reserved": True,
        "historical_zero_start_factory_used": False,
        "historical_first_pass_queue_used": False,
        "phase6_bypassed_on_repaired_joint_route": True,
        "stochastic_ranking_performed": False,
        "raw_start_bank_exposed": False,
        "raw_samples_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
    }
    return HMCFixedMassStepStageResult(
        config=config,
        windowed_stage_artifact_hash=windowed_stage.artifact_hash,
        selected_bootstrap_kernel_hash=windowed_stage.selected_bootstrap_kernel_hash,
        adapter_signature=windowed_stage.adapter_signature,
        phase4_hmc_adapter_signature=windowed_stage.hmc_adapter_signature,
        ladder_adapter_signature=stable_adapter_signature(phase4_adapter),
        ladder_hmc_adapter_signature=final_adapter_signature,
        adapted_mass_artifact_payload=adapted_mass.to_payload(include_arrays=True),
        adapted_mass_artifact_signature=mass_signature,
        initial_step_size=initial_step,
        fixed_num_leapfrog_steps=int(selected_l),
        target_dimension=windowed_stage.target_dimension,
        final_status=final_status,
        diagnostic_role=diagnostic_role,
        hard_vetoes=hard_vetoes,
        repair_triggers=repair_triggers,
        diagnostics=diagnostics,
        budget_ladder_config_payload=None,
        budget_ladder_result=None,
        selected_step_payload=selected_payload,
        selected_step_hash=selected_hash,
        repair_step_payload=repair_payload,
        repair_step_hash=repair_hash,
        frozen_mass_invariant={
            "before_signature": mass_signature,
            "after_signature": _mass_artifact_signature(adapted_mass),
            "passed": mass_signature == _mass_artifact_signature(adapted_mass),
        },
        seed_report={
            "windowed_stage_seed": windowed_stage.seed_report.get("windowed_stage_seed"),
            "operational_selection_root_seed": config.seed,
            "seed_owner": "BayesFilter",
        },
        diagnostic_roles={
            "acceptance_evidence": "promotion_criterion_and_repair_trigger",
            "movement_and_health": "promotion_veto_and_repair_trigger",
            "efficiency": "explanatory_only",
            "representative_tie_break": "policy_not_stochastic_ranking",
        },
        _operational_selection=selection,
        _operational_selection_loop=selection_loop,
        _operational_private_work_manifest=private_work_manifest,
        _operational_public_work_manifest=public_work_manifest,
    )


def run_hmc_frozen_step_trajectory_stage(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCFrozenStepTrajectoryStageConfig | None = None,
    screen_callback: TrajectoryScreenCallback | None = None,
    run_full_chain: RunFullChainFn = run_full_chain_tfp_hmc,
    _attempt_budget_policy: "_HMCAttemptBudgetPolicy" | None = None,
    _attempt_state: "_HMCPhaseAttemptState" | None = None,
    _progress_callback: LoopProgressCallback | None = None,
    _attempt_index: int | None = None,
    _private_diagnostic_callback: PrivateTuningDiagnosticCallback | None = None,
    _runner_cache_handoff: Mapping[str, Any] | None = None,
) -> HMCFrozenStepTrajectoryStageResult:
    """Run Phase 6 frozen-step trajectory tuning from a passed Phase 5 handoff.

    Phase 6 freezes the Phase 4 adapted mass and Phase 5 selected step, then
    screens internally generated candidate leapfrog counts with no adaptation.
    It is a trajectory handoff for the later tune-verify-repair loop, not final
    verification or posterior evidence.
    """

    cfg = HMCFrozenStepTrajectoryStageConfig() if config is None else config
    if not isinstance(cfg, HMCFrozenStepTrajectoryStageConfig):
        raise TypeError("config must be HMCFrozenStepTrajectoryStageConfig")
    if not isinstance(geometry, HMCGeometryInitializationResult):
        raise TypeError("geometry must be HMCGeometryInitializationResult")
    if not isinstance(bootstrap, HMCBootstrapScreenResult):
        raise TypeError("bootstrap must be HMCBootstrapScreenResult")
    if not isinstance(windowed_stage, HMCWindowedMassStageResult):
        raise TypeError("windowed_stage must be HMCWindowedMassStageResult")
    if not isinstance(fixed_mass_step_stage, HMCFixedMassStepStageResult):
        raise TypeError("fixed_mass_step_stage must be HMCFixedMassStepStageResult")
    _validate_frozen_step_trajectory_stage_inputs(
        adapter=adapter,
        geometry=geometry,
        bootstrap=bootstrap,
        windowed_stage=windowed_stage,
        fixed_mass_step_stage=fixed_mass_step_stage,
        config=cfg,
    )
    target_scope = _resolve_frozen_step_trajectory_stage_target_scope(adapter, cfg)
    adapted_mass = _phase4_adapted_mass_artifact(windowed_stage)
    frozen_step = _required_selected_step_size(fixed_mass_step_stage)
    fixed_pair_l = int(fixed_mass_step_stage.fixed_num_leapfrog_steps)
    phase4_adapter = _phase4_latent_adapter_for_step_stage(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        target_scope=target_scope,
    )
    before_mass_signature = _mass_artifact_signature(adapted_mass)
    trajectory_adapter = _build_fixed_mass_hmc_adapter(
        adapter=phase4_adapter,
        mass_artifact=adapted_mass,
        mass_signature=before_mass_signature,
        target_scope=target_scope,
    )
    trajectory_hmc_signature = stable_adapter_signature(trajectory_adapter)
    if trajectory_hmc_signature != fixed_mass_step_stage.ladder_hmc_adapter_signature:
        raise ValueError("Phase 6 trajectory HMC adapter signature mismatch")
    phase5_algorithm = fixed_mass_step_stage.diagnostics.get("algorithm")
    if phase5_algorithm in _PHASE5_DIRECT_GRID_ALGORITHMS:
        candidate_generation = _phase5_selected_pair_candidate_generation(
            geometry=geometry,
            phase5_algorithm_id=str(phase5_algorithm),
            selected_step_size=frozen_step,
            selected_num_leapfrog_steps=fixed_pair_l,
            fixed_bootstrap_l=fixed_pair_l,
            max_leapfrog_steps=cfg.max_leapfrog_steps,
            trajectory_window_lower_multiplier=cfg.trajectory_window_lower_multiplier,
            trajectory_window_upper_multiplier=cfg.trajectory_window_upper_multiplier,
            handoff_screen_policy=cfg.handoff_screen_policy,
        )
    else:
        candidate_generation = _frozen_step_trajectory_candidate_generation(
            geometry=geometry,
            selected_step_size=frozen_step,
            fixed_bootstrap_l=fixed_pair_l,
            max_leapfrog_steps=cfg.max_leapfrog_steps,
            trajectory_window_lower_multiplier=cfg.trajectory_window_lower_multiplier,
            trajectory_window_upper_multiplier=cfg.trajectory_window_upper_multiplier,
            handoff_screen_policy=cfg.handoff_screen_policy,
            attempt_state=_attempt_state,
        )
    candidates = tuple(int(item) for item in candidate_generation["candidate_l_values"])
    candidate_results: list[Mapping[str, Any]] = []
    stage_hard_vetoes: list[str] = []
    stage_repair_triggers: list[str] = []
    run_error: Exception | None = None
    use_reusable_route = (
        run_full_chain is run_full_chain_tfp_hmc
        and cfg.chain_execution_mode == "tf_function"
    )
    handoff = {} if _runner_cache_handoff is None else dict(_runner_cache_handoff)
    runner_cache = _coerce_private_runner_cache_handoff_mapping(
        handoff.get("runner_cache")
    )
    runner_contract_payloads = _coerce_private_runner_contract_handoff_mapping(
        handoff.get("runner_contract_payloads")
    )
    initial_handoff_contract_count = len(runner_contract_payloads)
    runner_handoff_source = (
        "none"
        if initial_handoff_contract_count == 0 and not runner_cache
        else str(handoff.get("source", "fixed_mass_step_private_runner_cache_handoff"))
    )
    runner_route_events: list[Mapping[str, Any]] = []
    candidate_elapsed_s: list[float] = []
    stage_start = time.perf_counter()
    soft_deadline_closeout: Mapping[str, Any] | None = None
    progress_attempt_index = (
        int(_attempt_budget_policy.attempt_index)
        if _attempt_index is None and _attempt_budget_policy is not None
        else None if _attempt_index is None else int(_attempt_index)
    )

    for candidate_index, leapfrog_count in enumerate(candidates):
        screen_seed = _round_seed(cfg.seed, candidate_index)
        screen_config = _frozen_step_trajectory_screen_config(
            cfg,
            seed=screen_seed,
            step=frozen_step,
            leapfrogs=leapfrog_count,
            target_scope=target_scope,
            attempt_budget_policy=_attempt_budget_policy,
        )
        soft_deadline_veto = _phase6_next_candidate_soft_deadline_veto(
            stage_start_perf_counter_s=stage_start,
            timeout_budget_s=cfg.public_timeout_budget_s,
            public_timeout_started_perf_counter_s=cfg.public_timeout_started_perf_counter_s,
            completed_elapsed_s=tuple(candidate_elapsed_s),
        )
        if soft_deadline_veto is not None:
            soft_deadline_closeout = {
                **soft_deadline_veto,
                "candidate_index": int(candidate_index),
                "candidate_count": len(candidates),
                "completed_candidate_count": len(candidate_results),
                "progress_only": True,
                "public_closeout_artifact_expected": True,
                "reason": "phase6_public_timeout_soft_deadline_before_next_candidate",
            }
            _emit_phase7_progress(
                _progress_callback,
                "trajectory_candidate_soft_deadline_closeout",
                attempt_index=0 if progress_attempt_index is None else progress_attempt_index,
                budget_policy=_attempt_budget_policy,
                completed=True,
                extra=_trajectory_candidate_progress_extra(
                    stage="trajectory_candidate_soft_deadline_closeout",
                    candidate_index=candidate_index,
                    candidate_count=len(candidates),
                    completed_candidate_count=len(candidate_results),
                    config=screen_config,
                    runner_event=runner_route_events[-1] if runner_route_events else None,
                    soft_deadline_payload=soft_deadline_closeout,
                ),
            )
            stage_hard_vetoes.append("phase6_public_timeout_soft_deadline")
            stage_repair_triggers.append(
                "phase6_public_timeout_soft_deadline_before_next_candidate"
            )
            break
        screen_result: FullChainHMCRunResult | None = None
        screen_error: Exception | None = None
        try:
            _emit_phase7_progress(
                _progress_callback,
                "trajectory_candidate_call_start",
                attempt_index=0 if progress_attempt_index is None else progress_attempt_index,
                budget_policy=_attempt_budget_policy,
                started=True,
                extra=_trajectory_candidate_progress_extra(
                    stage="trajectory_candidate_call_start",
                    candidate_index=candidate_index,
                    candidate_count=len(candidates),
                    completed_candidate_count=len(candidate_results),
                    config=screen_config,
                    runner_event=None,
                    elapsed_s=0.0,
                    started_perf_counter_s=time.perf_counter(),
                    soft_deadline_payload=_phase6_soft_deadline_state(
                        stage_start_perf_counter_s=stage_start,
                        timeout_budget_s=cfg.public_timeout_budget_s,
                        public_timeout_started_perf_counter_s=cfg.public_timeout_started_perf_counter_s,
                    ),
                ),
            )
            candidate_start = time.perf_counter()
            screen_result = _run_kernel_stage_with_optional_reusable_route(
                run_full_chain=run_full_chain,
                runner_cache=runner_cache,
                runner_contract_payloads=runner_contract_payloads,
                route_events=runner_route_events,
                route_name="frozen_step_trajectory_scoped_reusable_runner",
                route_scope="frozen_step_trajectory_candidate_screen",
                adapter=trajectory_adapter,
                initial_state=_float64_tensor((0.0,) * adapted_mass.dimension),
                config=screen_config,
                hmc_adapter_signature=trajectory_hmc_signature,
                target_dimension=windowed_stage.target_dimension,
                mass_signature=before_mass_signature,
                event_payload={
                    "candidate_index": candidate_index,
                    "num_leapfrog_steps": int(leapfrog_count),
                    "step_size": frozen_step,
                    "runner_cache_handoff_source": runner_handoff_source,
                    "runner_cache_handoff_initial_contract_count": int(
                        initial_handoff_contract_count
                    ),
                },
                dynamic_num_leapfrog_steps=True,
            )
            candidate_elapsed = time.perf_counter() - candidate_start
            candidate_elapsed_s.append(candidate_elapsed)
            _emit_phase7_progress(
                _progress_callback,
                "trajectory_candidate_call_complete",
                attempt_index=0 if progress_attempt_index is None else progress_attempt_index,
                budget_policy=_attempt_budget_policy,
                completed=True,
                extra=_trajectory_candidate_progress_extra(
                    stage="trajectory_candidate_call_complete",
                    candidate_index=candidate_index,
                    candidate_count=len(candidates),
                    completed_candidate_count=len(candidate_results) + 1,
                    config=screen_config,
                    runner_event=runner_route_events[-1] if runner_route_events else None,
                    elapsed_s=candidate_elapsed,
                    soft_deadline_payload=_phase6_soft_deadline_state(
                        stage_start_perf_counter_s=stage_start,
                        timeout_budget_s=cfg.public_timeout_budget_s,
                        public_timeout_started_perf_counter_s=cfg.public_timeout_started_perf_counter_s,
                    ),
                ),
            )
            diagnostics = _frozen_step_trajectory_diagnostics_payload(screen_result)
        except Exception as exc:  # noqa: BLE001 - return fail-closed artifact.
            screen_error = exc
            run_error = exc
            _emit_phase7_progress(
                _progress_callback,
                "trajectory_candidate_call_error",
                attempt_index=0 if progress_attempt_index is None else progress_attempt_index,
                budget_policy=_attempt_budget_policy,
                completed=True,
                extra=_trajectory_candidate_progress_extra(
                    stage="trajectory_candidate_call_error",
                    candidate_index=candidate_index,
                    candidate_count=len(candidates),
                    completed_candidate_count=len(candidate_results),
                    config=screen_config,
                    runner_event=runner_route_events[-1] if runner_route_events else None,
                    error_type=type(exc).__name__,
                    soft_deadline_payload=_phase6_soft_deadline_state(
                        stage_start_perf_counter_s=stage_start,
                        timeout_budget_s=cfg.public_timeout_budget_s,
                        public_timeout_started_perf_counter_s=cfg.public_timeout_started_perf_counter_s,
                    ),
                ),
            )
            diagnostics = _frozen_step_trajectory_error_diagnostics(exc)
        callback_result = _call_trajectory_screen_callback(
            screen_callback,
            round_payload={
                "candidate_index": candidate_index,
                "num_leapfrog_steps": int(leapfrog_count),
                "trajectory_length": float(frozen_step) * int(leapfrog_count),
                "step_size": frozen_step,
                "screen_seed": screen_seed,
                "screen_config_payload": screen_config.signature_payload(),
                "adapter_signature": stable_adapter_signature(phase4_adapter),
                "hmc_adapter_signature": trajectory_hmc_signature,
                "mass_artifact_signature": before_mass_signature,
                "sample_space": "phase4_latent_position",
                "hmc_sample_space": "adapted_mass_latent",
            },
            samples=None
            if screen_result is None
            else trajectory_adapter.latent_to_position(screen_result.samples),
            diagnostics=diagnostics,
        )
        trajectory_window = _trajectory_window_payload(
            step_size=frozen_step,
            num_leapfrog_steps=int(leapfrog_count),
            target_trajectory_length=geometry.target_trajectory_length,
            lower_multiplier=cfg.trajectory_window_lower_multiplier,
            upper_multiplier=cfg.trajectory_window_upper_multiplier,
            max_leapfrog_steps=cfg.max_leapfrog_steps,
        )
        (
            classification,
            diagnostic_role,
            hard_vetoes,
            continuation_vetoes,
            promotion_vetoes,
            repair_triggers,
        ) = _classify_frozen_step_trajectory_candidate(
            cfg,
            diagnostics=diagnostics,
            trajectory_window=trajectory_window,
            screen_error=screen_error,
            callback_result=callback_result,
        )
        trajectory_length = float(trajectory_window["trajectory_length"])
        candidate_payload = {
            "candidate_index": candidate_index,
            "seed": screen_seed,
            "step_size": frozen_step,
            "num_leapfrog_steps": int(leapfrog_count),
            "trajectory_length": trajectory_length,
            "target_trajectory_length": geometry.target_trajectory_length,
            "target_trajectory_distance": abs(
                trajectory_length - float(geometry.target_trajectory_length)
            ),
            "trajectory_window": trajectory_window["trajectory_window"],
            "trajectory_window_relation": trajectory_window[
                "trajectory_window_relation"
            ],
            "trajectory_target_ratio": trajectory_window["trajectory_target_ratio"],
            "minimum_step_size_for_tau_floor": trajectory_window[
                "minimum_step_size_for_tau_floor"
            ],
            "required_leapfrog_for_tau_floor": trajectory_window[
                "required_leapfrog_for_tau_floor"
            ],
            "tau_floor_feasible_at_step": trajectory_window[
                "tau_floor_feasible_at_step"
            ],
            "max_leapfrog_steps": trajectory_window["max_leapfrog_steps"],
            "handoff_screen_policy": cfg.handoff_screen_policy,
            "nomination_eligible": classification in {
                "passed_screen",
                "nomination_screen",
            },
            "nomination_role": (
                "phase23_candidate_for_phase7_verification"
                if classification == "nomination_screen"
                else (
                    "phase6_passed_screen_for_phase7_verification"
                    if classification == "passed_screen"
                    else "phase6_not_eligible_for_handoff"
                )
            ),
            "trajectory_window_viability_gate_active": (
                not _phase23_nomination_policy_active(cfg.handoff_screen_policy)
            ),
            "trajectory_window_nomination_only": _phase23_nomination_policy_active(
                cfg.handoff_screen_policy
            ),
            "classification": classification,
            "diagnostic_role": diagnostic_role,
            "screen_config_payload": screen_config.signature_payload(),
            "diagnostics": diagnostics,
            "callback_result": callback_result.payload(),
            "hard_vetoes": hard_vetoes,
            "continuation_vetoes": continuation_vetoes,
            "promotion_vetoes": promotion_vetoes,
            "repair_triggers": repair_triggers,
            "runtime_path": "run_full_chain_tfp_hmc_or_injected_run_full_chain_hook",
            "toy_fixed_trajectory_diagnostic_used": False,
            "no_adaptation": True,
            "candidate_elapsed_s": candidate_elapsed_s[-1]
            if candidate_elapsed_s
            else None,
        }
        if runner_route_events:
            candidate_payload["runner_route_event"] = runner_route_events[-1]
        candidate_results.append(candidate_payload)
        if _private_diagnostic_callback is not None:
            _private_diagnostic_callback(
                "frozen_step_trajectory_candidate_complete",
                {
                    "stage": "frozen_step_trajectory_candidate_complete",
                    "attempt_index": progress_attempt_index,
                    "candidate_index": int(candidate_index),
                    "candidate_count": len(candidates),
                    "candidate_completed_count": len(candidate_results),
                    "candidate_pass_count": sum(
                        1
                        for candidate in candidate_results
                        if candidate.get("classification") == "passed_screen"
                    ),
                    "candidate_hard_veto_count": sum(
                        1
                        for candidate in candidate_results
                        if tuple(candidate.get("hard_vetoes", ()))
                    ),
                    "step_size": float(frozen_step),
                    "num_leapfrog_steps": int(leapfrog_count),
                    "trajectory_length": trajectory_length,
                    "target_trajectory_length": geometry.target_trajectory_length,
                    "trajectory_window": trajectory_window["trajectory_window"],
                    "trajectory_window_relation": trajectory_window[
                        "trajectory_window_relation"
                    ],
                    "trajectory_target_ratio": trajectory_window[
                        "trajectory_target_ratio"
                    ],
                    "screen_acceptance_rate": diagnostics.get("acceptance_rate"),
                    "classification": classification,
                    "diagnostic_role": diagnostic_role,
                    "hard_vetoes": hard_vetoes,
                    "continuation_vetoes": continuation_vetoes,
                    "promotion_vetoes": promotion_vetoes,
                    "repair_triggers": repair_triggers,
                    "selected_candidate": False,
                    "runner_route_hash": None
                    if not runner_route_events
                    else stable_config_hash(runner_route_events[-1]),
                    "private_hmc_mechanics": True,
                    "reports_posterior_convergence": False,
                    "reports_sampler_superiority": False,
                    "nonclaims": FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS,
                },
            )
        stage_hard_vetoes.extend(hard_vetoes)
        if continuation_vetoes:
            stage_hard_vetoes.append("frozen_step_trajectory_continuation_veto")
            stage_hard_vetoes.extend(continuation_vetoes)
        stage_repair_triggers.extend(repair_triggers)
        if hard_vetoes or continuation_vetoes:
            break

    stage_hard_vetoes = list(dict.fromkeys(str(item) for item in stage_hard_vetoes))
    stage_repair_triggers = list(
        dict.fromkeys(str(item) for item in stage_repair_triggers)
    )
    selected_index = None
    selected_payload = None
    selected_hash = None
    if stage_hard_vetoes:
        final_status = "hard_veto"
    else:
        selected_index = _select_frozen_step_trajectory_candidate(
            tuple(candidate_results),
            config=cfg,
            target_trajectory=geometry.target_trajectory_length,
        )
        if selected_index is None:
            final_status = "repair_or_retry"
            if not stage_repair_triggers:
                stage_repair_triggers.append("no_candidate_in_closed_acceptance_band")
        else:
            final_status = "passed"
            selected_payload = _frozen_step_trajectory_selected_payload(
                config=cfg,
                candidate=candidate_results[selected_index],
                selected_step_hash=str(fixed_mass_step_stage.selected_step_hash),
                selected_bootstrap_kernel_hash=fixed_mass_step_stage.selected_bootstrap_kernel_hash,
                fixed_mass_step_stage_artifact_hash=fixed_mass_step_stage.artifact_hash,
                adapted_mass_artifact_signature=before_mass_signature,
                phase4_hmc_adapter_signature=windowed_stage.hmc_adapter_signature,
                trajectory_hmc_adapter_signature=trajectory_hmc_signature,
                target_scope=target_scope,
            )
            selected_hash = stable_config_hash(selected_payload)
    after_mass_signature = _mass_artifact_signature(adapted_mass)
    frozen_mass_invariant = _frozen_step_trajectory_frozen_mass_invariant(
        before_mass_signature,
        after_mass_signature,
    )
    if not frozen_mass_invariant["passed"]:
        stage_hard_vetoes.append("frozen_step_trajectory_mass_signature_mutated")
        final_status = "hard_veto"
        selected_index = None
        selected_payload = None
        selected_hash = None
    frozen_step_invariant = _frozen_step_trajectory_frozen_step_invariant(
        before=frozen_step,
        after=_required_selected_step_size(fixed_mass_step_stage),
    )
    if not frozen_step_invariant["passed"]:
        stage_hard_vetoes.append("frozen_step_trajectory_step_mutated")
        final_status = "hard_veto"
        selected_index = None
        selected_payload = None
        selected_hash = None
    stage_hard_vetoes = list(dict.fromkeys(str(item) for item in stage_hard_vetoes))
    if _private_diagnostic_callback is not None:
        selected_candidate = (
            None if selected_index is None else candidate_results[int(selected_index)]
        )
        _private_diagnostic_callback(
            "frozen_step_trajectory_round_selected",
            {
                "stage": "frozen_step_trajectory_round_selected",
                "attempt_index": progress_attempt_index,
                "candidate_count": len(candidates),
                "candidate_completed_count": len(candidate_results),
                "candidate_pass_count": sum(
                    1
                    for candidate in candidate_results
                    if candidate.get("classification") == "passed_screen"
                ),
                "candidate_hard_veto_count": sum(
                    1
                    for candidate in candidate_results
                    if tuple(candidate.get("hard_vetoes", ()))
                ),
                "selected_pair_exists": selected_candidate is not None,
                "selected_candidate_index": selected_index,
                "step_size": None
                if selected_candidate is None
                else float(selected_candidate["step_size"]),
                "num_leapfrog_steps": None
                if selected_candidate is None
                else int(selected_candidate["num_leapfrog_steps"]),
                "trajectory_length": None
                if selected_candidate is None
                else selected_candidate.get("trajectory_length"),
                "target_trajectory_length": geometry.target_trajectory_length,
                "selected_trajectory_hash": selected_hash,
                "final_status": final_status,
                "diagnostic_role": (
                    "frozen_step_trajectory_handoff_only"
                    if final_status == "passed"
                    else (
                        "repair_trigger"
                        if final_status == "repair_or_retry"
                        else "hard_veto"
                    )
                ),
                "hard_vetoes": tuple(stage_hard_vetoes),
                "repair_triggers": tuple(stage_repair_triggers),
                "mass_signature_unchanged": frozen_mass_invariant["passed"],
                "step_size_unchanged": frozen_step_invariant["passed"],
                "private_hmc_mechanics": True,
                "reports_posterior_convergence": False,
                "reports_sampler_superiority": False,
                "nonclaims": FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS,
            },
        )
    diagnostic_role = (
        "frozen_step_trajectory_handoff_only"
        if final_status == "passed"
        else ("repair_trigger" if final_status == "repair_or_retry" else "hard_veto")
    )
    return HMCFrozenStepTrajectoryStageResult(
        config=cfg,
        geometry_artifact_hash=geometry.artifact_hash,
        bootstrap_artifact_hash=bootstrap.artifact_hash,
        windowed_stage_artifact_hash=windowed_stage.artifact_hash,
        fixed_mass_step_stage_artifact_hash=fixed_mass_step_stage.artifact_hash,
        selected_bootstrap_kernel_hash=fixed_mass_step_stage.selected_bootstrap_kernel_hash,
        selected_step_hash=str(fixed_mass_step_stage.selected_step_hash),
        adapter_signature=fixed_mass_step_stage.adapter_signature,
        phase4_hmc_adapter_signature=windowed_stage.hmc_adapter_signature,
        phase5_ladder_hmc_adapter_signature=fixed_mass_step_stage.ladder_hmc_adapter_signature,
        trajectory_hmc_adapter_signature=trajectory_hmc_signature,
        adapted_mass_artifact_payload=adapted_mass.to_payload(include_arrays=True),
        adapted_mass_artifact_signature=before_mass_signature,
        frozen_step_size=frozen_step,
        fixed_bootstrap_num_leapfrog_steps=fixed_pair_l,
        target_dimension=windowed_stage.target_dimension,
        candidate_generation=candidate_generation,
        candidate_results=tuple(candidate_results),
        selected_candidate_index=selected_index,
        selected_trajectory_payload=selected_payload,
        selected_trajectory_hash=selected_hash,
        final_status=final_status,
        diagnostic_role=diagnostic_role,
        hard_vetoes=tuple(stage_hard_vetoes),
        repair_triggers=tuple(stage_repair_triggers),
        diagnostics=_frozen_step_trajectory_stage_diagnostics(
            tuple(candidate_results),
            final_status=final_status,
            selected_candidate_index=selected_index,
            run_error=run_error,
            hard_vetoes=tuple(stage_hard_vetoes),
            repair_triggers=tuple(stage_repair_triggers),
            handoff_screen_policy=cfg.handoff_screen_policy,
            runner_route_summary=_kernel_stage_runner_route_summary(
                active_route=(
                    "frozen_step_trajectory_scoped_reusable_runner"
                    if use_reusable_route
                    else "single_use_or_injected_runner"
                ),
                events=tuple(runner_route_events),
                contract_payloads=runner_contract_payloads,
                semantic_source="run_hmc_frozen_step_trajectory_stage",
                reuse_nonclaim=(
                    "uniform route telemetry does not imply uniform candidate L; "
                    "compatible selected-pair handoff screens may reuse a "
                    "fixed-mass screen runner"
                ),
                handoff_source=runner_handoff_source,
                initial_handoff_contract_count=initial_handoff_contract_count,
            ),
            soft_deadline_closeout=soft_deadline_closeout,
            expected_candidate_count=len(candidates),
        ),
        frozen_mass_invariant=frozen_mass_invariant,
        frozen_step_invariant=frozen_step_invariant,
        seed_report={
            "fixed_mass_step_stage_seed": fixed_mass_step_stage.seed_report.get(
                "fixed_mass_stage_root_seed"
            ),
            "frozen_step_trajectory_root_seed": cfg.seed,
            "candidate_screen_seeds": tuple(
                candidate["seed"] for candidate in candidate_results
            ),
            "seed_owner": "BayesFilter",
        },
        diagnostic_roles={
            "frozen_mass_invariant": "hard_veto",
            "frozen_step_invariant": "hard_veto",
            "candidate_acceptance": "trajectory_handoff_promotion_or_repair",
            "candidate_trajectory_window": "trajectory_handoff_promotion_or_repair",
            "candidate_log_accept_ratio": "hard_veto",
            "candidate_target_log_prob": "hard_veto",
            "target_status_telemetry": "hard_veto_when_enabled",
            "callback_hard_veto": "hard_veto",
            "callback_continuation_veto": "continuation_veto",
            "callback_promotion_veto": "repair_trigger",
            "runtime": "explanatory_or_hard_veto_when_missing",
            "candidate_l_values": "diagnostic_telemetry_only",
        },
    )


def _coerce_private_runner_cache_handoff_mapping(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise TypeError("private runner cache handoff must be a mapping")
    return dict(value)


def _coerce_private_runner_contract_handoff_mapping(
    value: Any,
) -> dict[str, Mapping[str, Any]]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise TypeError("private runner contract handoff must be a mapping")
    return {str(key): dict(payload) for key, payload in value.items()}


def _callable_accepts_private_diagnostic_callback(callback: Callable[..., Any]) -> bool:
    try:
        parameters = inspect.signature(callback).parameters
    except (TypeError, ValueError):
        return callback is run_hmc_frozen_step_trajectory_stage
    if "_private_diagnostic_callback" in parameters:
        return True
    return any(
        parameter.kind == inspect.Parameter.VAR_KEYWORD
        for parameter in parameters.values()
    )


def _callable_accepts_runner_cache_handoff(callback: Callable[..., Any]) -> bool:
    try:
        parameters = inspect.signature(callback).parameters
    except (TypeError, ValueError):
        return callback is run_hmc_frozen_step_trajectory_stage
    if "_runner_cache_handoff" in parameters:
        return True
    return any(
        parameter.kind == inspect.Parameter.VAR_KEYWORD
        for parameter in parameters.values()
    )


def run_hmc_tune_verify_repair_loop(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
    config: HMCTuneVerifyRepairLoopConfig | None = None,
    fixed_mass_screen_callback: FixedMassScreenCallback | None = None,
    trajectory_screen_callback: TrajectoryScreenCallback | None = None,
    verification_callback: VerificationCallback | None = None,
    verification_checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None = None,
    run_full_chain: RunFullChainFn = run_full_chain_tfp_hmc,
    _budget_policy_factory: Callable[[int, int], "_HMCAttemptBudgetPolicy"] | None = None,
    _windowed_stage_runner: Callable[..., HMCWindowedMassStageResult] = run_hmc_windowed_mass_stage,
    _fixed_mass_step_stage_runner: Callable[..., HMCFixedMassStepStageResult] = run_hmc_fixed_mass_step_stage,
    _frozen_step_trajectory_stage_runner: Callable[..., HMCFrozenStepTrajectoryStageResult] = run_hmc_frozen_step_trajectory_stage,
    _phase7_final_verification_runner: Callable[..., tuple[
        Mapping[str, Any] | None,
        Mapping[str, Any],
        FixedMassHMCTuningBudgetCallbackResult,
        str,
        str,
        tuple[str, ...],
        tuple[str, ...],
    ]] | None = None,
    _progress_callback: LoopProgressCallback | None = None,
    _private_diagnostic_callback: PrivateTuningDiagnosticCallback | None = None,
    _g2_seed_use_registry: G2PreboundarySeedUseRegistry | None = None,
    _campaign_checkpoint: HMCTuningCampaignCheckpoint | None = None,
) -> HMCTuneVerifyRepairLoopResult:
    """Run Phase 7 tune/verify/repair with private budget escalation.

    This is a scoped Phase 7 orchestration helper. It may be imported directly,
    but it is not the final one-call ``tune_hmc_kernel`` API.
    """

    cfg = HMCTuneVerifyRepairLoopConfig() if config is None else config
    if not isinstance(cfg, HMCTuneVerifyRepairLoopConfig):
        raise TypeError("config must be HMCTuneVerifyRepairLoopConfig")
    p4_route = cfg.engineering_probe_covariance_multiplier is not None
    if p4_route and not isinstance(
        _g2_seed_use_registry,
        G2PreboundarySeedUseRegistry,
    ):
        raise TypeError("P4-E requires a caller-owned G2 seed-use registry")
    if not p4_route and _g2_seed_use_registry is not None:
        raise TypeError("G2 seed-use registry is valid only for the P4-E route")
    route_decision = require_hmc_algorithm_route(
        algorithm_id=cfg.algorithm_id,
        stage=HMC_TOP_LEVEL_SELECTION_STAGE,
        runtime_backend="tensorflow",
        chain_execution_mode=cfg.chain_execution_mode,
        use_xla=cfg.use_xla,
        timeout_enabled=cfg.public_timeout_budget_s is not None,
        heartbeat_enabled=cfg.incall_progress_heartbeat_s is not None,
        checkpointing_enabled=verification_checkpoint_writer_config is not None,
        runner_identity=(
            "default" if run_full_chain is run_full_chain_tfp_hmc else "injected"
        ),
    )
    if not isinstance(geometry, HMCGeometryInitializationResult):
        raise TypeError("geometry must be HMCGeometryInitializationResult")
    if not isinstance(bootstrap, HMCBootstrapScreenResult):
        raise TypeError("bootstrap must be HMCBootstrapScreenResult")
    _validate_tune_verify_loop_inputs(adapter=adapter, geometry=geometry, bootstrap=bootstrap)
    target_scope = _resolve_tune_verify_loop_target_scope(adapter, cfg)
    if target_scope != _resolve_windowed_stage_target_scope(
        adapter,
        HMCWindowedMassStageConfig(
            algorithm_id=windowed_algorithm_for_selection_algorithm(cfg.algorithm_id),
            target_accept_prob=cfg.target_accept_prob,
            seed=_derive_seed(cfg.seed, stage_index=10),
            chain_execution_mode=cfg.chain_execution_mode,
            target_scope=cfg.target_scope,
            target_status_trace_policy=cfg.target_status_trace_policy,
            source=cfg.source,
        ),
    ):
        raise ValueError("Phase 7 target scope resolution mismatch")
    policy_factory = (
        _default_attempt_budget_policy if _budget_policy_factory is None else _budget_policy_factory
    )
    phase7_final_verification_runner = (
        _run_phase7_final_verification
        if _phase7_final_verification_runner is None
        else _phase7_final_verification_runner
    )
    attempts: list[HMCTuneVerifyRepairAttempt] = []
    hard_vetoes: list[str] = []
    repair_triggers: list[str] = []
    attempt_state: _HMCPhaseAttemptState | None = None
    verification_only_retry_bundle: Mapping[str, Any] | None = None
    operational_repair_verification_bundle: Mapping[str, Any] | None = None
    final_kernel_payload: Mapping[str, Any] | None = None
    final_kernel_hash: str | None = None
    final_status = "budget_exhausted"
    diagnostic_role = "budget_exhausted_non_promoting"
    terminal_budget_guard_payload: Mapping[str, Any] | None = None

    attempt_index = 0
    terminal_phase6_repair_extra_attempts_consumed = 0
    resume_terminal = False
    if _campaign_checkpoint is not None and _campaign_checkpoint.attempt_states:
        saved = _campaign_checkpoint.attempt_states
        attempts = [item["attempt"] for item in saved]
        if any(attempt.attempt_index != index for index, attempt in enumerate(attempts)):
            raise ValueError("checkpoint attempt indices are not contiguous")
        last = saved[-1]
        attempt_state = last["handoff_state"]
        attempt_index = len(attempts)
        hard_vetoes = [code for attempt in attempts for code in attempt.hard_vetoes]
        repair_triggers = [code for attempt in attempts for code in attempt.repair_triggers]
        verification_only_retry_bundle = last["verification_only_retry_bundle"]
        operational_repair_verification_bundle = last["operational_repair_verification_bundle"]
        terminal_phase6_repair_extra_attempts_consumed = last["extra_attempts_consumed"]
        if attempts[-1].final_status in {"passed", "hard_veto", "architecture_blocked"}:
            # A terminal real-target failure is never automatically retried.
            resume_terminal = True
            final_status = attempts[-1].final_status
            diagnostic_role = attempts[-1].diagnostic_role
            final_kernel_payload = last["final_kernel_payload"]
            final_kernel_hash = last["final_kernel_hash"]
    loop_exhausted = False
    terminal_phase6_slot_payload: Mapping[str, Any] | None = None
    while not resume_terminal:
        if attempt_index >= int(cfg.max_attempts):
            if _phase7_terminal_phase6_repair_slot_eligible(
                config=cfg,
                attempt_state=attempt_state,
                last_attempt=attempts[-1] if attempts else None,
                consumed_slots=terminal_phase6_repair_extra_attempts_consumed,
            ):
                terminal_phase6_slot_payload = _phase7_terminal_phase6_repair_slot_payload(
                    config=cfg,
                    attempt_state=attempt_state,
                    last_attempt=attempts[-1] if attempts else None,
                    attempt_index=attempt_index,
                    consumed_slots=terminal_phase6_repair_extra_attempts_consumed,
                )
            else:
                loop_exhausted = True
                break
        else:
            terminal_phase6_slot_payload = None
        budget_policy = policy_factory(geometry.target_dimension, attempt_index)
        if not isinstance(budget_policy, _HMCAttemptBudgetPolicy):
            raise TypeError("private budget policy factory must return _HMCAttemptBudgetPolicy")
        extended_attempt_stall_blocker = _phase7_extended_attempt_stall_blocker(
            config=cfg,
            attempt_state=attempt_state,
            last_attempt=attempts[-1] if attempts else None,
            next_attempt_policy=budget_policy,
        )
        if extended_attempt_stall_blocker is not None:
            final_status = "budget_exhausted"
            diagnostic_role = _PHASE7_EXTENDED_ATTEMPT_STALLED
            terminal_budget_guard_payload = extended_attempt_stall_blocker
            repair_triggers.append(_PHASE7_EXTENDED_ATTEMPT_STALLED)
            _emit_phase7_progress(
                _progress_callback,
                _PHASE7_EXTENDED_ATTEMPT_STALLED,
                attempt_index=attempt_index,
                budget_policy=budget_policy,
                completed=True,
                extra=extended_attempt_stall_blocker,
            )
            break
        verify_only_budget_blocker = _phase7_verify_only_budget_saturation_blocker(
            config=cfg,
            attempt_state=attempt_state,
            next_attempt_policy=budget_policy,
        )
        if verify_only_budget_blocker is not None:
            final_status = "budget_exhausted"
            diagnostic_role = _PHASE7_VERIFY_ONLY_BUDGET_SATURATED
            terminal_budget_guard_payload = verify_only_budget_blocker
            repair_triggers.append(_PHASE7_VERIFY_ONLY_BUDGET_SATURATED)
            _emit_phase7_progress(
                _progress_callback,
                _PHASE7_VERIFY_ONLY_BUDGET_SATURATED,
                attempt_index=attempt_index,
                budget_policy=budget_policy,
                completed=True,
                extra=verify_only_budget_blocker,
            )
            break
        verification_budget_blocker = _phase7_verification_acceptance_budget_blocker(
            config=cfg,
            attempt_state=attempt_state,
            next_attempt_policy=budget_policy,
        )
        if verification_budget_blocker is not None:
            final_status = "budget_exhausted"
            diagnostic_role = _PHASE7_VERIFICATION_ACCEPTANCE_BUDGET_BLOCKED
            terminal_budget_guard_payload = verification_budget_blocker
            repair_triggers.append(_PHASE7_VERIFICATION_ACCEPTANCE_BUDGET_BLOCKED)
            _emit_phase7_progress(
                _progress_callback,
                _PHASE7_VERIFICATION_ACCEPTANCE_BUDGET_BLOCKED,
                attempt_index=attempt_index,
                budget_policy=budget_policy,
                completed=True,
                extra=verification_budget_blocker,
            )
            break
        if terminal_phase6_slot_payload is not None:
            terminal_phase6_repair_extra_attempts_consumed += 1
        _emit_phase7_progress(
            _progress_callback,
            "loop_attempt_start",
            attempt_index=attempt_index,
            budget_policy=budget_policy,
            started=True,
            extra={
                "incoming_repair_handoff_available": attempt_state is not None,
                **(
                    {}
                    if terminal_phase6_slot_payload is None
                    else {"terminal_phase6_repair_slot": terminal_phase6_slot_payload}
                ),
            },
        )
        incoming_payload = None if attempt_state is None else attempt_state.payload()
        windowed_stage: HMCWindowedMassStageResult | None = None
        fixed_stage: HMCFixedMassStepStageResult | None = None
        trajectory_stage: HMCFrozenStepTrajectoryStageResult | None = None
        verification_config_payload: Mapping[str, Any] | None = None
        verification_diagnostics: Mapping[str, Any] = {
            "attempt_index": attempt_index,
            "not_run": True,
            "reports_posterior_convergence": False,
        }
        verification_callback_result = FixedMassHMCTuningBudgetCallbackResult()
        attempt_hard_vetoes: list[str] = []
        attempt_repair_triggers: list[str] = []
        attempt_status = "repair_or_retry"
        attempt_role = "repair_trigger"
        handoff_state: _HMCPhaseAttemptState | None = None
        direct_queue_result: _HMCPhase7DirectCandidateQueueResult | None = None
        direct_handoff_outcome: _HMCPhase7FixedKernelVerificationOutcome | None = None
        use_verification_only_retry = (
            verification_only_retry_bundle is not None
            and _phase7_should_retry_verification_only(attempt_state)
        )
        use_operational_repair_verification = (
            operational_repair_verification_bundle is not None
            and _phase7_should_run_operational_repair_verification(attempt_state)
        )
        pre_windowed_timeout: Mapping[str, Any] | None = None
        if not use_verification_only_retry and not use_operational_repair_verification:
            pre_windowed_timeout = _phase7_public_timeout_before_windowed_mass(
                config=_phase7_windowed_stage_config(cfg, attempt_index=attempt_index),
                attempt_index=attempt_index,
                target_dimension=geometry.target_dimension,
                budget_policy=budget_policy,
            )
            if pre_windowed_timeout is not None:
                attempt_status = "hard_veto"
                attempt_role = "hard_veto"
                attempt_hard_vetoes.append(
                    _PHASE7_PUBLIC_TIMEOUT_BEFORE_WINDOWED_MASS_HARD_VETO
                )
                attempt_repair_triggers.append(
                    _PHASE7_PUBLIC_TIMEOUT_BEFORE_WINDOWED_MASS_REPAIR_TRIGGER
                )
                verification_diagnostics = {
                    "attempt_index": attempt_index,
                    "not_run": _PHASE7_PUBLIC_TIMEOUT_BEFORE_WINDOWED_MASS_HARD_VETO,
                    "public_timeout_closeout": pre_windowed_timeout,
                    "windowed_stage_runner_called": False,
                    "reports_posterior_convergence": False,
                    "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
                }
                _emit_phase7_progress(
                    _progress_callback,
                    _PHASE7_PUBLIC_TIMEOUT_BEFORE_WINDOWED_MASS_HARD_VETO,
                    attempt_index=attempt_index,
                    budget_policy=budget_policy,
                    completed=True,
                    extra={
                        **dict(pre_windowed_timeout),
                        "resume_split_public_summary": _phase7_attempt_resume_split_public_summary(
                            HMCTuneVerifyRepairAttempt(
                                attempt_index=attempt_index,
                                budget_policy_payload=budget_policy.payload(),
                                incoming_state_payload=incoming_payload,
                                windowed_stage=None,
                                fixed_mass_step_stage=None,
                                frozen_step_trajectory_stage=None,
                                verification_config_payload=None,
                                verification_diagnostics=verification_diagnostics,
                                verification_callback_result=verification_callback_result,
                                final_status=attempt_status,
                                diagnostic_role=attempt_role,
                                hard_vetoes=tuple(attempt_hard_vetoes),
                                repair_triggers=tuple(attempt_repair_triggers),
                                handoff_state_payload=None,
                            )
                        ),
                    },
                )

        try:
            if pre_windowed_timeout is not None:
                pass
            elif use_operational_repair_verification:
                windowed_stage = operational_repair_verification_bundle[
                    "windowed_stage"
                ]
                fixed_stage = operational_repair_verification_bundle[
                    "fixed_mass_step_stage"
                ]
                trajectory_stage = None
                if attempt_state is None:
                    raise ValueError("operational repair verification lost attempt state")
                _emit_phase7_progress(
                    _progress_callback,
                    "operational_repair_verification_start",
                    attempt_index=attempt_index,
                    budget_policy=budget_policy,
                    started=True,
                    extra={
                        "retry_source": "phase7_operational_scalar_step_repair",
                        "skips_phase4_phase5_phase6": True,
                        "reservation_consumed": True,
                        "hmc_mechanics_exposed": False,
                        "reports_posterior_convergence": False,
                    },
                )
                direct_handoff_outcome = _run_phase7_operational_repair_verification(
                    adapter=adapter,
                    geometry=geometry,
                    windowed_stage=windowed_stage,
                    fixed_mass_step_stage=fixed_stage,
                    config=cfg,
                    budget_policy=budget_policy,
                    attempt_state=attempt_state,
                    attempt_index=attempt_index,
                    target_scope=target_scope,
                    verification_callback=verification_callback,
                    checkpoint_writer_config=verification_checkpoint_writer_config,
                    verification_start_callback=None,
                    checkpoint_reference_callback=lambda reference: _emit_phase7_progress(
                        _progress_callback,
                        "verification_checkpoint_written",
                        attempt_index=attempt_index,
                        budget_policy=budget_policy,
                        completed=True,
                        extra=_phase7_checkpoint_progress_extra(reference),
                    ),
                    run_full_chain=run_full_chain,
                )
                verification_config_payload = (
                    direct_handoff_outcome.verification_config_payload
                )
                verification_diagnostics = {
                    **dict(direct_handoff_outcome.diagnostics),
                    "phase7_retry_class": "operational_scalar_repair_verification",
                    "phase7_operational_repair_verification": True,
                    "phase7_reused_frozen_kernel_handoff": True,
                    "reports_posterior_convergence": False,
                }
                verification_callback_result = direct_handoff_outcome.callback_result
                attempt_status = direct_handoff_outcome.final_status
                attempt_role = direct_handoff_outcome.diagnostic_role
                attempt_hard_vetoes.extend(direct_handoff_outcome.hard_vetoes)
                attempt_repair_triggers.extend(direct_handoff_outcome.repair_triggers)
                if attempt_status == "passed":
                    final_kernel_payload = _phase7_direct_final_kernel_payload(
                        config=cfg,
                        geometry=geometry,
                        bootstrap=bootstrap,
                        windowed_stage=windowed_stage,
                        fixed_mass_step_stage=fixed_stage,
                        outcome=direct_handoff_outcome,
                        budget_policy=budget_policy,
                        attempt_index=attempt_index,
                        target_scope=target_scope,
                    )
                    final_kernel_hash = stable_config_hash(final_kernel_payload)
            elif use_verification_only_retry:
                windowed_stage = verification_only_retry_bundle["windowed_stage"]
                fixed_stage = verification_only_retry_bundle["fixed_mass_step_stage"]
                trajectory_stage = verification_only_retry_bundle["trajectory_stage"]
                _emit_phase7_progress(
                    _progress_callback,
                    "verification_only_retry_start",
                    attempt_index=attempt_index,
                    budget_policy=budget_policy,
                    started=True,
                    extra={
                        "retry_source": "phase7_rhat_cap_in_band",
                        "skips_phase4_phase5_phase6": True,
                        "hmc_mechanics_exposed": False,
                        "reports_posterior_convergence": False,
                    },
                )
                _emit_phase7_progress(
                    _progress_callback,
                    "verification_start",
                    attempt_index=attempt_index,
                    budget_policy=budget_policy,
                    started=True,
                )
                if verification_only_retry_bundle.get("source_kind") == (
                    "direct_phase5_candidate"
                ):
                    direct_handoff_outcome = _run_phase7_direct_candidate_verification(
                        adapter=adapter,
                        geometry=geometry,
                        windowed_stage=windowed_stage,
                        fixed_mass_step_stage=fixed_stage,
                        candidate_identity=verification_only_retry_bundle[
                            "candidate_identity"
                        ],
                        config=cfg,
                        budget_policy=budget_policy,
                        attempt_index=attempt_index,
                        target_scope=target_scope,
                        verification_callback=verification_callback,
                        checkpoint_writer_config=verification_checkpoint_writer_config,
                        verification_start_callback=None,
                        checkpoint_reference_callback=lambda reference: _emit_phase7_progress(
                            _progress_callback,
                            "verification_checkpoint_written",
                            attempt_index=attempt_index,
                            budget_policy=budget_policy,
                            completed=True,
                            extra=_phase7_checkpoint_progress_extra(reference),
                        ),
                        run_full_chain=run_full_chain,
                    )
                    verification_config_payload = (
                        direct_handoff_outcome.verification_config_payload
                    )
                    verification_diagnostics = direct_handoff_outcome.diagnostics
                    verification_callback_result = direct_handoff_outcome.callback_result
                    verify_status = direct_handoff_outcome.final_status
                    verify_role = direct_handoff_outcome.diagnostic_role
                    verify_hard_vetoes = direct_handoff_outcome.hard_vetoes
                    verify_repair_triggers = direct_handoff_outcome.repair_triggers
                elif verification_only_retry_bundle.get("source_kind") == (
                    "operational_selection_v2"
                ):
                    direct_handoff_outcome = (
                        _run_phase7_operational_evidence_extension(
                            adapter=adapter,
                            geometry=geometry,
                            windowed_stage=windowed_stage,
                            fixed_mass_step_stage=fixed_stage,
                            config=cfg,
                            budget_policy=budget_policy,
                            attempt_index=attempt_index,
                            target_scope=target_scope,
                            verification_callback=verification_callback,
                            checkpoint_writer_config=verification_checkpoint_writer_config,
                            checkpoint_reference_callback=lambda reference: _emit_phase7_progress(
                                _progress_callback,
                                "verification_checkpoint_written",
                                attempt_index=attempt_index,
                                budget_policy=budget_policy,
                                completed=True,
                                extra=_phase7_checkpoint_progress_extra(reference),
                            ),
                            run_full_chain=run_full_chain,
                        )
                    )
                    verification_config_payload = (
                        direct_handoff_outcome.verification_config_payload
                    )
                    verification_diagnostics = direct_handoff_outcome.diagnostics
                    verification_callback_result = direct_handoff_outcome.callback_result
                    verify_status = direct_handoff_outcome.final_status
                    verify_role = direct_handoff_outcome.diagnostic_role
                    verify_hard_vetoes = direct_handoff_outcome.hard_vetoes
                    verify_repair_triggers = direct_handoff_outcome.repair_triggers
                else:
                    (
                        verification_config_payload,
                        verification_diagnostics,
                        verification_callback_result,
                        verify_status,
                        verify_role,
                        verify_hard_vetoes,
                        verify_repair_triggers,
                    ) = phase7_final_verification_runner(
                        adapter=adapter,
                        geometry=geometry,
                        windowed_stage=windowed_stage,
                        fixed_mass_step_stage=fixed_stage,
                        trajectory_stage=trajectory_stage,
                        config=cfg,
                        budget_policy=budget_policy,
                        attempt_index=attempt_index,
                        target_scope=target_scope,
                        verification_callback=verification_callback,
                        checkpoint_writer_config=verification_checkpoint_writer_config,
                        verification_start_callback=None,
                        checkpoint_reference_callback=lambda reference: _emit_phase7_progress(
                            _progress_callback,
                            "verification_checkpoint_written",
                            attempt_index=attempt_index,
                            budget_policy=budget_policy,
                            completed=True,
                            extra=_phase7_checkpoint_progress_extra(reference),
                        ),
                        run_full_chain=run_full_chain,
                    )
                retry_remains_verification_only = (
                    _phase7_verification_result_supports_verification_only_retry(
                        config=cfg,
                        verification_diagnostics=verification_diagnostics,
                        verify_status=verify_status,
                        verify_role=verify_role,
                        verify_hard_vetoes=verify_hard_vetoes,
                        verify_repair_triggers=verify_repair_triggers,
                    )
                )
                verification_diagnostics = {
                    **dict(verification_diagnostics),
                    "phase7_retry_class": (
                        "verification_only_after_rhat_cap"
                        if retry_remains_verification_only
                        else "verification_only_disarmed_acceptance_repair"
                    ),
                    "phase7_verification_only_retry": retry_remains_verification_only,
                    "phase7_reused_frozen_kernel_handoff": True,
                    "reports_posterior_convergence": False,
                }
                _emit_phase7_progress(
                    _progress_callback,
                    "verification_complete",
                    attempt_index=attempt_index,
                    budget_policy=budget_policy,
                    completed=True,
                    extra={
                        "final_status": verify_status,
                        "diagnostic_role": verify_role,
                        "hard_veto_count": len(verify_hard_vetoes),
                        "repair_trigger_count": len(verify_repair_triggers),
                        "retry_class": verification_diagnostics["phase7_retry_class"],
                    },
                )
                attempt_status = verify_status
                attempt_role = verify_role
                attempt_hard_vetoes.extend(verify_hard_vetoes)
                attempt_repair_triggers.extend(verify_repair_triggers)
                if attempt_status == "passed":
                    if direct_handoff_outcome is not None:
                        final_kernel_payload = _phase7_direct_final_kernel_payload(
                            config=cfg,
                            geometry=geometry,
                            bootstrap=bootstrap,
                            windowed_stage=windowed_stage,
                            fixed_mass_step_stage=fixed_stage,
                            outcome=direct_handoff_outcome,
                            budget_policy=budget_policy,
                            attempt_index=attempt_index,
                            target_scope=target_scope,
                        )
                    else:
                        final_kernel_payload = _phase7_final_kernel_payload(
                            config=cfg,
                            geometry=geometry,
                            bootstrap=bootstrap,
                            windowed_stage=windowed_stage,
                            fixed_mass_step_stage=fixed_stage,
                            trajectory_stage=trajectory_stage,
                            verification_config_payload=verification_config_payload,
                            verification_diagnostics=verification_diagnostics,
                            budget_policy=budget_policy,
                            attempt_index=attempt_index,
                            target_scope=target_scope,
                        )
                    final_kernel_hash = stable_config_hash(final_kernel_payload)
            else:
                verification_only_retry_bundle = None
                _emit_phase7_progress(
                    _progress_callback,
                    "windowed_mass_start",
                    attempt_index=attempt_index,
                    budget_policy=budget_policy,
                    started=True,
                )

                def forward_windowed_mass_progress(
                    stage: str,
                    payload: Mapping[str, Any],
                ) -> None:
                    _emit_phase7_progress(
                        _progress_callback,
                        stage,
                        attempt_index=attempt_index,
                        budget_policy=budget_policy,
                        started=bool(payload.get("started")),
                        completed=bool(payload.get("completed")),
                        extra=_windowed_mass_progress_extra(payload),
                    )

                p4_registry_kwargs = (
                    {}
                    if _g2_seed_use_registry is None
                    else {"_g2_seed_use_registry": _g2_seed_use_registry}
                )
                windowed_stage = _windowed_stage_runner(
                    adapter=adapter,
                    geometry=geometry,
                    bootstrap=bootstrap,
                    config=_phase7_windowed_stage_config(cfg, attempt_index=attempt_index),
                    run_full_chain=run_full_chain,
                    _attempt_budget_policy=budget_policy,
                    _attempt_state=attempt_state,
                    _progress_callback=forward_windowed_mass_progress,
                    _attempt_index=attempt_index,
                    _checkpoint_writer_config=verification_checkpoint_writer_config,
                    _private_diagnostic_callback=_private_diagnostic_callback,
                    **p4_registry_kwargs,
                )
                expected_windowed_algorithm_id = (
                    windowed_algorithm_for_selection_algorithm(cfg.algorithm_id)
                )
                if windowed_stage.config.algorithm_id != expected_windowed_algorithm_id:
                    raise ValueError(
                        "Phase 7 windowed-stage algorithm route lineage mismatch"
                    )
                _emit_phase7_progress(
                    _progress_callback,
                    "windowed_mass_complete",
                    attempt_index=attempt_index,
                    budget_policy=budget_policy,
                    completed=True,
                    extra={
                        "final_status": windowed_stage.final_status,
                        "passed": windowed_stage.passed,
                        "artifact_hash": windowed_stage.artifact_hash,
                    },
                )
                if windowed_stage.final_status == "hard_veto":
                    attempt_hard_vetoes.extend(windowed_stage.hard_vetoes)
                    attempt_status = "hard_veto"
                    attempt_role = "hard_veto"
                elif windowed_stage.final_status == "budget_exhausted":
                    attempt_repair_triggers.extend(windowed_stage.repair_triggers)
                    attempt_status = "budget_exhausted"
                    attempt_role = windowed_stage.diagnostic_role
                    verification_diagnostics = {
                        "attempt_index": attempt_index,
                        "not_run": True,
                        "reason": "windowed_mass_resource_closeout",
                        "reports_posterior_convergence": False,
                    }
                elif not windowed_stage.passed:
                    attempt_repair_triggers.extend(windowed_stage.repair_triggers)
                    attempt_repair_triggers.append(
                        f"phase4_windowed_mass_status:{windowed_stage.final_status}"
                    )
                else:
                    _emit_phase7_progress(
                        _progress_callback,
                        "fixed_mass_step_start",
                        attempt_index=attempt_index,
                        budget_policy=budget_policy,
                        started=True,
                    )
                    fixed_stage = _fixed_mass_step_stage_runner(
                        adapter=adapter,
                        geometry=geometry,
                        bootstrap=bootstrap,
                        windowed_stage=windowed_stage,
                        config=_phase7_fixed_step_stage_config(cfg, attempt_index=attempt_index),
                        screen_callback=fixed_mass_screen_callback,
                        run_full_chain=run_full_chain,
                        _attempt_budget_policy=budget_policy,
                        _attempt_state=attempt_state,
                        _progress_callback=_progress_callback,
                        _attempt_index=attempt_index,
                        _max_leapfrog_steps=cfg.max_leapfrog_steps,
                        _private_diagnostic_callback=_private_diagnostic_callback,
                        _repair_verification_reserved=(
                            attempt_index + 1 < int(cfg.max_attempts)
                        ),
                        _selection_max_attempts=(
                            min(
                                5,
                                int(cfg.max_attempts) - int(attempt_index),
                            )
                        ),
                        _candidate_handoff_policy=(
                            cfg.operational_candidate_handoff_policy
                        ),
                    )
                    _emit_phase7_progress(
                        _progress_callback,
                        "fixed_mass_step_complete",
                        attempt_index=attempt_index,
                        budget_policy=budget_policy,
                        completed=True,
                        extra={
                            "final_status": fixed_stage.final_status,
                            "passed": fixed_stage.passed,
                            "artifact_hash": fixed_stage.artifact_hash,
                        },
                    )
                    phase5_route = _phase7_direct_candidate_queue_route(
                        fixed_mass_step_stage=fixed_stage,
                        fixed_mass_step_stage_runner=_fixed_mass_step_stage_runner,
                    )
                    if fixed_stage.final_status == "hard_veto":
                        attempt_hard_vetoes.extend(fixed_stage.hard_vetoes)
                        attempt_status = "hard_veto"
                        attempt_role = "hard_veto"
                        verification_diagnostics = (
                            _phase7_phase5_candidates_not_run_diagnostics(
                                fixed_mass_step_stage=fixed_stage,
                                reason="phase5_hard_veto",
                            )
                        )
                    elif fixed_stage.final_status == "budget_exhausted":
                        attempt_repair_triggers.extend(fixed_stage.repair_triggers)
                        attempt_repair_triggers.append(
                            f"phase5_fixed_mass_step_status:{fixed_stage.final_status}"
                        )
                        attempt_status = "budget_exhausted"
                        attempt_role = fixed_stage.diagnostic_role
                        verification_diagnostics = (
                            _phase7_phase5_candidates_not_run_diagnostics(
                                fixed_mass_step_stage=fixed_stage,
                                reason="phase5_budget_exhausted",
                            )
                        )
                    elif phase5_route == "direct_phase5_candidate_queue":
                        handoff = _phase5_candidate_batch_handoff(fixed_stage)
                        if handoff is None:
                            raise ValueError("direct Phase 5 route lost its candidate batch")
                        if (
                            fixed_stage.final_status == "repair_or_retry"
                            and handoff.handoff_eligible_count == 0
                        ):
                            attempt_repair_triggers.extend(fixed_stage.repair_triggers)
                            attempt_repair_triggers.append(
                                "phase5_repair_handoff_without_eligible_candidate"
                            )
                            verification_diagnostics = (
                                _phase7_phase5_candidates_not_run_diagnostics(
                                    fixed_mass_step_stage=fixed_stage,
                                    reason="phase5_repair_handoff_without_eligible_candidate",
                                )
                            )
                        else:
                            direct_queue_result = _run_phase7_direct_candidate_queue(
                                adapter=adapter,
                                geometry=geometry,
                                windowed_stage=windowed_stage,
                                fixed_mass_step_stage=fixed_stage,
                                config=cfg,
                                budget_policy=budget_policy,
                                attempt_index=attempt_index,
                                target_scope=target_scope,
                                verification_callback=verification_callback,
                                checkpoint_writer_config=(
                                    verification_checkpoint_writer_config
                                ),
                                progress_callback=_progress_callback,
                                run_full_chain=run_full_chain,
                            )
                            direct_handoff_outcome = (
                                direct_queue_result.admitted_outcome
                                or direct_queue_result.repair_outcome
                            )
                            representative = direct_queue_result.representative_outcome
                            if representative is not None:
                                verification_config_payload = (
                                    representative.verification_config_payload
                                )
                                verification_callback_result = representative.callback_result
                            verification_diagnostics = (
                                direct_queue_result.private_diagnostics()
                            )
                            attempt_status = direct_queue_result.final_status
                            attempt_role = direct_queue_result.diagnostic_role
                            attempt_hard_vetoes.extend(
                                direct_queue_result.hard_vetoes
                            )
                            attempt_repair_triggers.extend(
                                direct_queue_result.repair_triggers
                            )
                            if attempt_status == "passed":
                                if direct_queue_result.admitted_outcome is None:
                                    raise ValueError(
                                        "passed direct queue lost its admitted outcome"
                                    )
                                final_kernel_payload = (
                                    _phase7_direct_final_kernel_payload(
                                        config=cfg,
                                        geometry=geometry,
                                        bootstrap=bootstrap,
                                        windowed_stage=windowed_stage,
                                        fixed_mass_step_stage=fixed_stage,
                                        outcome=direct_queue_result.admitted_outcome,
                                        budget_policy=budget_policy,
                                        attempt_index=attempt_index,
                                        target_scope=target_scope,
                                    )
                                )
                                final_kernel_hash = stable_config_hash(
                                    final_kernel_payload
                                )
                    elif phase5_route == "operational_selection_v2":
                        if not fixed_stage.passed:
                            attempt_repair_triggers.extend(fixed_stage.repair_triggers)
                            attempt_repair_triggers.append(
                                f"phase5_operational_selection_status:{fixed_stage.final_status}"
                            )
                            attempt_status = fixed_stage.final_status
                            attempt_role = fixed_stage.diagnostic_role
                            verification_diagnostics = {
                                "attempt_index": attempt_index,
                                "not_run": True,
                                "reason": "operational_selection_not_ready_for_verification",
                                "operational_selection_summary": fixed_stage.payload().get(
                                    "operational_selection_summary"
                                ),
                                "reports_posterior_convergence": False,
                            }
                        else:
                            direct_handoff_outcome = (
                                _run_phase7_operational_selection_verification(
                                    adapter=adapter,
                                    geometry=geometry,
                                    windowed_stage=windowed_stage,
                                    fixed_mass_step_stage=fixed_stage,
                                    config=cfg,
                                    budget_policy=budget_policy,
                                    attempt_index=attempt_index,
                                    target_scope=target_scope,
                                    verification_callback=verification_callback,
                                    checkpoint_writer_config=(
                                        verification_checkpoint_writer_config
                                    ),
                                    verification_start_callback=lambda: _emit_phase7_progress(
                                        _progress_callback,
                                        "verification_start",
                                        attempt_index=attempt_index,
                                        budget_policy=budget_policy,
                                        started=True,
                                    ),
                                    checkpoint_reference_callback=lambda reference: _emit_phase7_progress(
                                        _progress_callback,
                                        "verification_checkpoint_written",
                                        attempt_index=attempt_index,
                                        budget_policy=budget_policy,
                                        completed=True,
                                        extra=_phase7_checkpoint_progress_extra(reference),
                                    ),
                                    run_full_chain=run_full_chain,
                                )
                            )
                            verification_config_payload = (
                                direct_handoff_outcome.verification_config_payload
                            )
                            verification_diagnostics = direct_handoff_outcome.diagnostics
                            verification_callback_result = (
                                direct_handoff_outcome.callback_result
                            )
                            attempt_status = direct_handoff_outcome.final_status
                            attempt_role = direct_handoff_outcome.diagnostic_role
                            attempt_hard_vetoes.extend(
                                direct_handoff_outcome.hard_vetoes
                            )
                            attempt_repair_triggers.extend(
                                direct_handoff_outcome.repair_triggers
                            )
                            if attempt_status == "passed":
                                final_kernel_payload = (
                                    _phase7_direct_final_kernel_payload(
                                        config=cfg,
                                        geometry=geometry,
                                        bootstrap=bootstrap,
                                        windowed_stage=windowed_stage,
                                        fixed_mass_step_stage=fixed_stage,
                                        outcome=direct_handoff_outcome,
                                        budget_policy=budget_policy,
                                        attempt_index=attempt_index,
                                        target_scope=target_scope,
                                    )
                                )
                                final_kernel_hash = stable_config_hash(
                                    final_kernel_payload
                                )
                    elif not fixed_stage.passed:
                        attempt_repair_triggers.extend(fixed_stage.repair_triggers)
                        attempt_repair_triggers.append(
                            f"phase5_fixed_mass_step_status:{fixed_stage.final_status}"
                        )
                    elif phase5_route == "historical_phase6_compatibility":
                        _emit_phase7_progress(
                            _progress_callback,
                            "trajectory_start",
                            attempt_index=attempt_index,
                            budget_policy=budget_policy,
                            started=True,
                        )
                        trajectory_kwargs: dict[str, Any] = {
                            "adapter": adapter,
                            "geometry": geometry,
                            "bootstrap": bootstrap,
                            "windowed_stage": windowed_stage,
                            "fixed_mass_step_stage": fixed_stage,
                            "config": _phase7_trajectory_stage_config(
                                cfg,
                                attempt_index=attempt_index,
                            ),
                            "screen_callback": trajectory_screen_callback,
                            "run_full_chain": run_full_chain,
                            "_attempt_budget_policy": budget_policy,
                            "_attempt_state": attempt_state,
                            "_progress_callback": _progress_callback,
                            "_attempt_index": attempt_index,
                        }
                        if _callable_accepts_private_diagnostic_callback(
                            _frozen_step_trajectory_stage_runner
                        ):
                            trajectory_kwargs["_private_diagnostic_callback"] = (
                                _private_diagnostic_callback
                            )
                        if _callable_accepts_runner_cache_handoff(
                            _frozen_step_trajectory_stage_runner
                        ):
                            trajectory_kwargs["_runner_cache_handoff"] = (
                                fixed_stage.private_runner_cache_handoff
                            )
                        trajectory_stage = _frozen_step_trajectory_stage_runner(
                            **trajectory_kwargs
                        )
                        _emit_phase7_progress(
                            _progress_callback,
                            "trajectory_complete",
                            attempt_index=attempt_index,
                            budget_policy=budget_policy,
                            completed=True,
                            extra={
                                "final_status": trajectory_stage.final_status,
                                "passed": trajectory_stage.passed,
                                "artifact_hash": trajectory_stage.artifact_hash,
                            },
                        )
                        if trajectory_stage.final_status == "hard_veto":
                            attempt_hard_vetoes.extend(trajectory_stage.hard_vetoes)
                            attempt_status = "hard_veto"
                            attempt_role = "hard_veto"
                        elif not trajectory_stage.passed:
                            attempt_repair_triggers.extend(trajectory_stage.repair_triggers)
                            attempt_repair_triggers.append(
                                f"phase6_trajectory_status:{trajectory_stage.final_status}"
                            )
                        else:
                            (
                                verification_config_payload,
                                verification_diagnostics,
                                verification_callback_result,
                                verify_status,
                                verify_role,
                                verify_hard_vetoes,
                                verify_repair_triggers,
                            ) = phase7_final_verification_runner(
                                adapter=adapter,
                                geometry=geometry,
                                windowed_stage=windowed_stage,
                                fixed_mass_step_stage=fixed_stage,
                                trajectory_stage=trajectory_stage,
                                config=cfg,
                                budget_policy=budget_policy,
                                attempt_index=attempt_index,
                                target_scope=target_scope,
                                verification_callback=verification_callback,
                                checkpoint_writer_config=verification_checkpoint_writer_config,
                                verification_start_callback=lambda: _emit_phase7_progress(
                                    _progress_callback,
                                    "verification_start",
                                    attempt_index=attempt_index,
                                    budget_policy=budget_policy,
                                    started=True,
                                ),
                                checkpoint_reference_callback=lambda reference: _emit_phase7_progress(
                                    _progress_callback,
                                    "verification_checkpoint_written",
                                    attempt_index=attempt_index,
                                    budget_policy=budget_policy,
                                    completed=True,
                                    extra=_phase7_checkpoint_progress_extra(reference),
                                ),
                                run_full_chain=run_full_chain,
                            )
                            _emit_phase7_progress(
                                _progress_callback,
                                "verification_complete",
                                attempt_index=attempt_index,
                                budget_policy=budget_policy,
                                completed=True,
                                extra={
                                    "final_status": verify_status,
                                    "diagnostic_role": verify_role,
                                    "hard_veto_count": len(verify_hard_vetoes),
                                    "repair_trigger_count": len(verify_repair_triggers),
                                },
                            )
                            attempt_status = verify_status
                            attempt_role = verify_role
                            attempt_hard_vetoes.extend(verify_hard_vetoes)
                            attempt_repair_triggers.extend(verify_repair_triggers)
                            if attempt_status == "passed":
                                final_kernel_payload = _phase7_final_kernel_payload(
                                    config=cfg,
                                    geometry=geometry,
                                    bootstrap=bootstrap,
                                    windowed_stage=windowed_stage,
                                    fixed_mass_step_stage=fixed_stage,
                                    trajectory_stage=trajectory_stage,
                                    verification_config_payload=verification_config_payload,
                                    verification_diagnostics=verification_diagnostics,
                                    budget_policy=budget_policy,
                                    attempt_index=attempt_index,
                                    target_scope=target_scope,
                                )
                                final_kernel_hash = stable_config_hash(final_kernel_payload)
                    else:
                        raise ValueError("unsupported Phase 5 outer-loop route")
        except Exception as exc:  # noqa: BLE001 - Phase 7 must fail closed.
            attempt_status = "hard_veto"
            attempt_role = "hard_veto"
            attempt_hard_vetoes.append("phase7_runtime_error")
            verification_diagnostics = {
                "attempt_index": attempt_index,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "reports_posterior_convergence": False,
                "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
            }

        retry_required_metric_update = bool(
            windowed_stage is not None
            and windowed_stage.final_status == "passed_no_metric_update"
            and cfg.metric_update_requirement == "require_operational_update"
        )
        if windowed_stage is not None and (
            windowed_stage.passed or retry_required_metric_update
        ):
            reserve_verified_midpoint = bool(
                use_operational_repair_verification
                and cfg.operational_verification_bracket_policy
                == _OPERATIONAL_VERIFICATION_BRACKET_POLICY_ONE_LOG_MIDPOINT
                and attempt_state is not None
                and attempt_state.verified_acceptance_bracket_state is not None
                and attempt_state.verified_acceptance_bracket_state.get("phase")
                == "one_endpoint"
            )
            later_verification_reserved = (
                attempt_index + 1 < int(cfg.max_attempts)
                and (
                    not use_operational_repair_verification
                    or reserve_verified_midpoint
                )
            )
            if direct_handoff_outcome is not None:
                handoff_state = _phase7_attempt_state_from_direct_outcome(
                    config=cfg,
                    windowed_stage=windowed_stage,
                    outcome=direct_handoff_outcome,
                    incoming_state=attempt_state,
                    repair_verification_reserved=later_verification_reserved,
                    suppress_scalar_repair_disposition=(
                        "inconclusive_conflict"
                        if direct_queue_result is not None
                        and direct_queue_result.repair_direction_conflict
                        else None
                    ),
                )
            else:
                handoff_state = _phase7_attempt_state_from_stages(
                    config=cfg,
                    windowed_stage=windowed_stage,
                    fixed_mass_step_stage=fixed_stage,
                    frozen_step_trajectory_stage=trajectory_stage,
                    verification_config_payload=verification_config_payload,
                    verification_diagnostics=verification_diagnostics,
                    verification_final_status=attempt_status,
                    verification_diagnostic_role=attempt_role,
                    verification_repair_triggers=attempt_repair_triggers,
                    incoming_state=attempt_state,
                    repair_verification_reserved=later_verification_reserved,
                )
            verified_bracket_phase = (
                None
                if handoff_state is None
                or handoff_state.verified_acceptance_bracket_state is None
                else handoff_state.verified_acceptance_bracket_state.get("phase")
            )
            if (
                use_operational_repair_verification
                and cfg.operational_verification_bracket_policy
                == _OPERATIONAL_VERIFICATION_BRACKET_POLICY_ONE_LOG_MIDPOINT
                and attempt_status == "repair_or_retry"
                and verified_bracket_phase != "midpoint_pending"
            ):
                attempt_status = "budget_exhausted"
                attempt_role = "verified_bracket_repair_exhausted_non_promoting"
                attempt_repair_triggers.append(
                    "phase7_verified_bracket_repair_exhausted"
                )
            if _private_diagnostic_callback is not None and handoff_state is not None:
                _private_diagnostic_callback(
                    "phase7_handoff_kernel_change",
                    {
                        "stage": "loop_attempt_handoff",
                        "attempt_index": int(attempt_index),
                        "handoff_stage": handoff_state.handoff_stage,
                        "mass_artifact_signature": handoff_state.mass_artifact_signature,
                        "step_size": handoff_state.selected_step_size,
                        "selected_step_hash": handoff_state.selected_step_hash,
                        "num_leapfrog_steps": handoff_state.selected_num_leapfrog_steps,
                        "selected_trajectory_hash": (
                            handoff_state.selected_trajectory_hash
                        ),
                        "phase6_retry_num_leapfrog_steps": (
                            handoff_state.phase6_retry_num_leapfrog_steps
                        ),
                        "phase6_retry_anchor_source": (
                            handoff_state.phase6_retry_anchor_source
                        ),
                        "verification_repair_applied": (
                            handoff_state.verification_repair_applied
                        ),
                        "verification_repair_step_size": (
                            handoff_state.verification_repair_step_size
                        ),
                        "verification_repair_step_hash": (
                            handoff_state.verification_repair_step_hash
                        ),
                        "verification_repair_trigger": (
                            handoff_state.verification_repair_trigger
                        ),
                        "private_hmc_mechanics": True,
                        "reports_posterior_convergence": False,
                        "reports_sampler_superiority": False,
                        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
                    },
                )
        if attempt_status == "repair_or_retry" and (
            handoff_state is None or not handoff_state.has_stage_repair_handoff
        ):
            attempt_status = "architecture_blocked"
            attempt_role = "architecture_blocked"
            attempt_repair_triggers.append("phase7_required_private_handoff_missing")

        attempt_hard_vetoes = list(dict.fromkeys(str(item) for item in attempt_hard_vetoes))
        attempt_repair_triggers = list(
            dict.fromkeys(str(item) for item in attempt_repair_triggers)
        )
        operational_work_reconciliation = _phase7_operational_work_reconciliation(
            prior_attempts=attempts,
            fixed_mass_step_stage=fixed_stage,
            verification_config_payload=verification_config_payload,
            verification_diagnostics=verification_diagnostics,
        )
        if operational_work_reconciliation is not None:
            verification_diagnostics = {
                **dict(verification_diagnostics),
                "operational_work_reconciliation": operational_work_reconciliation,
            }
        attempt = HMCTuneVerifyRepairAttempt(
            attempt_index=attempt_index,
            budget_policy_payload={
                **dict(budget_policy.payload()),
                **(
                    {}
                    if terminal_phase6_slot_payload is None
                    else {
                        "terminal_phase6_repair_extra_attempt": True,
                        "terminal_phase6_repair_extra_attempt_index": (
                            terminal_phase6_slot_payload[
                                "terminal_phase6_repair_extra_attempt_index"
                            ]
                        ),
                        "terminal_phase6_repair_extra_attempts": (
                            terminal_phase6_slot_payload[
                                "terminal_phase6_repair_extra_attempts"
                            ]
                        ),
                        "terminal_phase6_repair_extra_attempts_consumed": (
                            terminal_phase6_slot_payload[
                                "terminal_phase6_repair_extra_attempts_consumed"
                            ]
                        ),
                    }
                ),
            },
            incoming_state_payload=incoming_payload,
            windowed_stage=windowed_stage,
            fixed_mass_step_stage=fixed_stage,
            frozen_step_trajectory_stage=trajectory_stage,
            verification_config_payload=verification_config_payload,
            verification_diagnostics=verification_diagnostics,
            verification_callback_result=verification_callback_result,
            final_status=attempt_status,
            diagnostic_role=attempt_role,
            hard_vetoes=tuple(attempt_hard_vetoes),
            repair_triggers=tuple(attempt_repair_triggers),
            handoff_state_payload=None if handoff_state is None else handoff_state.payload(),
        )
        _emit_phase7_progress(
            _progress_callback,
            "loop_attempt_complete",
            attempt_index=attempt_index,
            budget_policy=budget_policy,
            completed=True,
            extra={
                "final_status": attempt_status,
                "diagnostic_role": attempt_role,
                "hard_veto_count": len(attempt_hard_vetoes),
                "repair_trigger_count": len(attempt_repair_triggers),
                "resume_split_public_summary": _phase7_attempt_resume_split_public_summary(
                    attempt
                ),
            },
        )
        attempts.append(attempt)
        hard_vetoes.extend(attempt_hard_vetoes)
        repair_triggers.extend(attempt_repair_triggers)
        if (
            handoff_state is not None
            and _phase7_should_run_operational_repair_verification(handoff_state)
            and windowed_stage is not None
            and fixed_stage is not None
        ):
            operational_repair_verification_bundle = {
                "windowed_stage": windowed_stage,
                "fixed_mass_step_stage": fixed_stage,
            }
        else:
            operational_repair_verification_bundle = None
        if _phase7_should_prepare_verification_only_retry(
            attempt_status=attempt_status,
            attempt_role=attempt_role,
            attempt_hard_vetoes=attempt_hard_vetoes,
            attempt_repair_triggers=attempt_repair_triggers,
            handoff_state=handoff_state,
            verification_diagnostics=verification_diagnostics,
        ):
            verification_only_retry_bundle = {
                "windowed_stage": windowed_stage,
                "fixed_mass_step_stage": fixed_stage,
                "trajectory_stage": trajectory_stage,
                **(
                    {}
                    if handoff_state is None
                    or handoff_state.direct_candidate_handoff is None
                    else {
                        **dict(handoff_state.direct_candidate_handoff),
                    }
                ),
            }
        else:
            verification_only_retry_bundle = None
        if _campaign_checkpoint is not None:
            _campaign_checkpoint.commit_attempt({
                "attempt": attempt, "handoff_state": handoff_state,
                "verification_only_retry_bundle": verification_only_retry_bundle,
                "operational_repair_verification_bundle": operational_repair_verification_bundle,
                "extra_attempts_consumed": terminal_phase6_repair_extra_attempts_consumed,
                "final_kernel_payload": final_kernel_payload if attempt_status == "passed" else None,
                "final_kernel_hash": final_kernel_hash if attempt_status == "passed" else None,
            })
        if attempt_status == "passed":
            final_status = "passed"
            diagnostic_role = "fresh_fixed_kernel_verification_passed"
            break
        if attempt_status == "hard_veto":
            final_status = "hard_veto"
            diagnostic_role = "hard_veto"
            final_kernel_payload = None
            final_kernel_hash = None
            break
        if attempt_status == "budget_exhausted":
            final_status = "budget_exhausted"
            diagnostic_role = attempt_role
            final_kernel_payload = None
            final_kernel_hash = None
            break
        if attempt_status == "architecture_blocked":
            final_status = "architecture_blocked"
            diagnostic_role = "architecture_blocked"
            final_kernel_payload = None
            final_kernel_hash = None
            break
        attempt_state = handoff_state
        attempt_index += 1
    if loop_exhausted:
        final_status = "budget_exhausted"
        final_kernel_payload = None
        final_kernel_hash = None
        if (
            terminal_phase6_repair_extra_attempts_consumed
            >= int(cfg.terminal_phase6_repair_extra_attempts)
            and int(cfg.terminal_phase6_repair_extra_attempts) > 0
        ):
            repair_handoff_slot_blocker = (
                _phase7_terminal_phase6_repair_slot_exhausted_payload(
                    config=cfg,
                    attempt_state=attempt_state,
                    last_attempt=attempts[-1] if attempts else None,
                    consumed_slots=terminal_phase6_repair_extra_attempts_consumed,
                )
                if _phase7_repair_handoff_attempt_slot_blocker(
                    config=cfg,
                    attempt_state=attempt_state,
                    last_attempt=attempts[-1] if attempts else None,
                )
                is not None
                else None
            )
        else:
            repair_handoff_slot_blocker = _phase7_repair_handoff_attempt_slot_blocker(
                config=cfg,
                attempt_state=attempt_state,
                last_attempt=attempts[-1] if attempts else None,
            )
        if repair_handoff_slot_blocker is not None:
            diagnostic_role = str(repair_handoff_slot_blocker["diagnostic_role"])
            terminal_budget_guard_payload = repair_handoff_slot_blocker
            repair_triggers.append(diagnostic_role)
        else:
            diagnostic_role = "budget_exhausted_non_promoting"
            repair_triggers.append("phase7_budget_exhausted")

    hard_vetoes = list(dict.fromkeys(str(item) for item in hard_vetoes))
    repair_triggers = list(dict.fromkeys(str(item) for item in repair_triggers))
    result = HMCTuneVerifyRepairLoopResult(
        config=cfg,
        geometry_artifact_hash=geometry.artifact_hash,
        bootstrap_artifact_hash=bootstrap.artifact_hash,
        adapter_signature=geometry.adapter_signature,
        target_dimension=geometry.target_dimension,
        attempts=tuple(attempts),
        final_status=final_status,
        diagnostic_role=diagnostic_role,
        hard_vetoes=tuple(hard_vetoes),
        repair_triggers=tuple(repair_triggers),
        final_kernel_payload=final_kernel_payload,
        final_kernel_hash=final_kernel_hash,
        seed_report={
            "phase7_root_seed": cfg.seed,
            "attempt_seeds": tuple(_phase7_attempt_seed(cfg.seed, index) for index in range(len(attempts))),
            "verification_seeds": tuple(
                _derive_seed(_phase7_attempt_seed(cfg.seed, attempt.attempt_index), stage_index=4)
                for attempt in attempts
            ),
            "verification_seeds_role": (
                "historical_phase6_compatibility_seed_per_attempt"
            ),
            "historical_verification_seed_policy": (
                _PHASE7_HISTORICAL_PHASE6_SEED_POLICY
            ),
            "direct_candidate_verification_seed_policy": (
                _PHASE7_DIRECT_CANDIDATE_SEED_POLICY
            ),
            "direct_candidate_verification_seed_maps": (
                _phase7_direct_candidate_seed_reports(
                    attempts=attempts,
                    root_seed=cfg.seed,
                )
            ),
            "seed_owner": "BayesFilter",
            "verification_seed_independent_of_stage_seeds": True,
            "direct_seed_maps_private_handoff_only": True,
        },
        diagnostic_roles={
            "fresh_fixed_kernel_verification": "promotion_or_repair_or_hard_veto",
            "budget_exhausted": "terminal_non_promoting_repair_status",
            "verification_acceptance_budget_blocked": (
                "terminal_non_promoting_public_budget_guard"
            ),
            "architecture_blocked": "terminal_non_promoting_private_plumbing_blocker",
            "callback_hard_veto": "hard_veto",
            "callback_continuation_veto": "hard_veto",
            "callback_promotion_veto": "repair_or_retry",
            "callback_repair_trigger": "repair_or_retry",
            "mass_step_l_invariant": "hard_veto",
            "phase6_handoff_screen": _PHASE6_HANDOFF_SCREEN_POLICY_ROLE,
            "trajectory_window": _TRAJECTORY_WINDOW_POLICY_ROLE,
            "runtime": "hard_veto_when_error",
        },
        terminal_budget_guard_payload=terminal_budget_guard_payload,
    )
    _emit_phase7_progress(
        _progress_callback,
        "loop_complete",
        attempt_index=attempts[-1].attempt_index,
        budget_policy=None,
        completed=True,
        extra={
            "final_status": result.final_status,
            "diagnostic_role": result.diagnostic_role,
            "loop_artifact_hash": result.artifact_hash,
        },
    )
    return result


def _ordinary_tuning_source_dependency_closure() -> Mapping[str, Any]:
    """Hash the executable source boundary of the default ordinary runner."""

    inference_root = Path(__file__).resolve().parent
    package_root = inference_root.parent
    repository_root = package_root.parent
    paths = (
        inference_root / "hmc_kernel_tuning.py",
        inference_root / "hmc_tuning_checkpoint.py",
        package_root / "runtime/durable_tensor_checkpoint.py",
        inference_root / "hmc.py",
        inference_root / "hmc_tuning.py",
        inference_root / "hmc_tuning_dispatch.py",
        inference_root / "hmc_warmup.py",
        inference_root / "hmc_budget_ladder.py",
        inference_root / "hmc_kernel_selection.py",
        inference_root / "hmc_tuning_state.py",
        inference_root / "hmc_verification.py",
        inference_root / "hmc_diagnostics.py",
        inference_root / "fixed_l_finite_bracket.py",
        inference_root / "batched_value_score.py",
        inference_root / "transition_health_tf.py",

        inference_root / "hmc_coordinates.py",
        inference_root / "tuning_contract.py",
        inference_root / "posterior_adapter.py",
        inference_root / "__init__.py",
        package_root / "hmc_budget_contract.py",
        package_root / "hmc_ordinary_selection_policy.py",
        package_root / "hmc_route_contract.py",
        package_root / "__init__.py",
    )
    missing = tuple(str(path) for path in paths if not path.is_file())
    if missing:
        raise RuntimeError(
            "ordinary HMC tuning source closure is incomplete: " + ", ".join(missing)
        )
    return {
        "schema": "bayesfilter.ordinary_hmc_tuning_source_closure.v1",
        "files": tuple(
            {
                "path": str(path.relative_to(repository_root)),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
            for path in paths
        ),
    }


def _public_tuning_runner_identity_payload(
    *,
    runner_binding: HMCTuningRunnerBinding | None,
    target_scope: str | None,
) -> Mapping[str, Any]:
    if runner_binding is not None:
        return runner_binding.payload()
    identity = {
        "schema": "bayesfilter.default_hmc_tuning_runner_identity.v1",
        "runner_identity": "bayesfilter.inference.hmc.run_full_chain_tfp_hmc",
        "algorithm_family": "tfp_exact_gradient_fixed_trajectory_hmc",
        "target_scope": target_scope,
        "supported_target_status_trace_policies": ("none", "per_chain_step"),
        "supported_chain_execution_modes": ("tf_function", "eager"),
        "backend": "tensorflow_probability",
        "source_dependency_closure": _ordinary_tuning_source_dependency_closure(),
        "artifact_authority": False,
    }
    return {**identity, "binding_hash": stable_config_hash(identity)}


def _run_canonical_hmc_tuning(
    *, adapter: Any, initial_position: Any, config: HMCKernelTuningConfig | None = None,
    output_dir: str | Path | None = None, negative_hessian: Any | None = None,
    initial_covariance: Any | None = None, parameter_scales: Any | None = None,
    diagnostic_callback: FixedMassScreenCallback | None = None,
    verification_checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None = None,
    runner_binding: HMCTuningRunnerBinding | None = None,
    campaign_checkpoint_dir: str | Path | None = None,
    campaign_time_budget_s: float | None = None,
    campaign_interrupted_elapsed_s: float | None = None,
) -> HMCKernelTuningResult:
    cfg = HMCKernelTuningConfig.standard() if config is None else config
    kwargs = dict(adapter=adapter, initial_position=initial_position, config=cfg,
                  output_dir=output_dir, negative_hessian=negative_hessian,
                  initial_covariance=initial_covariance, parameter_scales=parameter_scales,
                  diagnostic_callback=diagnostic_callback,
                  verification_checkpoint_writer_config=verification_checkpoint_writer_config,
                  runner_binding=runner_binding)
    if campaign_checkpoint_dir is None:
        if campaign_time_budget_s is not None or campaign_interrupted_elapsed_s is not None:
            raise ValueError("campaign options require campaign_checkpoint_dir")
        return _run_canonical_hmc_tuning_impl(**kwargs)
    if (not isinstance(cfg, HMCKernelTuningConfig) or runner_binding is not None
            or diagnostic_callback is not None or cfg.staged_timeout_policy is not None
            or cfg.engineering_probe_covariance_multiplier is not None
            or cfg.terminal_phase6_repair_extra_attempts != 0):
        raise ValueError("campaign recovery supports the ordinary default runner without extra attempt slots")
    if campaign_time_budget_s is None:
        raise ValueError("campaign recovery requires a cumulative time budget")
    # Only resource limits may change during budget extension. All numerical
    # policy, seeds, target/data identity and source bytes remain bound.
    policy = dict(cfg.payload())
    for key in ("max_attempts", "public_timeout_budget_s", "incall_progress_heartbeat_s"):
        policy.pop(key, None)
    from bayesfilter.runtime.durable_tensor_checkpoint import DurableTensorCheckpoint
    identity = {
        "schema": "bayesfilter.ordinary_tuning_campaign_identity.v1",
        "policy": policy, "adapter": stable_adapter_signature(adapter),
        "sources": _ordinary_tuning_source_dependency_closure(),
        "inputs": {name: None if value is None else DurableTensorCheckpoint.tensor_hash(_float64_tensor(value))
                   for name, value in (("position", initial_position), ("covariance", initial_covariance),
                                       ("negative_hessian", negative_hessian), ("scales", parameter_scales))},
    }
    with HMCTuningCampaignCheckpoint(
        campaign_checkpoint_dir, identity, max_attempts=cfg.max_attempts,
        time_budget_s=campaign_time_budget_s,
        interrupted_elapsed_s=campaign_interrupted_elapsed_s,
    ) as checkpoint:
        remaining = checkpoint.remaining_seconds - (time.monotonic() - checkpoint.started) - 60.0
        if remaining <= 0:
            raise ValueError("campaign time budget exhausted during checkpoint loading")
        native_limit = remaining if cfg.public_timeout_budget_s is None else min(remaining, cfg.public_timeout_budget_s)
        kwargs["config"] = dataclasses.replace(cfg, public_timeout_budget_s=native_limit)
        return _run_canonical_hmc_tuning_impl(**kwargs, _campaign_checkpoint=checkpoint)


def _run_canonical_hmc_tuning_impl(
    *,
    adapter: Any,
    initial_position: Any,
    config: HMCKernelTuningConfig | None = None,
    output_dir: str | Path | None = None,
    negative_hessian: Any | None = None,
    initial_covariance: Any | None = None,
    parameter_scales: Any | None = None,
    diagnostic_callback: FixedMassScreenCallback | None = None,
    verification_checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None = None,
    runner_binding: HMCTuningRunnerBinding | None = None,
    _campaign_checkpoint: HMCTuningCampaignCheckpoint | None = None,
) -> HMCKernelTuningResult:
    """Tune a frozen HMC kernel from model-facing inputs.

    The caller supplies the model adapter, an initial position, optional
    geometry hints, an optional diagnostic callback, and an optional output
    directory.  ``mass_policy='fixed_identity'`` ignores geometry hints and
    freezes identity covariance in the supplied coordinates; the default
    ``windowed_adaptive`` behavior is unchanged. BayesFilter owns the mass,
    step-size, leapfrog, screen,
    verification, and repair mechanics.  A final kernel is emitted only when
    the Phase 7 fresh fixed-kernel verification passes.
    """

    cfg = HMCKernelTuningConfig.standard() if config is None else config
    if not isinstance(cfg, HMCKernelTuningConfig):
        raise TypeError("config must be HMCKernelTuningConfig")
    p4_seed_use_registry = (
        None
        if cfg.engineering_probe_covariance_multiplier is None
        else _build_public_p4_seed_use_registry()
    )
    if runner_binding is not None and not isinstance(
        runner_binding, HMCTuningRunnerBinding
    ):
        raise TypeError("runner_binding must be HMCTuningRunnerBinding")
    # Resolve the public route before touching adapter geometry or any runtime
    # state. Legacy routes remain available to the private diagnostic loop,
    # but cannot enter the artifact-authority facade.
    _route_decision = require_hmc_artifact_authority_route(
        algorithm_id=cfg.algorithm_id,
        stage=HMC_TOP_LEVEL_SELECTION_STAGE,
        runtime_backend="tensorflow",
        chain_execution_mode=cfg.chain_execution_mode,
        use_xla=cfg.use_xla,
        timeout_enabled=cfg.public_timeout_budget_s is not None,
        heartbeat_enabled=cfg.incall_progress_heartbeat_s is not None,
        output_path_enabled=output_dir is not None,
        checkpointing_enabled=verification_checkpoint_writer_config is not None,
        runner_identity=(
            "default" if runner_binding is None else runner_binding.runner_identity
        ),
    )
    capability_scope = value_score_capability(adapter).target_scope
    resolved_target_scope = (
        cfg.target_scope if cfg.target_scope is not None else capability_scope
    )
    if runner_binding is not None:
        if resolved_target_scope is None or not str(resolved_target_scope):
            raise ValueError(
                "typed runner binding requires config.target_scope or adapter target scope"
            )
        runner_binding.validate_public_context(
            target_scope=str(resolved_target_scope),
            target_status_trace_policy=cfg.target_status_trace_policy,
            chain_execution_mode=cfg.chain_execution_mode,
            use_xla=cfg.use_xla,
        )
        if verification_checkpoint_writer_config is not None:
            raise ValueError(
                "typed runner binding does not support sequential-R-hat checkpoint writing"
            )
    selected_run_full_chain: RunFullChainFn = (
        run_full_chain_tfp_hmc if runner_binding is None else runner_binding
    )
    runner_identity_payload = _public_tuning_runner_identity_payload(
        runner_binding=runner_binding,
        target_scope=(
            None if resolved_target_scope is None else str(resolved_target_scope)
        ),
    )
    public_timeout_started_perf_counter_s = (
        time.perf_counter() if cfg.public_timeout_budget_s is not None else None
    )
    staged_timeout_global_started_perf_counter_s = (
        None
        if cfg.staged_timeout_policy is None
        else (
            cfg.staged_timeout_global_started_perf_counter_s
            if cfg.staged_timeout_global_started_perf_counter_s is not None
            else time.perf_counter()
        )
    )
    cfg_for_timeout = (
        cfg
        if cfg.staged_timeout_policy is None
        else dataclasses.replace(
            cfg,
            staged_timeout_global_started_perf_counter_s=(
                staged_timeout_global_started_perf_counter_s
            ),
        )
    )
    position = _validate_position(initial_position)
    adapter_signature = stable_adapter_signature(adapter)
    target_dimension = int(position.shape[0])
    artifact_path = _public_tuning_artifact_path(output_dir)
    geometry: HMCGeometryInitializationResult | None = None
    bootstrap: HMCBootstrapScreenResult | None = None
    loop: HMCTuneVerifyRepairLoopResult | None = None
    final_status = "architecture_blocked"
    diagnostic_role = "not_reached"
    hard_vetoes: tuple[str, ...] = ()
    repair_triggers: tuple[str, ...] = ()
    final_kernel_payload: Mapping[str, Any] | None = None
    final_kernel_hash: str | None = None
    progress_path = _public_tuning_progress_path(output_dir)
    progress_lock = threading.RLock()
    private_dir = _private_tuning_diagnostics_dir(output_dir)
    private_events_path = _private_tuning_events_path(private_dir)
    private_progress_state: dict[str, Any] = {
        "enabled": private_dir is not None,
        "event_count": 0,
        "last_event_hash": None,
        "last_mass_hash": None,
        "candidate_count": 0,
        "candidate_completed_count": 0,
        "candidate_pass_count": 0,
        "candidate_hard_veto_count": 0,
        "selected_pair_exists": False,
        "round_kind": None,
        "edge_repair_direction": None,
    }
    progress_state: dict[str, str | None] = {
        "last_started_stage": None,
        "last_completed_stage": None,
        "last_started_substage": None,
        "last_completed_substage": None,
        "last_started_artifact_stage": None,
        "last_completed_artifact_stage": None,
    }
    phase7_state: dict[str, Any] = {
        "last_attempt_index": None,
        "last_budget_payload": None,
        "last_progress_contract": None,
        "last_loop_event": None,
        "resume_split_public_summary": None,
        "early_closeout_public_summary": None,
    }

    def write_private_event(
        event_type: str,
        stage: str,
        payload: Mapping[str, Any],
    ) -> Mapping[str, Any] | None:
        event = _write_private_tuning_event(
            private_events_path,
            event_type=event_type,
            stage=stage,
            payload=payload,
        )
        if event is not None:
            private_progress_state["event_count"] = (
                int(private_progress_state["event_count"]) + 1
            )
            private_progress_state["last_event_hash"] = event["event_hash"]
        return event

    def write_private_mass_event(
        *,
        event_type: str,
        stage: str,
        label: str,
        mass_artifact: PrecomputedMassArtifact,
        payload: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any] | None:
        summary = _write_private_mass_matrix_artifact(
            private_dir,
            label=label,
            mass_artifact=mass_artifact,
        )
        if summary is None:
            return None
        private_progress_state["last_mass_hash"] = summary["mass_hash"]
        event_payload = {
            "mass_matrix_summary": summary,
            "mass_artifact_signature": summary["mass_hash"],
            **({} if payload is None else dict(payload)),
        }
        return write_private_event(event_type, stage, event_payload)

    def write_private_tuning_diagnostic(
        event_type: str,
        payload: Mapping[str, Any],
    ) -> None:
        stage = str(payload.get("stage", event_type))
        if event_type == "windowed_mass_matrix_change":
            mass_artifact = payload.get("mass_artifact")
            if isinstance(mass_artifact, PrecomputedMassArtifact):
                private_payload = {
                    key: value for key, value in payload.items() if key != "mass_artifact"
                }
                write_private_mass_event(
                    event_type=event_type,
                    stage=stage,
                    label=f"windowed_attempt_{payload.get('attempt_index', 'unknown')}",
                    mass_artifact=mass_artifact,
                    payload=private_payload,
                )
            return
        event = write_private_event(event_type, stage, payload)
        if event is None:
            return
        if event_type == "joint_l_epsilon_candidate_complete":
            private_progress_state["candidate_count"] = max(
                int(private_progress_state["candidate_count"]),
                int(payload.get("candidate_count", 0)),
            )
            private_progress_state["candidate_completed_count"] = int(
                payload.get(
                    "candidate_completed_count",
                    private_progress_state["candidate_completed_count"],
                )
            )
            private_progress_state["candidate_pass_count"] = int(
                payload.get(
                    "candidate_pass_count",
                    private_progress_state["candidate_pass_count"],
                )
            )
            private_progress_state["candidate_hard_veto_count"] = int(
                payload.get(
                    "candidate_hard_veto_count",
                    private_progress_state["candidate_hard_veto_count"],
                )
            )
        if event_type == "joint_l_epsilon_round_selected":
            private_progress_state["candidate_count"] = max(
                int(private_progress_state["candidate_count"]),
                int(payload.get("candidate_count", 0)),
            )
            private_progress_state["candidate_completed_count"] = int(
                payload.get(
                    "candidate_completed_count",
                    private_progress_state["candidate_completed_count"],
                )
            )
            private_progress_state["candidate_pass_count"] = int(
                payload.get(
                    "candidate_pass_count",
                    private_progress_state["candidate_pass_count"],
                )
            )
            private_progress_state["candidate_hard_veto_count"] = int(
                payload.get(
                    "candidate_hard_veto_count",
                    private_progress_state["candidate_hard_veto_count"],
                )
            )
            private_progress_state["selected_pair_exists"] = bool(
                payload.get("selected_pair_exists", False)
            )
            private_progress_state["round_kind"] = payload.get("grid_stage")
            private_progress_state["edge_repair_direction"] = payload.get(
                "edge_direction"
            )

    def write_progress(
        stage: str,
        *,
        started: bool = False,
        completed: bool = False,
        phase7_substage: bool = False,
        artifact_stage: bool = False,
        extra: Mapping[str, Any] | None = None,
    ) -> None:
        with progress_lock:
            if artifact_stage:
                if started:
                    progress_state["last_started_artifact_stage"] = stage
                if completed:
                    progress_state["last_completed_artifact_stage"] = stage
            else:
                if started:
                    progress_state["last_started_stage"] = stage
                if completed:
                    progress_state["last_completed_stage"] = stage
            if phase7_substage:
                if started:
                    progress_state["last_started_substage"] = stage
                if completed:
                    progress_state["last_completed_substage"] = stage
            progress_extra = None if extra is None else dict(extra)
            resume_split_summary = phase7_state.get("resume_split_public_summary")
            if isinstance(resume_split_summary, Mapping):
                if progress_extra is None:
                    progress_extra = {}
                progress_extra.setdefault(
                    "phase7_resume_split_public_summary",
                    dict(resume_split_summary),
                )
            last_loop_event = phase7_state.get("last_loop_event")
            if isinstance(last_loop_event, Mapping):
                if progress_extra is None:
                    progress_extra = {}
                progress_extra.setdefault("phase7_loop_event", dict(last_loop_event))
            last_progress_contract = phase7_state.get("last_progress_contract")
            if isinstance(last_progress_contract, Mapping):
                if progress_extra is None:
                    progress_extra = {}
                progress_extra.setdefault(
                    "phase7_progress_contract",
                    dict(last_progress_contract),
                )
            early_closeout = phase7_state.get("early_closeout_public_summary")
            if isinstance(early_closeout, Mapping):
                if progress_extra is None:
                    progress_extra = {}
                progress_extra.setdefault(
                    "phase7_early_closeout_public_summary",
                    dict(early_closeout),
                )
            private_summary = _private_tuning_public_summary(private_progress_state)
            if progress_extra is None:
                progress_extra = {}
            progress_extra.setdefault("private_tuning_diagnostics", private_summary)
            _write_public_tuning_progress_if_requested(
                progress_path=progress_path,
                config=cfg,
                artifact_path=artifact_path,
                current_stage=stage,
                last_started_stage=progress_state["last_started_stage"],
                last_completed_stage=progress_state["last_completed_stage"],
                last_started_substage=progress_state["last_started_substage"],
                last_completed_substage=progress_state["last_completed_substage"],
                last_started_artifact_stage=progress_state["last_started_artifact_stage"],
                last_completed_artifact_stage=progress_state["last_completed_artifact_stage"],
                phase7_last_attempt_index=phase7_state["last_attempt_index"],
                phase7_last_budget_payload=phase7_state["last_budget_payload"],
                bootstrap_public_summary=_bootstrap_public_summary(
                    bootstrap,
                    xla_requested=cfg.use_xla,
                ),
                adapter_signature=adapter_signature,
                target_dimension=target_dimension,
                extra=progress_extra,
            )

    def write_loop_progress(stage: str, payload: Mapping[str, Any]) -> None:
        event_payload = dict(payload)
        if "attempt_index" in event_payload:
            phase7_state["last_attempt_index"] = int(event_payload["attempt_index"])
        budget_payload = event_payload.get("bounded_public_budget_payload")
        if budget_payload is not None:
            phase7_state["last_budget_payload"] = dict(budget_payload)
        event_extra = event_payload.get("extra")
        if isinstance(event_extra, Mapping):
            resume_split_summary = event_extra.get("resume_split_public_summary")
            if isinstance(resume_split_summary, Mapping):
                phase7_state["resume_split_public_summary"] = dict(
                    resume_split_summary
                )
        phase7_state["last_loop_event"] = dict(event_payload)
        phase7_state["last_progress_contract"] = {
            "progress_only": True,
            "hmc_mechanics_exposed": False,
            "reports_posterior_convergence": False,
        }
        write_progress(
            stage,
            started=bool(event_payload.get("started")),
            completed=bool(event_payload.get("completed")),
            phase7_substage=True,
            extra={
                "phase7_loop_event": event_payload,
                "phase7_progress_contract": {
                    "progress_only": True,
                    "hmc_mechanics_exposed": False,
                    "reports_posterior_convergence": False,
                },
            },
        )

    def write_result_artifact(result: HMCKernelTuningResult) -> None:
        write_progress(
            "artifact_finalization_start",
            started=True,
            artifact_stage=True,
            extra={
                "final_status": result.final_status,
                "diagnostic_role": result.diagnostic_role,
            },
        )
        _write_public_tuning_artifact_if_requested(result, artifact_path)
        write_progress(
            "artifact_finalization_complete",
            completed=True,
            artifact_stage=True,
            extra={
                "artifact_path": None if artifact_path is None else str(artifact_path),
                "artifact_written": artifact_path is not None,
            },
        )

    try:
        write_progress("start", started=True)
        write_progress("geometry_start", started=True)
        if cfg.mass_policy == "fixed_identity" and any(
            value is not None
            for value in (negative_hessian, initial_covariance, parameter_scales)
        ):
            write_private_event(
                "fixed_identity_geometry_hints_ignored",
                "geometry_start",
                {
                    "mass_policy": cfg.mass_policy,
                    "negative_hessian_supplied": negative_hessian is not None,
                    "initial_covariance_supplied": initial_covariance is not None,
                    "parameter_scales_supplied": parameter_scales is not None,
                    "reports_posterior_convergence": False,
                },
            )
        def compute_geometry():
            return initialize_hmc_kernel_geometry(
                adapter=adapter,
                initial_position=position,
                config=_public_geometry_config(cfg),
                negative_hessian=negative_hessian,
                initial_covariance=initial_covariance,
                parameter_scales=parameter_scales,
            )
        geometry = (compute_geometry() if _campaign_checkpoint is None
                    else _campaign_checkpoint.stage("geometry", compute_geometry))
        write_private_mass_event(
            event_type="mass_matrix_change",
            stage="geometry_complete",
            label="geometry_initial",
            mass_artifact=geometry.mass_artifact,
            payload={
                "source": "initialize_hmc_kernel_geometry",
                "target_dimension": geometry.target_dimension,
                "geometry_artifact_hash": geometry.artifact_hash,
            },
        )
        write_private_event(
            "bootstrap_kernel_initial",
            "geometry_complete",
            {
                "step_size": geometry.initial_step_size,
                "num_leapfrog_steps": geometry.initial_num_leapfrog_steps,
                "unclamped_num_leapfrog_steps": geometry.unclamped_num_leapfrog_steps,
                "target_trajectory_length": geometry.target_trajectory_length,
                "geometry_artifact_hash": geometry.artifact_hash,
                "mass_artifact_signature": geometry.mass_artifact_signature,
            },
        )
        write_progress(
            "geometry_complete",
            completed=True,
            extra={"geometry_artifact_hash": geometry.artifact_hash},
        )
    except Exception as exc:  # noqa: BLE001 - public tuner returns fail-closed artifacts.
        final_status = "hard_veto"
        diagnostic_role = "geometry_initialization_hard_veto"
        hard_vetoes = ("geometry_initialization_error",)
        repair_triggers = (type(exc).__name__,)
        write_progress(
            "geometry_error",
            extra={"error_type": type(exc).__name__, "error_message": str(exc)},
        )
        result = HMCKernelTuningResult(
            config=cfg,
            adapter_signature=adapter_signature,
            target_dimension=target_dimension,
            geometry=None,
            bootstrap=None,
            tune_verify_repair_loop=None,
            final_status=final_status,
            diagnostic_role=diagnostic_role,
            hard_vetoes=hard_vetoes,
            repair_triggers=repair_triggers,
            final_kernel_payload=None,
            final_kernel_hash=None,
            artifact_path=None if artifact_path is None else str(artifact_path),
            diagnostic_roles=_public_tuning_diagnostic_roles(),
            runner_binding_payload=runner_identity_payload,
            failure_diagnostics=_public_failure_diagnostics(
                stage="geometry", exc=exc
            ),
        )
        write_result_artifact(result)
        write_progress(
            "result_written",
            extra={
                "final_status": result.final_status,
                "diagnostic_role": result.diagnostic_role,
            },
        )
        return result

    try:
        write_progress("bootstrap_start", started=True)

        def write_bootstrap_progress(
            stage: str,
            payload: Mapping[str, Any],
        ) -> None:
            write_progress(
                stage,
                started=stage.endswith("_start"),
                completed=(
                    stage.endswith("_complete") or stage.endswith("_classified")
                ),
                extra={
                    "bootstrap_progress_event": dict(payload),
                    "bootstrap_progress_contract": {
                        "progress_only": True,
                        "hmc_mechanics_exposed": False,
                        "reports_posterior_convergence": False,
                    },
                },
            )

        p4_registry_kwargs = (
            {}
            if p4_seed_use_registry is None
            else {"_g2_seed_use_registry": p4_seed_use_registry}
        )
        def compute_bootstrap():
            return run_hmc_bootstrap_screen(
                adapter=adapter,
                geometry=geometry,
                config=_public_bootstrap_config(cfg, geometry=geometry),
                run_full_chain=selected_run_full_chain,
                progress_callback=write_bootstrap_progress,
                _private_diagnostic_callback=write_private_tuning_diagnostic,
                **p4_registry_kwargs,
            )
        bootstrap = (compute_bootstrap() if _campaign_checkpoint is None
                    else _campaign_checkpoint.stage("bootstrap", compute_bootstrap))
        bootstrap_hard_vetoes = _bootstrap_hard_vetoes(bootstrap)
        if bootstrap_hard_vetoes:
            final_status = "hard_veto"
            diagnostic_role = "bootstrap_screen_hard_veto"
            hard_vetoes = bootstrap_hard_vetoes
            repair_triggers = _bootstrap_repair_triggers(bootstrap)
            result = HMCKernelTuningResult(
                config=cfg,
                adapter_signature=adapter_signature,
                target_dimension=target_dimension,
                geometry=geometry,
                bootstrap=bootstrap,
                tune_verify_repair_loop=None,
                final_status=final_status,
                diagnostic_role=diagnostic_role,
                hard_vetoes=hard_vetoes,
                repair_triggers=repair_triggers,
                final_kernel_payload=None,
                final_kernel_hash=None,
                artifact_path=None if artifact_path is None else str(artifact_path),
                diagnostic_roles=_public_tuning_diagnostic_roles(),
                runner_binding_payload=runner_identity_payload,
                failure_diagnostics=_public_bootstrap_failure_diagnostics(bootstrap),
            )
            write_result_artifact(result)
            write_progress(
                "result_written",
                extra={
                    "final_status": result.final_status,
                    "diagnostic_role": result.diagnostic_role,
                },
            )
            return result
        if cfg.preset == "serious" and not bootstrap.passed:
            final_status = "hard_veto"
            diagnostic_role = "bootstrap_acceptance_promotion_required"
            hard_vetoes = ("bootstrap_acceptance_promoted_kernel_missing",)
            repair_triggers = _bootstrap_repair_triggers(bootstrap) or (
                "bootstrap_nonpromoting_status",
            )
            result = HMCKernelTuningResult(
                config=cfg,
                adapter_signature=adapter_signature,
                target_dimension=target_dimension,
                geometry=geometry,
                bootstrap=bootstrap,
                tune_verify_repair_loop=None,
                final_status=final_status,
                diagnostic_role=diagnostic_role,
                hard_vetoes=hard_vetoes,
                repair_triggers=repair_triggers,
                final_kernel_payload=None,
                final_kernel_hash=None,
                artifact_path=None if artifact_path is None else str(artifact_path),
                diagnostic_roles=_public_tuning_diagnostic_roles(),
                runner_binding_payload=runner_identity_payload,
                failure_diagnostics={
                    "stage": "bootstrap",
                    "bootstrap_final_status": bootstrap.final_status,
                    "acceptance_promoted": False,
                    "fallback_handoff_forbidden": True,
                    "reports_posterior_convergence": False,
                    "reports_sampler_superiority": False,
                    "reports_default_readiness": False,
                },
            )
            write_result_artifact(result)
            write_progress(
                "result_written",
                extra={
                    "final_status": result.final_status,
                    "diagnostic_role": result.diagnostic_role,
                    "bootstrap_acceptance_promoted": False,
                },
            )
            return result
        handoff_kernel = _active_bootstrap_handoff_kernel_payload(
            geometry=geometry,
            bootstrap=bootstrap,
        )
        write_private_event(
            "bootstrap_kernel_handoff",
            "bootstrap_complete",
            {
                "step_size": handoff_kernel.get("step_size"),
                "num_leapfrog_steps": handoff_kernel.get("num_leapfrog_steps"),
                "target_trajectory_length": handoff_kernel.get(
                    "target_trajectory_length"
                ),
                "bootstrap_artifact_hash": bootstrap.artifact_hash,
                "selected_kernel_hash": _active_bootstrap_handoff_kernel_hash(
                    geometry=geometry,
                    bootstrap=bootstrap,
                ),
                "bootstrap_final_status": bootstrap.final_status,
            },
        )
        write_progress(
            "bootstrap_complete",
            completed=True,
            extra={"bootstrap_artifact_hash": bootstrap.artifact_hash},
        )
    except Exception as exc:  # noqa: BLE001 - public tuner returns fail-closed artifacts.
        final_status = "hard_veto"
        diagnostic_role = "bootstrap_screen_hard_veto"
        hard_vetoes = ("bootstrap_screen_error",)
        repair_triggers = (type(exc).__name__,)
        write_progress(
            "bootstrap_error",
            extra={
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "error_repr": repr(exc),
            },
        )
        result = HMCKernelTuningResult(
            config=cfg,
            adapter_signature=adapter_signature,
            target_dimension=target_dimension,
            geometry=geometry,
            bootstrap=None,
            tune_verify_repair_loop=None,
            final_status=final_status,
            diagnostic_role=diagnostic_role,
            hard_vetoes=hard_vetoes,
            repair_triggers=repair_triggers,
            final_kernel_payload=None,
            final_kernel_hash=None,
            artifact_path=None if artifact_path is None else str(artifact_path),
            diagnostic_roles=_public_tuning_diagnostic_roles(),
            runner_binding_payload=runner_identity_payload,
            failure_diagnostics=_public_failure_diagnostics(
                stage="bootstrap", exc=exc
            ),
        )
        write_result_artifact(result)
        write_progress(
            "result_written",
            extra={
                "final_status": result.final_status,
                "diagnostic_role": result.diagnostic_role,
            },
        )
        return result

    if cfg.staged_timeout_policy is not None:
        phase7_pre_windowed_started_perf_counter_s = time.perf_counter()
        cfg_for_timeout = dataclasses.replace(
            cfg_for_timeout,
            staged_timeout_stage_started_perf_counter_s=(
                phase7_pre_windowed_started_perf_counter_s
            ),
        )

    early_phase7_closeout = _phase7_early_global_timeout_before_loop(
        config=cfg_for_timeout,
        public_timeout_started_perf_counter_s=public_timeout_started_perf_counter_s,
        bootstrap=bootstrap,
        target_dimension=target_dimension,
        xla_requested=cfg.use_xla,
    )
    if early_phase7_closeout is not None:
        final_status = "hard_veto"
        diagnostic_role = _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO
        hard_vetoes = (_PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO,)
        repair_triggers = (_PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_REPAIR_TRIGGER,)
        phase7_state["early_closeout_public_summary"] = dict(early_phase7_closeout)
        write_progress(
            _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO,
            completed=True,
            phase7_substage=True,
            extra={
                "phase7_early_closeout_public_summary": early_phase7_closeout,
                "phase7_progress_contract": {
                    "progress_only": True,
                    "hmc_mechanics_exposed": False,
                    "reports_posterior_convergence": False,
                },
            },
        )
        result = HMCKernelTuningResult(
            config=cfg,
            adapter_signature=adapter_signature,
            target_dimension=target_dimension,
            geometry=geometry,
            bootstrap=bootstrap,
            tune_verify_repair_loop=None,
            final_status=final_status,
            diagnostic_role=diagnostic_role,
            hard_vetoes=hard_vetoes,
            repair_triggers=repair_triggers,
            final_kernel_payload=None,
            final_kernel_hash=None,
            artifact_path=None if artifact_path is None else str(artifact_path),
            diagnostic_roles=_public_tuning_diagnostic_roles(),
            runner_binding_payload=runner_identity_payload,
            phase7_early_closeout_public_summary=early_phase7_closeout,
        )
        write_result_artifact(result)
        write_progress(
            "result_written",
            extra={
                "final_status": result.final_status,
                "diagnostic_role": result.diagnostic_role,
                "phase7_early_closeout_public_summary": early_phase7_closeout,
            },
        )
        return result

    try:
        write_progress("loop_start", started=True)
        p4_registry_kwargs = (
            {}
            if p4_seed_use_registry is None
            else {"_g2_seed_use_registry": p4_seed_use_registry}
        )
        loop = run_hmc_tune_verify_repair_loop(
            adapter=adapter,
            geometry=geometry,
            bootstrap=bootstrap,
            config=_public_loop_config(
                cfg_for_timeout,
                public_timeout_started_perf_counter_s=(
                    public_timeout_started_perf_counter_s
                    if cfg.staged_timeout_policy is None
                    else staged_timeout_global_started_perf_counter_s
                ),
            ),
            fixed_mass_screen_callback=diagnostic_callback,
            trajectory_screen_callback=diagnostic_callback,
            verification_callback=diagnostic_callback,
            verification_checkpoint_writer_config=verification_checkpoint_writer_config,
            run_full_chain=selected_run_full_chain,
            _budget_policy_factory=_public_budget_policy_factory(
                cfg,
                geometry=geometry,
            ),
            _progress_callback=write_loop_progress,
            **({} if _campaign_checkpoint is None else {"_campaign_checkpoint": _campaign_checkpoint}),
            _private_diagnostic_callback=write_private_tuning_diagnostic,
            **p4_registry_kwargs,
        )
        write_progress(
            "loop_complete",
            completed=True,
            extra={"loop_artifact_hash": loop.artifact_hash},
        )
    except Exception as exc:  # noqa: BLE001 - public tuner returns fail-closed artifacts.
        final_status = "hard_veto"
        diagnostic_role = "tune_verify_repair_loop_hard_veto"
        hard_vetoes = ("tune_verify_repair_loop_error",)
        repair_triggers = (type(exc).__name__,)
        write_progress(
            "loop_error",
            extra={"error_type": type(exc).__name__, "error_message": str(exc)},
        )
        result = HMCKernelTuningResult(
            config=cfg,
            adapter_signature=adapter_signature,
            target_dimension=target_dimension,
            geometry=geometry,
            bootstrap=bootstrap,
            tune_verify_repair_loop=None,
            final_status=final_status,
            diagnostic_role=diagnostic_role,
            hard_vetoes=hard_vetoes,
            repair_triggers=repair_triggers,
            final_kernel_payload=None,
            final_kernel_hash=None,
            artifact_path=None if artifact_path is None else str(artifact_path),
            diagnostic_roles=_public_tuning_diagnostic_roles(),
            runner_binding_payload=runner_identity_payload,
        )
        write_result_artifact(result)
        write_progress(
            "result_written",
            extra={
                "final_status": result.final_status,
                "diagnostic_role": result.diagnostic_role,
            },
        )
        return result

    final_status = loop.final_status
    diagnostic_role = loop.diagnostic_role
    hard_vetoes = loop.hard_vetoes
    repair_triggers = loop.repair_triggers
    if loop.passed:
        final_kernel_payload = {
            **_public_final_kernel_handoff_payload(loop),
            "runner_binding_hash": runner_identity_payload["binding_hash"],
            "runner_identity": runner_identity_payload["runner_identity"],
        }
        final_kernel_hash = stable_config_hash(final_kernel_payload)
    result = HMCKernelTuningResult(
        config=cfg,
        adapter_signature=adapter_signature,
        target_dimension=target_dimension,
        geometry=geometry,
        bootstrap=bootstrap,
        tune_verify_repair_loop=loop,
        final_status=final_status,
        diagnostic_role=diagnostic_role,
        hard_vetoes=hard_vetoes,
        repair_triggers=repair_triggers,
        final_kernel_payload=final_kernel_payload,
        final_kernel_hash=final_kernel_hash,
        artifact_path=None if artifact_path is None else str(artifact_path),
        diagnostic_roles=_public_tuning_diagnostic_roles(),
        runner_binding_payload=runner_identity_payload,
    )
    write_result_artifact(result)
    write_progress(
        "result_written",
        extra={
            "final_status": result.final_status,
            "diagnostic_role": result.diagnostic_role,
        },
    )
    return result


class _HMCStartBankDiagnosticBoundaryReached(Exception):
    """Private control signal raised only after the bounded event is durable."""

    def __init__(
        self,
        *,
        qualification: Mapping[str, Any],
        qualification_sha256: str,
        private_event_hash: str,
    ) -> None:
        super().__init__("start-bank diagnostic boundary reached")
        self.qualification = qualification
        self.qualification_sha256 = str(qualification_sha256)
        self.private_event_hash = str(private_event_hash)


def _canonical_start_bank_qualification(
    payload: Mapping[str, Any],
) -> tuple[Mapping[str, Any], str]:
    validated = _validate_start_bank_qualification_payload(_json_ready(payload))
    blob = json.dumps(
        _json_ready(validated),
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
    normalized = json.loads(blob)
    return normalized, hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _start_bank_diagnostic_budget_summary(
    policy: "_HMCAttemptBudgetPolicy",
) -> Mapping[str, Any]:
    return {
        "schema": "bayesfilter.hmc_start_bank_diagnostic_budget_summary.v1",
        "attempt_index": int(policy.attempt_index),
        "budget": int(policy.budget),
        "phase4_warmup_steps": int(policy.phase4_warmup_steps),
        "public_budget_class": str(policy.public_budget_class),
        "public_diagnostic_preset": str(policy.public_diagnostic_preset),
        "full_policy_hash": stable_config_hash(policy.payload()),
        "later_stage_budgets_executed": False,
    }


def _write_start_bank_diagnostic_result(
    result: HMCStartBankDiagnosticResult,
    path: Path,
) -> None:
    payload = _json_ready(result.payload())
    artifact = {**payload, "result_hash": stable_config_hash(payload)}
    blob = json.dumps(artifact, indent=2, sort_keys=True, allow_nan=False) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(
        f".{path.name}.{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}.tmp"
    )
    with temporary.open("x", encoding="utf-8") as handle:
        handle.write(blob)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
    observed = json.loads(path.read_text(encoding="utf-8"))
    if observed != artifact:
        raise RuntimeError("start-bank diagnostic result readback mismatch")


def run_hmc_start_bank_diagnostic(
    *,
    adapter: Any,
    initial_position: Any,
    config: HMCKernelTuningConfig,
    output_dir: str | Path,
    negative_hessian: Any | None = None,
    initial_covariance: Any | None = None,
    parameter_scales: Any | None = None,
) -> HMCStartBankDiagnosticResult:
    """Run through the real start-bank callback and stop before later tuning.

    All HMC draws are discarded adaptation diagnostics. The returned object is
    not a kernel handoff and cannot authorize retained sampling.
    """

    if not isinstance(config, HMCKernelTuningConfig):
        raise TypeError("config must be HMCKernelTuningConfig")
    if config.preset != "diagnostic":
        raise ValueError("start-bank diagnostic requires preset='diagnostic'")
    position = _validate_position(initial_position)
    adapter_signature = stable_adapter_signature(adapter)
    target_dimension = int(position.shape[0])
    require_hmc_algorithm_route(
        algorithm_id=config.algorithm_id,
        stage=HMC_TOP_LEVEL_SELECTION_STAGE,
        runtime_backend="tensorflow",
        chain_execution_mode=config.chain_execution_mode,
        use_xla=config.use_xla,
        timeout_enabled=config.public_timeout_budget_s is not None,
        heartbeat_enabled=config.incall_progress_heartbeat_s is not None,
        output_path_enabled=True,
        checkpointing_enabled=False,
    )

    root = Path(output_dir)
    if root.exists():
        raise FileExistsError(f"start-bank diagnostic output already exists: {root}")
    root.parent.mkdir(parents=True, exist_ok=True)
    root.mkdir(exist_ok=False)
    artifact_path = root / "hmc_start_bank_diagnostic_result.json"
    private_events_path = (
        root / "private_diagnostics" / "hmc_start_bank_diagnostic_events.jsonl"
    )
    geometry: HMCGeometryInitializationResult | None = None
    bootstrap: HMCBootstrapScreenResult | None = None
    attempt_budget_summary: Mapping[str, Any] | None = None
    windowed_config_payload: Mapping[str, Any] | None = None

    def finalize(
        *,
        final_status: str,
        diagnostic_role: str,
        hard_vetoes: tuple[str, ...],
        repair_triggers: tuple[str, ...] = (),
        qualification: Mapping[str, Any] | None = None,
        qualification_sha256: str | None = None,
        private_event_hash: str | None = None,
        failure_diagnostics: Mapping[str, Any] | None = None,
    ) -> HMCStartBankDiagnosticResult:
        result = HMCStartBankDiagnosticResult(
            config=config,
            adapter_signature=adapter_signature,
            target_dimension=target_dimension,
            geometry_artifact_hash=(
                None if geometry is None else geometry.artifact_hash
            ),
            bootstrap_artifact_hash=(
                None if bootstrap is None else bootstrap.artifact_hash
            ),
            bootstrap_final_status=(
                None if bootstrap is None else bootstrap.final_status
            ),
            bootstrap_screen_count=(
                0 if bootstrap is None else len(bootstrap.rounds)
            ),
            attempt_budget_summary=attempt_budget_summary,
            windowed_stage_config_payload=windowed_config_payload,
            start_bank_qualification=qualification,
            start_bank_qualification_sha256=qualification_sha256,
            final_status=final_status,
            diagnostic_role=diagnostic_role,
            hard_vetoes=hard_vetoes,
            repair_triggers=repair_triggers,
            private_event_count=0 if qualification is None else 1,
            private_event_hash=private_event_hash,
            artifact_path=str(artifact_path),
            failure_diagnostics=failure_diagnostics,
        )
        _write_start_bank_diagnostic_result(result, artifact_path)
        return result

    try:
        geometry = initialize_hmc_kernel_geometry(
            adapter=adapter,
            initial_position=position,
            config=_public_geometry_config(config),
            negative_hessian=negative_hessian,
            initial_covariance=initial_covariance,
            parameter_scales=parameter_scales,
        )
    except Exception as exc:  # noqa: BLE001 - return a bounded failure artifact.
        return finalize(
            final_status="invalid_before_start_bank_boundary",
            diagnostic_role="geometry_initialization_error",
            hard_vetoes=("geometry_initialization_error",),
            failure_diagnostics={
                "stage": "geometry",
                "error_type": type(exc).__name__,
                "arbitrary_error_message_retained": False,
            },
        )

    try:
        bootstrap = run_hmc_bootstrap_screen(
            adapter=adapter,
            geometry=geometry,
            config=_public_bootstrap_config(config, geometry=geometry),
        )
    except Exception as exc:  # noqa: BLE001 - return a bounded failure artifact.
        return finalize(
            final_status="invalid_before_start_bank_boundary",
            diagnostic_role="bootstrap_screen_error",
            hard_vetoes=("bootstrap_screen_error",),
            failure_diagnostics={
                "stage": "bootstrap",
                "error_type": type(exc).__name__,
                "arbitrary_error_message_retained": False,
            },
        )

    bootstrap_hard_vetoes = _bootstrap_hard_vetoes(bootstrap)
    if bootstrap_hard_vetoes:
        return finalize(
            final_status="invalid_before_start_bank_boundary",
            diagnostic_role="bootstrap_screen_hard_veto",
            hard_vetoes=bootstrap_hard_vetoes,
            repair_triggers=_bootstrap_repair_triggers(bootstrap),
            failure_diagnostics={
                "stage": "bootstrap",
                "bootstrap_final_status": bootstrap.final_status,
                "start_bank_boundary_reached": False,
            },
        )

    public_timeout_started = (
        time.perf_counter()
        if config.public_timeout_budget_s is not None
        else None
    )
    loop_config = _public_loop_config(
        config,
        public_timeout_started_perf_counter_s=public_timeout_started,
    )
    policy_factory = _public_budget_policy_factory(config, geometry=geometry)
    if policy_factory is None:
        return finalize(
            final_status="invalid_before_start_bank_boundary",
            diagnostic_role="attempt_budget_policy_missing",
            hard_vetoes=("attempt_budget_policy_missing",),
        )
    try:
        attempt_budget_policy = policy_factory(target_dimension, 0)
        if not isinstance(attempt_budget_policy, _HMCAttemptBudgetPolicy):
            raise TypeError("attempt budget factory returned an invalid policy")
        attempt_budget_summary = _start_bank_diagnostic_budget_summary(
            attempt_budget_policy
        )
        windowed_config = _phase7_windowed_stage_config(
            loop_config,
            attempt_index=0,
        )
        windowed_config_payload = windowed_config.payload()
    except Exception as exc:  # noqa: BLE001 - return a bounded failure artifact.
        return finalize(
            final_status="invalid_before_start_bank_boundary",
            diagnostic_role="windowed_stage_configuration_error",
            hard_vetoes=("windowed_stage_configuration_error",),
            failure_diagnostics={
                "stage": "windowed_stage_configuration",
                "error_type": type(exc).__name__,
                "arbitrary_error_message_retained": False,
            },
        )

    def stop_at_start_bank(
        event_type: str,
        payload: Mapping[str, Any],
    ) -> None:
        if event_type != "start_bank_qualification":
            raise ValueError("unexpected diagnostic event before start-bank stop")
        if payload.get("stage") != "windowed_mass_start_bank_boundary":
            raise ValueError("start-bank diagnostic event stage mismatch")
        candidate = payload.get("start_bank_qualification")
        if not isinstance(candidate, Mapping):
            raise ValueError("start-bank diagnostic event lacks qualification")
        qualification, qualification_hash = _canonical_start_bank_qualification(
            candidate
        )
        scopes = qualification["scopes"]
        authoritative = scopes["authoritative_final_window"]
        shadow = scopes["shadow_all_windows"]
        if (
            int(authoritative["dimension"]) != target_dimension
            or int(shadow["dimension"]) != target_dimension
        ):
            raise ValueError("start-bank diagnostic dimension mismatch")
        if int(authoritative["source_row_count"]) != 4:
            raise ValueError("authoritative start-bank source must contain four rows")
        if int(shadow["source_row_count"]) != int(
            attempt_budget_policy.phase4_warmup_steps
        ):
            raise ValueError("shadow start-bank source does not cover full warmup")
        if (
            authoritative["minimum_relative_separation"]
            != shadow["minimum_relative_separation"]
        ):
            raise ValueError("start-bank scopes use different separation policies")
        event = _write_private_tuning_event(
            private_events_path,
            event_type="start_bank_qualification",
            stage="windowed_mass_start_bank_boundary",
            payload={
                "attempt_index": 0,
                "start_bank_qualification": qualification,
                "start_bank_qualification_sha256": qualification_hash,
                "private_hmc_mechanics": False,
                "raw_state_included": False,
                "reports_posterior_convergence": False,
                "nonclaims": HMC_START_BANK_DIAGNOSTIC_NONCLAIMS,
            },
        )
        if event is None or event.get("start_bank_qualification") != qualification:
            raise RuntimeError("start-bank private event write/readback mismatch")
        if event.get("start_bank_qualification_sha256") != qualification_hash:
            raise RuntimeError("start-bank private event SHA256 mismatch")
        raise _HMCStartBankDiagnosticBoundaryReached(
            qualification=qualification,
            qualification_sha256=qualification_hash,
            private_event_hash=str(event["event_hash"]),
        )

    try:
        returned_stage = run_hmc_windowed_mass_stage(
            adapter=adapter,
            geometry=geometry,
            bootstrap=bootstrap,
            config=windowed_config,
            _attempt_budget_policy=attempt_budget_policy,
            _attempt_state=None,
            _attempt_index=0,
            _private_diagnostic_callback=stop_at_start_bank,
        )
    except _HMCStartBankDiagnosticBoundaryReached as boundary:
        shadow_failure = boundary.qualification["scopes"]["shadow_all_windows"][
            "failure_code"
        ]
        if str(shadow_failure).startswith("shadow_"):
            return finalize(
                final_status="diagnostic_incomplete_shadow_failure",
                diagnostic_role="shadow_start_bank_diagnostic_failure",
                hard_vetoes=("shadow_start_bank_diagnostic_failure",),
                qualification=boundary.qualification,
                qualification_sha256=boundary.qualification_sha256,
                private_event_hash=boundary.private_event_hash,
                failure_diagnostics={
                    "stage": "start_bank_boundary",
                    "shadow_failure_code": str(shadow_failure),
                },
            )
        return finalize(
            final_status="diagnostic_boundary_reached",
            diagnostic_role="start_bank_qualification_explanatory_only",
            hard_vetoes=(),
            qualification=boundary.qualification,
            qualification_sha256=boundary.qualification_sha256,
            private_event_hash=boundary.private_event_hash,
        )
    except Exception as exc:  # noqa: BLE001 - return a bounded failure artifact.
        return finalize(
            final_status="invalid_before_start_bank_boundary",
            diagnostic_role="windowed_stage_or_boundary_writer_error",
            hard_vetoes=("windowed_stage_or_boundary_writer_error",),
            failure_diagnostics={
                "stage": "windowed_mass_or_boundary_writer",
                "error_type": type(exc).__name__,
                "arbitrary_error_message_retained": False,
            },
        )

    return finalize(
        final_status="invalid_before_start_bank_boundary",
        diagnostic_role="start_bank_boundary_not_observed",
        hard_vetoes=("start_bank_boundary_not_observed",),
        repair_triggers=tuple(returned_stage.repair_triggers),
        failure_diagnostics={
            "stage": "windowed_mass",
            "windowed_stage_final_status": returned_stage.final_status,
            "windowed_stage_artifact_hash": returned_stage.artifact_hash,
            "start_bank_boundary_reached": False,
        },
    )


def _resolve_fixed_mass_step_stage_target_scope(
    adapter: Any,
    config: HMCFixedMassStepStageConfig,
) -> str:
    capability = value_score_capability(adapter)
    capability_scope = capability.target_scope
    if config.target_scope is not None:
        target_scope = str(config.target_scope)
        if not target_scope:
            raise ValueError("target_scope must be non-empty when provided")
        if capability_scope is not None and target_scope != capability_scope:
            raise ValueError("value/score target_scope mismatch")
        return target_scope
    if capability_scope is None or not str(capability_scope):
        raise ValueError(
            "fixed-mass step stage requires config.target_scope or an adapter "
            "value_score_capability target_scope"
        )
    return str(capability_scope)


def _resolve_frozen_step_trajectory_stage_target_scope(
    adapter: Any,
    config: HMCFrozenStepTrajectoryStageConfig,
) -> str:
    capability = value_score_capability(adapter)
    capability_scope = capability.target_scope
    if config.target_scope is not None:
        target_scope = str(config.target_scope)
        if not target_scope:
            raise ValueError("target_scope must be non-empty when provided")
        if capability_scope is not None and target_scope != capability_scope:
            raise ValueError("value/score target_scope mismatch")
        return target_scope
    if capability_scope is None or not str(capability_scope):
        raise ValueError(
            "frozen-step trajectory stage requires config.target_scope or an "
            "adapter value_score_capability target_scope"
        )
    return str(capability_scope)




def _validate_fixed_mass_step_stage_inputs(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
    windowed_stage: HMCWindowedMassStageResult,
    config: HMCFixedMassStepStageConfig,
) -> None:
    if config.mass_policy != windowed_stage.config.mass_policy:
        raise ValueError("Phase 5 mass policy does not match Phase 4")
    expected_windowed_algorithm = windowed_algorithm_for_selection_algorithm(
        config.algorithm_id
    )
    if windowed_stage.config.algorithm_id != expected_windowed_algorithm:
        raise ValueError("Phase 5 selection and Phase 4 warmup algorithms do not match")
    adapter_signature = stable_adapter_signature(adapter)
    if adapter_signature != windowed_stage.adapter_signature:
        raise ValueError("fixed-mass step stage adapter signature must match Phase 4")
    if geometry.adapter_signature != windowed_stage.adapter_signature:
        raise ValueError("fixed-mass step stage geometry must match Phase 4")
    if geometry.artifact_hash != windowed_stage.geometry_artifact_hash:
        raise ValueError("fixed-mass step stage geometry artifact must match Phase 4")
    if bootstrap.artifact_hash != windowed_stage.bootstrap_artifact_hash:
        raise ValueError("fixed-mass step stage bootstrap artifact must match Phase 4")
    if (
        _active_bootstrap_handoff_kernel_hash(geometry=geometry, bootstrap=bootstrap)
        != windowed_stage.selected_bootstrap_kernel_hash
    ):
        raise ValueError("fixed-mass step stage selected bootstrap kernel mismatch")
    _validate_windowed_stage_inputs(adapter=adapter, geometry=geometry, bootstrap=bootstrap)
    if not windowed_stage.passed:
        raise ValueError("fixed-mass step stage requires passed Phase 4 result")
    if windowed_stage.adapted_mass_artifact_signature is None:
        raise ValueError("fixed-mass step stage requires adapted mass signature")
    if windowed_stage.candidate_step_size is None:
        raise ValueError("fixed-mass step stage requires candidate step size")
    if not math.isfinite(float(windowed_stage.candidate_step_size)):
        raise ValueError("fixed-mass step candidate step must be finite")
    if float(windowed_stage.candidate_step_size) <= 0.0:
        raise ValueError("fixed-mass step candidate step must be positive")
    selected = _mass_window_seed_kernel_from_windowed_stage(
        windowed_stage,
        bootstrap=bootstrap,
        geometry=geometry,
    )
    if int(selected.get("num_leapfrog_steps", 0)) <= 0:
        raise ValueError("fixed-mass step stage requires positive mass-window seed L")
    artifact = _phase4_adapted_mass_artifact(windowed_stage)
    if artifact.adapter_signature != windowed_stage.hmc_adapter_signature:
        raise ValueError("Phase 4 adapted mass adapter signature mismatch")
    signature = _mass_artifact_signature(artifact)
    if signature != windowed_stage.adapted_mass_artifact_signature:
        raise ValueError("Phase 4 adapted mass signature mismatch")
    if config.mass_policy == "fixed_identity" and (
        signature != windowed_stage.initial_mass_artifact_signature
    ):
        raise ValueError("fixed identity Phase 5 mass signature mutated")
    artifact.validate_for_adapter(
        _phase4_latent_adapter_for_step_stage(
            adapter=adapter,
            geometry=geometry,
            windowed_stage=windowed_stage,
            target_scope=_resolve_fixed_mass_step_stage_target_scope(adapter, config),
        ),
        expected_dim=windowed_stage.target_dimension,
    )


def _validate_frozen_step_trajectory_stage_inputs(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCFrozenStepTrajectoryStageConfig,
) -> None:
    if config.mass_policy != windowed_stage.config.mass_policy:
        raise ValueError("Phase 6 mass policy does not match Phase 4")
    if config.mass_policy != fixed_mass_step_stage.config.mass_policy:
        raise ValueError("Phase 6 mass policy does not match Phase 5")
    adapter_signature = stable_adapter_signature(adapter)
    if adapter_signature != fixed_mass_step_stage.adapter_signature:
        raise ValueError("frozen-step trajectory adapter signature mismatch")
    if adapter_signature != windowed_stage.adapter_signature:
        raise ValueError("frozen-step trajectory Phase 4 adapter signature mismatch")
    if geometry.adapter_signature != adapter_signature:
        raise ValueError("frozen-step trajectory geometry adapter signature mismatch")
    if bootstrap.adapter_signature != adapter_signature:
        raise ValueError("frozen-step trajectory bootstrap adapter signature mismatch")
    if geometry.artifact_hash != windowed_stage.geometry_artifact_hash:
        raise ValueError("frozen-step trajectory geometry artifact mismatch")
    if bootstrap.artifact_hash != windowed_stage.bootstrap_artifact_hash:
        raise ValueError("frozen-step trajectory bootstrap artifact mismatch")
    if fixed_mass_step_stage.windowed_stage_artifact_hash != windowed_stage.artifact_hash:
        raise ValueError("frozen-step trajectory Phase 5 windowed artifact mismatch")
    active_bootstrap_hash = _active_bootstrap_handoff_kernel_hash(
        geometry=geometry,
        bootstrap=bootstrap,
    )
    if fixed_mass_step_stage.selected_bootstrap_kernel_hash != active_bootstrap_hash:
        raise ValueError("frozen-step trajectory selected bootstrap kernel hash mismatch")
    if fixed_mass_step_stage.selected_bootstrap_kernel_hash != windowed_stage.selected_bootstrap_kernel_hash:
        raise ValueError("frozen-step trajectory Phase 4 selected bootstrap hash mismatch")
    if not fixed_mass_step_stage.passed:
        raise ValueError("frozen-step trajectory requires passed Phase 5 result")
    if fixed_mass_step_stage.selected_step_payload is None:
        raise ValueError("frozen-step trajectory requires selected step payload")
    if fixed_mass_step_stage.selected_step_hash is None:
        raise ValueError("frozen-step trajectory requires selected step hash")
    if stable_config_hash(fixed_mass_step_stage.selected_step_payload) != fixed_mass_step_stage.selected_step_hash:
        raise ValueError("frozen-step trajectory selected step hash mismatch")
    selected_step = float(fixed_mass_step_stage.selected_step_payload.get("step_size"))
    if not math.isfinite(selected_step) or selected_step <= 0.0:
        raise ValueError("frozen-step trajectory selected step must be positive")
    selected_payload_l = int(
        fixed_mass_step_stage.selected_step_payload.get("num_leapfrog_steps", 0)
    )
    if selected_payload_l <= 0:
        raise ValueError("frozen-step trajectory selected payload L must be positive")
    if selected_payload_l != int(fixed_mass_step_stage.fixed_num_leapfrog_steps):
        raise ValueError("frozen-step trajectory selected L payload mismatch")
    if fixed_mass_step_stage.budget_ladder_result is None:
        raise ValueError("frozen-step trajectory requires Phase 5 budget ladder result")
    ladder = fixed_mass_step_stage.budget_ladder_result
    if not ladder.passed:
        raise ValueError("frozen-step trajectory requires passed Phase 5 ladder")
    if ladder.mass_artifact_signature != fixed_mass_step_stage.adapted_mass_artifact_signature:
        raise ValueError("frozen-step trajectory Phase 5 ladder mass signature mismatch")
    if ladder.selected_config_hash != fixed_mass_step_stage.selected_step_hash:
        raise ValueError("frozen-step trajectory ladder selected step hash mismatch")
    if ladder.adapter_signature != fixed_mass_step_stage.phase4_hmc_adapter_signature:
        raise ValueError("frozen-step trajectory ladder adapter signature mismatch")
    if ladder.hmc_adapter_signature != fixed_mass_step_stage.ladder_hmc_adapter_signature:
        raise ValueError("frozen-step trajectory ladder HMC adapter signature mismatch")
    if fixed_mass_step_stage.adapted_mass_artifact_signature != windowed_stage.adapted_mass_artifact_signature:
        raise ValueError("frozen-step trajectory Phase 4 adapted mass signature mismatch")
    if config.mass_policy == "fixed_identity" and (
        fixed_mass_step_stage.adapted_mass_artifact_signature
        != windowed_stage.initial_mass_artifact_signature
    ):
        raise ValueError("fixed identity Phase 6 mass signature mutated")
    if fixed_mass_step_stage.target_dimension != windowed_stage.target_dimension:
        raise ValueError("frozen-step trajectory target dimension mismatch")
    if geometry.target_dimension != fixed_mass_step_stage.target_dimension:
        raise ValueError("frozen-step trajectory geometry dimension mismatch")
    _validate_fixed_mass_step_stage_inputs(
        adapter=adapter,
        geometry=geometry,
        bootstrap=bootstrap,
        windowed_stage=windowed_stage,
        config=HMCFixedMassStepStageConfig(
            algorithm_id=fixed_mass_step_stage.config.algorithm_id,
            target_accept_prob=fixed_mass_step_stage.config.target_accept_prob,
            acceptance_band=fixed_mass_step_stage.config.acceptance_band,
            repair_band=fixed_mass_step_stage.config.repair_band,
            step_repair_factor=fixed_mass_step_stage.config.step_repair_factor,
            step_repair_min_directional_factor=(
                fixed_mass_step_stage.config.step_repair_min_directional_factor
            ),
            step_repair_high_acceptance_directional_factor=(
                fixed_mass_step_stage.config.step_repair_high_acceptance_directional_factor
            ),
            step_repair_high_acceptance_ladder_max_factor=(
                fixed_mass_step_stage.config.step_repair_high_acceptance_ladder_max_factor
            ),
            trajectory_window_lower_multiplier=(
                fixed_mass_step_stage.config.trajectory_window_lower_multiplier
            ),
            trajectory_window_upper_multiplier=(
                fixed_mass_step_stage.config.trajectory_window_upper_multiplier
            ),
            handoff_screen_policy=fixed_mass_step_stage.config.handoff_screen_policy,
            seed=fixed_mass_step_stage.config.seed,
            chain_execution_mode=fixed_mass_step_stage.config.chain_execution_mode,
            target_scope=config.target_scope
            if config.target_scope is not None
            else fixed_mass_step_stage.config.target_scope,
            target_status_trace_policy=fixed_mass_step_stage.config.target_status_trace_policy,
            mass_policy=fixed_mass_step_stage.config.mass_policy,
            public_timeout_budget_s=fixed_mass_step_stage.config.public_timeout_budget_s,
            public_timeout_started_perf_counter_s=(
                fixed_mass_step_stage.config.public_timeout_started_perf_counter_s
            ),
            incall_progress_heartbeat_s=(
                fixed_mass_step_stage.config.incall_progress_heartbeat_s
            ),
            source=fixed_mass_step_stage.config.source,
        ),
    )
    target_scope = _resolve_frozen_step_trajectory_stage_target_scope(adapter, config)
    selected_payload_scope = fixed_mass_step_stage.selected_step_payload.get("target_scope")
    if selected_payload_scope is not None and str(selected_payload_scope) != target_scope:
        raise ValueError("frozen-step trajectory selected step target_scope mismatch")


def _validate_tune_verify_loop_inputs(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
) -> None:
    adapter_signature = stable_adapter_signature(adapter)
    if adapter_signature != geometry.adapter_signature:
        raise ValueError("Phase 7 adapter signature must match geometry")
    if adapter_signature != bootstrap.adapter_signature:
        raise ValueError("Phase 7 adapter signature must match bootstrap")
    if bootstrap.geometry_artifact_hash != geometry.artifact_hash:
        raise ValueError("Phase 7 bootstrap must match geometry artifact")
    if not _bootstrap_preflight_passed(bootstrap):
        raise ValueError("Phase 7 requires bootstrap preflight without hard veto")
    if geometry.target_dimension != bootstrap.target_dimension:
        raise ValueError("Phase 7 geometry and bootstrap dimensions must match")
    geometry.mass_artifact.validate_for_adapter(
        adapter,
        expected_dim=geometry.target_dimension,
    )


def _public_final_kernel_handoff_payload(
    loop: HMCTuneVerifyRepairLoopResult,
) -> Mapping[str, Any]:
    if not loop.passed or loop.final_kernel_payload is None:
        raise ValueError("public handoff requires passed Phase 7 final kernel")
    return _public_final_kernel_summary_from_private_payload(
        loop.final_kernel_payload,
        config=loop.config,
        phase7_final_kernel_hash=loop.final_kernel_hash,
    )


def _public_final_kernel_summary_from_private_payload(
    private_payload: Mapping[str, Any],
    *,
    config: Any,
    phase7_final_kernel_hash: str | None,
) -> Mapping[str, Any]:
    """Return a non-replayable public summary of a private frozen HMC kernel."""

    required_keys = (
        "schema",
        "target_scope",
        "target_dimension",
        "adapted_mass_artifact_signature",
        "mass_policy",
        "target_accept_prob",
        "acceptance_band",
        "verification_acceptance_rate",
        "geometry_artifact_hash",
        "bootstrap_artifact_hash",
        "windowed_stage_artifact_hash",
        "fixed_mass_step_stage_artifact_hash",
        "frozen_step_trajectory_stage_artifact_hash",
        "selected_step_hash",
        "selected_trajectory_hash",
        "fresh_fixed_kernel_verification_passed",
        "reports_posterior_convergence",
        "reports_sampler_superiority",
        "reports_default_readiness",
        "reports_external_client_scientific_claim",
        "reports_gpu_or_xla_readiness",
        "nonclaims",
    )
    return {
        "runtime": "bayesfilter.inference.tune_hmc_kernel",
        "public_handoff_schema": "bayesfilter.hmc_public_frozen_kernel_handoff.v1",
        "ordinary_selection_policy": _ordinary_selection_policy_payload(config),
        "replay_role": REPLAY_ROLE_MECHANICS_ONLY,
        "claim_bearing_artifact_authority": False,
        **{key: private_payload[key] for key in required_keys if key in private_payload},
        "phase7_final_kernel_hash": phase7_final_kernel_hash,
        "internal_tuning_controls_exposed": False,
        "hmc_mechanics_exposed": False,
        "mass_arrays_exposed": False,
        "raw_samples_exposed": False,
        "private_replay_payload": False,
        "public_reconstruction_api": False,
    }


def _phase7_private_resume_split_contract(
    *,
    loop: HMCTuneVerifyRepairLoopResult,
    attempt_index: int | None = None,
) -> Mapping[str, Any]:
    """Build a private-only Phase 7 repair handoff contract.

    This is a resume/split contract for BayesFilter-owned repair orchestration,
    not a public verifier-entry checkpoint and not a final frozen-kernel
    handoff.  The returned payload may contain private HMC mechanics because it
    is explicitly private-only; callers must expose only
    ``_phase7_resume_split_public_summary``.
    """

    if not isinstance(loop, HMCTuneVerifyRepairLoopResult):
        raise TypeError("loop must be HMCTuneVerifyRepairLoopResult")
    attempts = tuple(loop.attempts)
    selected_attempt = (
        attempts[-1]
        if attempt_index is None
        else next(
            (
                attempt
                for attempt in attempts
                if int(attempt.attempt_index) == int(attempt_index)
            ),
            None,
        )
    )
    if selected_attempt is None:
        raise ValueError("Phase 7 resume/split attempt not found")
    if selected_attempt.handoff_state_payload is None:
        raise ValueError("Phase 7 resume/split contract requires private handoff state")
    handoff_state = dict(selected_attempt.handoff_state_payload)
    handoff_stage = str(handoff_state.get("handoff_stage", ""))
    if not handoff_stage:
        raise ValueError("Phase 7 resume/split contract missing handoff stage")
    if handoff_state.get("required_private_handoff_complete") is not True:
        raise ValueError("Phase 7 resume/split contract requires complete private handoff")
    contract_payload = {
        "schema": "bayesfilter.phase7_private_resume_split_contract.v1",
        "runtime": "bayesfilter.inference.run_hmc_tune_verify_repair_loop",
        "loop_artifact_hash": loop.artifact_hash,
        "geometry_artifact_hash": loop.geometry_artifact_hash,
        "bootstrap_artifact_hash": loop.bootstrap_artifact_hash,
        "adapter_signature": loop.adapter_signature,
        "target_dimension": loop.target_dimension,
        "attempt_index": selected_attempt.attempt_index,
        "attempt_final_status": selected_attempt.final_status,
        "attempt_diagnostic_role": selected_attempt.diagnostic_role,
        "handoff_stage": handoff_stage,
        "private_handoff_state": handoff_state,
        "private_handoff_state_hash": stable_config_hash(handoff_state),
        "resume_entry_kind": "phase7_repair_handoff",
        "resume_entry_stage": _phase7_resume_split_entry_stage(handoff_state),
        "private_resume_payload_only": True,
        "public_summary_schema": "bayesfilter.phase7_resume_split_public_summary.v1",
        "checkpoint_kind": None,
        "verifier_entry_manifest": False,
        "final_kernel_handoff": False,
        "actual_target_runtime_executed": False,
        "public_payload_exposes_private_handoff": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }
    return {
        **contract_payload,
        "contract_hash": stable_config_hash(contract_payload),
    }


def _phase7_resume_split_entry_stage(handoff_state: Mapping[str, Any]) -> str:
    handoff_stage = str(handoff_state.get("handoff_stage", ""))
    if handoff_stage == "phase4":
        return "phase5_fixed_mass_step"
    if handoff_stage in {"phase5_repair", "phase5_selected"}:
        return "phase5_fixed_mass_step"
    if handoff_stage == "phase6":
        return "phase7_final_verification_or_verification_only_retry"
    if handoff_stage == "phase7_direct":
        return "phase7_direct_verification_or_verification_only_retry"
    raise ValueError("Phase 7 resume/split contract has unsupported handoff stage")


def _phase7_resume_split_public_summary(
    contract: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Return the public-safe summary of a private resume/split contract."""

    if not isinstance(contract, Mapping):
        raise TypeError("contract must be a mapping")
    if contract.get("schema") != "bayesfilter.phase7_private_resume_split_contract.v1":
        raise ValueError("Phase 7 resume/split contract schema mismatch")
    public_payload = {
        "schema": "bayesfilter.phase7_resume_split_public_summary.v1",
        "private_contract_schema": contract.get("schema"),
        "contract_hash": contract.get("contract_hash"),
        "loop_artifact_hash": contract.get("loop_artifact_hash"),
        "geometry_artifact_hash": contract.get("geometry_artifact_hash"),
        "bootstrap_artifact_hash": contract.get("bootstrap_artifact_hash"),
        "target_dimension": contract.get("target_dimension"),
        "attempt_index": contract.get("attempt_index"),
        "attempt_final_status": contract.get("attempt_final_status"),
        "attempt_diagnostic_role": contract.get("attempt_diagnostic_role"),
        "handoff_stage": contract.get("handoff_stage"),
        "private_resume_payload_hash": contract.get("private_handoff_state_hash"),
        "resume_entry_kind": contract.get("resume_entry_kind"),
        "resume_entry_stage": contract.get("resume_entry_stage"),
        "private_resume_payload_available": bool(
            contract.get("private_resume_payload_only")
        ),
        "private_resume_payload_exposed": False,
        "public_payload_contains_private_paths": False,
        "public_payload_contains_checkpoint_filenames": False,
        "public_payload_contains_hmc_draws_or_positions": False,
        "public_payload_contains_hmc_tuning_mechanics": False,
        "public_payload_contains_log_prob_values": False,
        "checkpoint_kind": None,
        "verifier_entry_manifest": False,
        "final_kernel_handoff": False,
        "actual_target_runtime_executed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }
    for key, value in public_payload.items():
        if value is None and key not in {"checkpoint_kind"}:
            raise ValueError(f"Phase 7 resume/split public summary missing {key}")
    return public_payload


def _public_tuning_artifact_path(output_dir: str | Path | None) -> Path | None:
    if output_dir is None:
        return None
    path = Path(output_dir)
    if path.suffix:
        return path
    return path / "hmc_kernel_tuning_result.json"


def _public_tuning_progress_path(output_dir: str | Path | None) -> Path | None:
    if output_dir is None:
        return None
    path = Path(output_dir)
    if path.suffix:
        return path.with_name(_PUBLIC_TUNING_PROGRESS_FILENAME)
    return path / _PUBLIC_TUNING_PROGRESS_FILENAME


def _private_tuning_diagnostics_dir(output_dir: str | Path | None) -> Path | None:
    if output_dir is None:
        return None
    path = Path(output_dir)
    if path.suffix:
        return path.parent / "private_diagnostics"
    return path / "private_diagnostics"


def _private_tuning_events_path(private_dir: Path | None) -> Path | None:
    if private_dir is None:
        return None
    return private_dir / "hmc_tuning_events.jsonl"


def _utc_now_isoformat() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _selection_route_public_payload(
    config: HMCKernelTuningConfig | HMCTuneVerifyRepairLoopConfig,
    *,
    output_path_enabled: bool | None = None,
    checkpointing_enabled: bool | None = None,
    runner_identity: str = "not_retained_in_public_result",
) -> Mapping[str, Any]:
    decision = require_hmc_algorithm_route(
        algorithm_id=config.algorithm_id,
        stage=HMC_TOP_LEVEL_SELECTION_STAGE,
        runtime_backend="tensorflow",
        chain_execution_mode=config.chain_execution_mode,
        use_xla=config.use_xla,
        timeout_enabled=config.public_timeout_budget_s is not None,
        heartbeat_enabled=config.incall_progress_heartbeat_s is not None,
        output_path_enabled=bool(output_path_enabled),
        checkpointing_enabled=bool(checkpointing_enabled),
        runner_identity=runner_identity,
    )
    return {
        **decision.payload(),
        "windowed_mass_algorithm_id": windowed_algorithm_for_selection_algorithm(
            config.algorithm_id
        ),
        "execution_control_configuration": {
            "chain_execution_mode": config.chain_execution_mode,
            "use_xla": config.use_xla,
            "timeout_enabled": config.public_timeout_budget_s is not None,
            "heartbeat_enabled": config.incall_progress_heartbeat_s is not None,
            "output_path_enabled": output_path_enabled,
            "checkpointing_enabled": checkpointing_enabled,
            "runner_identity": runner_identity,
        },
    }


def _public_resolved_policy_payload(
    config: HMCKernelTuningConfig | HMCTuneVerifyRepairLoopConfig,
    *,
    output_path_enabled: bool | None = None,
    checkpointing_enabled: bool | None = None,
    runner_identity: str = "not_retained_in_public_result",
    config_variant: str = "ordinary_hmc",
) -> Mapping[str, Any]:
    """Serialize policy roles without conflating route and claim authority."""

    route = _selection_route_public_payload(
        config,
        output_path_enabled=output_path_enabled,
        checkpointing_enabled=checkpointing_enabled,
        runner_identity=runner_identity,
    )
    preset = getattr(config, "preset", None)
    preset_role = (
        None if preset is None else _public_tuning_preset_role(str(preset))
    )
    ordinary_policy = _ordinary_selection_policy_payload(config)
    policy_blockers = tuple(
        str(item) for item in ordinary_policy.get("claim_bearing_blockers", ())
    )
    # Ordinary numerical work now uses TF/TFP; host copies only materialize
    # artifacts and scalar decisions. Backend eligibility grants no target,
    # verification, XLA or scientific authority. Replay checks this identity
    # against config so historical blocked artifacts cannot silently upgrade.
    policy_blockers = tuple(dict.fromkeys(policy_blockers))
    return {
        "schema": "bayesfilter.hmc_resolved_tuning_policy.v1",
        "runtime_backend_policy": _ORDINARY_RUNTIME_BACKEND_POLICY_ID,
        "interface_name": "tune_hmc_kernel",
        "config_variant": str(config_variant),
        "preset": None if preset is None else str(preset),
        "preset_role": preset_role,
        "algorithm_id": route["algorithm_id"],
        "windowed_mass_algorithm_id": route["windowed_mass_algorithm_id"],
        "route_contract_version": route["route_contract_version"],
        "operational_authority": bool(route["operational_authority"]),
        "artifact_authority": bool(route["artifact_authority"]),
        "scientific_promotion_authority": bool(
            route["scientific_promotion_authority"]
        ),
        "ordinary_selection_policy": dict(ordinary_policy),
        "claim_bearing_artifact_authority": bool(
            route["artifact_authority"] and not policy_blockers
        ),
        "claim_bearing_blockers": policy_blockers,
        # Keep one stable primary blocker for older consumers while exposing
        # every blocker to new authority checks.
        "claim_bearing_blocker": policy_blockers[0] if policy_blockers else None,
        "evidence_role": route["evidence_role"],
        "promotion_role": route["promotion_role"],
        "use_xla": bool(config.use_xla),
        "execution_control_configuration": dict(
            route["execution_control_configuration"]
        ),
    }


def _mass_matrix_private_summary(
    mass_artifact: PrecomputedMassArtifact,
    *,
    mass_hash: str,
    mass_npz_filename: str,
) -> Mapping[str, Any]:
    import tensorflow as tf

    covariance = _float64_tensor(mass_artifact.covariance)
    diagonal = tf.linalg.diag_part(covariance)
    eigenvalues = tf.linalg.eigvalsh(0.5 * (covariance + tf.transpose(covariance)))
    finite = _all_finite(covariance) and _all_finite(eigenvalues)
    positive = finite and bool(tf.reduce_all(eigenvalues > 0.0).numpy())
    if positive:
        condition_number = float((tf.reduce_max(eigenvalues) / tf.reduce_min(eigenvalues)).numpy())
    else:
        condition_number = None
    return {
        "schema": "bayesfilter.hmc_private_mass_matrix_summary.v1",
        "mass_hash": str(mass_hash),
        "mass_npz_filename": str(mass_npz_filename),
        "dimension": int(mass_artifact.dimension),
        "covariance_shape": tuple(int(dim) for dim in covariance.shape),
        "factor_shape": tuple(int(dim) for dim in _float64_tensor(mass_artifact.factor).shape),
        "finite": finite,
        "positive_definite": positive,
        "eigen_min": None if not finite else float(tf.reduce_min(eigenvalues).numpy()),
        "eigen_max": None if not finite else float(tf.reduce_max(eigenvalues).numpy()),
        "condition_number": condition_number,
        "diagonal_min": float(tf.reduce_min(diagonal).numpy()),
        "diagonal_max": float(tf.reduce_max(diagonal).numpy()),
        "diagonal_mean": float(tf.reduce_mean(diagonal).numpy()),
        "covariance_source": mass_artifact.covariance_source,
        "regularization_report": dict(mass_artifact.regularization_report),
        "nonclaims": mass_artifact.nonclaims,
    }


def _write_float64_mass_npz(path: Path, tensors: Mapping[str, Any]) -> None:
    """Write standard little-endian NPY v1.0 members without NumPy runtime.

    Only float64 mass arrays cross this host artifact boundary. TensorFlow
    performs conversion; the standard library packs the already computed
    values. Existing NPZ readers retain position/covariance/factor compatibility.
    """

    import tensorflow as tf

    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_STORED) as archive:
        for name, value in tensors.items():
            tensor = _float64_tensor(value)
            shape = tuple(int(size) for size in tensor.shape)
            header = repr({"descr": "<f8", "fortran_order": False, "shape": shape}).encode("latin1")
            padding = (-(10 + len(header) + 1)) % 64
            header += b" " * padding + b"\n"
            prefix = b"\x93NUMPY\x01\x00" + struct.pack("<H", len(header))
            values = array.array("d", tf.reshape(tensor, (-1,)).numpy().tolist())
            if sys.byteorder != "little":
                values.byteswap()
            archive.writestr(f"{name}.npy", prefix + header + values.tobytes())


def _write_private_mass_matrix_artifact(
    private_dir: Path | None,
    *,
    label: str,
    mass_artifact: PrecomputedMassArtifact,
) -> Mapping[str, Any] | None:
    if private_dir is None:
        return None
    private_dir.mkdir(parents=True, exist_ok=True)
    mass_hash = _mass_artifact_signature(mass_artifact)
    safe_label = "".join(
        char if char.isalnum() or char in {"_", "-"} else "_"
        for char in str(label)
    ).strip("_")
    filename = f"mass_{safe_label}_{mass_hash[:16]}.npz"
    path = private_dir / filename
    _write_float64_mass_npz(path, {
        "position": mass_artifact.position,
        "covariance": mass_artifact.covariance,
        "factor": mass_artifact.factor,
    })
    return _mass_matrix_private_summary(
        mass_artifact,
        mass_hash=mass_hash,
        mass_npz_filename=filename,
    )


def _private_event_hash(event: Mapping[str, Any]) -> str:
    return stable_config_hash({key: value for key, value in event.items() if key != "event_hash"})


def _write_private_tuning_event(
    events_path: Path | None,
    *,
    event_type: str,
    stage: str,
    payload: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    if events_path is None:
        return None
    events_path.parent.mkdir(parents=True, exist_ok=True)
    event = {
        "schema": "bayesfilter.hmc_private_tuning_event.v1",
        "event_type": str(event_type),
        "stage": str(stage),
        "timestamp_utc": _utc_now_isoformat(),
        **dict(payload),
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
    }
    event_hash = _private_event_hash(event)
    event["event_hash"] = event_hash
    with events_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(_json_ready(event), sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    return event


def _private_tuning_public_summary(
    state: Mapping[str, Any],
) -> Mapping[str, Any]:
    return {
        "schema": "bayesfilter.hmc_private_tuning_public_summary.v1",
        "available": bool(state.get("enabled")),
        "private_event_count": int(state.get("event_count", 0)),
        "last_private_event_hash": state.get("last_event_hash"),
        "mass_hash": state.get("last_mass_hash"),
        "candidate_count": int(state.get("candidate_count", 0)),
        "candidate_completed_count": int(state.get("candidate_completed_count", 0)),
        "candidate_pass_count": int(state.get("candidate_pass_count", 0)),
        "candidate_hard_veto_count": int(state.get("candidate_hard_veto_count", 0)),
        "selected_pair_exists": bool(state.get("selected_pair_exists", False)),
        "round_kind": state.get("round_kind"),
        "edge_repair_direction": state.get("edge_repair_direction"),
        "private_paths_publicized": False,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
    }


def _write_public_tuning_progress_if_requested(
    *,
    progress_path: Path | None,
    config: HMCKernelTuningConfig,
    artifact_path: Path | None,
    current_stage: str,
    last_started_stage: str | None,
    last_completed_stage: str | None,
    adapter_signature: str | None,
    target_dimension: int | None,
    last_started_substage: str | None = None,
    last_completed_substage: str | None = None,
    last_started_artifact_stage: str | None = None,
    last_completed_artifact_stage: str | None = None,
    phase7_last_attempt_index: int | None = None,
    phase7_last_budget_payload: Mapping[str, Any] | None = None,
    bootstrap_public_summary: Mapping[str, Any] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> None:
    if progress_path is None:
        return
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": "bayesfilter.hmc_kernel_tuning_progress.v1",
        "preset": config.preset,
        "algorithm_id": config.algorithm_id,
        "operational_budget_policy_id": config.operational_budget_policy_id,
        "route_contract_version": _selection_route_public_payload(
            config,
            output_path_enabled=True,
        )["route_contract_version"],
        "algorithm_route": _selection_route_public_payload(
            config,
            output_path_enabled=True,
        ),
        "current_stage": str(current_stage),
        "last_started_stage": last_started_stage,
        "last_completed_stage": last_completed_stage,
        "last_started_substage": last_started_substage,
        "last_completed_substage": last_completed_substage,
        "last_started_artifact_stage": last_started_artifact_stage,
        "last_completed_artifact_stage": last_completed_artifact_stage,
        "phase7_last_attempt_index": phase7_last_attempt_index,
        "phase7_last_budget_payload": None
        if phase7_last_budget_payload is None
        else dict(phase7_last_budget_payload),
        "bootstrap_public_summary": _bootstrap_public_summary(
            None,
            xla_requested=config.use_xla,
        )
        if bootstrap_public_summary is None
        else dict(bootstrap_public_summary),
        "timestamp_utc": _utc_now_isoformat(),
        "process_id": os.getpid(),
        "output_directory": str(progress_path.parent),
        "artifact_path": None if artifact_path is None else str(artifact_path),
        "progress_artifact_path": str(progress_path),
        "adapter_signature": adapter_signature,
        "target_dimension": None if target_dimension is None else int(target_dimension),
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": HMC_KERNEL_TUNING_PUBLIC_NONCLAIMS,
    }
    if extra is not None:
        payload["extra"] = dict(extra)
    tmp_path = progress_path.with_name(
        f".{progress_path.name}.{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}.tmp"
    )
    with tmp_path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(_json_ready(payload), indent=2, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp_path, progress_path)


def _write_public_tuning_artifact_if_requested(
    result: HMCKernelTuningResult,
    artifact_path: Path | None,
) -> None:
    if artifact_path is None:
        return
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    artifact = _public_tuning_artifact_payload(result)
    artifact_path.write_text(
        json.dumps(_json_ready(artifact), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _public_tuning_artifact_payload(
    result: HMCKernelTuningResult,
) -> Mapping[str, Any]:
    active_repair_triggers = () if result.final_status == "passed" else result.repair_triggers
    historical_repair_triggers = result.repair_triggers if result.final_status == "passed" else ()
    phase7_public_summary = _phase7_public_summary(result.tune_verify_repair_loop)
    phase7_early_closeout = _phase7_early_closeout_public_summary(result)
    resolved_policy = _public_resolved_policy_payload(
        result.config,
        output_path_enabled=True,
        config_variant="ordinary_hmc",
    )
    return {
        "schema": "bayesfilter.hmc_kernel_tuning_public_artifact.v1",
        "algorithm_id": result.config.algorithm_id,
        "resolved_policy": resolved_policy,
        "operational_budget_policy_id": (
            result.config.operational_budget_policy_id
        ),
        "route_contract_version": _selection_route_public_payload(
            result.config,
            output_path_enabled=True,
        )["route_contract_version"],
        "algorithm_route": _selection_route_public_payload(
            result.config,
            output_path_enabled=True,
        ),
        "result_hash": result.artifact_hash,
        "config": result.config.payload(),
        "adapter_signature": result.adapter_signature,
        "target_dimension": result.target_dimension,
        "stage_hashes": {
            "geometry": None if result.geometry is None else result.geometry.artifact_hash,
            "bootstrap": None if result.bootstrap is None else result.bootstrap.artifact_hash,
            "tune_verify_repair_loop": None
            if result.tune_verify_repair_loop is None
            else result.tune_verify_repair_loop.artifact_hash,
        },
        "status": result.final_status,
        "diagnostic_role": result.diagnostic_role,
        "hard_vetoes": result.hard_vetoes,
        "repair_triggers": active_repair_triggers,
        "active_repair_triggers": active_repair_triggers,
        "historical_repair_triggers": historical_repair_triggers,
        "bootstrap_public_summary": _bootstrap_public_summary(
            result.bootstrap,
            xla_requested=result.config.use_xla,
        ),
        "final_kernel_payload": result.final_kernel_payload,
        "final_kernel_hash": result.final_kernel_hash,
        "final_kernel_requires_phase7_pass": True,
        "attempt_count": None
        if result.tune_verify_repair_loop is None
        else len(result.tune_verify_repair_loop.attempts),
        "phase7_public_summary": phase7_public_summary,
        "phase7_early_closeout_public_summary": phase7_early_closeout,
        "failure_diagnostics": result.failure_diagnostics,
        "diagnostic_roles": result.diagnostic_roles,
        "artifact_policy": {
            "posterior_samples_written": False,
            "internal_tuning_controls_exposed": False,
            "private_budget_schedule_exposed": False,
            "mass_window_schedule_exposed": False,
            "candidate_grid_exposed": False,
            "phase7_public_summary_exposed": phase7_public_summary is not None,
            "phase7_early_closeout_public_summary_exposed": (
                phase7_early_closeout is not None
            ),
            "raw_draw_counts_exposed": False,
            "private_state_exposed": False,
            "public_reconstruction_api": False,
        },
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": result.nonclaims,
    }


def _phase7_early_closeout_public_summary(
    result: HMCKernelTuningResult,
) -> Mapping[str, Any] | None:
    payload = result.phase7_early_closeout_public_summary
    if not isinstance(payload, Mapping):
        return None
    allowed_keys = {
        "schema",
        "stage",
        "enabled",
        "timeout_budget_s",
        "reserve_s",
        "elapsed_s",
        "remaining_s",
        "within_closeout_window",
        "deadline_clock_scope",
        "closeout_required_before_phase7_loop",
        "phase7_loop_entered",
        "windowed_mass_runner_called",
        "bootstrap_passed",
        "bootstrap_public_summary",
        "target_dimension",
        "hard_veto",
        "repair_trigger",
        "diagnostic_role",
        "progress_only",
        "public_closeout_artifact_expected",
        "hmc_mechanics_exposed",
        "reports_posterior_convergence",
        "reports_sampler_superiority",
        "reports_default_readiness",
        "reports_external_client_scientific_claim",
        "reports_gpu_or_xla_readiness",
        "nonclaims",
        "staged_timeout",
    }
    return {key: payload[key] for key in allowed_keys if key in payload}


def _phase7_public_summary(
    loop: HMCTuneVerifyRepairLoopResult | None,
) -> Mapping[str, Any] | None:
    if loop is None:
        return None
    last_attempt = loop.attempts[-1] if loop.attempts else None
    last_phase6_summary = (
        None
        if last_attempt is None
        else _frozen_step_trajectory_public_summary(last_attempt.frozen_step_trajectory_stage)
    )
    attempt_summaries = tuple(
        _phase7_attempt_public_summary(attempt) for attempt in loop.attempts
    )
    latest_resume_split_summary = (
        None
        if last_attempt is None
        else _phase7_loop_resume_split_public_summary(loop)
    )
    resolved_policy = _public_resolved_policy_payload(
        loop.config,
        output_path_enabled=False,
        config_variant="ordinary_phase7_loop",
    )
    return {
        "schema": "bayesfilter.hmc_tune_verify_repair_public_summary.v1",
        "algorithm_id": loop.config.algorithm_id,
        "resolved_policy": resolved_policy,
        "operational_budget_policy_id": (
            loop.config.operational_budget_policy_id
        ),
        "route_contract_version": _selection_route_public_payload(loop.config)[
            "route_contract_version"
        ],
        "algorithm_route": _selection_route_public_payload(loop.config),
        "final_status": loop.final_status,
        "diagnostic_role": loop.diagnostic_role,
        "attempt_count": len(loop.attempts),
        "attempt_summaries": attempt_summaries,
        "latest_attempt_index": None if last_attempt is None else last_attempt.attempt_index,
        "latest_attempt_status": None if last_attempt is None else last_attempt.final_status,
        "latest_attempt_diagnostic_role": None
        if last_attempt is None
        else last_attempt.diagnostic_role,
        "latest_attempt_repair_triggers": ()
        if last_attempt is None
        else last_attempt.repair_triggers,
        "latest_phase6_public_summary": last_phase6_summary,
        "latest_resume_split_public_summary": latest_resume_split_summary,
        "terminal_budget_guard": _phase7_terminal_budget_guard_public_summary(
            loop.terminal_budget_guard_payload
        ),
        "repair_triggers": loop.repair_triggers,
        "hard_vetoes": loop.hard_vetoes,
        "candidate_grid_exposed": False,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_terminal_budget_guard_public_summary(
    payload: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    if not isinstance(payload, Mapping):
        return None
    allowed_keys = {
        "schema",
        "classification",
        "previous_verification_acceptance_relation",
        "previous_verification_repair_source",
        "verification_repair_trigger",
        "verification_repair_applied",
        "next_attempt_index",
        "next_attempt_public_budget_class",
        "next_attempt_public_budget_cap",
        "next_attempt_budget_is_public_policy",
        "last_attempt_index",
        "base_max_attempts",
        "configured_max_attempts",
        "remaining_attempt_slots",
        "terminal_phase6_repair_extra_attempt",
        "terminal_phase6_repair_extra_attempt_index",
        "terminal_phase6_repair_extra_attempts",
        "terminal_phase6_repair_extra_attempts_consumed",
        "attempt_index",
        "last_attempt_final_status",
        "last_attempt_diagnostic_role",
        "last_handoff_stage",
        "verification_only_retry_eligible",
        "timeout_budget_s",
        "elapsed_s",
        "remaining_s",
        "reserve_s",
        "estimated_next_candidate_s",
        "estimated_pre_phase6_retry_overhead_s",
        "estimated_pre_phase6_retry_overhead_reserve_multiplier",
        "estimated_minimum_next_attempt_s",
        "deadline_clock_scope",
        "closeout_required_before_next_attempt",
        "previous_verification_budget_results",
        "next_attempt_verification_budget_results",
        "stalled_reason",
        "closeout_required_before_extended_attempt",
        "remaining_attempts_after_next",
        "budget_increases_on_next_attempt",
        "closeout_required_before_identical_verify_only_retry",
        "diagnostic_role",
        "progress_only",
        "hmc_mechanics_exposed",
        "reports_posterior_convergence",
        "reports_sampler_superiority",
        "reports_default_readiness",
        "reports_external_client_scientific_claim",
        "reports_gpu_or_xla_readiness",
        "nonclaims",
    }
    return {key: payload[key] for key in allowed_keys if key in payload}


def _phase7_checkpoint_progress_extra(reference: Mapping[str, Any]) -> Mapping[str, Any]:
    """Return the only checkpoint payload shape allowed in public progress."""

    assert_sequential_rhat_checkpoint_public_reference_safe(reference)
    return {
        "checkpoint_reference": dict(reference),
        "checkpoint_reference_public_safe": True,
        "private_paths_publicized": False,
        "public_summary_contains_paths": False,
        "public_summary_contains_raw_values": False,
        "public_summary_contains_tensor_descriptors": False,
        "public_summary_contains_kernel_payload": False,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "progress_only": True,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_attempt_public_summary(
    attempt: HMCTuneVerifyRepairAttempt,
) -> Mapping[str, Any]:
    """Summarize a Phase 7 attempt without exposing HMC mechanics."""

    operational_work_summary = (
        attempt.fixed_mass_step_stage.payload().get(
            "operational_work_manifest_summary"
        )
        if attempt.fixed_mass_step_stage is not None
        else (
            None
            if attempt.windowed_stage is None
            else attempt.windowed_stage.diagnostics.get(
                "operational_work_manifest_summary"
            )
        )
    )
    if operational_work_summary is not None and attempt.fixed_mass_step_stage is not None:
        operational_work_summary = {
            **dict(operational_work_summary),
            "phase7_cumulative_work_summary": attempt.verification_diagnostics.get(
                "operational_work_reconciliation"
            ),
        }
    return {
        "schema": "bayesfilter.hmc_tune_verify_repair_attempt_public_summary.v1",
        "attempt_index": attempt.attempt_index,
        "final_status": attempt.final_status,
        "diagnostic_role": attempt.diagnostic_role,
        "hard_vetoes": attempt.hard_vetoes,
        "repair_triggers": attempt.repair_triggers,
        "budget_public_summary": _phase7_attempt_budget_public_summary(
            attempt.budget_policy_payload
        ),
        "operational_work_manifest_summary": operational_work_summary,
        "stage_statuses": {
            "windowed_mass": _stage_status_public_summary(attempt.windowed_stage),
            "fixed_mass_step": _stage_status_public_summary(attempt.fixed_mass_step_stage),
            "frozen_step_trajectory": _stage_status_public_summary(
                attempt.frozen_step_trajectory_stage
            ),
            "verification": _phase7_verification_public_summary(attempt),
        },
        "phase6_public_summary": _frozen_step_trajectory_public_summary(
            attempt.frozen_step_trajectory_stage
        ),
        "resume_split_public_summary": _phase7_attempt_resume_split_public_summary(
            attempt
        ),
        "private_handoff_payload_exposed": False,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_loop_resume_split_public_summary(
    loop: HMCTuneVerifyRepairLoopResult,
    *,
    attempt_index: int | None = None,
) -> Mapping[str, Any]:
    attempts = tuple(loop.attempts)
    selected_attempt = (
        attempts[-1]
        if attempt_index is None
        else next(
            (
                attempt
                for attempt in attempts
                if int(attempt.attempt_index) == int(attempt_index)
            ),
            None,
        )
    )
    if selected_attempt is None:
        raise ValueError("Phase 7 resume/split attempt not found")
    loop_public_fields = {
        "loop_artifact_hash": loop.artifact_hash,
        "geometry_artifact_hash": loop.geometry_artifact_hash,
        "bootstrap_artifact_hash": loop.bootstrap_artifact_hash,
        "target_dimension": loop.target_dimension,
    }
    if selected_attempt.handoff_state_payload is None:
        return {
            **_phase7_attempt_resume_split_public_summary(selected_attempt),
            **loop_public_fields,
        }
    try:
        contract = _phase7_private_resume_split_contract(
            loop=loop,
            attempt_index=selected_attempt.attempt_index,
        )
        return _phase7_resume_split_public_summary(contract)
    except ValueError:
        return {
            **_phase7_attempt_resume_split_public_summary(selected_attempt),
            **loop_public_fields,
        }


def _phase7_attempt_resume_split_public_summary(
    attempt: HMCTuneVerifyRepairAttempt,
) -> Mapping[str, Any]:
    """Public-safe resume/split availability without private HMC mechanics."""

    base_payload: dict[str, Any] = {
        "schema": "bayesfilter.phase7_resume_split_public_summary.v1",
        "private_contract_schema": "bayesfilter.phase7_private_resume_split_contract.v1",
        "contract_hash": None,
        "loop_artifact_hash": None,
        "geometry_artifact_hash": None,
        "bootstrap_artifact_hash": None,
        "target_dimension": None,
        "attempt_index": attempt.attempt_index,
        "attempt_final_status": attempt.final_status,
        "attempt_diagnostic_role": attempt.diagnostic_role,
        "handoff_stage": None,
        "private_resume_payload_hash": None,
        "resume_entry_kind": "phase7_repair_handoff",
        "resume_entry_stage": None,
        "private_resume_payload_available": False,
        "private_resume_payload_exposed": False,
        "public_payload_contains_private_paths": False,
        "public_payload_contains_checkpoint_filenames": False,
        "public_payload_contains_hmc_draws_or_positions": False,
        "public_payload_contains_hmc_tuning_mechanics": False,
        "public_payload_contains_log_prob_values": False,
        "checkpoint_kind": None,
        "verifier_entry_manifest": False,
        "final_kernel_handoff": False,
        "actual_target_runtime_executed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }
    handoff_state = attempt.handoff_state_payload
    if not isinstance(handoff_state, Mapping):
        return {
            **base_payload,
            "availability_status": "unavailable",
            "unavailable_reason": "no_private_handoff_before_resume_split",
        }
    handoff_stage = str(handoff_state.get("handoff_stage", ""))
    if handoff_state.get("required_private_handoff_complete") is not True:
        return {
            **base_payload,
            "handoff_stage": handoff_stage or None,
            "availability_status": "unavailable",
            "unavailable_reason": "private_handoff_incomplete",
        }
    try:
        resume_entry_stage = _phase7_resume_split_entry_stage(handoff_state)
    except ValueError:
        return {
            **base_payload,
            "handoff_stage": handoff_stage or None,
            "private_resume_payload_hash": stable_config_hash(handoff_state),
            "availability_status": "unavailable",
            "unavailable_reason": "unsupported_private_handoff_stage",
        }
    return {
        **base_payload,
        "handoff_stage": handoff_stage,
        "private_resume_payload_hash": stable_config_hash(handoff_state),
        "resume_entry_stage": resume_entry_stage,
        "private_resume_payload_available": True,
        "availability_status": "available",
        "unavailable_reason": None,
    }


def _stage_status_public_summary(stage: Any) -> Mapping[str, Any] | None:
    if stage is None:
        return None
    summary = {
        "final_status": getattr(stage, "final_status", None),
        "diagnostic_role": getattr(stage, "diagnostic_role", None),
        "passed": bool(getattr(stage, "passed", False)),
        "hard_vetoes": tuple(getattr(stage, "hard_vetoes", ())),
        "repair_triggers": tuple(getattr(stage, "repair_triggers", ())),
        "artifact_hash": getattr(stage, "artifact_hash", None),
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
    }
    if isinstance(stage, HMCWindowedMassStageResult):
        timeout_closeout = _windowed_mass_public_timeout_closeout_summary(stage)
        if timeout_closeout is not None:
            summary["public_timeout_closeout"] = timeout_closeout
    if isinstance(stage, HMCFixedMassStepStageResult):
        timeout_closeout = _fixed_mass_step_public_timeout_closeout_summary(stage)
        if timeout_closeout is not None:
            summary["public_timeout_closeout"] = timeout_closeout
    return summary


def _windowed_mass_public_timeout_closeout_summary(
    stage: HMCWindowedMassStageResult,
) -> Mapping[str, Any] | None:
    timeout_closeout = stage.diagnostics.get("public_timeout_closeout")
    if not isinstance(timeout_closeout, Mapping):
        return None
    allowed_keys = {
        "schema",
        "stage",
        "attempt_index",
        "enabled",
        "timeout_budget_s",
        "reserve_s",
        "elapsed_s",
        "remaining_s",
        "within_closeout_window",
        "deadline_clock_scope",
        "closeout_required_before_hmc_call",
        "diagnostic_role",
        "hard_veto",
        "repair_trigger",
        "progress_only",
        "public_closeout_artifact_expected",
        "completed_segment_count",
        "planned_segment_count",
        "hmc_mechanics_exposed",
        "reports_posterior_convergence",
        "reports_sampler_superiority",
        "reports_default_readiness",
        "reports_external_client_scientific_claim",
        "reports_gpu_or_xla_readiness",
        "nonclaims",
        "staged_timeout",
    }
    return {key: timeout_closeout[key] for key in allowed_keys if key in timeout_closeout}


def _fixed_mass_step_public_timeout_closeout_summary(
    stage: HMCFixedMassStepStageResult,
) -> Mapping[str, Any] | None:
    timeout_closeout = stage.diagnostics.get("public_timeout_closeout")
    if not isinstance(timeout_closeout, Mapping):
        return None
    allowed_keys = {
        "schema",
        "stage",
        "attempt_index",
        "enabled",
        "timeout_budget_s",
        "reserve_s",
        "elapsed_s",
        "remaining_s",
        "within_closeout_window",
        "deadline_clock_scope",
        "stage_elapsed_s",
        "stage_remaining_s",
        "effective_remaining_s",
        "estimated_next_candidate_s",
        "stage_enlargement_available",
        "completed_candidate_elapsed_count",
        "completed_candidate_elapsed_estimator",
        "completed_candidate_elapsed_recent_window",
        "closeout_required_before_hmc_call",
        "closeout_required_before_next_candidate",
        "diagnostic_role",
        "hard_veto",
        "repair_trigger",
        "budget_incomplete",
        "budget_incomplete_scope",
        "selected_pair_progress_before_closeout",
        "progress_only",
        "public_closeout_artifact_expected",
        "round_index",
        "grid_stage",
        "candidate_index",
        "candidate_count",
        "completed_candidate_count",
        "reason",
        "hmc_mechanics_exposed",
        "reports_posterior_convergence",
        "reports_sampler_superiority",
        "reports_default_readiness",
        "reports_external_client_scientific_claim",
        "reports_gpu_or_xla_readiness",
        "nonclaims",
        "staged_timeout",
    }
    return {key: timeout_closeout[key] for key in allowed_keys if key in timeout_closeout}


def _phase7_attempt_budget_public_summary(
    budget_payload: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    if not isinstance(budget_payload, Mapping):
        return None
    allowed_keys = {
        "target_dimension",
        "attempt_index",
        "budget",
        "serious_policy",
        "public_budget_class",
        "public_budget_cap",
        "public_max_attempts",
        "public_diagnostic_preset",
        "terminal_phase6_repair_extra_attempt",
        "terminal_phase6_repair_extra_attempt_index",
        "terminal_phase6_repair_extra_attempts",
        "terminal_phase6_repair_extra_attempts_consumed",
        "diagnostic_role",
        "internal_policy_only",
        "operational_budget_policy_id",
        "operational_budget_policy_hash",
        "operational_screen_num_results",
        "operational_screen_num_burnin_steps",
        "operational_evidence_extension_checkpoints",
        "operational_exact_l_tune_adaptation_steps",
        "operational_verification_num_results",
        "operational_verification_num_burnin_steps",
    }
    summary = {key: budget_payload[key] for key in allowed_keys if key in budget_payload}
    summary["substage_budget_details_exposed"] = False
    summary["operational_aggregate_counts_public_safe"] = True
    summary["hmc_mechanics_exposed"] = False
    summary["reports_posterior_convergence"] = False
    return summary


def _phase7_verification_public_summary(
    attempt: HMCTuneVerifyRepairAttempt,
) -> Mapping[str, Any]:
    diagnostics = (
        attempt.verification_diagnostics
        if isinstance(attempt.verification_diagnostics, Mapping)
        else {}
    )
    config_payload = (
        attempt.verification_config_payload
        if isinstance(attempt.verification_config_payload, Mapping)
        else {}
    )
    budget_payload = (
        attempt.budget_policy_payload
        if isinstance(attempt.budget_policy_payload, Mapping)
        else {}
    )
    # HMCTuneVerifyRepairAttempt intentionally does not retain the loop config,
    # so the verifier payload must carry the acceptance band used by the final
    # promotion classifier.  The fallback is exposed as a provenance flag rather
    # than silently pretending the payload was complete.
    raw_band = config_payload.get("acceptance_band")
    acceptance_band_from_payload = (
        isinstance(raw_band, Sequence)
        and not isinstance(raw_band, (str, bytes))
        and len(raw_band) == 2
    )
    acceptance_band = (
        tuple(float(item) for item in raw_band)
        if acceptance_band_from_payload
        else (0.55, 0.85)
    )
    relation = _acceptance_relation_to_band(diagnostics.get("acceptance_rate"), acceptance_band)
    sequential_policy = diagnostics.get("sequential_rhat_policy")
    checkpoint_references = tuple(
        diagnostics.get("phase7_checkpoint_references")
        or diagnostics.get("checkpoint_references")
        or ()
    )
    runner_route = diagnostics.get("runner_route_summary")
    route_summary = None
    if isinstance(runner_route, Mapping):
        route_summary = {
            "active_route": runner_route.get("active_route"),
            "single_use_build_count": runner_route.get("single_use_build_count"),
            "fallback_status": runner_route.get("fallback_status"),
            "semantic_source": runner_route.get("semantic_source"),
        }
    summary = {
        "schema": "bayesfilter.hmc_phase7_verification_public_summary.v1",
        "attempt_index": attempt.attempt_index,
        "verification_ran": bool(
            attempt.verification_config_payload is not None
            and not diagnostics.get("not_run")
        ),
        "final_status": attempt.final_status,
        "diagnostic_role": attempt.diagnostic_role,
        "hard_vetoes": attempt.hard_vetoes,
        "repair_triggers": attempt.repair_triggers,
        "verification_policy": config_payload.get(
            "verification_policy",
            "sequential_rhat" if diagnostics.get("sequential_rhat_verification") else None,
        ),
        "sequential_rhat_verification": bool(
            diagnostics.get("sequential_rhat_verification")
        ),
        "rhat_threshold": diagnostics.get("rhat_threshold"),
        "rhat_role": diagnostics.get("rhat_role"),
        "max_finite_rhat": diagnostics.get("max_finite_rhat"),
        "finite_rhat_count": diagnostics.get("finite_rhat_count"),
        "nonfinite_rhat_count": diagnostics.get("nonfinite_rhat_count"),
        "rhat_threshold_role": (
            config_payload.get("rhat_threshold_role")
            or (
                sequential_policy.get("rhat_threshold_role")
                if isinstance(sequential_policy, Mapping)
                else None
            )
        ),
        "rhat_definition": diagnostics.get("rhat_definition"),
        "max_rank_normalized_split_rhat": diagnostics.get(
            "max_rank_normalized_split_rhat"
        ),
        "max_folded_rank_normalized_split_rhat": diagnostics.get(
            "max_folded_rank_normalized_split_rhat"
        ),
        "check_interval": diagnostics.get("check_interval"),
        "max_results": diagnostics.get("max_results")
        or config_payload.get("max_results")
        or budget_payload.get("verification_num_results"),
        "num_burnin_steps": config_payload.get("num_burnin_steps"),
        "chain_count": config_payload.get("chain_count"),
        "all_finite_rhat_at_or_below_threshold": diagnostics.get(
            "all_finite_rhat_at_or_below_threshold"
        ),
        "cap_hit": diagnostics.get("cap_hit"),
        "checkpointing_enabled": bool(
            diagnostics.get("phase7_checkpointing_enabled")
            or diagnostics.get("checkpointing_enabled")
        ),
        "checkpoint_count": int(
            diagnostics.get("phase7_checkpoint_count")
            or diagnostics.get("checkpoint_count")
            or 0
        ),
        "checkpoint_references": checkpoint_references,
        "checkpoint_references_public_safe": bool(
            all(_checkpoint_reference_is_public_safe(reference) for reference in checkpoint_references)
        ),
        "acceptance_relation": relation,
        "acceptance_band_from_payload": acceptance_band_from_payload,
        "acceptance_band_fallback_used": not acceptance_band_from_payload,
        "runtime_finite": diagnostics.get("runtime_finite"),
        "private_acceptance_log_health_passed": _verification_acceptance_log_health_passed(
            diagnostics
        ),
        "draw_values_finite": diagnostics.get("samples_all_finite"),
        "private_target_value_health_passed": _verification_target_value_health_passed(
            diagnostics
        ),
        "runner_route_public_summary": route_summary,
        "public_timeout_closeout": _phase7_pre_windowed_timeout_public_summary(
            diagnostics.get("public_timeout_closeout")
        ),
        "phase7_retry_class": diagnostics.get("phase7_retry_class"),
        "verification_only_retry": bool(
            diagnostics.get("phase7_verification_only_retry")
        ),
        "reused_frozen_kernel_handoff": bool(
            diagnostics.get("phase7_reused_frozen_kernel_handoff")
        ),
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }
    return summary


def _phase7_pre_windowed_timeout_public_summary(
    payload: Any,
) -> Mapping[str, Any] | None:
    if not isinstance(payload, Mapping):
        return None
    allowed_keys = {
        "schema",
        "stage",
        "attempt_index",
        "enabled",
        "timeout_budget_s",
        "reserve_s",
        "elapsed_s",
        "remaining_s",
        "within_closeout_window",
        "deadline_clock_scope",
        "closeout_required_before_windowed_mass_runner_build",
        "diagnostic_role",
        "hard_veto",
        "repair_trigger",
        "progress_only",
        "public_closeout_artifact_expected",
        "windowed_mass_runner_called",
        "target_dimension",
        "public_budget_class",
        "public_budget_cap",
        "budget_is_public_policy",
        "hmc_mechanics_exposed",
        "reports_posterior_convergence",
        "reports_sampler_superiority",
        "reports_default_readiness",
        "reports_external_client_scientific_claim",
        "reports_gpu_or_xla_readiness",
        "nonclaims",
        "staged_timeout",
    }
    return {key: payload[key] for key in allowed_keys if key in payload}


def _checkpoint_reference_is_public_safe(reference: Any) -> bool:
    if not isinstance(reference, Mapping):
        return False
    try:
        assert_sequential_rhat_checkpoint_public_reference_safe(reference)
    except ValueError:
        return False
    return True


def _verification_acceptance_log_health_passed(diagnostics: Mapping[str, Any]) -> bool:
    if "acceptance_log_health_passed" in diagnostics:
        return diagnostics.get("acceptance_log_health_passed") is True
    return diagnostics.get("log_accept_ratio_finite") is True


def _verification_target_value_health_passed(diagnostics: Mapping[str, Any]) -> bool:
    if "target_value_health_passed" in diagnostics:
        return diagnostics.get("target_value_health_passed") is True
    return diagnostics.get("target_log_prob_finite") is True


def _public_tuning_diagnostic_roles() -> Mapping[str, str]:
    return {
        "geometry_initialization": "hard_veto_when_invalid",
        "bootstrap_screen": "promotion_or_repair_or_hard_veto",
        "tune_verify_repair_loop": "promotion_or_repair_or_hard_veto",
        "fresh_fixed_kernel_verification": "kernel_handoff_screen_only",
        "output_artifact": "audit_evidence_only_not_public_reconstruction_api",
    }


def _bootstrap_public_summary(
    bootstrap: HMCBootstrapScreenResult | None,
    *,
    xla_requested: bool,
) -> Mapping[str, Any]:
    """Summarize Phase 3 routing evidence without raw HMC mechanics."""

    if bootstrap is None:
        return {
            "round_count": None,
            "final_status": None,
            "preflight_passed": False,
            "acceptance_promoted_kernel": False,
            "handoff_kernel_source": "not_available",
            "last_round_index": None,
            "last_classification": None,
            "last_diagnostic_role": None,
            "last_acceptance_relation_to_band": None,
            "observed_acceptance_relations": (),
            "oscillatory_acceptance_repair_observed": False,
            "hard_veto_present": False,
            "hard_veto_categories": (),
            "leapfrog_cap_saturation_observed": False,
            "leapfrog_cap_saturation_direction": "none",
            "xla_requested": bool(xla_requested),
            "jit_compile_metadata": "missing",
            "round_timing_available": False,
            "max_round_runtime_s": None,
            "timing_scope": "missing",
            "metadata_limitations": ("bootstrap_not_started",),
        }
    rounds = tuple(bootstrap.rounds)
    last_round = rounds[-1] if rounds else None
    relations = tuple(
        _bootstrap_acceptance_relation(
            round_result.diagnostics.get("mean_acceptance_probability"),
            bootstrap.config.acceptance_band,
        )
        for round_result in rounds
    )
    hard_veto_categories = tuple(
        dict.fromkeys(
            _public_bootstrap_hard_veto_category(veto)
            for round_result in rounds
            for veto in round_result.hard_vetoes
        )
    )
    clamp_directions = tuple(
        str(round_result.clamp_direction)
        for round_result in rounds
        if round_result.leapfrog_clamped and round_result.clamp_direction is not None
    )
    finite_runtimes = tuple(
        runtime
        for runtime in (
            _scalar_or_none(round_result.diagnostics.get("runtime_s"))
            for round_result in rounds
        )
        if runtime is not None and bool(math.isfinite(runtime))
    )
    timing_scopes = tuple(
        str(scope)
        for scope in (
            _bootstrap_round_timing_scope(round_result.diagnostics)
            for round_result in rounds
        )
        if scope is not None
    )
    metadata_limitations: list[str] = []
    jit_states = tuple(
        _bootstrap_round_jit_metadata(round_result.diagnostics)
        for round_result in rounds
    )
    if not jit_states or any(state == "missing" for state in jit_states):
        metadata_limitations.append("jit_compile_metadata_missing")
    if not finite_runtimes:
        metadata_limitations.append("round_runtime_missing")
    if not timing_scopes:
        metadata_limitations.append("timing_scope_missing")
    if any(
        _bootstrap_round_uses_fixture_or_synthetic(round_result.diagnostics)
        for round_result in rounds
    ):
        metadata_limitations.append("fixture_or_synthetic_metadata_present")
    if any(relation == "missing_or_nonfinite" for relation in relations):
        metadata_limitations.append("acceptance_relation_missing_or_nonfinite")
    return {
        "round_count": len(rounds),
        "final_status": bootstrap.final_status,
        "preflight_passed": _bootstrap_preflight_passed(bootstrap),
        "acceptance_promoted_kernel": bool(bootstrap.passed),
        "handoff_kernel_source": "bootstrap_acceptance_selection"
        if bootstrap.passed
        else (
            "geometry_preflight_fallback"
            if _bootstrap_preflight_passed(bootstrap)
            else "not_available"
        ),
        "last_round_index": None if last_round is None else last_round.round_index,
        "last_classification": None if last_round is None else last_round.classification,
        "last_diagnostic_role": None
        if last_round is None
        else last_round.diagnostic_role,
        "last_acceptance_relation_to_band": None
        if last_round is None
        else relations[-1],
        "observed_acceptance_relations": tuple(dict.fromkeys(relations)),
        "oscillatory_acceptance_repair_observed": (
            "below" in relations and "above" in relations
        ),
        "hard_veto_present": bool(hard_veto_categories),
        "hard_veto_categories": hard_veto_categories,
        "leapfrog_cap_saturation_observed": bool(clamp_directions),
        "leapfrog_cap_saturation_direction": _bootstrap_cap_saturation_direction(
            clamp_directions
        ),
        "xla_requested": bool(xla_requested),
        "jit_compile_metadata": _summarize_bootstrap_jit_metadata(jit_states),
        "round_timing_available": bool(finite_runtimes),
        "max_round_runtime_s": None if not finite_runtimes else max(finite_runtimes),
        "timing_scope": _summarize_bootstrap_timing_scope(timing_scopes),
        "metadata_limitations": tuple(dict.fromkeys(metadata_limitations)),
    }






def _bootstrap_cap_saturation_direction(directions: tuple[str, ...]) -> str:
    if not directions:
        return "none"
    unique = tuple(dict.fromkeys(directions))
    if len(unique) == 1 and unique[0] in {"min", "max"}:
        return unique[0]
    if any(direction not in {"min", "max"} for direction in unique):
        return "unknown"
    return "mixed"


def _bootstrap_round_metadata(diagnostics: Mapping[str, Any]) -> Mapping[str, Any]:
    metadata = diagnostics.get("runtime_metadata")
    return metadata if isinstance(metadata, Mapping) else {}


def _bootstrap_round_jit_metadata(diagnostics: Mapping[str, Any]) -> str:
    metadata = _bootstrap_round_metadata(diagnostics)
    value = _bool_or_none(metadata.get("jit_compile"))
    if value is None:
        return "missing"
    return "true" if value else "false"


def _summarize_bootstrap_jit_metadata(states: tuple[str, ...]) -> str:
    if not states or any(state == "missing" for state in states):
        return "missing"
    if all(state == "true" for state in states):
        return "true"
    if all(state == "false" for state in states):
        return "false"
    return "missing"


def _bootstrap_round_timing_scope(diagnostics: Mapping[str, Any]) -> str | None:
    metadata = _bootstrap_round_metadata(diagnostics)
    scope = metadata.get("sample_chain_timing_scope")
    if scope is None:
        return None
    value = str(scope)
    return value if value else None


def _summarize_bootstrap_timing_scope(scopes: tuple[str, ...]) -> str:
    if not scopes:
        return "missing"
    unique = tuple(dict.fromkeys(scopes))
    return unique[0] if len(unique) == 1 else "mixed"


def _bootstrap_round_uses_fixture_or_synthetic(
    diagnostics: Mapping[str, Any],
) -> bool:
    metadata = _bootstrap_round_metadata(diagnostics)
    return _metadata_marks_fixture_or_synthetic(metadata)


def _resolve_tune_verify_loop_target_scope(
    adapter: Any,
    config: HMCTuneVerifyRepairLoopConfig,
) -> str:
    capability = value_score_capability(adapter)
    capability_scope = capability.target_scope
    if config.target_scope is not None:
        target_scope = str(config.target_scope)
        if not target_scope:
            raise ValueError("target_scope must be non-empty when provided")
        if capability_scope is not None and target_scope != capability_scope:
            raise ValueError("value/score target_scope mismatch")
        return target_scope
    if capability_scope is None or not str(capability_scope):
        raise ValueError(
            "Phase 7 requires config.target_scope or an adapter "
            "value_score_capability target_scope"
        )
    return str(capability_scope)




def _phase7_progress_budget_payload(
    budget_policy: _HMCAttemptBudgetPolicy | None,
) -> Mapping[str, Any] | None:
    if budget_policy is None:
        return None
    return {
        "target_dimension": budget_policy.target_dimension,
        "attempt_index": budget_policy.attempt_index,
        "budget": budget_policy.budget,
        "serious_policy": budget_policy.serious_policy,
        "public_budget_class": budget_policy.public_budget_class,
        "public_budget_cap": budget_policy.public_budget_cap,
        "public_max_attempts": budget_policy.public_max_attempts,
        "public_diagnostic_preset": budget_policy.public_diagnostic_preset,
        "geometry_budget_summary": dict(budget_policy.geometry_budget_summary),
        "budget_formula": budget_policy.budget_formula,
        "budget_claim": budget_policy.budget_claim,
        "diagnostic_role": (
            "public_bounded_timeout_diagnostic"
            if budget_policy.public_diagnostic_preset == "diagnostic"
            else (
                "public_bounded_verification_diagnostic_plus"
                if budget_policy.public_diagnostic_preset == "diagnostic_plus"
                else "public_kernel_tuning_budget"
            )
        ),
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
        "internal_policy_only": True,
        "substage_budget_details_exposed": False,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
    }




def _windowed_mass_progress_extra(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    allowed_keys = {
        "stage",
        "attempt_index",
        "started",
        "completed",
        "progress_only",
        "hmc_mechanics_exposed",
        "route_category",
        "algorithm_id",
        "route_contract_version",
        "algorithm_route",
        "elapsed_s",
        "started_perf_counter_s",
        "timing_anchor_role",
        "checkpoint_reference",
        "checkpoint_reference_public_safe",
        "public_timeout_closeout",
        "segment_index",
        "segment_count",
        "segment_active_results",
        "operational_progress",
        "reports_posterior_convergence",
        "reports_sampler_superiority",
        "reports_default_readiness",
        "reports_external_client_scientific_claim",
        "reports_gpu_or_xla_readiness",
        "nonclaims",
    }
    return {key: payload[key] for key in allowed_keys if key in payload}


def _phase7_early_global_timeout_before_loop(
    *,
    config: HMCKernelTuningConfig,
    public_timeout_started_perf_counter_s: float | None,
    bootstrap: HMCBootstrapScreenResult,
    target_dimension: int,
    xla_requested: bool,
) -> Mapping[str, Any] | None:
    if config.staged_timeout_policy is not None and config.staged_timeout_policy.enabled:
        policy = config.staged_timeout_policy
        staged = _staged_timeout_public_state(
            policy=policy,
            stage="phase7_pre_windowed",
            attempt_index=0,
            global_started_perf_counter_s=(
                config.staged_timeout_global_started_perf_counter_s
            ),
            stage_started_perf_counter_s=(
                config.staged_timeout_stage_started_perf_counter_s
            ),
            enlargement_rounds=config.staged_timeout_enlargement_rounds,
        )
        if (
            float(staged["stage_remaining_s"]) > float(policy.reserve_s)
            and float(staged["global_remaining_s"]) > float(policy.reserve_s)
        ):
            return None
        bootstrap_summary = _bootstrap_public_summary(
            bootstrap,
            xla_requested=xla_requested,
        )
        return {
            "schema": "bayesfilter.phase7_early_global_timeout_closeout.v1",
            "stage": "phase7_before_tune_verify_repair_loop",
            "enabled": True,
            "timeout_budget_s": staged["stage_timeout_budget_s"],
            "reserve_s": policy.reserve_s,
            "elapsed_s": staged["stage_elapsed_s"],
            "remaining_s": staged["stage_remaining_s"],
            "within_closeout_window": True,
            "deadline_clock_scope": "staged_timeout_phase7_pre_windowed_stage_local",
            "staged_timeout": {
                **dict(staged),
                "hard_veto": _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO,
                "repair_trigger": _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_REPAIR_TRIGGER,
            },
            "closeout_required_before_phase7_loop": True,
            "phase7_loop_entered": False,
            "windowed_mass_runner_called": False,
            "bootstrap_passed": bool(bootstrap.passed),
            "bootstrap_public_summary": dict(bootstrap_summary),
            "target_dimension": int(target_dimension),
            "hard_veto": _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO,
            "repair_trigger": _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_REPAIR_TRIGGER,
            "diagnostic_role": _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO,
            "progress_only": True,
            "public_closeout_artifact_expected": True,
            "hmc_mechanics_exposed": False,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
            "reports_default_readiness": False,
            "reports_external_client_scientific_claim": False,
            "reports_gpu_or_xla_readiness": False,
            "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
        }
    if config.public_timeout_budget_s is None:
        return None
    if public_timeout_started_perf_counter_s is None:
        return None
    budget = float(config.public_timeout_budget_s)
    reserve = max(0.0, min(_WINDOWED_MASS_PUBLIC_TIMEOUT_RESERVE_S, budget * 0.5))
    now = time.perf_counter()
    elapsed = max(0.0, now - float(public_timeout_started_perf_counter_s))
    remaining = budget - elapsed
    if remaining > reserve:
        return None
    bootstrap_summary = _bootstrap_public_summary(
        bootstrap,
        xla_requested=xla_requested,
    )
    return {
        "schema": "bayesfilter.phase7_early_global_timeout_closeout.v1",
        "stage": "phase7_before_tune_verify_repair_loop",
        "enabled": True,
        "timeout_budget_s": budget,
        "reserve_s": reserve,
        "elapsed_s": elapsed,
        "remaining_s": remaining,
        "within_closeout_window": True,
        "deadline_clock_scope": "public_one_call_global",
        "closeout_required_before_phase7_loop": True,
        "phase7_loop_entered": False,
        "windowed_mass_runner_called": False,
        "bootstrap_passed": bool(bootstrap.passed),
        "bootstrap_public_summary": dict(bootstrap_summary),
        "target_dimension": int(target_dimension),
        "hard_veto": _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO,
        "repair_trigger": _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_REPAIR_TRIGGER,
        "diagnostic_role": _PHASE7_EARLY_GLOBAL_TIMEOUT_BEFORE_LOOP_HARD_VETO,
        "progress_only": True,
        "public_closeout_artifact_expected": True,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }






def _phase7_public_timeout_before_windowed_mass(
    config: HMCWindowedMassStageConfig,
    *,
    attempt_index: int,
    target_dimension: int,
    budget_policy: "_HMCAttemptBudgetPolicy",
) -> Mapping[str, Any] | None:
    closeout = _windowed_mass_public_timeout_preflight(
        config,
        stage="phase7_loop_attempt_before_windowed_mass",
        attempt_index=attempt_index,
    )
    if closeout is None:
        return None
    return {
        **dict(closeout),
        "schema": "bayesfilter.phase7_public_timeout_before_windowed_mass.v1",
        "stage": "phase7_loop_attempt_before_windowed_mass",
        "hard_veto": _PHASE7_PUBLIC_TIMEOUT_BEFORE_WINDOWED_MASS_HARD_VETO,
        "repair_trigger": _PHASE7_PUBLIC_TIMEOUT_BEFORE_WINDOWED_MASS_REPAIR_TRIGGER,
        "diagnostic_role": "phase7_pre_windowed_public_timeout_hard_veto",
        "closeout_required_before_windowed_mass_runner_build": True,
        "windowed_mass_runner_called": False,
        "target_dimension": int(target_dimension),
        "public_budget_class": budget_policy.public_budget_class,
        "public_budget_cap": budget_policy.public_budget_cap,
        "budget_is_public_policy": budget_policy.public_budget_class is not None,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _budget_ladder_progress_extra(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    allowed_keys = {
        "stage",
        "round_index",
        "budget",
        "role",
        "started",
        "completed",
        "route_category",
        "call_config_hash",
        "num_results",
        "num_burnin_steps",
        "substage_budget_details_exposed",
        "uses_dual_averaging",
        "runner_reused",
        "static_contract_hash",
        "elapsed_s",
        "started_perf_counter_s",
        "timing_anchor_role",
        "error_type",
        "incall_work_snapshot",
        "incall_heartbeat",
        "incall_heartbeat_index",
        "incall_heartbeat_sequence_is_not_progress",
        "incall_monitor_error_count",
        "incall_monitor_error_types",
        "incall_monitor_errors_are_explanatory_only",
        "progress_only",
        "hmc_mechanics_exposed",
        "reports_posterior_convergence",
        "reports_sampler_superiority",
        "reports_default_readiness",
        "reports_external_client_scientific_claim",
        "reports_gpu_or_xla_readiness",
        "nonclaims",
    }
    return {key: payload[key] for key in allowed_keys if key in payload}


def _trajectory_candidate_progress_extra(
    *,
    stage: str,
    candidate_index: int,
    candidate_count: int,
    config: FullChainHMCConfig,
    runner_event: Mapping[str, Any] | None,
    completed_candidate_count: int | None = None,
    soft_deadline_payload: Mapping[str, Any] | None = None,
    elapsed_s: float | None = None,
    started_perf_counter_s: float | None = None,
    error_type: str | None = None,
) -> Mapping[str, Any]:
    payload: dict[str, Any] = {
        "stage": str(stage),
        "candidate_index": int(candidate_index),
        "candidate_count": int(candidate_count),
        "completed_candidate_count": (
            int(completed_candidate_count)
            if completed_candidate_count is not None
            else int(candidate_index)
        ),
        "num_results": int(config.num_results),
        "num_burnin_steps": int(config.num_burnin_steps),
        "substage_budget_details_exposed": True,
        "call_config_hash": stable_config_hash(config.signature_payload()),
        "route_category": (
            "injected_runner"
            if config.chain_execution_mode != "tf_function"
            else "reusable_runner"
        ),
        "runner_reused": None
        if runner_event is None
        else bool(runner_event.get("runner_reused", False)),
        "static_contract_hash": None
        if runner_event is None
        else runner_event.get("static_contract_hash"),
        "progress_only": True,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS,
    }
    if elapsed_s is not None:
        payload["elapsed_s"] = float(elapsed_s)
    if started_perf_counter_s is not None:
        payload["started_perf_counter_s"] = float(started_perf_counter_s)
        payload["timing_anchor_role"] = "process_local_monotonic_debug_only"
    if soft_deadline_payload is not None:
        payload["soft_deadline"] = dict(soft_deadline_payload)
    if error_type is not None:
        payload["error_type"] = str(error_type)
    return payload


def _phase6_soft_deadline_state(
    *,
    stage_start_perf_counter_s: float,
    timeout_budget_s: float | None,
    public_timeout_started_perf_counter_s: float | None = None,
    reserve_s: float = _FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RESERVE_S,
) -> Mapping[str, Any]:
    if timeout_budget_s is None:
        return {
            "enabled": False,
            "hmc_mechanics_exposed": False,
            "reports_posterior_convergence": False,
        }
    budget = float(timeout_budget_s)
    reserve = max(0.0, min(float(reserve_s), budget * 0.5))
    now = time.perf_counter()
    stage_elapsed = max(0.0, now - float(stage_start_perf_counter_s))
    anchor = (
        float(stage_start_perf_counter_s)
        if public_timeout_started_perf_counter_s is None
        else float(public_timeout_started_perf_counter_s)
    )
    elapsed = max(0.0, now - anchor)
    remaining = budget - elapsed
    return {
        "enabled": True,
        "timeout_budget_s": budget,
        "reserve_s": reserve,
        "elapsed_s": elapsed,
        "remaining_s": remaining,
        "within_closeout_window": remaining <= reserve,
        "deadline_clock_scope": (
            "phase6_stage_local"
            if public_timeout_started_perf_counter_s is None
            else "public_one_call_global"
        ),
        "stage_elapsed_s": stage_elapsed,
        "stage_remaining_s": budget - stage_elapsed,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
    }


def _phase6_next_candidate_soft_deadline_veto(
    *,
    stage_start_perf_counter_s: float,
    timeout_budget_s: float | None,
    public_timeout_started_perf_counter_s: float | None = None,
    completed_elapsed_s: Sequence[float],
) -> Mapping[str, Any] | None:
    if timeout_budget_s is None:
        return None
    state = dict(
        _phase6_soft_deadline_state(
            stage_start_perf_counter_s=stage_start_perf_counter_s,
            timeout_budget_s=timeout_budget_s,
            public_timeout_started_perf_counter_s=public_timeout_started_perf_counter_s,
        )
    )
    completed = tuple(float(value) for value in completed_elapsed_s)
    if not completed:
        estimated_next_s = _FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RESERVE_S
    else:
        recent_window = max(
            1,
            int(_FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RECENT_WINDOW),
        )
        recent_completed = tuple(completed[-recent_window:])
        estimated_next_s = (
            max(recent_completed)
            * _FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_SAFETY_MULTIPLIER
        )
    closeout_required = bool(
        state["within_closeout_window"]
        or float(state["remaining_s"]) <= estimated_next_s + float(state["reserve_s"])
    )
    if not closeout_required:
        return None
    return {
        **state,
        "estimated_next_candidate_s": float(estimated_next_s),
        "completed_candidate_elapsed_count": len(completed),
        "completed_candidate_elapsed_estimator": "recent_max_times_safety_multiplier",
        "completed_candidate_elapsed_recent_window": min(len(completed), recent_window)
        if completed
        else 0,
        "closeout_required_before_next_candidate": True,
        "diagnostic_role": "public_timeout_closeout_hard_veto",
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
    }


def _fixed_mass_step_public_timeout_state(
    config: HMCFixedMassStepStageConfig,
    *,
    stage_start_perf_counter_s: float,
    attempt_index: int | None,
) -> Mapping[str, Any]:
    staged = _staged_timeout_public_payload_for_config(
        config,
        stage="fixed_mass_step",
        attempt_index=attempt_index,
    )
    if staged is not None:
        return {
            "enabled": True,
            "timeout_budget_s": staged["stage_timeout_budget_s"],
            "reserve_s": config.staged_timeout_policy.reserve_s,
            "elapsed_s": staged["stage_elapsed_s"],
            "remaining_s": staged["stage_remaining_s"],
            "within_closeout_window": staged["cap_hit"],
            "deadline_clock_scope": "staged_timeout_fixed_mass_step_stage_local",
            "stage_elapsed_s": staged["stage_elapsed_s"],
            "stage_remaining_s": staged["stage_remaining_s"],
            "staged_timeout": staged,
            "hmc_mechanics_exposed": False,
            "reports_posterior_convergence": False,
        }
    if config.public_timeout_budget_s is None:
        return {
            "enabled": False,
            "hmc_mechanics_exposed": False,
            "reports_posterior_convergence": False,
        }
    budget = float(config.public_timeout_budget_s)
    reserve = max(0.0, min(_FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RESERVE_S, budget * 0.5))
    now = time.perf_counter()
    stage_elapsed = max(0.0, now - float(stage_start_perf_counter_s))
    anchor = (
        float(stage_start_perf_counter_s)
        if config.public_timeout_started_perf_counter_s is None
        else float(config.public_timeout_started_perf_counter_s)
    )
    elapsed = max(0.0, now - anchor)
    remaining = budget - elapsed
    return {
        "enabled": True,
        "timeout_budget_s": budget,
        "reserve_s": reserve,
        "elapsed_s": elapsed,
        "remaining_s": remaining,
        "within_closeout_window": remaining <= reserve,
        "deadline_clock_scope": (
            "fixed_mass_step_stage_local"
            if config.public_timeout_started_perf_counter_s is None
            else "public_one_call_global"
        ),
        "stage_elapsed_s": stage_elapsed,
        "stage_remaining_s": budget - stage_elapsed,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
    }


def _fixed_mass_step_next_candidate_soft_deadline_veto(
    config: HMCFixedMassStepStageConfig,
    *,
    stage_start_perf_counter_s: float,
    attempt_index: int | None,
    completed_elapsed_s: Sequence[float],
) -> Mapping[str, Any] | None:
    if config.public_timeout_budget_s is None:
        return None
    state = dict(
        _fixed_mass_step_public_timeout_state(
            config,
            stage_start_perf_counter_s=stage_start_perf_counter_s,
            attempt_index=attempt_index,
        )
    )
    completed = tuple(float(value) for value in completed_elapsed_s)
    if not completed:
        estimated_next_s = float(state["reserve_s"])
        estimator = "fallback_reserve"
        recent_window_count = 0
    else:
        recent_window = max(1, int(_FIXED_MASS_STEP_SOFT_DEADLINE_RECENT_WINDOW))
        recent_completed = tuple(completed[-recent_window:])
        estimated_next_s = (
            max(recent_completed)
            * _FIXED_MASS_STEP_SOFT_DEADLINE_SAFETY_MULTIPLIER
        )
        estimator = "recent_max_times_safety_multiplier"
        recent_window_count = min(len(completed), recent_window)
    remaining_values = [float(state["remaining_s"])]
    staged = state.get("staged_timeout")
    if isinstance(staged, Mapping):
        remaining_values.append(float(staged["global_remaining_s"]))
    effective_remaining_s = min(remaining_values)
    stage_enlargement_available = bool(
        isinstance(staged, Mapping)
        and staged.get("repair_loop_available") is True
        and float(staged.get("global_remaining_s", 0.0))
        > float(state["reserve_s"]) + float(estimated_next_s)
    )
    closeout_required = bool(
        state["within_closeout_window"]
        or effective_remaining_s <= float(state["reserve_s"]) + float(estimated_next_s)
    )
    if not closeout_required or stage_enlargement_available:
        return None
    return {
        **state,
        "schema": "bayesfilter.fixed_mass_step_public_timeout_closeout.v1",
        "stage": "fixed_mass_step_joint_l_epsilon_candidate_start",
        "effective_remaining_s": float(effective_remaining_s),
        "estimated_next_candidate_s": float(estimated_next_s),
        "stage_enlargement_available": False,
        "completed_candidate_elapsed_count": len(completed),
        "completed_candidate_elapsed_estimator": estimator,
        "completed_candidate_elapsed_recent_window": recent_window_count,
        "closeout_required_before_hmc_call": True,
        "closeout_required_before_next_candidate": True,
        "diagnostic_role": "public_timeout_closeout_hard_veto",
        "hard_veto": _FIXED_MASS_STEP_PUBLIC_TIMEOUT_HARD_VETO,
        "repair_trigger": _FIXED_MASS_STEP_PUBLIC_TIMEOUT_REPAIR_TRIGGER,
        "progress_only": True,
        "public_closeout_artifact_expected": True,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
    }


def _phase7_verification_acceptance_budget_blocker(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_state: "_HMCPhaseAttemptState | None",
    next_attempt_policy: "_HMCAttemptBudgetPolicy",
) -> Mapping[str, Any] | None:
    if config.public_timeout_budget_s is None or attempt_state is None:
        return None
    # A direct scalar repair also consumes a fresh verification run. It must
    # respect the global closeout guard even though it reuses earlier stages.
    budget_guard_repair_triggers = {
        _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER,
        _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
    }
    if (
        attempt_state.verification_repair_trigger
        not in budget_guard_repair_triggers
        or not attempt_state.verification_repair_applied
    ):
        return None
    relation_is_directional = attempt_state.verification_acceptance_relation in {
        "below_acceptance_band",
        "above_acceptance_band",
    }
    source_is_tau_underreach = (
        attempt_state.verification_repair_source
        == "phase6_frozen_step_trajectory_underreach"
    )
    if not relation_is_directional and not source_is_tau_underreach:
        return None
    budget = float(config.public_timeout_budget_s)
    anchor = (
        time.perf_counter()
        if config.public_timeout_started_perf_counter_s is None
        else float(config.public_timeout_started_perf_counter_s)
    )
    elapsed = max(0.0, time.perf_counter() - anchor)
    remaining = budget - elapsed
    reserve = max(0.0, min(_FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RESERVE_S, budget * 0.5))
    # The next attempt must at least survive the public work before Phase 6 and
    # the first Phase 6 candidate preflight.  Phase 6 uses one reserve as the
    # no-candidate timing estimate; add a public lower-bound reserve for the
    # retry's Phase 4/5 overhead so the outer loop does not spend work whose
    # likely outcome is an immediate Phase 6 timeout closeout.
    estimated_next_candidate_s = reserve
    estimated_pre_phase6_retry_overhead_s = (
        reserve * _PHASE7_VERIFICATION_ACCEPTANCE_RETRY_PRE_PHASE6_MIN_RESERVES
    )
    estimated_minimum_next_attempt_s = (
        estimated_pre_phase6_retry_overhead_s + estimated_next_candidate_s
    )
    closeout_required = remaining <= reserve + estimated_minimum_next_attempt_s
    if not closeout_required:
        return None
    return {
        "schema": "bayesfilter.hmc_phase7_verification_acceptance_budget_blocker.v1",
        "classification": _PHASE7_VERIFICATION_ACCEPTANCE_BUDGET_BLOCKED,
        "previous_verification_acceptance_relation": (
            attempt_state.verification_acceptance_relation
        ),
        "previous_verification_repair_source": attempt_state.verification_repair_source,
        "verification_repair_trigger": attempt_state.verification_repair_trigger,
        "verification_repair_applied": True,
        "next_attempt_index": int(next_attempt_policy.attempt_index),
        "next_attempt_public_budget_class": next_attempt_policy.public_budget_class,
        "next_attempt_public_budget_cap": next_attempt_policy.public_budget_cap,
        "next_attempt_budget_is_public_policy": (
            next_attempt_policy.public_budget_class is not None
        ),
        "timeout_budget_s": budget,
        "elapsed_s": elapsed,
        "remaining_s": remaining,
        "reserve_s": reserve,
        "estimated_next_candidate_s": estimated_next_candidate_s,
        "estimated_pre_phase6_retry_overhead_s": estimated_pre_phase6_retry_overhead_s,
        "estimated_pre_phase6_retry_overhead_reserve_multiplier": (
            _PHASE7_VERIFICATION_ACCEPTANCE_RETRY_PRE_PHASE6_MIN_RESERVES
        ),
        "estimated_minimum_next_attempt_s": estimated_minimum_next_attempt_s,
        "deadline_clock_scope": (
            "phase7_loop_local"
            if config.public_timeout_started_perf_counter_s is None
            else "public_one_call_global"
        ),
        "closeout_required_before_next_attempt": True,
        "diagnostic_role": _PHASE7_VERIFICATION_ACCEPTANCE_BUDGET_BLOCKED,
        "progress_only": True,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_verify_only_budget_saturation_blocker(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_state: "_HMCPhaseAttemptState | None",
    next_attempt_policy: "_HMCAttemptBudgetPolicy",
) -> Mapping[str, Any] | None:
    if attempt_state is None:
        return None
    if not _phase7_should_retry_verification_only(attempt_state):
        return None
    if attempt_state.verification_budget_results is None:
        return None
    previous_budget = int(attempt_state.verification_budget_results)
    next_budget = _phase7_verification_num_results(config, next_attempt_policy)
    attempts_after_next = int(config.max_attempts) - int(next_attempt_policy.attempt_index) - 1
    if next_budget > previous_budget or attempts_after_next > 0:
        return None
    return {
        "schema": "bayesfilter.hmc_phase7_verify_only_budget_saturation_blocker.v1",
        "classification": _PHASE7_VERIFY_ONLY_BUDGET_SATURATED,
        "previous_verification_acceptance_relation": (
            attempt_state.verification_acceptance_relation
        ),
        "previous_verification_repair_source": attempt_state.verification_repair_source,
        "verification_repair_trigger": attempt_state.verification_repair_trigger,
        "verification_repair_applied": False,
        "previous_verification_budget_results": previous_budget,
        "next_attempt_index": int(next_attempt_policy.attempt_index),
        "next_attempt_verification_budget_results": next_budget,
        "remaining_attempts_after_next": attempts_after_next,
        "budget_increases_on_next_attempt": False,
        "next_attempt_public_budget_class": next_attempt_policy.public_budget_class,
        "next_attempt_public_budget_cap": next_attempt_policy.public_budget_cap,
        "next_attempt_budget_is_public_policy": (
            next_attempt_policy.public_budget_class is not None
        ),
        "closeout_required_before_identical_verify_only_retry": True,
        "diagnostic_role": _PHASE7_VERIFY_ONLY_BUDGET_SATURATED,
        "progress_only": True,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_extended_attempt_stall_blocker(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_state: "_HMCPhaseAttemptState | None",
    last_attempt: HMCTuneVerifyRepairAttempt | None,
    next_attempt_policy: "_HMCAttemptBudgetPolicy",
) -> Mapping[str, Any] | None:
    if int(next_attempt_policy.attempt_index) < _PHASE7_BASE_MAX_ATTEMPTS:
        return None
    if int(config.max_attempts) <= _PHASE7_BASE_MAX_ATTEMPTS:
        return None
    if attempt_state is None or last_attempt is None:
        reason = "missing_previous_repair_handoff"
    elif str(last_attempt.final_status) != "repair_or_retry":
        reason = "previous_attempt_not_repair_or_retry"
    elif tuple(last_attempt.hard_vetoes):
        reason = "previous_attempt_hard_veto"
    elif (
        _phase7_should_retry_verification_only(attempt_state)
        and attempt_state.verification_budget_results is not None
        and _phase7_verification_num_results(config, next_attempt_policy)
        > int(attempt_state.verification_budget_results)
    ):
        return None
    elif attempt_state.has_stage_repair_handoff and (
        attempt_state.verification_repair_applied
        or attempt_state.verification_repair_trigger is not None
        or tuple(last_attempt.repair_triggers)
    ):
        return None
    else:
        reason = "previous_attempt_left_no_effective_repair_progress"
    return {
        "schema": "bayesfilter.hmc_phase7_extended_attempt_stall_blocker.v1",
        "classification": _PHASE7_EXTENDED_ATTEMPT_STALLED,
        "base_max_attempts": _PHASE7_BASE_MAX_ATTEMPTS,
        "configured_max_attempts": int(config.max_attempts),
        "next_attempt_index": int(next_attempt_policy.attempt_index),
        "last_attempt_index": None
        if last_attempt is None
        else int(last_attempt.attempt_index),
        "last_attempt_final_status": None
        if last_attempt is None
        else last_attempt.final_status,
        "last_attempt_diagnostic_role": None
        if last_attempt is None
        else last_attempt.diagnostic_role,
        "last_handoff_stage": None
        if attempt_state is None
        else attempt_state.handoff_stage,
        "verification_repair_trigger": None
        if attempt_state is None
        else attempt_state.verification_repair_trigger,
        "verification_repair_applied": False
        if attempt_state is None
        else bool(attempt_state.verification_repair_applied),
        "verification_only_retry_eligible": False
        if attempt_state is None
        else _phase7_should_retry_verification_only(attempt_state),
        "previous_verification_budget_results": None
        if attempt_state is None
        else attempt_state.verification_budget_results,
        "next_attempt_verification_budget_results": _phase7_verification_num_results(
            config,
            next_attempt_policy,
        ),
        "stalled_reason": reason,
        "closeout_required_before_extended_attempt": True,
        "diagnostic_role": _PHASE7_EXTENDED_ATTEMPT_STALLED,
        "progress_only": True,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_repair_handoff_attempt_slot_blocker(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_state: "_HMCPhaseAttemptState | None",
    last_attempt: HMCTuneVerifyRepairAttempt | None,
) -> Mapping[str, Any] | None:
    if attempt_state is None or last_attempt is None:
        return None
    if (
        not attempt_state.verification_repair_applied
        or attempt_state.verification_repair_trigger
        != _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER
    ):
        return None
    remaining_attempt_slots = (
        int(config.max_attempts) - int(last_attempt.attempt_index) - 1
    )
    if remaining_attempt_slots > 0:
        return None
    return {
        "schema": "bayesfilter.hmc_phase7_repair_handoff_budget_exhausted.v1",
        "classification": _PHASE7_REPAIR_HANDOFF_BUDGET_EXHAUSTED,
        "last_attempt_index": int(last_attempt.attempt_index),
        "configured_max_attempts": int(config.max_attempts),
        "remaining_attempt_slots": remaining_attempt_slots,
        "last_attempt_final_status": last_attempt.final_status,
        "last_attempt_diagnostic_role": last_attempt.diagnostic_role,
        "last_handoff_stage": attempt_state.handoff_stage,
        "previous_verification_acceptance_relation": (
            attempt_state.verification_acceptance_relation
        ),
        "previous_verification_repair_source": attempt_state.verification_repair_source,
        "verification_repair_trigger": attempt_state.verification_repair_trigger,
        "verification_repair_applied": True,
        "closeout_required_before_next_attempt": True,
        "diagnostic_role": _PHASE7_REPAIR_HANDOFF_BUDGET_EXHAUSTED,
        "progress_only": False,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_terminal_phase6_repair_slot_eligible(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_state: "_HMCPhaseAttemptState | None",
    last_attempt: HMCTuneVerifyRepairAttempt | None,
    consumed_slots: int,
) -> bool:
    if int(config.terminal_phase6_repair_extra_attempts) <= int(consumed_slots):
        return False
    if attempt_state is None or last_attempt is None:
        return False
    if str(last_attempt.final_status) != "repair_or_retry":
        return False
    if tuple(last_attempt.hard_vetoes):
        return False
    return (
        attempt_state.verification_repair_applied
        and attempt_state.verification_repair_trigger
        == _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER
        and attempt_state.has_stage_repair_handoff
    )


def _phase7_terminal_phase6_repair_slot_payload(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_state: "_HMCPhaseAttemptState | None",
    last_attempt: HMCTuneVerifyRepairAttempt | None,
    attempt_index: int,
    consumed_slots: int,
) -> Mapping[str, Any]:
    return {
        "schema": "bayesfilter.hmc_phase7_terminal_phase6_repair_slot.v1",
        "classification": "terminal_phase6_repair_extra_attempt",
        "terminal_phase6_repair_extra_attempt": True,
        "terminal_phase6_repair_extra_attempt_index": int(consumed_slots) + 1,
        "terminal_phase6_repair_extra_attempts": (
            int(config.terminal_phase6_repair_extra_attempts)
        ),
        "terminal_phase6_repair_extra_attempts_consumed": int(consumed_slots) + 1,
        "attempt_index": int(attempt_index),
        "last_attempt_index": None
        if last_attempt is None
        else int(last_attempt.attempt_index),
        "configured_max_attempts": int(config.max_attempts),
        "verification_repair_trigger": None
        if attempt_state is None
        else attempt_state.verification_repair_trigger,
        "verification_repair_applied": False
        if attempt_state is None
        else bool(attempt_state.verification_repair_applied),
        "last_handoff_stage": None
        if attempt_state is None
        else attempt_state.handoff_stage,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_terminal_phase6_repair_slot_exhausted_payload(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_state: "_HMCPhaseAttemptState | None",
    last_attempt: HMCTuneVerifyRepairAttempt | None,
    consumed_slots: int,
) -> Mapping[str, Any]:
    return {
        "schema": "bayesfilter.hmc_phase7_terminal_phase6_repair_slot_exhausted.v1",
        "classification": _PHASE7_TERMINAL_PHASE6_REPAIR_SLOT_EXHAUSTED,
        "terminal_phase6_repair_extra_attempts": (
            int(config.terminal_phase6_repair_extra_attempts)
        ),
        "terminal_phase6_repair_extra_attempts_consumed": int(consumed_slots),
        "last_attempt_index": None
        if last_attempt is None
        else int(last_attempt.attempt_index),
        "configured_max_attempts": int(config.max_attempts),
        "last_attempt_final_status": None
        if last_attempt is None
        else last_attempt.final_status,
        "last_attempt_diagnostic_role": None
        if last_attempt is None
        else last_attempt.diagnostic_role,
        "last_handoff_stage": None
        if attempt_state is None
        else attempt_state.handoff_stage,
        "previous_verification_acceptance_relation": None
        if attempt_state is None
        else attempt_state.verification_acceptance_relation,
        "previous_verification_repair_source": None
        if attempt_state is None
        else attempt_state.verification_repair_source,
        "verification_repair_trigger": None
        if attempt_state is None
        else attempt_state.verification_repair_trigger,
        "verification_repair_applied": False
        if attempt_state is None
        else bool(attempt_state.verification_repair_applied),
        "closeout_required_before_next_attempt": True,
        "diagnostic_role": _PHASE7_TERMINAL_PHASE6_REPAIR_SLOT_EXHAUSTED,
        "progress_only": False,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_should_retry_verification_only(
    attempt_state: "_HMCPhaseAttemptState | None",
) -> bool:
    # Ordinary tuning does not spend another verification-only attempt chasing
    # an R-hat threshold. Posterior convergence consumers invoke their own
    # explicitly gated verifier and do not enter this Phase 7 loop.
    return False


def _phase7_should_run_operational_repair_verification(
    attempt_state: "_HMCPhaseAttemptState | None",
) -> bool:
    if attempt_state is None or attempt_state.direct_candidate_handoff is None:
        return False
    return (
        attempt_state.direct_candidate_handoff.get("source_kind")
        in {"direct_phase5_candidate", "operational_selection_v2"}
        and attempt_state.has_final_kernel_handoff
        and attempt_state.verification_repair_applied
        and attempt_state.verification_repair_trigger
        == _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER
        and attempt_state.verification_repair_direction
        in {"lower_epsilon", "higher_epsilon"}
        and attempt_state.verification_repair_step_size is not None
        and attempt_state.verification_repair_step_hash is not None
        and attempt_state.repair_verification_reserved
    )


def _phase7_should_prepare_verification_only_retry(
    *,
    attempt_status: str,
    attempt_role: str,
    attempt_hard_vetoes: Sequence[str],
    attempt_repair_triggers: Sequence[str],
    handoff_state: "_HMCPhaseAttemptState | None",
    verification_diagnostics: Mapping[str, Any],
) -> bool:
    """Historical retry hook; ordinary tuning never retries solely for R-hat."""

    return False


def _phase7_verification_result_supports_verification_only_retry(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    verification_diagnostics: Mapping[str, Any],
    verify_status: str,
    verify_role: str,
    verify_hard_vetoes: Sequence[str],
    verify_repair_triggers: Sequence[str],
) -> bool:
    """Historical retry hook; ordinary tuning never retries solely for R-hat."""

    return False


def _emit_phase7_progress(
    callback: LoopProgressCallback | None,
    stage: str,
    *,
    attempt_index: int,
    budget_policy: _HMCAttemptBudgetPolicy | None,
    started: bool = False,
    completed: bool = False,
    extra: Mapping[str, Any] | None = None,
) -> None:
    if callback is None:
        return
    payload: dict[str, Any] = {
        "stage": str(stage),
        "attempt_index": int(attempt_index),
        "started": bool(started),
        "completed": bool(completed),
        "bounded_public_budget_payload": _phase7_progress_budget_payload(
            budget_policy
        ),
        "progress_only": True,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }
    if extra is not None:
        payload["extra"] = dict(extra)
        if (
            extra.get("substage_budget_details_exposed") is True
            and payload["bounded_public_budget_payload"] is not None
        ):
            bounded = dict(payload["bounded_public_budget_payload"])
            bounded["substage_budget_details_exposed"] = True
            payload["bounded_public_budget_payload"] = bounded
    callback(str(stage), payload)


_PHASE7_VERIFIED_BRACKET_LINEAGE_KEYS = (
    "operational_selection_signature",
    "operational_candidate_signature",
    "coordinate_signature",
    "metric_signature",
    "trajectory_signature",
    "start_bank_signature",
    "target_scope",
    "windowed_stage_artifact_hash",
    "adapted_mass_artifact_signature",
    "fixed_mass_step_stage_artifact_hash",
    "verification_hmc_adapter_signature",
)


def _phase7_verified_endpoint_payload(
    *,
    verification_input: _HMCPhase7FixedKernelVerificationInput,
    evidence: HMCAcceptanceEvidence,
) -> Mapping[str, Any]:
    if verification_input.source_kind != "operational_selection_v2":
        raise ValueError("verified endpoint requires operational selection lineage")
    if evidence.evidence_validity != "valid" or evidence.repair_direction not in {
        "lower_epsilon",
        "higher_epsilon",
    }:
        raise ValueError("verified endpoint requires valid directional evidence")
    relation = (
        "low_acceptance"
        if evidence.repair_direction == "lower_epsilon"
        else "high_acceptance"
    )
    payload = {
        "schema": "bayesfilter.hmc_phase7_verified_acceptance_endpoint.v1",
        "relation": relation,
        "step_size": verification_input.step_size,
        "step_hash": verification_input.selected_step_hash,
        "verification_input_hash": verification_input.input_hash,
        "acceptance_evidence_hash": stable_config_hash(evidence.payload()),
        "acceptance_decision": evidence.acceptance_decision,
        **{
            key: getattr(verification_input, key)
            for key in _PHASE7_VERIFIED_BRACKET_LINEAGE_KEYS
        },
        "private_handoff_only": True,
    }
    payload["endpoint_hash"] = stable_config_hash(payload)
    return payload


def _coerce_phase7_verified_endpoint(
    endpoint: Mapping[str, Any] | None,
    *,
    expected_relation: str,
) -> Mapping[str, Any] | None:
    if endpoint is None:
        return None
    if not isinstance(endpoint, Mapping):
        raise ValueError("verified acceptance endpoint must be a mapping")
    result = dict(endpoint)
    observed_hash = str(result.pop("endpoint_hash", ""))
    if result.get("schema") != "bayesfilter.hmc_phase7_verified_acceptance_endpoint.v1":
        raise ValueError("verified acceptance endpoint schema mismatch")
    if result.get("relation") != expected_relation:
        raise ValueError("verified acceptance endpoint relation mismatch")
    step = _phase7_positive_finite_or_none(result.get("step_size"))
    if step is None:
        raise ValueError("verified acceptance endpoint step is invalid")
    result["step_size"] = step
    for key in (
        "step_hash",
        "verification_input_hash",
        "acceptance_evidence_hash",
        "acceptance_decision",
        *_PHASE7_VERIFIED_BRACKET_LINEAGE_KEYS,
    ):
        if not str(result.get(key, "")):
            raise ValueError(f"verified acceptance endpoint lacks {key}")
    expected_decision = (
        "repair_step_lower"
        if expected_relation == "low_acceptance"
        else "repair_step_higher"
    )
    if result["acceptance_decision"] != expected_decision:
        raise ValueError("verified acceptance endpoint decision mismatch")
    if result.get("private_handoff_only") is not True:
        raise ValueError("verified acceptance endpoint must remain private")
    if not observed_hash or observed_hash != stable_config_hash(result):
        raise ValueError("verified acceptance endpoint hash mismatch")
    result["endpoint_hash"] = observed_hash
    return result


def _coerce_phase7_verified_acceptance_bracket_state(
    state: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    if state is None:
        return None
    if not isinstance(state, Mapping):
        raise ValueError("verified_acceptance_bracket_state must be a mapping")
    result = dict(state)
    observed_hash = str(result.pop("state_hash", ""))
    if result.get("schema") != "bayesfilter.hmc_phase7_verified_acceptance_bracket.v1":
        raise ValueError("verified acceptance bracket schema mismatch")
    phase = str(result.get("phase", ""))
    if phase not in {"one_endpoint", "midpoint_pending", "midpoint_consumed"}:
        raise ValueError("verified acceptance bracket phase mismatch")
    high = _coerce_phase7_verified_endpoint(
        result.get("high_acceptance_endpoint"),
        expected_relation="high_acceptance",
    )
    low = _coerce_phase7_verified_endpoint(
        result.get("low_acceptance_endpoint"),
        expected_relation="low_acceptance",
    )
    if high is None and low is None:
        raise ValueError("verified acceptance bracket requires an endpoint")
    if high is not None and low is not None:
        if any(high[key] != low[key] for key in _PHASE7_VERIFIED_BRACKET_LINEAGE_KEYS):
            raise ValueError("verified acceptance bracket lineage drift")
        if float(high["step_size"]) >= float(low["step_size"]):
            raise ValueError("verified acceptance bracket endpoints are inverted")
    midpoint = _phase7_positive_finite_or_none(result.get("midpoint_step_size"))
    midpoint_hash = result.get("midpoint_step_hash")
    midpoint_input_hash = result.get("midpoint_verification_input_hash")
    if phase == "one_endpoint":
        if high is not None and low is not None:
            raise ValueError("one-endpoint bracket cannot contain both endpoints")
        if any(value is not None for value in (midpoint, midpoint_hash, midpoint_input_hash)):
            raise ValueError("one-endpoint bracket cannot carry midpoint state")
    else:
        if high is None or low is None or midpoint is None or not str(midpoint_hash or ""):
            raise ValueError("midpoint bracket state is incomplete")
        if not float(high["step_size"]) < midpoint < float(low["step_size"]):
            raise ValueError("verified midpoint is not strict interior")
        if phase == "midpoint_pending" and midpoint_input_hash is not None:
            raise ValueError("pending midpoint cannot carry a verifier input hash")
        if phase == "midpoint_consumed" and not str(midpoint_input_hash or ""):
            raise ValueError("consumed midpoint requires a verifier input hash")
    result.update(
        {
            "phase": phase,
            "high_acceptance_endpoint": high,
            "low_acceptance_endpoint": low,
            "midpoint_step_size": midpoint,
            "midpoint_step_hash": midpoint_hash,
            "midpoint_verification_input_hash": midpoint_input_hash,
            "private_handoff_only": True,
            "public_progress_exposes_step": False,
        }
    )
    if not observed_hash or observed_hash != stable_config_hash(result):
        raise ValueError("verified acceptance bracket state hash mismatch")
    result["state_hash"] = observed_hash
    return result


def _phase7_verified_acceptance_bracket_payload(
    *,
    high_endpoint: Mapping[str, Any] | None,
    low_endpoint: Mapping[str, Any] | None,
    phase: str,
    midpoint_step_size: float | None = None,
    midpoint_step_hash: str | None = None,
    midpoint_verification_input_hash: str | None = None,
) -> Mapping[str, Any]:
    payload = {
        "schema": "bayesfilter.hmc_phase7_verified_acceptance_bracket.v1",
        "phase": phase,
        "high_acceptance_endpoint": high_endpoint,
        "low_acceptance_endpoint": low_endpoint,
        "midpoint_step_size": midpoint_step_size,
        "midpoint_step_hash": midpoint_step_hash,
        "midpoint_verification_input_hash": midpoint_verification_input_hash,
        "private_handoff_only": True,
        "public_progress_exposes_step": False,
    }
    payload["state_hash"] = stable_config_hash(payload)
    return _coerce_phase7_verified_acceptance_bracket_state(payload)


@dataclass(frozen=True)
class _HMCPhaseAttemptState:
    mass_artifact_payload: Mapping[str, Any] | None = None
    mass_artifact_signature: str | None = None
    canonical_theta_state: Any | None = dataclasses.field(default=None, repr=False)
    private_start_bank_theta: Any | None = dataclasses.field(default=None, repr=False)
    private_start_bank_signature: str | None = None
    selected_step_size: float | None = None
    selected_step_hash: str | None = None
    selected_num_leapfrog_steps: int | None = None
    selected_trajectory_hash: str | None = None
    phase6_retry_num_leapfrog_steps: int | None = None
    phase6_retry_anchor_source: str | None = None
    verification_acceptance_rate: float | None = None
    verification_acceptance_relation: str = "unavailable"
    verification_repair_trigger: str | None = None
    verification_repair_source: str | None = None
    verification_repair_step_size: float | None = None
    verification_repair_step_hash: str | None = None
    verification_repair_applied: bool = False
    verification_repair_max_step_size: float | None = None
    verification_repair_direction: str | None = None
    verification_repair_disposition: str = "not_requested"
    repair_direction_history: tuple[str, ...] = ()
    repaired_step_history: tuple[float, ...] = ()
    repair_verification_reserved: bool = False
    verification_budget_results: int | None = None
    fixed_mass_bracket_state: Mapping[str, Any] | None = None
    verified_acceptance_bracket_state: Mapping[str, Any] | None = None
    handoff_stage: str = "initial"
    direct_candidate_handoff: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        payload = (
            None if self.mass_artifact_payload is None else dict(self.mass_artifact_payload)
        )
        object.__setattr__(self, "mass_artifact_payload", payload)
        mass_signature = (
            None
            if self.mass_artifact_signature is None
            else str(self.mass_artifact_signature)
        )
        object.__setattr__(self, "mass_artifact_signature", mass_signature)
        canonical_theta = None
        if self.canonical_theta_state is not None:
            canonical_tensor = _float64_tensor(self.canonical_theta_state)
            if canonical_tensor.shape.rank != 1 or not _all_finite(canonical_tensor):
                raise ValueError("canonical_theta_state must be one-dimensional and finite")
            canonical_theta = canonical_tensor.numpy()
            canonical_theta.setflags(write=False)
        object.__setattr__(self, "canonical_theta_state", canonical_theta)
        start_bank = None
        if self.private_start_bank_theta is not None:
            bank_tensor = _float64_tensor(self.private_start_bank_theta)
            if (
                bank_tensor.shape.rank != 2
                or bank_tensor.shape[0] != 4
                or not _all_finite(bank_tensor)
            ):
                raise ValueError("private_start_bank_theta must contain four finite rows")
            start_bank = bank_tensor.numpy()
            if canonical_theta is not None and start_bank.shape[1] != canonical_theta.shape[0]:
                raise ValueError("private start bank dimension must match canonical state")
            start_bank.setflags(write=False)
        start_bank_signature = (
            None
            if self.private_start_bank_signature is None
            else str(self.private_start_bank_signature)
        )
        if (start_bank is None) != (start_bank_signature is None):
            raise ValueError("private start bank values/signature must be paired")
        if start_bank_signature is not None and not start_bank_signature:
            raise ValueError("private_start_bank_signature must be non-empty")
        object.__setattr__(self, "private_start_bank_theta", start_bank)
        object.__setattr__(self, "private_start_bank_signature", start_bank_signature)
        step = None if self.selected_step_size is None else float(self.selected_step_size)
        if step is not None and (not math.isfinite(step) or step <= 0.0):
            raise ValueError("attempt handoff selected_step_size must be positive")
        object.__setattr__(self, "selected_step_size", step)
        step_hash = None if self.selected_step_hash is None else str(self.selected_step_hash)
        object.__setattr__(self, "selected_step_hash", step_hash)
        leapfrog = (
            None
            if self.selected_num_leapfrog_steps is None
            else int(self.selected_num_leapfrog_steps)
        )
        if leapfrog is not None and leapfrog <= 0:
            raise ValueError("attempt handoff selected_num_leapfrog_steps must be positive")
        object.__setattr__(self, "selected_num_leapfrog_steps", leapfrog)
        trajectory_hash = (
            None
            if self.selected_trajectory_hash is None
            else str(self.selected_trajectory_hash)
        )
        object.__setattr__(self, "selected_trajectory_hash", trajectory_hash)
        retry_leapfrog = (
            None
            if self.phase6_retry_num_leapfrog_steps is None
            else int(self.phase6_retry_num_leapfrog_steps)
        )
        if retry_leapfrog is not None and retry_leapfrog <= 0:
            raise ValueError("phase6_retry_num_leapfrog_steps must be positive")
        object.__setattr__(self, "phase6_retry_num_leapfrog_steps", retry_leapfrog)
        retry_anchor_source = (
            None
            if self.phase6_retry_anchor_source is None
            else str(self.phase6_retry_anchor_source)
        )
        if retry_anchor_source is not None and not retry_anchor_source:
            raise ValueError("phase6_retry_anchor_source must be non-empty when provided")
        if (retry_leapfrog is None) != (retry_anchor_source is None):
            raise ValueError("phase6 retry anchor L/source must be paired")
        object.__setattr__(self, "phase6_retry_anchor_source", retry_anchor_source)
        direct_handoff = (
            None
            if self.direct_candidate_handoff is None
            else dict(self.direct_candidate_handoff)
        )
        if direct_handoff is not None:
            source_kind = str(direct_handoff.get("source_kind", ""))
            if source_kind == "direct_phase5_candidate":
                required_direct_keys = (
                    "source_kind",
                    "candidate_batch_hash",
                    "candidate_identity",
                    "candidate_record_hash",
                    "verification_input_hash",
                )
            elif source_kind == "operational_selection_v2":
                required_direct_keys = (
                    "source_kind",
                    "operational_selection_signature",
                    "operational_candidate_signature",
                    "coordinate_signature",
                    "metric_signature",
                    "trajectory_signature",
                    "start_bank_signature",
                    "verification_seed_policy",
                    "verification_input_hash",
                )
            else:
                raise ValueError("direct private handoff source kind mismatch")
            if any(not direct_handoff.get(key) for key in required_direct_keys):
                raise ValueError("direct candidate handoff is incomplete")
            if source_kind == "direct_phase5_candidate":
                identity = tuple(direct_handoff["candidate_identity"])
                if len(identity) != 4 or not str(identity[2]):
                    raise ValueError("direct candidate handoff identity is invalid")
                direct_handoff["candidate_identity"] = (
                    int(identity[0]),
                    int(identity[1]),
                    str(identity[2]),
                    int(identity[3]),
                )
            elif any(
                direct_handoff.get(key) is not None
                for key in (
                    "candidate_batch_hash",
                    "candidate_identity",
                    "candidate_record_hash",
                )
            ):
                raise ValueError("operational handoff cannot carry v1 candidate lineage")
            if direct_handoff.get("private_handoff_only") is not True:
                raise ValueError("direct candidate handoff must remain private")
        object.__setattr__(self, "direct_candidate_handoff", direct_handoff)
        stage = str(self.handoff_stage)
        if stage not in {
            "initial",
            "phase4",
            "phase5_repair",
            "phase5_selected",
            "phase6",
            "phase7_direct",
        }:
            raise ValueError("attempt handoff_stage is invalid")
        if (stage == "phase7_direct") != (direct_handoff is not None):
            raise ValueError("phase7_direct stage and direct handoff must be paired")
        if direct_handoff is not None and trajectory_hash is not None:
            raise ValueError("direct candidate handoff forbids a trajectory hash")
        object.__setattr__(self, "handoff_stage", stage)
        acceptance = (
            None
            if self.verification_acceptance_rate is None
            else float(self.verification_acceptance_rate)
        )
        if acceptance is not None and not math.isfinite(acceptance):
            raise ValueError("verification_acceptance_rate must be finite when provided")
        object.__setattr__(self, "verification_acceptance_rate", acceptance)
        relation = str(self.verification_acceptance_relation)
        if relation not in {
            "below_acceptance_band",
            "inside_acceptance_band",
            "above_acceptance_band",
            "unavailable",
        }:
            raise ValueError("verification_acceptance_relation is invalid")
        object.__setattr__(self, "verification_acceptance_relation", relation)
        trigger = (
            None
            if self.verification_repair_trigger is None
            else str(self.verification_repair_trigger)
        )
        if trigger is not None and trigger not in {
            _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
            _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER,
        }:
            raise ValueError("verification_repair_trigger is invalid")
        object.__setattr__(self, "verification_repair_trigger", trigger)
        source = (
            None
            if self.verification_repair_source is None
            else str(self.verification_repair_source)
        )
        if source is not None and not source:
            raise ValueError("verification_repair_source must be non-empty when provided")
        object.__setattr__(self, "verification_repair_source", source)
        repair_step = (
            None
            if self.verification_repair_step_size is None
            else float(self.verification_repair_step_size)
        )
        if repair_step is not None and (not math.isfinite(repair_step) or repair_step <= 0.0):
            raise ValueError("verification_repair_step_size must be positive and finite")
        repair_hash = (
            None
            if self.verification_repair_step_hash is None
            else str(self.verification_repair_step_hash)
        )
        if (repair_step is None) != (repair_hash is None):
            raise ValueError("verification repair step size/hash must be paired")
        object.__setattr__(self, "verification_repair_step_size", repair_step)
        object.__setattr__(self, "verification_repair_step_hash", repair_hash)
        repair_max_step = (
            None
            if self.verification_repair_max_step_size is None
            else float(self.verification_repair_max_step_size)
        )
        if repair_max_step is not None and (
            not math.isfinite(repair_max_step) or repair_max_step <= 0.0
        ):
            raise ValueError("verification_repair_max_step_size must be positive and finite")
        object.__setattr__(self, "verification_repair_max_step_size", repair_max_step)
        repair_direction = (
            None
            if self.verification_repair_direction is None
            else str(self.verification_repair_direction)
        )
        if repair_direction not in {None, "lower_epsilon", "higher_epsilon"}:
            raise ValueError("verification_repair_direction is invalid")
        repair_disposition = str(self.verification_repair_disposition)
        if repair_disposition not in {
            "not_requested",
            "repair_step",
            "inconclusive_conflict",
            "inconclusive_evidence",
            "inconclusive_resonance",
            "inconclusive_stalled_or_oscillating",
            "candidate_data_invalid",
            "shared_invalidity",
        }:
            raise ValueError("verification_repair_disposition is invalid")
        direction_history = tuple(str(item) for item in self.repair_direction_history)
        if any(item not in {"lower_epsilon", "higher_epsilon"} for item in direction_history):
            raise ValueError("repair_direction_history contains an invalid direction")
        step_history = tuple(float(item) for item in self.repaired_step_history)
        if any(not math.isfinite(item) or item <= 0.0 for item in step_history):
            raise ValueError("repaired_step_history must contain positive finite values")
        if len(direction_history) != len(step_history):
            raise ValueError("repair direction and step histories must have equal length")
        repair_reserved = bool(self.repair_verification_reserved)
        object.__setattr__(self, "verification_repair_direction", repair_direction)
        object.__setattr__(self, "verification_repair_disposition", repair_disposition)
        object.__setattr__(self, "repair_direction_history", direction_history)
        object.__setattr__(self, "repaired_step_history", step_history)
        object.__setattr__(self, "repair_verification_reserved", repair_reserved)
        budget_results = (
            None
            if self.verification_budget_results is None
            else int(self.verification_budget_results)
        )
        if budget_results is not None and budget_results <= 0:
            raise ValueError("verification_budget_results must be positive when provided")
        object.__setattr__(self, "verification_budget_results", budget_results)
        bracket_state = _coerce_phase7_fixed_mass_bracket_state(
            self.fixed_mass_bracket_state
        )
        object.__setattr__(self, "fixed_mass_bracket_state", bracket_state)
        verified_bracket = _coerce_phase7_verified_acceptance_bracket_state(
            self.verified_acceptance_bracket_state
        )
        object.__setattr__(
            self,
            "verified_acceptance_bracket_state",
            verified_bracket,
        )
        repair_applied = bool(self.verification_repair_applied)
        if repair_applied and (
            trigger is None
            or (
                relation not in {"below_acceptance_band", "above_acceptance_band"}
                and source
                not in {
                    "phase6_frozen_step_trajectory_underreach",
                    "phase6_frozen_step_trajectory_overreach",
                }
            )
            or repair_step is None
            or repair_hash is None
        ):
            raise ValueError("verification repair handoff is incomplete")
        if repair_applied and repair_direction is not None:
            if (
                not direction_history
                or direction_history[-1] != repair_direction
                or not step_history
                or not _all_close(step_history[-1], repair_step, rtol=1.0e-12, atol=0.0)
            ):
                raise ValueError("applied repair is missing append-only repair history")
        if (
            repair_applied
            and direct_handoff is not None
            and direct_handoff.get("source_kind") == "operational_selection_v2"
            and (repair_direction is None or not repair_reserved)
        ):
            raise ValueError("operational repair requires direction and reserved verification")
        object.__setattr__(self, "verification_repair_applied", repair_applied)

    @property
    def has_mass_handoff(self) -> bool:
        return (
            self.mass_artifact_payload is not None
            and self.mass_artifact_signature is not None
        )

    @property
    def has_step_handoff(self) -> bool:
        return (
            self.has_mass_handoff
            and self.selected_step_size is not None
            and self.selected_step_hash is not None
        )

    @property
    def has_required_repair_handoff(self) -> bool:
        return self.has_stage_repair_handoff

    @property
    def has_stage_repair_handoff(self) -> bool:
        if self.handoff_stage == "phase4":
            return self.has_mass_handoff
        if self.handoff_stage in {"phase5_repair", "phase5_selected"}:
            return self.has_step_handoff
        if self.handoff_stage == "phase7_direct":
            return (
                self.has_step_handoff
                and self.selected_num_leapfrog_steps is not None
                and self.direct_candidate_handoff is not None
                and self.selected_trajectory_hash is None
            )
        if self.handoff_stage != "phase6":
            return False
        return (
            self.mass_artifact_payload is not None
            and self.mass_artifact_signature is not None
            and self.selected_step_size is not None
            and self.selected_step_hash is not None
            and self.selected_num_leapfrog_steps is not None
            and self.selected_trajectory_hash is not None
        )

    @property
    def has_final_kernel_handoff(self) -> bool:
        if self.handoff_stage == "phase7_direct":
            return self.has_stage_repair_handoff
        return (
            self.mass_artifact_payload is not None
            and self.mass_artifact_signature is not None
            and self.selected_step_size is not None
            and self.selected_step_hash is not None
            and self.selected_num_leapfrog_steps is not None
            and self.selected_trajectory_hash is not None
        )

    def payload(self) -> Mapping[str, Any]:
        canonical_theta_signature = (
            None
            if self.canonical_theta_state is None
            else stable_config_hash(
                {
                    "schema": "bayesfilter.hmc_private_canonical_theta.v2",
                    "values": self.canonical_theta_state.tolist(),
                }
            )
        )
        payload = {
            "handoff_stage": self.handoff_stage,
            "mass_artifact_payload": self.mass_artifact_payload,
            "mass_artifact_signature": self.mass_artifact_signature,
            "canonical_theta_state_signature": canonical_theta_signature,
            "canonical_theta_state_available": self.canonical_theta_state is not None,
            "private_start_bank_signature": self.private_start_bank_signature,
            "private_start_bank_available": self.private_start_bank_theta is not None,
            "private_raw_state_values_exposed": False,
            "private_start_bank_values_exposed": False,
            "selected_step_size": self.selected_step_size,
            "selected_step_hash": self.selected_step_hash,
            "selected_num_leapfrog_steps": self.selected_num_leapfrog_steps,
            "selected_trajectory_hash": self.selected_trajectory_hash,
            "phase6_retry_num_leapfrog_steps": self.phase6_retry_num_leapfrog_steps,
            "phase6_retry_anchor_source": self.phase6_retry_anchor_source,
            "verification_acceptance_rate": self.verification_acceptance_rate,
            "verification_acceptance_relation": self.verification_acceptance_relation,
            "verification_repair_trigger": self.verification_repair_trigger,
            "verification_repair_source": self.verification_repair_source,
            "verification_repair_step_size": self.verification_repair_step_size,
            "verification_repair_step_hash": self.verification_repair_step_hash,
            "verification_repair_applied": self.verification_repair_applied,
            "verification_repair_max_step_size": self.verification_repair_max_step_size,
            "verification_repair_direction": self.verification_repair_direction,
            "verification_repair_disposition": self.verification_repair_disposition,
            "repair_direction_history": self.repair_direction_history,
            "repaired_step_history": self.repaired_step_history,
            "repair_verification_reserved": self.repair_verification_reserved,
            "verification_budget_results": self.verification_budget_results,
            "fixed_mass_bracket_state": self.fixed_mass_bracket_state,
            "fixed_mass_bracket_state_available": (
                self.fixed_mass_bracket_state is not None
            ),
            "verified_acceptance_bracket_state": (
                self.verified_acceptance_bracket_state
            ),
            "verified_acceptance_bracket_state_available": (
                self.verified_acceptance_bracket_state is not None
            ),
            "mass_handoff_complete": self.has_mass_handoff,
            "step_handoff_complete": self.has_step_handoff,
            "stage_repair_handoff_complete": self.has_stage_repair_handoff,
            "required_private_handoff_complete": self.has_required_repair_handoff,
            "final_kernel_handoff_complete": self.has_final_kernel_handoff,
        }
        if self.direct_candidate_handoff is not None:
            payload["direct_candidate_handoff"] = self.direct_candidate_handoff
        return payload


def _coerce_phase7_fixed_mass_bracket_state(
    state: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    if state is None:
        return None
    if not isinstance(state, Mapping):
        raise ValueError("fixed_mass_bracket_state must be a mapping")
    step = _phase7_positive_finite_or_none(state.get("next_step_size"))
    if step is None:
        raise ValueError("fixed_mass_bracket_state requires positive next_step_size")
    high_bound = _phase7_positive_finite_or_none(
        state.get("high_acceptance_step_lower_bound")
    )
    low_bound = _phase7_positive_finite_or_none(
        state.get("low_acceptance_step_upper_bound")
    )
    if (
        high_bound is not None
        and low_bound is not None
        and float(high_bound) >= float(low_bound)
    ):
        raise ValueError("fixed_mass_bracket_state requires high bound below low bound")
    result = {
        "schema": str(state.get("schema", "bayesfilter.fixed_mass_bracket_state.v1")),
        "next_step_size": float(step),
        "high_acceptance_step_lower_bound": high_bound,
        "low_acceptance_step_upper_bound": low_bound,
        "bracketed": bool(
            high_bound is not None
            and low_bound is not None
            and float(high_bound) < float(low_bound)
        ),
        "repair_action": state.get("repair_action"),
        "private_handoff_only": True,
        "public_progress_exposes_step": False,
        "reports_posterior_convergence": False,
    }
    if state.get("bracket_role") is not None:
        result["bracket_role"] = state.get("bracket_role")
    return result


def _phase7_positive_finite_or_none(value: Any) -> float | None:
    scalar = _scalar_or_none(value)
    if scalar is None or not math.isfinite(scalar) or scalar <= 0.0:
        return None
    return float(scalar)






def _phase7_direct_candidate_seed_reports(
    *,
    attempts: Sequence[HMCTuneVerifyRepairAttempt],
    root_seed: tuple[int, int],
) -> tuple[Mapping[str, Any], ...]:
    """Preserve private direct seed provenance without changing legacy fields."""

    reports: list[Mapping[str, Any]] = []
    for attempt in attempts:
        diagnostics = attempt.verification_diagnostics
        queue = (
            diagnostics.get("phase7_direct_candidate_queue")
            if isinstance(diagnostics, Mapping)
            else None
        )
        if isinstance(queue, Mapping) and queue.get("seed_map_precomputed") is True:
            candidates = tuple(queue.get("candidate_results", ()))
            seed_map: list[Mapping[str, Any]] = []
            for candidate in candidates:
                if not isinstance(candidate, Mapping):
                    raise ValueError("direct queue seed report candidate must be a mapping")
                identity = tuple(candidate.get("candidate_identity", ()))
                if len(identity) != 4:
                    raise ValueError("direct queue seed report identity is invalid")
                normalized_identity = (
                    int(identity[0]),
                    int(identity[1]),
                    str(identity[2]),
                    int(identity[3]),
                )
                seed = _validate_seed(candidate.get("verification_seed"))
                expected_seed = _phase7_direct_candidate_seed(
                    root_seed,
                    int(attempt.attempt_index),
                    normalized_identity,
                )
                if seed != expected_seed:
                    raise ValueError("direct queue seed report does not match policy")
                seed_map.append(
                    {
                        "candidate_identity": normalized_identity,
                        "verification_seed": seed,
                    }
                )
            if len(seed_map) != int(queue.get("candidate_count", -1)):
                raise ValueError("direct queue seed report count mismatch")
            reports.append(
                {
                    "attempt_index": int(attempt.attempt_index),
                    "route": "direct_phase5_candidate_queue",
                    "candidate_batch_hash": queue.get("candidate_batch_hash"),
                    "plan_hash": queue.get("plan_hash"),
                    "verification_seed_policy": _PHASE7_DIRECT_CANDIDATE_SEED_POLICY,
                    "seed_map_precomputed": True,
                    "candidate_seed_map": tuple(seed_map),
                    "private_handoff_only": True,
                }
            )
            continue

        handoff = attempt.handoff_state_payload
        direct_handoff = (
            handoff.get("direct_candidate_handoff")
            if isinstance(handoff, Mapping)
            else None
        )
        if not isinstance(direct_handoff, Mapping):
            continue
        source_kind = str(direct_handoff.get("source_kind", ""))
        if source_kind == "operational_selection_v2":
            candidate_signature = str(
                direct_handoff.get("operational_candidate_signature", "")
            )
            seed_policy = str(direct_handoff.get("verification_seed_policy", ""))
            domain = (
                "verified_bracket_midpoint"
                if seed_policy
                == _PHASE7_OPERATIONAL_BRACKET_MIDPOINT_SEED_POLICY
                else (
                    "repair_verification"
                    if seed_policy == _PHASE7_OPERATIONAL_REPAIR_SEED_POLICY
                    else (
                        "evidence_extension"
                        if seed_policy
                        == _PHASE7_OPERATIONAL_EVIDENCE_EXTENSION_SEED_POLICY
                        else "independent_final_verification"
                    )
                )
            )
            if seed_policy not in {
                _PHASE7_OPERATIONAL_SELECTION_SEED_POLICY,
                _PHASE7_OPERATIONAL_REPAIR_SEED_POLICY,
                _PHASE7_OPERATIONAL_BRACKET_MIDPOINT_SEED_POLICY,
                _PHASE7_OPERATIONAL_EVIDENCE_EXTENSION_SEED_POLICY,
            } or not candidate_signature:
                raise ValueError("operational seed report lineage is invalid")
            expected_seed = paired_candidate_seed(
                _phase7_attempt_seed(root_seed, int(attempt.attempt_index)),
                candidate_signature=candidate_signature,
                replication_index=0,
                domain=domain,
            )
            seed = _validate_seed(direct_handoff.get("verification_seed"))
            if seed != expected_seed:
                raise ValueError("operational seed report does not match policy")
            reports.append(
                {
                    "attempt_index": int(attempt.attempt_index),
                    "route": (
                        "operational_verified_bracket_midpoint_verification"
                        if domain == "verified_bracket_midpoint"
                        else (
                            "operational_scalar_repair_verification"
                            if domain == "repair_verification"
                            else (
                                "operational_evidence_extension"
                                if domain == "evidence_extension"
                                else "operational_selection_verification"
                            )
                        )
                    ),
                    "operational_selection_signature": direct_handoff.get(
                        "operational_selection_signature"
                    ),
                    "operational_candidate_signature": candidate_signature,
                    "coordinate_signature": direct_handoff.get("coordinate_signature"),
                    "metric_signature": direct_handoff.get("metric_signature"),
                    "trajectory_signature": direct_handoff.get("trajectory_signature"),
                    "start_bank_signature": direct_handoff.get("start_bank_signature"),
                    "verification_seed_policy": seed_policy,
                    "verification_seed_domain": domain,
                    "verification_seed": seed,
                    "private_handoff_only": True,
                }
            )
            continue
        if source_kind != "direct_phase5_candidate":
            raise ValueError("direct retry seed report source kind is invalid")
        identity = tuple(direct_handoff.get("candidate_identity", ()))
        if len(identity) != 4:
            raise ValueError("direct retry seed report identity is invalid")
        normalized_identity = (
            int(identity[0]),
            int(identity[1]),
            str(identity[2]),
            int(identity[3]),
        )
        reports.append(
            {
                "attempt_index": int(attempt.attempt_index),
                "route": "direct_phase5_candidate_verification_only_retry",
                "candidate_batch_hash": direct_handoff.get("candidate_batch_hash"),
                "plan_hash": None,
                "verification_seed_policy": _PHASE7_DIRECT_CANDIDATE_SEED_POLICY,
                "seed_map_precomputed": True,
                "candidate_seed_map": (
                    {
                        "candidate_identity": normalized_identity,
                        "verification_seed": _phase7_direct_candidate_seed(
                            root_seed,
                            int(attempt.attempt_index),
                            normalized_identity,
                        ),
                    },
                ),
                "private_handoff_only": True,
            }
        )
    return tuple(reports)


def _phase7_direct_candidate_seed(
    root_seed: tuple[int, int],
    attempt_index: int,
    candidate_identity: tuple[int, int, str, int],
) -> tuple[int, int]:
    """Fold stable candidate identity into the attempt seed without Python hash()."""

    identity = (
        int(candidate_identity[0]),
        int(candidate_identity[1]),
        str(candidate_identity[2]),
        int(candidate_identity[3]),
    )
    if identity[0] < 0 or not identity[2]:
        raise ValueError("candidate identity is invalid")
    attempt_seed = _phase7_attempt_seed(_validate_seed(root_seed), int(attempt_index))
    digest = stable_config_hash(
        {
            "schema": _PHASE7_DIRECT_CANDIDATE_SEED_POLICY,
            "attempt_seed": attempt_seed,
            "candidate_identity": identity,
        }
    )
    word0 = int(digest[0:8], 16)
    word1 = int(digest[8:16], 16)
    modulus = 2**31 - 1
    seed = (
        (int(attempt_seed[0]) + word0) % modulus,
        (int(attempt_seed[1]) + word1) % modulus,
    )
    return (0, 1) if seed == (0, 0) else seed


def _phase7_direct_candidate_queue_plan(
    *,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_index: int,
) -> _HMCPhase7DirectCandidateQueuePlan:
    """Validate the entire direct queue and its seed map before any draw."""

    handoff = _phase5_candidate_batch_handoff(fixed_mass_step_stage)
    if handoff is None:
        raise ValueError("direct Phase 7 queue requires a Phase 5 candidate batch")
    if handoff.final_status not in {"passed", "repair_or_retry"}:
        raise ValueError("Phase 5 status does not authorize direct verification")
    records_by_ordinal = {
        record.batch_ordinal: record for record in handoff.candidate_records
    }
    identities: list[tuple[int, int, str, int]] = []
    record_hashes: list[str] = []
    seeds: list[tuple[int, int]] = []
    for ordinal in handoff.verification_order_seed:
        record = records_by_ordinal.get(int(ordinal))
        if record is None or not record.handoff_eligible:
            raise ValueError("direct Phase 7 queue contains an invalid eligible reference")
        identity = (
            record.batch_ordinal,
            record.source_round_index,
            record.source_grid_stage,
            record.source_round_candidate_index,
        )
        identities.append(identity)
        record_hashes.append(record.record_hash)
        seeds.append(_phase7_direct_candidate_seed(config.seed, attempt_index, identity))
    if not identities:
        raise ValueError("direct Phase 7 queue has no eligible candidates")
    return _HMCPhase7DirectCandidateQueuePlan(
        phase5_status=handoff.final_status,
        fixed_mass_step_stage_artifact_hash=fixed_mass_step_stage.artifact_hash,
        candidate_batch_hash=handoff.handoff_hash,
        candidate_identities=tuple(identities),
        candidate_record_hashes=tuple(record_hashes),
        verification_seeds=tuple(seeds),
        verification_num_results=_phase7_verification_num_results(
            config,
            budget_policy,
        ),
        verification_num_burnin_steps=_phase7_verification_num_burnin_steps(
            config,
            budget_policy,
        ),
    )


def _phase7_uses_operational_budget_policy(
    config: HMCTuneVerifyRepairLoopConfig,
) -> bool:
    return config.algorithm_id == ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID


def _phase7_verification_num_results(
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
) -> int:
    return int(
        budget_policy.operational_verification_num_results
        if _phase7_uses_operational_budget_policy(config)
        else budget_policy.verification_num_results
    )


def _phase7_verification_num_burnin_steps(
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
) -> int:
    return int(
        budget_policy.operational_verification_num_burnin_steps
        if _phase7_uses_operational_budget_policy(config)
        else budget_policy.verification_num_burnin_steps
    )


def _phase7_operational_work_reconciliation(
    *,
    prior_attempts: Sequence[HMCTuneVerifyRepairAttempt],
    fixed_mass_step_stage: HMCFixedMassStepStageResult | None,
    verification_config_payload: Mapping[str, Any] | None,
    verification_diagnostics: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    """Charge every started verification at its cap against the Phase 5 manifest."""

    if (
        fixed_mass_step_stage is None
        or fixed_mass_step_stage._operational_public_work_manifest is None
    ):
        return None
    public_manifest = validate_public_hmc_work_manifest(
        fixed_mass_step_stage._operational_public_work_manifest
    )
    partial = validate_executed_hmc_work_reconciliation(
        fixed_mass_step_stage.diagnostics.get("executed_work_reconciliation", {}),
        expected_public_manifest_hash=public_manifest["manifest_hash"],
        public_manifest=public_manifest,
    )
    verification_started = (
        verification_config_payload is not None
        and not verification_diagnostics.get("not_run")
    )
    prior_started_count = sum(
        1
        for attempt in prior_attempts
        if attempt.fixed_mass_step_stage is fixed_mass_step_stage
        and attempt.verification_config_payload is not None
        and not attempt.verification_diagnostics.get("not_run")
    )
    start_count = prior_started_count + int(verification_started)
    start_cap = int(public_manifest["fresh_verification_start_count_upper_bound"])
    if start_count > start_cap:
        raise ValueError("operational fresh verification start count exceeded its bound")
    verification_work_per_start = int(public_manifest["fresh_verification_results"]) + int(
        public_manifest["fresh_verification_burnin_steps"]
    )
    executed = dict(partial["executed_work"])
    executed["metric_adaptation_batched_transitions"] = int(
        public_manifest["maximum_work"]["metric_adaptation_batched_transitions"]
    )
    executed["fresh_verification_batched_transitions"] = (
        start_count * verification_work_per_start
    )
    executed["total_batched_transitions"] = sum(
        int(executed.get(key, 0))
        for key in (
            "metric_adaptation_batched_transitions",
            "initial_candidate_batched_transitions",
            "extension_candidate_batched_transitions",
            "exact_l_tune_batched_transitions",
            "fresh_verification_batched_transitions",
        )
    )
    reconciliation = reconcile_executed_hmc_work(
        public_manifest=public_manifest,
        executed_work=executed,
    )
    return {
        "schema": "bayesfilter.hmc_operational_phase7_work_summary.v1",
        "reconciliation": reconciliation,
        "accounting_scope": "metric_adaptation_through_started_fresh_verification",
        "fresh_verification_start_count_charged": start_count,
        "fresh_verification_start_count_upper_bound": start_cap,
        "fresh_verification_accounting_basis": "declared_cap_per_started_verification",
        "fresh_verification_exact_completed_draw_count_claimed": False,
    }


def _phase7_direct_candidate_queue_route(
    *,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    fixed_mass_step_stage_runner: Callable[..., HMCFixedMassStepStageResult],
) -> str:
    """Choose direct Phase 5 or explicit historical compatibility."""

    if fixed_mass_step_stage._operational_selection is not None:
        if fixed_mass_step_stage.diagnostics.get("algorithm") != (
            LEGACY_OPERATIONAL_FIXED_TRAJECTORY_ALGORITHM_ID
        ):
            raise ValueError("operational selection authority/algorithm mismatch")
        return "operational_selection_v2"
    algorithm = fixed_mass_step_stage.diagnostics.get("algorithm")
    is_direct_phase5 = algorithm in _PHASE5_DIRECT_GRID_ALGORITHMS
    handoff = _phase5_candidate_batch_handoff(fixed_mass_step_stage)
    if is_direct_phase5 and fixed_mass_step_stage.final_status in {
        "budget_exhausted",
        "hard_veto",
    }:
        return "direct_phase5_terminal_no_queue"
    if handoff is not None:
        return "direct_phase5_candidate_queue"
    if is_direct_phase5:
        raise ValueError("direct Phase 5 result is missing its candidate batch")
    explicitly_injected = fixed_mass_step_stage_runner is not run_hmc_fixed_mass_step_stage
    historical_fixture = (
        fixed_mass_step_stage.diagnostics.get("historical_phase5_compatibility_fixture")
        is True
    )
    if explicitly_injected and historical_fixture:
        return "historical_phase6_compatibility"
    raise ValueError("Phase 5 route is neither direct selection nor reviewed historical")


def _phase7_direct_candidate_queue_timeout_closeout(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_index: int,
    stage_start_perf_counter_s: float,
    completed_elapsed_s: Sequence[float],
) -> Mapping[str, Any] | None:
    """Apply the existing reserve policy before every direct verifier start."""

    completed = tuple(float(item) for item in completed_elapsed_s)
    estimated_next_s = (
        _FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RESERVE_S
        if not completed
        else max(completed[-_FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_RECENT_WINDOW:])
        * _FROZEN_STEP_TRAJECTORY_SOFT_DEADLINE_SAFETY_MULTIPLIER
    )
    if config.staged_timeout_policy is not None and config.staged_timeout_policy.enabled:
        policy = config.staged_timeout_policy
        state = dict(
            _staged_timeout_public_state(
                policy=policy,
                stage="fresh_fixed_kernel_verification",
                attempt_index=attempt_index,
                global_started_perf_counter_s=(
                    config.staged_timeout_global_started_perf_counter_s
                ),
                stage_started_perf_counter_s=stage_start_perf_counter_s,
                enlargement_rounds=config.staged_timeout_enlargement_rounds,
            )
        )
        reserve_s = float(policy.reserve_s)
        effective_remaining_s = min(
            float(state["stage_remaining_s"]),
            float(state["global_remaining_s"]),
        )
        closeout_required = bool(
            state["cap_hit"]
            or effective_remaining_s <= reserve_s + float(estimated_next_s)
        )
        if not closeout_required:
            return None
        return {
            **state,
            "schema": "bayesfilter.hmc_phase7_direct_queue_timeout_closeout.v1",
            "effective_remaining_s": effective_remaining_s,
            "reserve_s": reserve_s,
            "estimated_next_candidate_s": float(estimated_next_s),
            "completed_candidate_elapsed_count": len(completed),
            "closeout_required_before_next_candidate": True,
            "diagnostic_role": "phase7_direct_queue_timeout_closeout",
            "progress_only": True,
            "public_closeout_artifact_expected": True,
            "hmc_mechanics_exposed": False,
            "reports_posterior_convergence": False,
            "reports_sampler_superiority": False,
            "reports_default_readiness": False,
            "reports_gpu_or_xla_readiness": False,
        }
    if config.public_timeout_budget_s is None:
        return None
    state = dict(
        _phase6_soft_deadline_state(
            stage_start_perf_counter_s=stage_start_perf_counter_s,
            timeout_budget_s=config.public_timeout_budget_s,
            public_timeout_started_perf_counter_s=(
                config.public_timeout_started_perf_counter_s
            ),
        )
    )
    closeout_required = bool(
        state["within_closeout_window"]
        or float(state["remaining_s"])
        <= float(state["reserve_s"]) + float(estimated_next_s)
    )
    if not closeout_required:
        return None
    return {
        **state,
        "schema": "bayesfilter.hmc_phase7_direct_queue_timeout_closeout.v1",
        "estimated_next_candidate_s": float(estimated_next_s),
        "completed_candidate_elapsed_count": len(completed),
        "closeout_required_before_next_candidate": True,
        "diagnostic_role": "phase7_direct_queue_timeout_closeout",
        "progress_only": True,
        "public_closeout_artifact_expected": True,
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
    }


def _phase7_phase5_candidates_not_run_diagnostics(
    *,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    reason: str,
) -> Mapping[str, Any]:
    """Preserve private candidate closeout without treating unrun work as failure."""

    handoff = _phase5_candidate_batch_handoff(fixed_mass_step_stage)
    records = () if handoff is None else handoff.candidate_records
    return {
        "not_run": True,
        "phase7_direct_candidate_queue_active": handoff is not None,
        "phase7_direct_candidate_queue": {
            "schema": "bayesfilter.hmc_phase7_direct_candidate_queue_result.v2",
            "candidate_batch_hash": None if handoff is None else handoff.handoff_hash,
            "candidate_results": tuple(
                {
                    "candidate_identity": (
                        record.batch_ordinal,
                        record.source_round_index,
                        record.source_grid_stage,
                        record.source_round_candidate_index,
                    ),
                    "candidate_record_hash": record.record_hash,
                    "state": "not_run",
                    "started": False,
                    "not_run_reason": str(reason),
                    "private_handoff_only": True,
                }
                for record in records
            ),
            "candidate_count": len(records),
            "repair_directions": (),
            "repair_direction_conflict": False,
            "started_count": 0,
            "not_run_count": len(records),
            "maximum_candidate_starts": _PHASE7_DIRECT_QUEUE_MAX_STARTS,
            "unused_start_quota": _PHASE7_DIRECT_QUEUE_MAX_STARTS,
            "private_handoff_only": True,
        },
        "reports_posterior_convergence": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }






def _phase7_fixed_step_stage_config(
    config: HMCTuneVerifyRepairLoopConfig,
    *,
    attempt_index: int,
) -> HMCFixedMassStepStageConfig:
    return HMCFixedMassStepStageConfig(
        algorithm_id=config.algorithm_id,
        target_accept_prob=config.target_accept_prob,
        acceptance_band=config.acceptance_band,
        repair_band=config.repair_band,
        step_repair_factor=config.step_repair_factor,
        step_repair_min_directional_factor=config.step_repair_min_directional_factor,
        step_repair_high_acceptance_directional_factor=(
            config.step_repair_high_acceptance_directional_factor
        ),
        step_repair_high_acceptance_ladder_max_factor=(
            config.step_repair_high_acceptance_ladder_max_factor
        ),
        repair_nonfinite_proposal_screen=config.repair_nonfinite_proposal_screen,
        trajectory_window_lower_multiplier=config.trajectory_window_lower_multiplier,
        trajectory_window_upper_multiplier=config.trajectory_window_upper_multiplier,
        handoff_screen_policy=config.handoff_screen_policy,
        seed=_derive_seed(_phase7_attempt_seed(config.seed, attempt_index), stage_index=1),
        chain_execution_mode=config.chain_execution_mode,
        use_xla=config.use_xla,
        target_scope=config.target_scope,
        target_status_trace_policy=config.target_status_trace_policy,
        mass_policy=config.mass_policy,
        public_timeout_budget_s=_staged_timeout_stage_budget(
            config.staged_timeout_policy,
            "fixed_mass_step",
            config.public_timeout_budget_s,
        ),
        public_timeout_started_perf_counter_s=None
        if config.staged_timeout_policy is not None
        else config.public_timeout_started_perf_counter_s,
        staged_timeout_policy=config.staged_timeout_policy,
        staged_timeout_global_started_perf_counter_s=(
            config.staged_timeout_global_started_perf_counter_s
        ),
        staged_timeout_stage_started_perf_counter_s=(
            None
            if config.staged_timeout_policy is None
            else time.perf_counter()
        ),
        staged_timeout_enlargement_rounds=config.staged_timeout_enlargement_rounds,
        incall_progress_heartbeat_s=config.incall_progress_heartbeat_s,
        source=config.source,
    )


def _phase7_trajectory_stage_config(
    config: HMCTuneVerifyRepairLoopConfig,
    *,
    attempt_index: int,
) -> HMCFrozenStepTrajectoryStageConfig:
    return HMCFrozenStepTrajectoryStageConfig(
        target_accept_prob=config.target_accept_prob,
        acceptance_band=config.acceptance_band,
        max_leapfrog_steps=config.max_leapfrog_steps,
        trajectory_window_lower_multiplier=config.trajectory_window_lower_multiplier,
        trajectory_window_upper_multiplier=config.trajectory_window_upper_multiplier,
        handoff_screen_policy=config.handoff_screen_policy,
        seed=_derive_seed(_phase7_attempt_seed(config.seed, attempt_index), stage_index=2),
        chain_execution_mode=config.chain_execution_mode,
        use_xla=config.use_xla,
        target_scope=config.target_scope,
        target_status_trace_policy=config.target_status_trace_policy,
        mass_policy=config.mass_policy,
        public_timeout_budget_s=_staged_timeout_stage_budget(
            config.staged_timeout_policy,
            "frozen_step_trajectory",
            config.public_timeout_budget_s,
        ),
        public_timeout_started_perf_counter_s=None
        if config.staged_timeout_policy is not None
        else config.public_timeout_started_perf_counter_s,
        staged_timeout_policy=config.staged_timeout_policy,
        staged_timeout_global_started_perf_counter_s=(
            config.staged_timeout_global_started_perf_counter_s
        ),
        staged_timeout_stage_started_perf_counter_s=(
            None
            if config.staged_timeout_policy is None
            else time.perf_counter()
        ),
        staged_timeout_enlargement_rounds=config.staged_timeout_enlargement_rounds,
        source=config.source,
    )


def _selected_bootstrap_kernel_from_windowed_stage(
    windowed_stage: HMCWindowedMassStageResult,
    *,
    bootstrap: HMCBootstrapScreenResult,
    geometry: HMCGeometryInitializationResult,
) -> Mapping[str, Any]:
    selected = _active_bootstrap_handoff_kernel_payload(
        geometry=geometry,
        bootstrap=bootstrap,
    )
    selected_hash = _active_bootstrap_handoff_kernel_hash(
        geometry=geometry,
        bootstrap=bootstrap,
    )
    if selected_hash != windowed_stage.selected_bootstrap_kernel_hash:
        raise ValueError("Phase 5 selected bootstrap kernel hash mismatch")
    return selected


def _mass_window_seed_kernel_from_windowed_stage(
    windowed_stage: HMCWindowedMassStageResult,
    *,
    bootstrap: HMCBootstrapScreenResult,
    geometry: HMCGeometryInitializationResult,
) -> Mapping[str, Any]:
    _selected_bootstrap_kernel_from_windowed_stage(
        windowed_stage,
        bootstrap=bootstrap,
        geometry=geometry,
    )
    payload = None
    if windowed_stage.diagnostic_run_config_payload is not None:
        payload = windowed_stage.diagnostic_run_config_payload
    if payload is None:
        raise ValueError("Phase 4 result missing diagnostic run config payload")
    step_size = payload.get("step_size")
    leapfrog = payload.get("num_leapfrog_steps")
    if step_size is None or leapfrog is None:
        raise ValueError("Phase 4 diagnostic config missing selected kernel fields")
    return {"step_size": float(step_size), "num_leapfrog_steps": int(leapfrog)}


def _fixed_mass_step_stage_ladder_config(
    config: HMCFixedMassStepStageConfig,
    *,
    initial_step: float,
    num_leapfrog_steps: int,
    target_scope: str,
    attempt_budget_policy: _HMCAttemptBudgetPolicy | None = None,
    attempt_state: _HMCPhaseAttemptState | None = None,
    qualified_step_size_upper_bound: float | None = None,
) -> FixedMassHMCTuningBudgetLadderConfig:
    if attempt_budget_policy is None:
        budget_schedule = _FIXED_MASS_STAGE_TEST_BUDGET_SCHEDULE
        tune_num_results = _FIXED_MASS_STAGE_TUNE_NUM_RESULTS
        screen_num_results = _FIXED_MASS_STAGE_SCREEN_NUM_RESULTS
        screen_num_burnin_steps = _FIXED_MASS_STAGE_SCREEN_BURNIN_STEPS
    else:
        budget_schedule = attempt_budget_policy.phase5_tune_budgets
        tune_num_results = _FIXED_MASS_STAGE_TUNE_NUM_RESULTS
        screen_num_results = attempt_budget_policy.phase5_screen_num_results
        screen_num_burnin_steps = attempt_budget_policy.phase5_screen_burnin_steps
    repair_max_step = (
        None if attempt_state is None else attempt_state.verification_repair_max_step_size
    )
    bracket_state = None if attempt_state is None else attempt_state.fixed_mass_bracket_state
    if qualified_step_size_upper_bound is not None:
        if attempt_state is not None and attempt_state.selected_num_leapfrog_steps != num_leapfrog_steps:
            repair_max_step, bracket_state = None, None
        repair_max_step = (
            qualified_step_size_upper_bound if repair_max_step is None
            else min(repair_max_step, qualified_step_size_upper_bound)
        )
    return FixedMassHMCTuningBudgetLadderConfig(
        budget_schedule=budget_schedule,
        initial_step_size=float(initial_step),
        num_leapfrog_steps=int(num_leapfrog_steps),
        target_accept_prob=config.target_accept_prob,
        acceptance_band=config.acceptance_band,
        repair_band=config.repair_band,
        step_repair_factor=config.step_repair_factor,
        step_repair_min_directional_factor=config.step_repair_min_directional_factor,
        step_repair_high_acceptance_directional_factor=(
            config.step_repair_high_acceptance_directional_factor
        ),
        step_repair_high_acceptance_ladder_max_factor=(
            config.step_repair_high_acceptance_ladder_max_factor
        ),
        repair_nonfinite_proposal_screen=config.repair_nonfinite_proposal_screen,
        step_repair_max_step_size=repair_max_step,
        step_size_upper_bound=qualified_step_size_upper_bound,
        initial_fixed_mass_bracket_state=bracket_state,
        tune_num_results=tune_num_results,
        screen_num_results=screen_num_results,
        screen_num_burnin_steps=screen_num_burnin_steps,
        tune_seed_base=_derive_seed(config.seed, stage_index=0),
        screen_seed_base=_derive_seed(config.seed, stage_index=1),
        chain_execution_mode=config.chain_execution_mode,
        use_xla=config.use_xla,
        target_scope=target_scope,
        target_status_trace_policy=config.target_status_trace_policy,
        public_timeout_budget_s=config.public_timeout_budget_s,
        public_timeout_started_perf_counter_s=(
            config.public_timeout_started_perf_counter_s
        ),
        incall_progress_heartbeat_s=config.incall_progress_heartbeat_s,
        source=config.source,
    )




def _fixed_mass_step_initial_step(
    windowed_stage: HMCWindowedMassStageResult,
    *,
    attempt_state: _HMCPhaseAttemptState | None,
) -> float:
    operational = windowed_stage.operational_warmup_result
    if operational is not None:
        step = operational.final_kernel_state.epsilon
        if step is None or not math.isfinite(step) or step <= 0.0:
            raise ValueError("operational warmup did not produce a current epsilon")
        return float(step)
    if (
        attempt_state is not None
        and attempt_state.verification_repair_applied
        and attempt_state.verification_repair_step_size is not None
    ):
        return float(attempt_state.verification_repair_step_size)
    if attempt_state is not None and attempt_state.selected_step_size is not None:
        return float(attempt_state.selected_step_size)
    if windowed_stage.candidate_step_size is None:
        raise ValueError("fixed-mass step stage requires candidate step size")
    return float(windowed_stage.candidate_step_size)


def _fixed_mass_step_initial_state_factory(
    dimension: int,
) -> Callable[[tuple[int, int], str, int, int, float], Any]:
    dim = int(dimension)
    if dim <= 0:
        raise ValueError("initial state dimension must be positive")

    def factory(
        _seed: tuple[int, int],
        _stage: str,
        _round_index: int,
        _budget: int,
        _step: float,
    ) -> Any:
        import tensorflow as tf

        return tf.zeros(dim, dtype=tf.float64).numpy()

    return factory


def _operational_fixed_mass_initial_state_factory(
    start_bank: Any,
    *,
    expected_signature: str,
    transform_signature: str,
    call_state: dict[str, int] | None = None,
) -> Callable[[tuple[int, int], str, int, int, float], Any]:
    """Return a copy-only factory for the validated P4-E start bank.

    The bank is already in the final fixed-mass latent coordinates.  Each
    ladder receives a distinct array copy, while the content signature is
    checked at the call boundary so a silent zero-state restart cannot pass as
    operational evidence.  Raw bank values never enter a public payload.
    """

    import tensorflow as tf

    bank = _float64_tensor(start_bank)
    if bank.shape.rank != 2 or bank.shape[0] != 4 or bank.shape[1] <= 0:
        raise ValueError("operational start bank must have shape (4, dimension)")
    if not _all_finite(bank):
        raise ValueError("operational start bank must be finite")
    expected = str(expected_signature)
    transform = str(transform_signature)
    if not expected or not transform:
        raise ValueError("operational start-bank signatures must be non-empty")
    frozen = tf.identity(bank)
    state = call_state if call_state is not None else {"call_count": 0}

    def factory(
        _seed: tuple[int, int],
        _stage: str,
        _round_index: int,
        _budget: int,
        _step: float,
    ) -> Any:
        candidate = tf.identity(frozen).numpy()
        observed = private_start_bank_content_signature(candidate, transform)
        if observed != expected:
            raise ValueError("operational start-bank signature changed")
        state["call_count"] = int(state.get("call_count", 0)) + 1
        return candidate

    return factory


def _joint_l_epsilon_anchor_l(
    *,
    selected_kernel: Mapping[str, Any],
    attempt_state: "_HMCPhaseAttemptState | None",
    final_step_size: float | None = None,
    target_trajectory_length: float | None = None,
    max_leapfrog_steps: int = _GEOMETRY_MAX_LEAPFROG,
) -> int:
    if attempt_state is not None:
        for value in (
            attempt_state.phase6_retry_num_leapfrog_steps,
            attempt_state.selected_num_leapfrog_steps,
        ):
            if value is not None:
                anchor = int(value)
                if anchor > 0:
                    return anchor
    if final_step_size is not None or target_trajectory_length is not None:
        step = float(final_step_size) if final_step_size is not None else float("nan")
        target = (
            float(target_trajectory_length)
            if target_trajectory_length is not None
            else float("nan")
        )
        if not math.isfinite(step) or step <= 0.0:
            raise ValueError("final adapted step size must be finite and positive")
        if not math.isfinite(target) or target <= 0.0:
            raise ValueError("target trajectory length must be finite and positive")
        return int(
            min(_validate_max_leapfrog_steps(max_leapfrog_steps),
                max(_GEOMETRY_MIN_LEAPFROG, math.ceil(target / step)))
        )
    anchor = int(selected_kernel["num_leapfrog_steps"])
    if anchor <= 0:
        raise ValueError("joint L/epsilon grid anchor L must be positive")
    return anchor


def _joint_l_epsilon_grid_values(
    *,
    anchor_l: int,
    max_leapfrog_steps: int,
    offsets: Sequence[int],
) -> tuple[int, ...]:
    anchor = int(anchor_l)
    if anchor <= 0:
        raise ValueError("joint L/epsilon grid anchor must be positive")
    max_l = _validate_max_leapfrog_steps(max_leapfrog_steps)
    values = [
        min(max_l, max(_GEOMETRY_MIN_LEAPFROG, anchor + int(offset)))
        for offset in offsets
    ]
    values.append(min(max_l, max(_GEOMETRY_MIN_LEAPFROG, anchor)))
    return tuple(sorted(dict.fromkeys(values)))


def _joint_l_epsilon_ladder_config(
    config: HMCFixedMassStepStageConfig,
    *,
    initial_step: float,
    num_leapfrog_steps: int,
    target_scope: str,
    seed_offset: int,
    attempt_budget_policy: "_HMCAttemptBudgetPolicy | None" = None,
    attempt_state: "_HMCPhaseAttemptState | None" = None,
    qualified_step_size_upper_bound: float | None = None,
) -> FixedMassHMCTuningBudgetLadderConfig:
    ladder_config = _fixed_mass_step_stage_ladder_config(
        config,
        initial_step=initial_step,
        num_leapfrog_steps=int(num_leapfrog_steps),
        target_scope=target_scope,
        attempt_budget_policy=attempt_budget_policy,
        attempt_state=attempt_state,
        qualified_step_size_upper_bound=qualified_step_size_upper_bound,
    )
    return dataclasses.replace(
        ladder_config,
        require_finite_trajectory_bracket=(
            config.algorithm_id == ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID
        ),
        initial_fixed_mass_bracket_state=(
            None if config.algorithm_id == ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID
            else ladder_config.initial_fixed_mass_bracket_state
        ),
        repair_nonfinite_proposal_screen=(
            False if config.algorithm_id == ORDINARY_BROAD_FIXED_METRIC_ALGORITHM_ID
            else ladder_config.repair_nonfinite_proposal_screen
        ),
        tune_seed_base=_round_seed(ladder_config.tune_seed_base, int(seed_offset)),
        screen_seed_base=_round_seed(ladder_config.screen_seed_base, int(seed_offset)),
    )


def _joint_l_epsilon_ladder_candidate_payload(
    *,
    round_index: int,
    grid_stage: str,
    candidate_index: int,
    num_leapfrog_steps: int,
    ladder: FixedMassHMCTuningBudgetLadderResult,
    target_trajectory: float,
    target_accept_prob: float,
    trajectory_window_lower_multiplier: float,
    trajectory_window_upper_multiplier: float,
    max_leapfrog_steps: int,
    handoff_screen_policy: str = _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE,
) -> Mapping[str, Any]:
    policy = _validate_handoff_screen_policy(handoff_screen_policy)
    phase23_policy = _phase23_nomination_policy_active(policy)
    selected = ladder.selected_round
    selected_step = None if selected is None else selected.tuned_step_size
    acceptance = None
    selected_budget = None
    if selected is not None:
        acceptance = _scalar_or_none(selected.screen_diagnostics.get("acceptance_rate"))
        selected_budget = int(selected.budget)
    trajectory = (
        None
        if selected_step is None
        else float(selected_step) * int(num_leapfrog_steps)
    )
    candidate_hard_vetoes = _collect_ladder_hard_vetoes_for_joint_grid(ladder)
    candidate_continuation_vetoes = (
        _collect_ladder_continuation_vetoes_for_joint_grid(ladder)
    )
    repair_triggers = list(_collect_ladder_repair_triggers_for_joint_grid(ladder))
    trajectory_window = None
    trajectory_relation = "unavailable"
    trajectory_ratio = None
    minimum_step_size_for_tau_floor = None
    required_leapfrog_for_tau_floor = None
    tau_floor_feasible_at_step = None
    if selected_step is not None and math.isfinite(float(selected_step)) and float(selected_step) > 0.0:
        trajectory_window = _trajectory_window_payload(
            step_size=float(selected_step),
            num_leapfrog_steps=int(num_leapfrog_steps),
            target_trajectory_length=float(target_trajectory),
            lower_multiplier=float(trajectory_window_lower_multiplier),
            upper_multiplier=float(trajectory_window_upper_multiplier),
            max_leapfrog_steps=int(max_leapfrog_steps),
        )
        trajectory_relation = str(trajectory_window["trajectory_window_relation"])
        trajectory_ratio = trajectory_window["trajectory_target_ratio"]
        minimum_step_size_for_tau_floor = trajectory_window[
            "minimum_step_size_for_tau_floor"
        ]
        required_leapfrog_for_tau_floor = trajectory_window[
            "required_leapfrog_for_tau_floor"
        ]
        tau_floor_feasible_at_step = trajectory_window["tau_floor_feasible_at_step"]
        if trajectory_relation != "inside_trajectory_window":
            repair_triggers.append("trajectory_length_outside_window")
            if trajectory_relation == "below_trajectory_window":
                repair_triggers.append("trajectory_length_below_window")
            elif trajectory_relation == "above_trajectory_window":
                repair_triggers.append("trajectory_length_above_window")
            elif trajectory_relation == "invalid_trajectory_length":
                repair_triggers.append("trajectory_length_invalid")
    elif selected_step is not None:
        trajectory_relation = "invalid_trajectory_length"
        repair_triggers.append("trajectory_length_invalid")
    candidate_repair_triggers = tuple(dict.fromkeys(str(item) for item in repair_triggers))
    trajectory_inside_window = trajectory_relation == "inside_trajectory_window"
    historical_viable = bool(
        ladder.passed
        and selected_step is not None
        and acceptance is not None
        and not candidate_hard_vetoes
        and not candidate_continuation_vetoes
        and trajectory_inside_window
    )
    selected_step_finite = _finite_number(selected_step)
    acceptance_finite = _finite_number(acceptance)
    artifact_hash_available = bool(str(ladder.artifact_hash))
    trajectory_relation_allowed = trajectory_relation in {
        "inside_trajectory_window",
        "below_trajectory_window",
        "above_trajectory_window",
    }
    nomination_eligible = bool(
        phase23_policy
        and ladder.passed
        and selected_step_finite
        and acceptance_finite
        and not candidate_hard_vetoes
        and not candidate_continuation_vetoes
        and trajectory_relation_allowed
        and artifact_hash_available
    )
    return {
        "schema": "bayesfilter.hmc_joint_l_epsilon_candidate.v1",
        "round_index": int(round_index),
        "grid_stage": str(grid_stage),
        "candidate_index": int(candidate_index),
        "num_leapfrog_steps": int(num_leapfrog_steps),
        "handoff_screen_policy": policy,
        "ladder_final_status": ladder.final_status,
        "ladder_passed": bool(ladder.passed),
        "selected_round_index": ladder.selected_round_index,
        "selected_budget": selected_budget,
        "selected_step_size": selected_step,
        "screen_acceptance_rate": acceptance,
        "trajectory_length": trajectory,
        "target_trajectory_length": float(target_trajectory),
        "target_trajectory_distance": None
        if trajectory is None
        else abs(float(trajectory) - float(target_trajectory)),
        "trajectory_window": None
        if trajectory_window is None
        else trajectory_window["trajectory_window"],
        "trajectory_window_lower_multiplier": float(trajectory_window_lower_multiplier),
        "trajectory_window_upper_multiplier": float(trajectory_window_upper_multiplier),
        "trajectory_window_relation": trajectory_relation,
        "trajectory_window_policy_role": _TRAJECTORY_WINDOW_POLICY_ROLE,
        "trajectory_window_viability_gate_active": not phase23_policy,
        "trajectory_window_nomination_only": phase23_policy,
        "trajectory_target_ratio": trajectory_ratio,
        "minimum_step_size_for_tau_floor": minimum_step_size_for_tau_floor,
        "required_leapfrog_for_tau_floor": required_leapfrog_for_tau_floor,
        "tau_floor_feasible_at_step": tau_floor_feasible_at_step,
        "acceptance_distance_to_target": None
        if acceptance is None
        else abs(float(acceptance) - float(target_accept_prob)),
        "hard_vetoes": candidate_hard_vetoes,
        "continuation_vetoes": candidate_continuation_vetoes,
        "repair_triggers": candidate_repair_triggers,
        "viable": historical_viable,
        "nomination_eligible": nomination_eligible,
        "nomination_role": (
            "phase23_candidate_for_phase7_verification"
            if nomination_eligible
            else (
                "historical_viability_gate"
                if not phase23_policy
                else "phase23_not_eligible_for_nomination"
            )
        ),
        "ladder_artifact_hash": ladder.artifact_hash,
        "ladder_payload": ladder.payload(),
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
    }


def _joint_l_epsilon_ladder_private_diagnostic_summary(
    ladder: FixedMassHMCTuningBudgetLadderResult,
) -> Mapping[str, Any]:
    """Summarize the last fixed-mass ladder round for private diagnostics only."""

    if not ladder.rounds:
        return {
            "available": False,
            "reason": "ladder_has_no_rounds",
            "private_hmc_mechanics": True,
            "reports_posterior_convergence": False,
        }
    last_round = ladder.rounds[-1]
    tune = dict(last_round.tune_diagnostics)
    screen = dict(last_round.screen_diagnostics)
    return {
        "available": True,
        "round_index": int(last_round.round_index),
        "classification": last_round.classification,
        "diagnostic_role": last_round.diagnostic_role,
        "hard_vetoes": last_round.hard_vetoes,
        "repair_triggers": last_round.repair_triggers,
        "tune": _private_log_accept_diagnostic_summary(tune),
        "screen": _private_log_accept_diagnostic_summary(screen),
        "private_hmc_mechanics": True,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
    }


def _joint_l_epsilon_ladder_transition_count(
    ladder: FixedMassHMCTuningBudgetLadderResult,
) -> int:
    """Count all declared tune/screen transitions in one completed ladder."""

    total = 0
    for round_result in ladder.rounds:
        for config_payload in (
            round_result.tune_config_payload,
            round_result.screen_config_payload,
        ):
            if not isinstance(config_payload, Mapping):
                continue
            total += int(config_payload.get("num_results", 0))
            total += int(config_payload.get("num_burnin_steps", 0))
    if total < 0:
        raise ValueError("joint ladder transition count cannot be negative")
    return total


def _private_log_accept_diagnostic_summary(
    diagnostics: Mapping[str, Any],
) -> Mapping[str, Any]:
    trace_summary = diagnostics.get("trace_summary")
    trace_keys = ()
    trace_unavailability = None
    if isinstance(trace_summary, Mapping):
        trace_keys = tuple(str(item) for item in trace_summary.get("trace_keys", ()))
        trace_unavailability = trace_summary.get("trace_unavailability")
    return {
        "acceptance_rate": _scalar_or_none(diagnostics.get("acceptance_rate")),
        "log_accept_ratio_finite": diagnostics.get("log_accept_ratio_finite"),
        "log_accept_ratio_diagnostic_source": diagnostics.get(
            "log_accept_ratio_diagnostic_source"
        ),
        "log_accept_ratio_summary": diagnostics.get("log_accept_ratio_summary"),
        "max_abs_log_accept_ratio": _scalar_or_none(
            diagnostics.get("max_abs_log_accept_ratio")
        ),
        "target_log_prob_finite": diagnostics.get("target_log_prob_finite"),
        "target_log_prob_diagnostic_source": diagnostics.get(
            "target_log_prob_diagnostic_source"
        ),
        "target_log_prob_summary": diagnostics.get("target_log_prob_summary"),
        "proposed_target_log_prob_finite": diagnostics.get(
            "proposed_target_log_prob_finite"
        ),
        "proposed_target_log_prob_diagnostic_source": diagnostics.get(
            "proposed_target_log_prob_diagnostic_source"
        ),
        "proposed_target_log_prob_summary": diagnostics.get(
            "proposed_target_log_prob_summary"
        ),
        "log_acceptance_correction_finite": diagnostics.get(
            "log_acceptance_correction_finite"
        ),
        "log_acceptance_correction_diagnostic_source": diagnostics.get(
            "log_acceptance_correction_diagnostic_source"
        ),
        "log_acceptance_correction_summary": diagnostics.get(
            "log_acceptance_correction_summary"
        ),
        "samples_all_finite": diagnostics.get("samples_all_finite"),
        "trace_keys": trace_keys,
        "trace_unavailability": trace_unavailability,
    }


def _joint_l_epsilon_ladder_error_candidate_payload(
    *,
    round_index: int,
    grid_stage: str,
    candidate_index: int,
    num_leapfrog_steps: int,
    error: Exception,
    target_trajectory: float,
    handoff_screen_policy: str = _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE,
) -> Mapping[str, Any]:
    policy = _validate_handoff_screen_policy(handoff_screen_policy)
    phase23_policy = _phase23_nomination_policy_active(policy)
    return {
        "schema": "bayesfilter.hmc_joint_l_epsilon_candidate.v1",
        "round_index": int(round_index),
        "grid_stage": str(grid_stage),
        "candidate_index": int(candidate_index),
        "num_leapfrog_steps": int(num_leapfrog_steps),
        "handoff_screen_policy": policy,
        "ladder_final_status": "ladder_error",
        "ladder_passed": False,
        "selected_round_index": None,
        "selected_budget": None,
        "selected_step_size": None,
        "screen_acceptance_rate": None,
        "trajectory_length": None,
        "target_trajectory_length": float(target_trajectory),
        "target_trajectory_distance": None,
        "trajectory_window": None,
        "trajectory_window_relation": "unavailable",
        "trajectory_target_ratio": None,
        "acceptance_distance_to_target": None,
        "trajectory_window_viability_gate_active": not phase23_policy,
        "trajectory_window_nomination_only": phase23_policy,
        "hard_vetoes": ("fixed_mass_step_ladder_error",),
        "continuation_vetoes": (),
        "repair_triggers": (),
        "viable": False,
        "nomination_eligible": False,
        "nomination_role": (
            "historical_viability_gate"
            if not phase23_policy
            else "phase23_not_eligible_for_nomination"
        ),
        "run_error_type": type(error).__name__,
        "run_error_message": str(error),
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
    }


def _collect_ladder_hard_vetoes_for_joint_grid(
    ladder: FixedMassHMCTuningBudgetLadderResult,
) -> tuple[str, ...]:
    values: list[str] = []
    for round_result in ladder.rounds:
        values.extend(round_result.hard_vetoes)
    return tuple(dict.fromkeys(str(item) for item in values))


def _collect_ladder_continuation_vetoes_for_joint_grid(
    ladder: FixedMassHMCTuningBudgetLadderResult,
) -> tuple[str, ...]:
    values: list[str] = []
    for round_result in ladder.rounds:
        values.extend(round_result.continuation_vetoes)
    return tuple(dict.fromkeys(str(item) for item in values))


def _collect_ladder_repair_triggers_for_joint_grid(
    ladder: FixedMassHMCTuningBudgetLadderResult,
) -> tuple[str, ...]:
    values: list[str] = []
    for round_result in ladder.rounds:
        values.extend(round_result.repair_triggers)
    return tuple(dict.fromkeys(str(item) for item in values))


def _select_joint_l_epsilon_candidate(
    candidates: Sequence[Mapping[str, Any]],
    *,
    target_accept_prob: float,
    target_trajectory: float,
    handoff_screen_policy: str = _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE,
) -> int | None:
    policy = _validate_handoff_screen_policy(handoff_screen_policy)
    if _phase23_nomination_policy_active(policy):
        def phase23_selection_key(item: tuple[int, Mapping[str, Any]]) -> tuple[
            int,
            int,
            float,
            int,
            float,
            float,
            int,
            int,
            int,
        ]:
            candidate = item[1]
            trajectory_length = _scalar_or_none(candidate.get("trajectory_length"))
            selected_budget = _scalar_or_none(candidate.get("selected_budget"))
            public_cost_proxy = (
                float(selected_budget)
                if selected_budget is not None
                else float(candidate.get("num_leapfrog_steps", _GEOMETRY_MAX_LEAPFROG))
            )
            return (
                len(tuple(candidate.get("hard_vetoes", ()))),
                len(tuple(candidate.get("continuation_vetoes", ()))),
                abs(float(candidate["screen_acceptance_rate"]) - float(target_accept_prob)),
                _trajectory_window_class_penalty(
                    candidate.get("trajectory_window_relation", "unavailable")
                ),
                (
                    abs(float(trajectory_length) - float(target_trajectory))
                    if trajectory_length is not None
                    else float("inf")
                ),
                public_cost_proxy,
                int(candidate["num_leapfrog_steps"]),
                int(candidate["candidate_index"]),
                int(candidate.get("round_index", 0)),
            )

        nomination_candidates = [
            (index, candidate)
            for index, candidate in enumerate(candidates)
            if candidate.get("nomination_eligible") is True
            and _finite_number(candidate.get("screen_acceptance_rate"))
            and _finite_number(candidate.get("selected_step_size"))
        ]
        if not nomination_candidates:
            return None
        selected_index, _candidate = min(
            nomination_candidates,
            key=phase23_selection_key,
        )
        return int(selected_index)
    viable = [
        (index, candidate)
        for index, candidate in enumerate(candidates)
        if candidate.get("viable") is True
        and _scalar_or_none(candidate.get("screen_acceptance_rate")) is not None
        and _scalar_or_none(candidate.get("selected_step_size")) is not None
    ]
    if not viable:
        return None
    selected_index, _candidate = min(
        viable,
        key=lambda item: (
            abs(float(item[1]["screen_acceptance_rate"]) - float(target_accept_prob)),
            abs(float(item[1]["trajectory_length"]) - float(target_trajectory)),
            float(item[1]["trajectory_length"]),
            int(item[1]["num_leapfrog_steps"]),
            int(item[1]["candidate_index"]),
        ),
    )
    return int(selected_index)


def _joint_l_epsilon_selected_at_grid_edge(
    *,
    selected_l: int,
    grid_values: Sequence[int],
    max_leapfrog_steps: int,
) -> str | None:
    values = tuple(sorted(dict.fromkeys(int(item) for item in grid_values)))
    if not values:
        return None
    selected = int(selected_l)
    max_l = _validate_max_leapfrog_steps(max_leapfrog_steps)
    if selected == values[0] and selected > _GEOMETRY_MIN_LEAPFROG:
        return "lower"
    if selected == values[-1] and selected < max_l:
        return "upper"
    return None


def _joint_l_epsilon_round_summary(
    *,
    round_index: int,
    grid_stage: str,
    anchor_l: int,
    grid_values: Sequence[int],
    selected_candidate: Mapping[str, Any] | None,
    edge_direction: str | None,
) -> Mapping[str, Any]:
    return {
        "round_index": int(round_index),
        "grid_stage": str(grid_stage),
        "anchor_l": int(anchor_l),
        "candidate_l_values": tuple(int(item) for item in grid_values),
        "selected_candidate_index": None
        if selected_candidate is None
        else int(selected_candidate["candidate_index"]),
        "selected_num_leapfrog_steps": None
        if selected_candidate is None
        else int(selected_candidate["num_leapfrog_steps"]),
        "selected_step_size": None
        if selected_candidate is None
        else selected_candidate.get("selected_step_size"),
        "selected_acceptance_rate": None
        if selected_candidate is None
        else selected_candidate.get("screen_acceptance_rate"),
        "selected_at_grid_edge": edge_direction is not None,
        "edge_direction": edge_direction,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
    }


def _run_joint_l_epsilon_grid_round(
    *,
    adapter: Any,
    adapted_mass: PrecomputedMassArtifact,
    initial_state_factory: Callable[[tuple[int, int], str, int, int, float], Any],
    config: HMCFixedMassStepStageConfig,
    initial_step: float,
    target_scope: str,
    target_trajectory: float,
    anchor_l: int,
    max_leapfrog_steps: int,
    round_index: int,
    grid_stage: str,
    grid_values: Sequence[int],
    fixed_mass_stage_start_perf_counter_s: float,
    completed_candidate_elapsed_s: list[float],
    screen_callback: FixedMassScreenCallback | None,
    run_full_chain: RunFullChainFn,
    attempt_budget_policy: "_HMCAttemptBudgetPolicy | None",
    attempt_state: "_HMCPhaseAttemptState | None",
    progress_callback: LoopProgressCallback | None,
    progress_attempt_index: int,
    private_diagnostic_callback: PrivateTuningDiagnosticCallback | None = None,
    shared_runner_cache: dict[str, Any] | None = None,
    shared_runner_contract_payloads: dict[str, Mapping[str, Any]] | None = None,
    qualified_step_size_upper_bound: float | None = None,
) -> Mapping[str, Any]:
    candidates: list[Mapping[str, Any]] = []
    ladders_by_candidate_index: dict[int, FixedMassHMCTuningBudgetLadderResult] = {}
    run_errors: list[Mapping[str, Any]] = []
    grid = tuple(int(item) for item in grid_values)
    selection_algorithm = str(config.algorithm_id)
    public_timeout_closeout: Mapping[str, Any] | None = None
    runner_cache = {} if shared_runner_cache is None else shared_runner_cache
    runner_contract_payloads = (
        {}
        if shared_runner_contract_payloads is None
        else shared_runner_contract_payloads
    )
    for candidate_index, leapfrog_count in enumerate(grid):
        soft_deadline_veto = _fixed_mass_step_next_candidate_soft_deadline_veto(
            config,
            stage_start_perf_counter_s=fixed_mass_stage_start_perf_counter_s,
            attempt_index=progress_attempt_index,
            completed_elapsed_s=tuple(completed_candidate_elapsed_s),
        )
        if soft_deadline_veto is not None:
            public_timeout_closeout = {
                **soft_deadline_veto,
                "round_index": int(round_index),
                "grid_stage": str(grid_stage),
                "candidate_index": int(candidate_index),
                "candidate_count": len(grid),
                "completed_candidate_count": len(candidates),
                "progress_only": True,
                "public_closeout_artifact_expected": True,
                "reason": "fixed_mass_step_public_timeout_soft_deadline_before_next_candidate",
            }
            _emit_phase7_progress(
                progress_callback,
                "fixed_mass_step_candidate_soft_deadline_closeout",
                attempt_index=progress_attempt_index,
                budget_policy=attempt_budget_policy,
                completed=True,
                extra={
                    "schema": "bayesfilter.fixed_mass_step_public_timeout_progress.v1",
                    "stage": "fixed_mass_step_candidate_soft_deadline_closeout",
                    "joint_l_epsilon_algorithm": selection_algorithm,
                    "joint_l_epsilon_grid_stage": str(grid_stage),
                    "joint_l_epsilon_round_index": int(round_index),
                    "joint_l_epsilon_candidate_index": int(candidate_index),
                    "joint_l_epsilon_candidate_count": len(grid),
                    "completed_candidate_count": len(candidates),
                    "public_timeout_closeout": public_timeout_closeout,
                    "progress_only": True,
                    "hmc_mechanics_exposed": False,
                    "reports_posterior_convergence": False,
                    "reports_sampler_superiority": False,
                    "reports_default_readiness": False,
                    "reports_external_client_scientific_claim": False,
                    "reports_gpu_or_xla_readiness": False,
                    "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
                },
            )
            break
        seed_offset = int(round_index) * 100 + int(candidate_index)
        budget_config = _joint_l_epsilon_ladder_config(
            config,
            initial_step=initial_step,
            num_leapfrog_steps=int(leapfrog_count),
            target_scope=target_scope,
            seed_offset=seed_offset,
            attempt_budget_policy=attempt_budget_policy,
            attempt_state=attempt_state,
            qualified_step_size_upper_bound=qualified_step_size_upper_bound,
        )

        def forward_ladder_progress(stage: str, payload: Mapping[str, Any]) -> None:
            _emit_phase7_progress(
                progress_callback,
                stage,
                attempt_index=progress_attempt_index,
                budget_policy=attempt_budget_policy,
                started=bool(payload.get("started")),
                completed=bool(payload.get("completed")),
                extra={
                    **_budget_ladder_progress_extra(payload),
                    "joint_l_epsilon_algorithm": selection_algorithm,
                    "joint_l_epsilon_grid_stage": str(grid_stage),
                    "joint_l_epsilon_round_index": int(round_index),
                    "joint_l_epsilon_candidate_index": int(candidate_index),
                    "joint_l_epsilon_candidate_count": len(grid),
                    "hmc_mechanics_exposed": False,
                },
            )

        candidate_start = time.perf_counter()
        try:
            ladder = run_fixed_mass_hmc_tuning_budget_ladder(
                adapter=adapter,
                mass_artifact=adapted_mass,
                initial_state_factory=initial_state_factory,
                config=budget_config,
                screen_callback=screen_callback,
                progress_callback=forward_ladder_progress,
                run_full_chain=run_full_chain,
                _runner_cache=runner_cache,
                _runner_contract_payloads=runner_contract_payloads,
                _dynamic_num_leapfrog_steps=True,
            )
            ladders_by_candidate_index[int(candidate_index)] = ladder
            ladder_private_summary = _joint_l_epsilon_ladder_private_diagnostic_summary(
                ladder
            )
            candidates.append(
                _joint_l_epsilon_ladder_candidate_payload(
                    round_index=round_index,
                    grid_stage=grid_stage,
                    candidate_index=candidate_index,
                    num_leapfrog_steps=int(leapfrog_count),
                    ladder=ladder,
                    target_trajectory=target_trajectory,
                    target_accept_prob=config.target_accept_prob,
                    trajectory_window_lower_multiplier=(
                        config.trajectory_window_lower_multiplier
                    ),
                    trajectory_window_upper_multiplier=(
                        config.trajectory_window_upper_multiplier
                    ),
                    max_leapfrog_steps=max_leapfrog_steps,
                    handoff_screen_policy=config.handoff_screen_policy,
                )
            )
            candidate_payload = candidates[-1]
            if private_diagnostic_callback is not None:
                completed = len(candidates)
                private_diagnostic_callback(
                    "joint_l_epsilon_candidate_complete",
                    {
                        "stage": "joint_l_epsilon_candidate_complete",
                        "round_index": int(round_index),
                        "grid_stage": str(grid_stage),
                        "candidate_index": int(candidate_index),
                        "candidate_count": len(grid),
                        "candidate_completed_count": completed,
                        "candidate_pass_count": sum(
                            1
                            for candidate in candidates
                            if candidate.get("viable") is True
                        ),
                        "candidate_hard_veto_count": sum(
                            1
                            for candidate in candidates
                            if tuple(candidate.get("hard_vetoes", ()))
                        ),
                        "num_leapfrog_steps": int(leapfrog_count),
                        "step_size": candidate_payload.get("selected_step_size"),
                        "selected_round_index": candidate_payload.get(
                            "selected_round_index"
                        ),
                        "selected_budget": candidate_payload.get("selected_budget"),
                        "ladder_final_status": candidate_payload.get(
                            "ladder_final_status"
                        ),
                        "ladder_passed": candidate_payload.get("ladder_passed"),
                        "viable": candidate_payload.get("viable"),
                        "screen_acceptance_rate": candidate_payload.get(
                            "screen_acceptance_rate"
                        ),
                        "trajectory_length": candidate_payload.get("trajectory_length"),
                        "trajectory_window_relation": candidate_payload.get(
                            "trajectory_window_relation"
                        ),
                        "trajectory_target_ratio": candidate_payload.get(
                            "trajectory_target_ratio"
                        ),
                        "target_trajectory_length": float(target_trajectory),
                        "hard_vetoes": candidate_payload.get("hard_vetoes", ()),
                        "continuation_vetoes": candidate_payload.get(
                            "continuation_vetoes", ()
                        ),
                        "repair_triggers": candidate_payload.get(
                            "repair_triggers", ()
                        ),
                        "last_ladder_round_private_diagnostics": (
                            ladder_private_summary
                        ),
                        "ladder_artifact_hash": candidate_payload.get(
                            "ladder_artifact_hash"
                        ),
                        "private_hmc_mechanics": True,
                        "reports_posterior_convergence": False,
                        "reports_sampler_superiority": False,
                        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
                    },
                )
        except Exception as exc:  # noqa: BLE001 - candidate-level fail-closed record.
            run_errors.append(
                {
                    "round_index": int(round_index),
                    "grid_stage": str(grid_stage),
                    "candidate_index": int(candidate_index),
                    "num_leapfrog_steps": int(leapfrog_count),
                    "run_error_type": type(exc).__name__,
                    "run_error_message": str(exc),
                }
            )
            candidates.append(
                _joint_l_epsilon_ladder_error_candidate_payload(
                    round_index=round_index,
                    grid_stage=grid_stage,
                    candidate_index=candidate_index,
                    num_leapfrog_steps=int(leapfrog_count),
                    error=exc,
                    target_trajectory=target_trajectory,
                    handoff_screen_policy=config.handoff_screen_policy,
                )
            )
            if private_diagnostic_callback is not None:
                private_diagnostic_callback(
                    "joint_l_epsilon_candidate_complete",
                    {
                        "stage": "joint_l_epsilon_candidate_error",
                        "round_index": int(round_index),
                        "grid_stage": str(grid_stage),
                        "candidate_index": int(candidate_index),
                        "candidate_count": len(grid),
                        "candidate_completed_count": len(candidates),
                        "candidate_pass_count": sum(
                            1
                            for candidate in candidates
                            if candidate.get("viable") is True
                        ),
                        "candidate_hard_veto_count": sum(
                            1
                            for candidate in candidates
                            if tuple(candidate.get("hard_vetoes", ()))
                        ),
                        "num_leapfrog_steps": int(leapfrog_count),
                        "step_size": None,
                        "run_error_type": type(exc).__name__,
                        "run_error_message": str(exc),
                        "private_hmc_mechanics": True,
                        "reports_posterior_convergence": False,
                        "reports_sampler_superiority": False,
                        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
                    },
                )
        finally:
            completed_candidate_elapsed_s.append(
                max(0.0, time.perf_counter() - float(candidate_start))
            )

    selected_index = _select_joint_l_epsilon_candidate(
        candidates,
        target_accept_prob=config.target_accept_prob,
        target_trajectory=target_trajectory,
        handoff_screen_policy=config.handoff_screen_policy,
    )
    selected_candidate = None if selected_index is None else candidates[selected_index]
    selected_ladder = (
        None
        if selected_index is None
        else ladders_by_candidate_index.get(int(selected_candidate["candidate_index"]))
    )
    edge_direction = (
        None
        if selected_candidate is None
        else _joint_l_epsilon_selected_at_grid_edge(
            selected_l=int(selected_candidate["num_leapfrog_steps"]),
            grid_values=grid,
            max_leapfrog_steps=max_leapfrog_steps,
        )
    )
    if private_diagnostic_callback is not None:
        private_diagnostic_callback(
            "joint_l_epsilon_round_selected",
            {
                "stage": "joint_l_epsilon_round_selected",
                "round_index": int(round_index),
                "grid_stage": str(grid_stage),
                "candidate_count": len(grid),
                "candidate_completed_count": len(candidates),
                "candidate_pass_count": sum(
                    1 for candidate in candidates if candidate.get("viable") is True
                ),
                "candidate_hard_veto_count": sum(
                    1
                    for candidate in candidates
                    if tuple(candidate.get("hard_vetoes", ()))
                ),
                "selected_pair_exists": selected_candidate is not None,
                "selected_candidate_index": selected_index,
                "num_leapfrog_steps": None
                if selected_candidate is None
                else int(selected_candidate["num_leapfrog_steps"]),
                "step_size": None
                if selected_candidate is None
                else selected_candidate.get("selected_step_size"),
                "screen_acceptance_rate": None
                if selected_candidate is None
                else selected_candidate.get("screen_acceptance_rate"),
                "trajectory_length": None
                if selected_candidate is None
                else selected_candidate.get("trajectory_length"),
                "target_trajectory_length": float(target_trajectory),
                "edge_direction": edge_direction,
                "public_timeout_closeout": None
                if public_timeout_closeout is None
                else dict(public_timeout_closeout),
                "private_hmc_mechanics": True,
                "reports_posterior_convergence": False,
                "reports_sampler_superiority": False,
                "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
            },
        )
    return {
        "round_index": int(round_index),
        "grid_stage": str(grid_stage),
        "grid_values": grid,
        "candidates": tuple(candidates),
        "ladders_by_candidate_index": ladders_by_candidate_index,
        "selected_candidate_index": selected_index,
        "selected_candidate": selected_candidate,
        "selected_ladder": selected_ladder,
        "edge_direction": edge_direction,
        "run_errors": tuple(run_errors),
        "public_timeout_closeout": None
        if public_timeout_closeout is None
        else dict(public_timeout_closeout),
        "summary": _joint_l_epsilon_round_summary(
            round_index=round_index,
            grid_stage=grid_stage,
            anchor_l=int(anchor_l),
            grid_values=grid,
            selected_candidate=selected_candidate,
            edge_direction=edge_direction,
        ),
    }


def _select_joint_l_epsilon_repair_ladder(
    rounds: Sequence[Mapping[str, Any]],
    *,
    target_accept_prob: float,
    target_trajectory: float,
) -> FixedMassHMCTuningBudgetLadderResult | None:
    ladder, _source_key = _select_joint_l_epsilon_repair_ladder_with_source(
        rounds,
        target_accept_prob=target_accept_prob,
        target_trajectory=target_trajectory,
    )
    return ladder


def _select_joint_l_epsilon_repair_ladder_with_source(
    rounds: Sequence[Mapping[str, Any]],
    *,
    target_accept_prob: float,
    target_trajectory: float,
) -> tuple[
    FixedMassHMCTuningBudgetLadderResult | None,
    tuple[int, str, int] | None,
]:
    repair_options: list[
        tuple[
            tuple[float, float, int, int, int],
            FixedMassHMCTuningBudgetLadderResult,
            tuple[int, str, int],
        ]
    ] = []
    for round_payload in rounds:
        ladders = round_payload.get("ladders_by_candidate_index", {})
        if not isinstance(ladders, Mapping):
            continue
        candidates = tuple(round_payload.get("candidates", ()))
        for candidate in candidates:
            candidate_index = int(candidate.get("candidate_index", -1))
            ladder = ladders.get(candidate_index)
            if ladder is None or ladder.repair_config_payload is None:
                continue
            acceptance = _scalar_or_none(candidate.get("screen_acceptance_rate"))
            trajectory = _scalar_or_none(candidate.get("trajectory_length"))
            repair_round = ladder.last_repair_compatible_round
            repair_acceptance = (
                None
                if repair_round is None
                else _scalar_or_none(repair_round.screen_diagnostics.get("acceptance_rate"))
            )
            acceptance_distance = (
                abs(float(acceptance) - float(target_accept_prob))
                if acceptance is not None
                else (
                    abs(float(repair_acceptance) - float(target_accept_prob))
                    if repair_acceptance is not None
                    else float("inf")
                )
            )
            trajectory_distance = (
                abs(float(trajectory) - float(target_trajectory))
                if trajectory is not None
                else float("inf")
            )
            repair_options.append(
                (
                    (
                        acceptance_distance,
                        trajectory_distance,
                        int(candidate.get("num_leapfrog_steps", _GEOMETRY_MAX_LEAPFROG)),
                        int(round_payload.get("round_index", 0)),
                        candidate_index,
                    ),
                    ladder,
                    _phase5_candidate_source_key(candidate),
                )
            )
    if not repair_options:
        return None, None
    _key, ladder, source_key = min(repair_options, key=lambda item: item[0])
    return ladder, source_key


def _fixed_mass_step_frozen_mass_invariant(
    before: str,
    after: str,
) -> Mapping[str, Any]:
    return {
        "passed": before == after,
        "before_signature": before,
        "after_signature": after,
        "signature_includes_arrays": True,
        "mass_update_allowed": False,
        "role": "hard_veto",
    }


def _fixed_mass_step_stage_diagnostics(
    ladder_result: FixedMassHMCTuningBudgetLadderResult | None,
    *,
    run_error: Exception | None,
    hard_vetoes: tuple[str, ...],
) -> Mapping[str, Any]:
    if ladder_result is None:
        return {
            "passed": False,
            "ladder_final_status": None,
            "ladder_round_count": 0,
            "selected_round_index": None,
            "selected_step_size": None,
            "hard_vetoes_from_ladder": (),
            "repair_triggers_from_ladder": (),
            "run_error_type": None if run_error is None else type(run_error).__name__,
            "run_error_message": None if run_error is None else str(run_error),
            "reports_posterior_convergence": False,
            "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
        }
    hard_from_ladder: list[str] = []
    continuation_from_ladder: list[str] = []
    repair_from_ladder: list[str] = []
    for round_result in ladder_result.rounds:
        hard_from_ladder.extend(round_result.hard_vetoes)
        continuation_from_ladder.extend(round_result.continuation_vetoes)
        repair_from_ladder.extend(round_result.repair_triggers)
    selected = ladder_result.selected_round
    return {
        "passed": ladder_result.passed,
        "ladder_final_status": ladder_result.final_status,
        "ladder_round_count": len(ladder_result.rounds),
        "selected_round_index": ladder_result.selected_round_index,
        "selected_step_size": None if selected is None else selected.tuned_step_size,
        "selected_budget": None if selected is None else selected.budget,
        "hard_vetoes_from_ladder": tuple(dict.fromkeys(hard_from_ladder)),
        "continuation_vetoes_from_ladder": tuple(
            dict.fromkeys(continuation_from_ladder)
        ),
        "repair_triggers_from_ladder": tuple(dict.fromkeys(repair_from_ladder)),
        "stage_hard_vetoes_before_ladder": hard_vetoes,
        "reports_posterior_convergence": False,
        "nonclaims": FIXED_MASS_STEP_STAGE_NONCLAIMS,
    }


def _required_selected_step_size(
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
) -> float:
    step = fixed_mass_step_stage.selected_step_size
    if step is None:
        raise ValueError("frozen-step trajectory requires selected step size")
    value = float(step)
    if not math.isfinite(value) or value <= 0.0:
        raise ValueError("frozen-step trajectory selected step must be positive")
    return value


def _frozen_step_trajectory_candidate_generation(
    *,
    geometry: HMCGeometryInitializationResult,
    selected_step_size: float,
    fixed_bootstrap_l: int,
    max_leapfrog_steps: int = _GEOMETRY_MAX_LEAPFROG,
    trajectory_window_lower_multiplier: float = 0.3,
    trajectory_window_upper_multiplier: float = 3.0,
    handoff_screen_policy: str = _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE,
    attempt_state: _HMCPhaseAttemptState | None = None,
) -> Mapping[str, Any]:
    policy = _validate_handoff_screen_policy(handoff_screen_policy)
    phase23_policy = _phase23_nomination_policy_active(policy)
    step = float(selected_step_size)
    if not math.isfinite(step) or step <= 0.0:
        raise ValueError("selected_step_size must be positive and finite")
    target = float(geometry.target_trajectory_length)
    if not math.isfinite(target) or target <= 0.0:
        raise ValueError("target trajectory length must be positive and finite")
    max_l = _validate_max_leapfrog_steps(max_leapfrog_steps)
    tau_min, tau_max = _trajectory_window_bounds(
        target,
        lower_multiplier=float(trajectory_window_lower_multiplier),
        upper_multiplier=float(trajectory_window_upper_multiplier),
    )
    center = int(math.ceil(target / step))
    if center <= 0:
        raise ValueError("formula-derived trajectory center L must be positive")
    tau_floor_l = int(math.ceil(tau_min / step))
    raw_candidates_list = [
        center + int(offset) for offset in _FROZEN_STEP_TRAJECTORY_CANDIDATE_OFFSETS
    ]
    raw_candidates_list.append(int(fixed_bootstrap_l))
    raw_candidates_list.append(tau_floor_l)
    selected_previous_l = (
        None if attempt_state is None else attempt_state.selected_num_leapfrog_steps
    )
    retry_anchor_l = (
        None if attempt_state is None else attempt_state.phase6_retry_num_leapfrog_steps
    )
    previous_l = selected_previous_l if selected_previous_l is not None else retry_anchor_l
    if previous_l is not None:
        raw_candidates_list.append(int(previous_l))
    verification_repair_applied = bool(
        attempt_state is not None
        and attempt_state.verification_repair_applied
        and attempt_state.verification_repair_trigger
        in {
            _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
            _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER,
        }
    )
    if verification_repair_applied and previous_l is not None:
        raw_candidates_list.extend(
            int(previous_l) + int(offset)
            for offset in _FROZEN_STEP_TRAJECTORY_REPAIR_NEIGHBORHOOD_OFFSETS
        )
        raw_candidates_list.append(tau_floor_l)
    raw_candidates = tuple(raw_candidates_list)
    local_max = max(
        _GEOMETRY_MIN_LEAPFROG,
        min(max_l, center + _FROZEN_STEP_TRAJECTORY_CENTER_SLACK),
    )
    clamped = tuple(
        min(local_max, max(_GEOMETRY_MIN_LEAPFROG, item))
        for item in raw_candidates
    )
    candidates = tuple(sorted(dict.fromkeys(clamped)))
    ordered_candidates, candidate_order = _frozen_step_trajectory_order_candidates(
        candidates,
        step_size=step,
        tau_min=tau_min,
        tau_max=tau_max,
        target_trajectory=target,
        attempt_state=attempt_state,
    )
    return {
        "formula": "L*=ceil(geometry.target_trajectory_length / selected_step_size)",
        "center_candidate_l": center,
        "selected_step_size": step,
        "target_trajectory_length": target,
        "trajectory_window": (tau_min, tau_max),
        "trajectory_window_lower_multiplier": float(trajectory_window_lower_multiplier),
        "trajectory_window_upper_multiplier": float(trajectory_window_upper_multiplier),
        "trajectory_window_policy_role": _TRAJECTORY_WINDOW_POLICY_ROLE,
        "handoff_screen_policy": policy,
        "trajectory_window_viability_gate_active": not phase23_policy,
        "trajectory_window_nomination_only": phase23_policy,
        "minimum_step_size_for_tau_floor": tau_min / max_l,
        "tau_floor_candidate_l": tau_floor_l,
        "tau_floor_feasible_at_selected_step": tau_floor_l <= max_l,
        "fixed_bootstrap_num_leapfrog_steps": int(fixed_bootstrap_l),
        "previous_attempt_center_l": previous_l,
        "previous_selected_num_leapfrog_steps": selected_previous_l,
        "phase6_retry_num_leapfrog_steps": retry_anchor_l,
        "phase6_retry_anchor_source": None
        if attempt_state is None
        else attempt_state.phase6_retry_anchor_source,
        "previous_l_anchor_role": (
            "selected_trajectory"
            if selected_previous_l is not None
            else (
                "phase6_retry_anchor"
                if retry_anchor_l is not None
                else "unavailable"
            )
        ),
        "neighborhood_offsets": _FROZEN_STEP_TRAJECTORY_CANDIDATE_OFFSETS,
        "verification_repair_neighborhood_applied": verification_repair_applied,
        "verification_repair_neighborhood_offsets": (
            _FROZEN_STEP_TRAJECTORY_REPAIR_NEIGHBORHOOD_OFFSETS
            if verification_repair_applied
            else ()
        ),
        "raw_candidate_l_values": raw_candidates,
        "internal_min_leapfrog": _GEOMETRY_MIN_LEAPFROG,
        "internal_max_leapfrog": max_l,
        "default_max_leapfrog_steps": _GEOMETRY_MAX_LEAPFROG,
        "max_leapfrog_steps": max_l,
        "local_max_leapfrog": local_max,
        "local_max_leapfrog_formula": "min(max_leapfrog_steps, center_candidate_l + 10)",
        "candidate_l_values": ordered_candidates,
        "candidate_order": candidate_order,
        "candidate_set_order_before_directional_repair": candidates,
        "candidate_mechanics_are_diagnostic_telemetry_only": True,
    }


def _phase5_selected_pair_candidate_generation(
    *,
    geometry: HMCGeometryInitializationResult,
    phase5_algorithm_id: str,
    selected_step_size: float,
    selected_num_leapfrog_steps: int,
    fixed_bootstrap_l: int,
    max_leapfrog_steps: int,
    trajectory_window_lower_multiplier: float,
    trajectory_window_upper_multiplier: float,
    handoff_screen_policy: str = _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE,
) -> Mapping[str, Any]:
    policy = _validate_handoff_screen_policy(handoff_screen_policy)
    phase23_policy = _phase23_nomination_policy_active(policy)
    step = float(selected_step_size)
    if not math.isfinite(step) or step <= 0.0:
        raise ValueError("selected_step_size must be positive and finite")
    selected_l = int(selected_num_leapfrog_steps)
    if selected_l <= 0:
        raise ValueError("selected_num_leapfrog_steps must be positive")
    max_l = _validate_max_leapfrog_steps(max_leapfrog_steps)
    if selected_l > max_l:
        raise ValueError("selected_num_leapfrog_steps exceeds max_leapfrog_steps")
    target = float(geometry.target_trajectory_length)
    if not math.isfinite(target) or target <= 0.0:
        raise ValueError("target trajectory length must be positive and finite")
    tau_min, tau_max = _trajectory_window_bounds(
        target,
        lower_multiplier=float(trajectory_window_lower_multiplier),
        upper_multiplier=float(trajectory_window_upper_multiplier),
    )
    trajectory_length = step * selected_l
    phase5_algorithm = str(phase5_algorithm_id)
    if phase5_algorithm not in _PHASE5_DIRECT_GRID_ALGORITHMS:
        raise ValueError("selected-pair handoff requires a direct Phase 5 algorithm")
    return {
        "formula": "Phase 5 measured epsilon/L selected-pair handoff screen",
        "algorithm": f"{phase5_algorithm}_selected_pair_handoff",
        "phase5_algorithm_id": phase5_algorithm,
        "phase5_measured_epsilon_l_pair": True,
        "phase5_joint_l_epsilon_algorithm": bool(
            phase5_algorithm == _PHASE5_JOINT_L_EPSILON_ALGORITHM
        ),
        "selected_step_size": step,
        "selected_num_leapfrog_steps": selected_l,
        "target_trajectory_length": target,
        "selected_trajectory_length": trajectory_length,
        "trajectory_window": (tau_min, tau_max),
        "trajectory_window_lower_multiplier": float(trajectory_window_lower_multiplier),
        "trajectory_window_upper_multiplier": float(trajectory_window_upper_multiplier),
        "trajectory_window_policy_role": _TRAJECTORY_WINDOW_POLICY_ROLE,
        "handoff_screen_policy": policy,
        "trajectory_window_viability_gate_active": not phase23_policy,
        "trajectory_window_nomination_only": phase23_policy,
        "fixed_bootstrap_num_leapfrog_steps": int(fixed_bootstrap_l),
        "bootstrap_l_is_lineage_not_constraint": True,
        "internal_min_leapfrog": _GEOMETRY_MIN_LEAPFROG,
        "internal_max_leapfrog": max_l,
        "default_max_leapfrog_steps": _GEOMETRY_MAX_LEAPFROG,
        "max_leapfrog_steps": max_l,
        "candidate_l_values": (selected_l,),
        "candidate_order": "selected_pair_only",
        "candidate_mechanics_are_diagnostic_telemetry_only": True,
        "no_second_frozen_epsilon_l_search": True,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "nonclaims": FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS,
    }


def _frozen_step_trajectory_order_candidates(
    candidates: Sequence[int],
    *,
    step_size: float,
    tau_min: float,
    tau_max: float,
    target_trajectory: float,
    attempt_state: _HMCPhaseAttemptState | None,
) -> tuple[tuple[int, ...], str]:
    """Order Phase 6 screens without changing the private candidate set.

    A previous directional repair is evidence about which side of the trajectory
    exposure should be tested first.  Keep the historical ascending order when
    that evidence is unavailable so non-repair behavior remains stable.
    """

    unique_candidates = tuple(int(item) for item in candidates)
    if attempt_state is None or not attempt_state.verification_repair_applied:
        return unique_candidates, _FROZEN_STEP_TRAJECTORY_ORDER_ASCENDING
    if attempt_state.verification_repair_trigger not in {
        _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
        _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER,
    }:
        return unique_candidates, _FROZEN_STEP_TRAJECTORY_ORDER_ASCENDING
    relation = attempt_state.verification_acceptance_relation
    if relation not in {"above_acceptance_band", "below_acceptance_band"}:
        return unique_candidates, _FROZEN_STEP_TRAJECTORY_ORDER_ASCENDING

    def trajectory_length(leapfrog_count: int) -> float:
        return float(step_size) * int(leapfrog_count)

    def inside_rank(leapfrog_count: int) -> int:
        tau = trajectory_length(leapfrog_count)
        return 0 if float(tau_min) <= tau <= float(tau_max) else 1

    if relation == "above_acceptance_band":
        ordered = tuple(
            sorted(
                unique_candidates,
                key=lambda item: (
                    inside_rank(item),
                    -trajectory_length(item),
                    abs(trajectory_length(item) - float(target_trajectory)),
                    -int(item),
                ),
            )
        )
        return ordered, _FROZEN_STEP_TRAJECTORY_ORDER_HIGH_ACCEPTANCE_REPAIR

    ordered = tuple(
        sorted(
            unique_candidates,
            key=lambda item: (
                inside_rank(item),
                trajectory_length(item),
                abs(trajectory_length(item) - float(target_trajectory)),
                int(item),
            ),
        )
    )
    return ordered, _FROZEN_STEP_TRAJECTORY_ORDER_LOW_ACCEPTANCE_REPAIR


def _frozen_step_trajectory_screen_config(
    config: HMCFrozenStepTrajectoryStageConfig,
    *,
    seed: tuple[int, int],
    step: float,
    leapfrogs: int,
    target_scope: str,
    attempt_budget_policy: _HMCAttemptBudgetPolicy | None = None,
) -> FullChainHMCConfig:
    if attempt_budget_policy is None:
        num_results = _FROZEN_STEP_TRAJECTORY_SCREEN_NUM_RESULTS
        burnin_steps = _FROZEN_STEP_TRAJECTORY_SCREEN_BURNIN_STEPS
    else:
        num_results = attempt_budget_policy.phase6_screen_num_results
        burnin_steps = attempt_budget_policy.phase6_screen_burnin_steps
    return FullChainHMCConfig(
        num_results=num_results,
        num_burnin_steps=burnin_steps,
        step_size=float(step),
        num_leapfrog_steps=int(leapfrogs),
        seed=seed,
        use_xla=config.use_xla,
        trace_policy="standard",
        target_status_trace_policy=config.target_status_trace_policy,
        target_scope=target_scope,
        chain_execution_mode=config.chain_execution_mode,
        capture_first_failure=config.chain_execution_mode == "tf_function" and not config.use_xla,
        failure_capture_role="sampling",
    )


def _frozen_step_trajectory_diagnostics_payload(
    run_result: FullChainHMCRunResult,
) -> Mapping[str, Any]:
    payload = dict(_bootstrap_diagnostics_payload(run_result))
    screen = dict(payload.get("screen_diagnostic", {}))
    roles = dict(screen.get("diagnostic_roles", {}))
    roles["screen"] = "frozen-step trajectory fixed-kernel screen only"
    screen["diagnostic_roles"] = roles
    screen["nonclaims"] = FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS
    payload["screen_diagnostic"] = screen
    payload["diagnostic_context"] = "frozen_step_trajectory_candidate_screen"
    payload["nonclaims"] = FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS
    return payload


def _run_kernel_stage_with_optional_reusable_route(
    *,
    run_full_chain: RunFullChainFn,
    runner_cache: dict[str, Any],
    runner_contract_payloads: dict[str, Mapping[str, Any]],
    route_events: list[Mapping[str, Any]],
    route_name: str,
    route_scope: str,
    adapter: Any,
    initial_state: Any,
    config: FullChainHMCConfig,
    hmc_adapter_signature: str,
    target_dimension: int,
    mass_signature: str,
    event_payload: Mapping[str, Any],
    dynamic_num_leapfrog_steps: bool = False,
) -> FullChainHMCRunResult:
    if run_full_chain is not run_full_chain_tfp_hmc or config.chain_execution_mode != "tf_function":
        route_event = {
            **dict(event_payload),
            "route_scope": str(route_scope),
            "route": "single_use_or_injected_runner",
            "static_contract_hash": None,
            "call_config_hash": stable_config_hash(config.signature_payload()),
            "runner_reused": False,
            "used_single_use_runner": run_full_chain is run_full_chain_tfp_hmc,
            "dynamic_num_leapfrog_steps": bool(dynamic_num_leapfrog_steps),
        }
        route_events.append(route_event)
        return run_full_chain(adapter, initial_state, config)

    contract_payload = _kernel_stage_reusable_static_contract_payload(
        config,
        hmc_adapter_signature=hmc_adapter_signature,
        target_dimension=target_dimension,
        mass_signature=mass_signature,
        initial_state=initial_state,
        dynamic_num_leapfrog_steps=dynamic_num_leapfrog_steps,
    )
    contract_hash = stable_config_hash(contract_payload)
    runner = runner_cache.get(contract_hash)
    runner_reused = runner is not None
    if runner is None:
        runner = build_reusable_full_chain_tfp_hmc_runner(
            adapter,
            initial_state,
            config,
            dynamic_num_leapfrog_steps=dynamic_num_leapfrog_steps,
        )
        runner_cache[contract_hash] = runner
        runner_contract_payloads[contract_hash] = contract_payload
    runner_kwargs = {
        "current_state": initial_state,
        "seed": config.seed,
        "step_size": config.step_size,
    }
    if dynamic_num_leapfrog_steps:
        runner_kwargs["num_leapfrog_steps"] = config.num_leapfrog_steps
    result = runner.run(**runner_kwargs)
    route_event = {
        **dict(event_payload),
        "route_scope": str(route_scope),
        "route": str(route_name),
        "static_contract_hash": contract_hash,
        "call_config_hash": stable_config_hash(config.signature_payload()),
        "runner_reused": runner_reused,
        "used_single_use_runner": False,
        "dynamic_num_leapfrog_steps": bool(dynamic_num_leapfrog_steps),
    }
    route_events.append(route_event)
    metadata = {
        **dict(result.metadata),
        "kernel_stage_route": str(route_name),
        "kernel_stage_route_scope": str(route_scope),
        "kernel_stage_static_contract_hash": contract_hash,
        "kernel_stage_call_config_hash": route_event["call_config_hash"],
        "kernel_stage_runner_reused": runner_reused,
        "kernel_stage_static_contract_payload": contract_payload,
        "kernel_stage_dynamic_num_leapfrog_steps": bool(dynamic_num_leapfrog_steps),
    }
    return FullChainHMCRunResult(
        samples=result.samples,
        trace=result.trace,
        diagnostics=result.diagnostics,
        metadata=metadata,
    )


def _kernel_stage_reusable_static_contract_payload(
    config: FullChainHMCConfig,
    *,
    hmc_adapter_signature: str,
    target_dimension: int,
    mass_signature: str,
    initial_state: Any,
    dynamic_num_leapfrog_steps: bool = False,
) -> Mapping[str, Any]:
    payload = dict(config.signature_payload())
    payload.pop("seed", None)
    payload.pop("step_size", None)
    if dynamic_num_leapfrog_steps:
        payload.pop("num_leapfrog_steps", None)
    state_contract = _kernel_stage_reusable_state_template_contract(initial_state)
    return {
        "runner": "build_reusable_full_chain_tfp_hmc_runner",
        "hmc_adapter_signature": str(hmc_adapter_signature),
        "target_dimension": int(target_dimension),
        "mass_artifact_signature": str(mass_signature),
        "initial_state_shape": state_contract["initial_state_shape"],
        "initial_state_dtype": state_contract["initial_state_dtype"],
        "initial_state_dtype_source": state_contract["initial_state_dtype_source"],
        "static_config": payload,
        "dynamic_inputs": (
            ("current_state", "seed", "step_size", "num_leapfrog_steps")
            if dynamic_num_leapfrog_steps
            else ("current_state", "seed", "step_size")
        ),
        "dynamic_num_leapfrog_steps": bool(dynamic_num_leapfrog_steps),
    }


def _kernel_stage_reusable_state_template_contract(initial_state: Any) -> Mapping[str, Any]:
    import tensorflow as tf

    template = tf.cast(tf.convert_to_tensor(initial_state), tf.float64)
    if template.shape.rank is None:
        raise ValueError("reusable HMC runner requires static state rank")
    shape = template.shape.as_list()
    if any(dim is None for dim in shape):
        raise ValueError("reusable HMC runner requires fully static state shape")
    return {
        "initial_state_shape": tuple(int(dim) for dim in shape),
        "initial_state_dtype": template.dtype.name,
        "initial_state_dtype_source": "tf.cast(tf.convert_to_tensor(initial_state), tf.float64)",
    }


def _kernel_stage_runner_route_summary(
    *,
    active_route: str,
    events: Sequence[Mapping[str, Any]],
    contract_payloads: Mapping[str, Mapping[str, Any]],
    semantic_source: str,
    reuse_nonclaim: str,
    handoff_source: str | None = None,
    initial_handoff_contract_count: int = 0,
) -> Mapping[str, Any]:
    initial_count = int(initial_handoff_contract_count)
    final_count = len(contract_payloads)
    if initial_count < 0 or initial_count > final_count:
        raise ValueError("runner handoff contract count is inconsistent")
    reusable_events = tuple(
        item
        for item in events
        if item.get("route") != "single_use_or_injected_runner"
    )
    stage_build_count = sum(
        1 for item in reusable_events if item.get("runner_reused") is False
    )
    stage_reuse_count = sum(
        1 for item in reusable_events if item.get("runner_reused") is True
    )
    stage_new_distinct_count = final_count - initial_count
    single_use_count = sum(
        1 for item in events if item.get("used_single_use_runner") is True
    )
    injected_count = sum(
        1
        for item in events
        if item.get("route") == "single_use_or_injected_runner"
        and item.get("used_single_use_runner") is False
    )
    return {
        "active_route": str(active_route),
        "semantic_source": str(semantic_source),
        "runner_cache_handoff_source": (
            None if handoff_source is None else str(handoff_source)
        ),
        "initial_handoff_contract_count": initial_count,
        "stage_runner_build_count": stage_build_count,
        "stage_runner_reuse_count": stage_reuse_count,
        "stage_new_distinct_contract_count": stage_new_distinct_count,
        "final_distinct_contract_count": final_count,
        "single_use_call_count": single_use_count,
        "injected_runner_call_count": injected_count,
        "contract_count_invariant_satisfied": (
            final_count == initial_count + stage_new_distinct_count
        ),
        # Compatibility aliases retain only meanings that were already exact.
        "reusable_runner_build_count": stage_build_count,
        "distinct_static_runner_contract_count": final_count,
        "single_use_build_count": single_use_count,
        "round_route_events": tuple(dict(item) for item in events),
        "distinct_static_runner_contracts": tuple(
            {
                "static_contract_hash": contract_hash,
                "static_contract_payload": contract_payloads[contract_hash],
            }
            for contract_hash in sorted(contract_payloads)
        ),
        "fallback_to_single_use_runner": any(
            item.get("used_single_use_runner") is True for item in events
        )
        and active_route != "single_use_or_injected_runner",
        "fallback_status": (
            "none"
            if active_route != "single_use_or_injected_runner"
            and not any(item.get("used_single_use_runner") is True for item in events)
            else "inactive_reusable_route"
        ),
        "route_nonclaims": (
            "route telemetry is engineering evidence only",
            str(reuse_nonclaim),
            "does not establish posterior convergence or sampler superiority",
        ),
        "evidence_role": "engineering_only",
        "promotion_role": "non_promoting",
        "stopping_rule_role": "not_a_stopping_rule",
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
    }


def _frozen_step_trajectory_error_diagnostics(exc: Exception) -> Mapping[str, Any]:
    payload = dict(_bootstrap_error_diagnostics(exc))
    payload["screen_diagnostic"] = {
        **dict(payload.get("screen_diagnostic", {})),
        "diagnostic_roles": {"screen": "frozen-step trajectory runtime hard veto"},
        "nonclaims": FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS,
    }
    payload["diagnostic_context"] = "frozen_step_trajectory_candidate_screen"
    payload["nonclaims"] = FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS
    return payload


def _call_trajectory_screen_callback(
    callback: TrajectoryScreenCallback | None,
    *,
    round_payload: Mapping[str, Any],
    samples: Any,
    diagnostics: Mapping[str, Any],
) -> FixedMassHMCTuningBudgetCallbackResult:
    if callback is None:
        return FixedMassHMCTuningBudgetCallbackResult()
    try:
        raw = callback(round_payload, samples, diagnostics)
        return _coerce_trajectory_callback_result(raw)
    except Exception as exc:  # noqa: BLE001 - callback failures are fail-closed.
        return FixedMassHMCTuningBudgetCallbackResult(
            hard_vetoes=("callback_error",),
            diagnostics={
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            },
        )


def _call_phase7_verification_callback(
    callback: VerificationCallback | None,
    *,
    round_payload: Mapping[str, Any],
    samples: Any,
    diagnostics: Mapping[str, Any],
) -> tuple[FixedMassHMCTuningBudgetCallbackResult, Exception | None]:
    """Preserve callback output while retaining private exception provenance."""

    if callback is None:
        return FixedMassHMCTuningBudgetCallbackResult(), None
    try:
        raw = callback(round_payload, samples, diagnostics)
        return _coerce_trajectory_callback_result(raw), None
    except Exception as exc:  # noqa: BLE001 - callback failures are fail-closed.
        return (
            FixedMassHMCTuningBudgetCallbackResult(
                hard_vetoes=("callback_error",),
                diagnostics={
                    "error_type": type(exc).__name__,
                    "error_message": str(exc),
                },
            ),
            exc,
        )


def _coerce_trajectory_callback_result(
    raw: Any,
) -> FixedMassHMCTuningBudgetCallbackResult:
    if raw is None:
        return FixedMassHMCTuningBudgetCallbackResult()
    if isinstance(raw, FixedMassHMCTuningBudgetCallbackResult):
        return raw
    if not isinstance(raw, Mapping):
        raise ValueError("screen_callback must return a mapping or callback result")
    return FixedMassHMCTuningBudgetCallbackResult(
        hard_vetoes=tuple(raw.get("hard_vetoes", ())),
        continuation_vetoes=tuple(raw.get("continuation_vetoes", ())),
        promotion_vetoes=tuple(raw.get("promotion_vetoes", ())),
        repair_triggers=tuple(raw.get("repair_triggers", ())),
        diagnostics=dict(raw.get("diagnostics", {})),
    )


def _classify_frozen_step_trajectory_candidate(
    config: HMCFrozenStepTrajectoryStageConfig,
    *,
    diagnostics: Mapping[str, Any],
    trajectory_window: Mapping[str, Any],
    screen_error: Exception | None,
    callback_result: FixedMassHMCTuningBudgetCallbackResult,
) -> tuple[
    str,
    str,
    tuple[str, ...],
    tuple[str, ...],
    tuple[str, ...],
    tuple[str, ...],
]:
    hard_vetoes: list[str] = []
    if screen_error is not None:
        hard_vetoes.append("trajectory_screen_hmc_error")
    acceptance = diagnostics.get("acceptance_rate")
    if acceptance is None or not _finite_number(acceptance):
        hard_vetoes.append("trajectory_acceptance_missing_or_nonfinite")
    if diagnostics.get("runtime_finite") is not True:
        hard_vetoes.append("trajectory_runtime_missing_or_nonfinite")
    if diagnostics.get("log_accept_ratio_finite") is not True:
        hard_vetoes.append("trajectory_log_accept_nonfinite_or_missing")
    if diagnostics.get("samples_all_finite") is not True:
        hard_vetoes.append("trajectory_samples_nonfinite_or_missing")
    if diagnostics.get("target_log_prob_finite") is not True:
        hard_vetoes.append("trajectory_target_log_prob_nonfinite_or_missing")
    tau_relation = str(trajectory_window.get("trajectory_window_relation", "unavailable"))
    if tau_relation == "invalid_trajectory_length":
        hard_vetoes.append("trajectory_length_invalid")
    if bool(trajectory_window.get("leapfrog_exceeds_max", False)):
        hard_vetoes.append("trajectory_leapfrog_exceeds_configured_max")
    telemetry = diagnostics.get("target_status_telemetry")
    if isinstance(telemetry, Mapping) and telemetry.get("telemetry_failure_veto_bool"):
        hard_vetoes.append("trajectory_target_status_telemetry_failure")
    hard_vetoes.extend(callback_result.hard_vetoes)
    if hard_vetoes:
        return (
            "hard_veto",
            "hard_veto",
            tuple(dict.fromkeys(hard_vetoes)),
            callback_result.continuation_vetoes,
            callback_result.promotion_vetoes,
            callback_result.repair_triggers,
        )
    if callback_result.continuation_vetoes:
        return (
            "continuation_veto",
            "continuation_veto",
            (),
            callback_result.continuation_vetoes,
            callback_result.promotion_vetoes,
            callback_result.repair_triggers,
        )
    promotion_vetoes = tuple(callback_result.promotion_vetoes)
    repair_triggers = tuple(callback_result.repair_triggers)
    if promotion_vetoes or repair_triggers:
        return (
            "repair_or_retry",
            "promotion_veto_repair_trigger",
            (),
            (),
            promotion_vetoes,
            repair_triggers,
        )
    acceptance_value = float(acceptance)
    acceptance_relation = _acceptance_relation_to_band(
        acceptance_value,
        config.acceptance_band,
    )
    if tau_relation != "inside_trajectory_window":
        triggers = ["trajectory_length_outside_window"]
        if tau_relation == "below_trajectory_window":
            triggers.append("trajectory_length_below_window")
            if acceptance_relation == "above_acceptance_band":
                triggers.append("high_acceptance_trajectory_underreach")
            elif acceptance_relation == "inside_acceptance_band":
                triggers.append("acceptance_pass_but_trajectory_underreach")
        elif tau_relation == "above_trajectory_window":
            triggers.append("trajectory_length_above_window")
        if acceptance_relation != "inside_acceptance_band":
            triggers.append("acceptance_outside_pass_band")
        if _phase23_nomination_policy_active(config.handoff_screen_policy):
            return (
                "nomination_screen",
                "phase23_nomination_handoff_screen_non_promoting",
                (),
                (),
                (),
                tuple(dict.fromkeys(triggers)),
            )
        return (
            "repair_or_retry",
            "trajectory_window_repair_trigger",
            (),
            (),
            (),
            tuple(dict.fromkeys(triggers)),
        )
    if acceptance_relation == "inside_acceptance_band":
        return "passed_screen", "trajectory_handoff_promotion_only", (), (), (), ()
    trigger = (
        "acceptance_below_pass_band_valid_tau"
        if acceptance_relation == "below_acceptance_band"
        else "acceptance_above_pass_band_valid_tau"
    )
    if _phase23_nomination_policy_active(config.handoff_screen_policy):
        return (
            "nomination_screen",
            "phase23_nomination_handoff_screen_non_promoting",
            (),
            (),
            (),
            ("acceptance_outside_pass_band", trigger),
        )
    return (
        "repair_or_retry",
        "trajectory_acceptance_repair_trigger",
        (),
        (),
        (),
        ("acceptance_outside_pass_band", trigger),
    )


def _select_frozen_step_trajectory_candidate(
    candidates: tuple[Mapping[str, Any], ...],
    *,
    config: HMCFrozenStepTrajectoryStageConfig,
    target_trajectory: float,
) -> int | None:
    if _phase23_nomination_policy_active(config.handoff_screen_policy):
        selectable_classifications = {"passed_screen", "nomination_screen"}
    else:
        selectable_classifications = {"passed_screen"}
    selectable = [
        (index, candidate)
        for index, candidate in enumerate(candidates)
        if candidate.get("classification") in selectable_classifications
    ]
    if not selectable:
        return None
    lower, upper = config.acceptance_band
    midpoint = 0.5 * (lower + upper)
    selected_index, _selected = min(
        selectable,
        key=lambda item: (
            0 if item[1].get("classification") == "passed_screen" else 1,
            abs(float(item[1]["diagnostics"]["acceptance_rate"]) - midpoint),
            _trajectory_window_class_penalty(
                item[1].get("trajectory_window_relation", "unavailable")
            ),
            abs(float(item[1]["trajectory_length"]) - float(target_trajectory)),
            float(item[1]["trajectory_length"]),
            int(item[1]["candidate_index"]),
        ),
    )
    return int(selected_index)


def _frozen_step_trajectory_selected_payload(
    *,
    config: HMCFrozenStepTrajectoryStageConfig,
    candidate: Mapping[str, Any],
    selected_step_hash: str,
    selected_bootstrap_kernel_hash: str,
    fixed_mass_step_stage_artifact_hash: str,
    adapted_mass_artifact_signature: str,
    phase4_hmc_adapter_signature: str,
    trajectory_hmc_adapter_signature: str,
    target_scope: str,
) -> Mapping[str, Any]:
    return {
        "runtime": "bayesfilter.inference.run_hmc_frozen_step_trajectory_stage",
        "step_size": float(candidate["step_size"]),
        "num_leapfrog_steps": int(candidate["num_leapfrog_steps"]),
        "trajectory_length": float(candidate["trajectory_length"]),
        "target_trajectory_length": float(candidate["target_trajectory_length"]),
        "target_trajectory_distance": float(candidate["target_trajectory_distance"]),
        "target_accept_prob": config.target_accept_prob,
        "acceptance_band": config.acceptance_band,
        "target_scope": target_scope,
        "selected_step_hash": str(selected_step_hash),
        "selected_bootstrap_kernel_hash": str(selected_bootstrap_kernel_hash),
        "fixed_mass_step_stage_artifact_hash": str(fixed_mass_step_stage_artifact_hash),
        "adapted_mass_artifact_signature": str(adapted_mass_artifact_signature),
        "phase4_hmc_adapter_signature": str(phase4_hmc_adapter_signature),
        "trajectory_hmc_adapter_signature": str(trajectory_hmc_adapter_signature),
        "screen_seed": candidate["seed"],
        "screen_config_payload": candidate["screen_config_payload"],
        "candidate_index": int(candidate["candidate_index"]),
        "candidate_mechanics_are_diagnostic_telemetry_only": True,
        "not_fresh_final_verification": True,
        "nonclaims": FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS,
    }


def _frozen_step_trajectory_frozen_mass_invariant(
    before: str,
    after: str,
) -> Mapping[str, Any]:
    return {
        "passed": before == after,
        "before_signature": before,
        "after_signature": after,
        "signature_includes_arrays": True,
        "mass_update_allowed": False,
        "role": "hard_veto",
    }


def _frozen_step_trajectory_frozen_step_invariant(
    *,
    before: float,
    after: float,
) -> Mapping[str, Any]:
    return {
        "passed": float(before) == float(after),
        "before_step_size": float(before),
        "after_step_size": float(after),
        "step_update_allowed": False,
        "role": "hard_veto",
    }


def _frozen_step_trajectory_stage_diagnostics(
    candidates: tuple[Mapping[str, Any], ...],
    *,
    final_status: str,
    selected_candidate_index: int | None,
    run_error: Exception | None,
    hard_vetoes: tuple[str, ...],
    repair_triggers: tuple[str, ...],
    handoff_screen_policy: str = _HANDOFF_SCREEN_POLICY_PHASE22_HEURISTIC_GATE,
    runner_route_summary: Mapping[str, Any],
    soft_deadline_closeout: Mapping[str, Any] | None = None,
    expected_candidate_count: int | None = None,
) -> Mapping[str, Any]:
    policy = _validate_handoff_screen_policy(handoff_screen_policy)
    phase23_policy = _phase23_nomination_policy_active(policy)
    candidate_count = len(candidates)
    expected_count = (
        candidate_count
        if expected_candidate_count is None
        else int(expected_candidate_count)
    )
    skipped_count = max(0, expected_count - candidate_count)
    trajectory_window_relations_seen = tuple(
        sorted(
            {
                str(candidate.get("trajectory_window_relation", "unavailable"))
                for candidate in candidates
            }
        )
    )
    return {
        "passed": final_status == "passed",
        "final_status": final_status,
        "candidate_count": candidate_count,
        "expected_candidate_count": expected_count,
        "completed_candidate_count": candidate_count,
        "skipped_candidate_count": skipped_count,
        "passed_candidate_count": sum(
            candidate.get("classification") == "passed_screen"
            for candidate in candidates
        ),
        "nomination_candidate_count": sum(
            candidate.get("classification") == "nomination_screen"
            for candidate in candidates
        ),
        "selected_candidate_index": selected_candidate_index,
        "selected_acceptance_rate": None
        if selected_candidate_index is None
        else candidates[selected_candidate_index]["diagnostics"].get("acceptance_rate"),
        "hard_vetoes": hard_vetoes,
        "repair_triggers": repair_triggers,
        "run_error_type": None if run_error is None else type(run_error).__name__,
        "run_error_message": None if run_error is None else str(run_error),
        "reports_fresh_final_verification": False,
        "reports_posterior_convergence": False,
        "candidate_mechanics_are_diagnostic_telemetry_only": True,
        "public_timeout_closeout": None
        if soft_deadline_closeout is None
        else dict(soft_deadline_closeout),
        "phase6_handoff_screen_policy_role": _PHASE6_HANDOFF_SCREEN_POLICY_ROLE,
        "phase6_handoff_screen_is_fresh_final_verification": False,
        "phase6_handoff_screen_is_posterior_or_sampler_validity_evidence": False,
        "handoff_screen_policy": policy,
        "trajectory_window_policy_role": _TRAJECTORY_WINDOW_POLICY_ROLE,
        "trajectory_window_viability_gate_active": not phase23_policy,
        "trajectory_window_nomination_only": phase23_policy,
        "trajectory_window_relations_seen": trajectory_window_relations_seen,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "runner_route_summary": runner_route_summary,
        "nonclaims": FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS,
    }


def _acceptance_relation_to_band(
    acceptance: Any,
    band: tuple[float, float],
) -> str:
    value = _scalar_or_none(acceptance)
    if value is None:
        return "unavailable"
    lower, upper = (float(band[0]), float(band[1]))
    if value < lower:
        return "below_acceptance_band"
    if value > upper:
        return "above_acceptance_band"
    return "inside_acceptance_band"


def prepare_operational_windowed_mass_handoff(
    *,
    adapter: Any,
    initial_position: Any,
    config: HMCKernelTuningConfig | None = None,
    negative_hessian: Any | None = None,
    initial_covariance: Any | None = None,
    parameter_scales: Any | None = None,
    progress_callback: Callable[[str, Mapping[str, Any]], None] | None = None,
    initialize_bootstrap: bool = False,
    bootstrap_execution: Any | None = None,
) -> Mapping[str, Any]:
    """Compatibility import for the active ordinary preparation orchestration."""
    from bayesfilter.inference.hmc_preparation import prepare_operational_windowed_mass_handoff as prepare
    return prepare(adapter=adapter, initial_position=initial_position, config=config,
        negative_hessian=negative_hessian, initial_covariance=initial_covariance,
        parameter_scales=parameter_scales, progress_callback=progress_callback,
        initialize_bootstrap=initialize_bootstrap, bootstrap_execution=bootstrap_execution)


def _phase7_historical_verification_input(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    trajectory_stage: HMCFrozenStepTrajectoryStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_index: int,
    target_scope: str,
) -> _HMCPhase7FixedKernelVerificationInput:
    """Normalize the existing Phase-6-fed verifier without changing replay."""

    scope = str(target_scope)
    if not scope or (config.target_scope is not None and scope != config.target_scope):
        raise ValueError("Phase 7 historical target scope mismatch")
    (
        _adapted_mass,
        mass_signature,
        phase4_adapter,
        verification_adapter,
        verification_signature,
    ) = _phase7_verification_runtime_context(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        target_scope=scope,
    )
    adapter_signature = stable_adapter_signature(adapter)
    phase4_signature = stable_adapter_signature(phase4_adapter)
    if not fixed_mass_step_stage.passed:
        raise ValueError("Phase 7 historical verification requires passed Phase 5")
    if not trajectory_stage.passed:
        raise ValueError("Phase 7 historical verification requires passed Phase 6")
    if fixed_mass_step_stage.windowed_stage_artifact_hash != windowed_stage.artifact_hash:
        raise ValueError("Phase 7 historical Phase 5 lineage mismatch")
    if trajectory_stage.windowed_stage_artifact_hash != windowed_stage.artifact_hash:
        raise ValueError("Phase 7 historical Phase 6/Phase 4 lineage mismatch")
    if trajectory_stage.geometry_artifact_hash != geometry.artifact_hash:
        raise ValueError("Phase 7 historical Phase 6 geometry lineage mismatch")
    if trajectory_stage.bootstrap_artifact_hash != windowed_stage.bootstrap_artifact_hash:
        raise ValueError("Phase 7 historical Phase 6 bootstrap lineage mismatch")
    if (
        trajectory_stage.fixed_mass_step_stage_artifact_hash
        != fixed_mass_step_stage.artifact_hash
    ):
        raise ValueError("Phase 7 historical Phase 6/Phase 5 lineage mismatch")
    if (
        fixed_mass_step_stage.adapter_signature != adapter_signature
        or trajectory_stage.adapter_signature != adapter_signature
    ):
        raise ValueError("Phase 7 historical source adapter signature mismatch")
    if (
        fixed_mass_step_stage.selected_bootstrap_kernel_hash
        != windowed_stage.selected_bootstrap_kernel_hash
        or trajectory_stage.selected_bootstrap_kernel_hash
        != windowed_stage.selected_bootstrap_kernel_hash
    ):
        raise ValueError("Phase 7 historical bootstrap handoff lineage mismatch")
    if (
        fixed_mass_step_stage.phase4_hmc_adapter_signature != phase4_signature
        or trajectory_stage.phase4_hmc_adapter_signature != phase4_signature
    ):
        raise ValueError("Phase 7 historical Phase 4 adapter lineage mismatch")
    if (
        fixed_mass_step_stage.ladder_hmc_adapter_signature != verification_signature
        or trajectory_stage.phase5_ladder_hmc_adapter_signature
        != verification_signature
        or trajectory_stage.trajectory_hmc_adapter_signature != verification_signature
    ):
        raise ValueError("Phase 7 historical fixed-mass adapter lineage mismatch")
    if (
        fixed_mass_step_stage.adapted_mass_artifact_signature != mass_signature
        or trajectory_stage.adapted_mass_artifact_signature != mass_signature
    ):
        raise ValueError("Phase 7 historical adapted mass lineage mismatch")
    if (
        fixed_mass_step_stage.target_dimension != geometry.target_dimension
        or trajectory_stage.target_dimension != geometry.target_dimension
    ):
        raise ValueError("Phase 7 historical source dimension mismatch")
    if fixed_mass_step_stage.selected_step_payload is None:
        raise ValueError("Phase 7 historical verification requires selected step payload")
    selected_step_hash = fixed_mass_step_stage.selected_step_hash
    if selected_step_hash is None or stable_config_hash(
        fixed_mass_step_stage.selected_step_payload
    ) != selected_step_hash:
        raise ValueError("Phase 7 historical selected step hash mismatch")
    step = _required_selected_step_size(fixed_mass_step_stage)
    if (
        trajectory_stage.selected_step_hash != selected_step_hash
        or trajectory_stage.frozen_step_size != step
    ):
        raise ValueError("Phase 7 historical Phase 6 step mismatch")
    trajectory_payload = trajectory_stage.selected_trajectory_payload
    trajectory_hash = trajectory_stage.selected_trajectory_hash
    if (
        trajectory_payload is None
        or trajectory_hash is None
        or stable_config_hash(trajectory_payload) != trajectory_hash
    ):
        raise ValueError("Phase 7 historical selected trajectory hash mismatch")
    leapfrog = trajectory_stage.selected_num_leapfrog_steps
    if leapfrog is None or int(leapfrog) <= 0:
        raise ValueError("Phase 7 historical verification requires selected L")
    if (
        int(trajectory_payload.get("num_leapfrog_steps", 0)) != int(leapfrog)
        or float(trajectory_payload.get("step_size", float("nan"))) != step
        or str(trajectory_payload.get("selected_step_hash", "")) != selected_step_hash
        or str(trajectory_payload.get("target_scope", "")) != scope
        or str(
            trajectory_payload.get("fixed_mass_step_stage_artifact_hash", "")
        )
        != fixed_mass_step_stage.artifact_hash
        or str(trajectory_payload.get("adapted_mass_artifact_signature", ""))
        != mass_signature
        or str(trajectory_payload.get("phase4_hmc_adapter_signature", ""))
        != phase4_signature
        or str(trajectory_payload.get("trajectory_hmc_adapter_signature", ""))
        != verification_signature
        or str(trajectory_payload.get("selected_bootstrap_kernel_hash", ""))
        != windowed_stage.selected_bootstrap_kernel_hash
    ):
        raise ValueError("Phase 7 historical selected trajectory mechanics mismatch")
    verification_seed = _derive_seed(
        _phase7_attempt_seed(config.seed, int(attempt_index)),
        stage_index=4,
    )
    return _HMCPhase7FixedKernelVerificationInput(
        source_kind="historical_phase6",
        attempt_index=attempt_index,
        target_scope=scope,
        target_dimension=geometry.target_dimension,
        windowed_stage_artifact_hash=windowed_stage.artifact_hash,
        adapted_mass_artifact_signature=mass_signature,
        fixed_mass_step_stage_artifact_hash=fixed_mass_step_stage.artifact_hash,
        candidate_batch_hash=None,
        candidate_identity=None,
        candidate_record_hash=None,
        operational_selection_signature=None,
        operational_candidate_signature=None,
        trajectory_stage_artifact_hash=trajectory_stage.artifact_hash,
        selected_step_hash=selected_step_hash,
        step_size=step,
        num_leapfrog_steps=int(leapfrog),
        adapter_signature=adapter_signature,
        phase4_adapter_signature=phase4_signature,
        verification_hmc_adapter_signature=verification_signature,
        verification_seed=verification_seed,
        seed_policy=_PHASE7_HISTORICAL_PHASE6_SEED_POLICY,
        coordinate_signature=None,
        metric_signature=None,
        trajectory_signature=None,
        start_bank_signature=None,
    )


def _phase7_direct_candidate_verification_input(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_index: int,
    target_scope: str,
    candidate_identity: tuple[int, int, str, int],
) -> _HMCPhase7FixedKernelVerificationInput:
    """Normalize one eligible Phase 5 record without constructing Phase 6."""

    handoff = _phase5_candidate_batch_handoff(fixed_mass_step_stage)
    if handoff is None:
        raise ValueError("direct Phase 7 verification requires Phase 5 candidate batch")
    identity = (
        int(candidate_identity[0]),
        int(candidate_identity[1]),
        str(candidate_identity[2]),
        int(candidate_identity[3]),
    )
    matches = tuple(
        record
        for record in handoff.candidate_records
        if (
            record.batch_ordinal,
            record.source_round_index,
            record.source_grid_stage,
            record.source_round_candidate_index,
        )
        == identity
    )
    if len(matches) != 1:
        raise ValueError("direct Phase 7 candidate identity is missing or ambiguous")
    record = matches[0]
    if not record.handoff_eligible:
        raise ValueError("direct Phase 7 candidate is not handoff eligible")
    if record.hard_vetoes or record.continuation_vetoes:
        raise ValueError("direct Phase 7 candidate carries a pre-verification veto")
    if (
        record.record_hash != stable_config_hash(record.payload())
        or handoff.handoff_hash != stable_config_hash(handoff.payload())
    ):
        raise ValueError("direct Phase 7 candidate hash mismatch")
    scope = str(target_scope)
    if not scope or (config.target_scope is not None and scope != config.target_scope):
        raise ValueError("direct Phase 7 target scope mismatch")
    (
        _adapted_mass,
        mass_signature,
        phase4_adapter,
        verification_adapter,
        verification_signature,
    ) = _phase7_verification_runtime_context(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        target_scope=scope,
    )
    adapter_signature = stable_adapter_signature(adapter)
    phase4_signature = stable_adapter_signature(phase4_adapter)
    context = handoff.source_context
    if (
        context.target_scope != scope
        or context.target_dimension != geometry.target_dimension
        or context.windowed_stage_artifact_hash != windowed_stage.artifact_hash
        or context.selected_bootstrap_kernel_hash
        != windowed_stage.selected_bootstrap_kernel_hash
        or context.adapter_signature != adapter_signature
        or context.phase4_hmc_adapter_signature != phase4_signature
        or context.adapted_mass_artifact_signature != mass_signature
    ):
        raise ValueError("direct Phase 7 candidate batch source lineage mismatch")
    if (
        fixed_mass_step_stage.windowed_stage_artifact_hash != windowed_stage.artifact_hash
        or fixed_mass_step_stage.selected_bootstrap_kernel_hash
        != windowed_stage.selected_bootstrap_kernel_hash
        or fixed_mass_step_stage.adapter_signature != adapter_signature
        or fixed_mass_step_stage.phase4_hmc_adapter_signature != phase4_signature
        or fixed_mass_step_stage.adapted_mass_artifact_signature != mass_signature
        or fixed_mass_step_stage.target_dimension != geometry.target_dimension
    ):
        raise ValueError("direct Phase 7 Phase 5 stage lineage mismatch")
    if (
        not record.ladder_passed
        or not record.selected_step_size_finite
        or record.selected_step_size is None
        or record.selected_step_hash is None
        or record.ladder_artifact_hash is None
        or record.ladder_adapter_signature != phase4_signature
        or record.ladder_hmc_adapter_signature != verification_signature
        or record.ladder_mass_artifact_signature != mass_signature
        or record.ladder_target_scope != scope
        or record.ladder_target_dimension != geometry.target_dimension
    ):
        raise ValueError("direct Phase 7 candidate verifier lineage mismatch")
    if handoff.selected_batch_ordinal == record.batch_ordinal:
        if (
            handoff.selected_record_hash != record.record_hash
            or fixed_mass_step_stage.selected_step_size != record.selected_step_size
            or fixed_mass_step_stage.selected_step_hash != record.selected_step_hash
            or fixed_mass_step_stage.fixed_num_leapfrog_steps
            != record.num_leapfrog_steps
            or fixed_mass_step_stage.budget_ladder_result is None
            or fixed_mass_step_stage.budget_ladder_result.artifact_hash
            != record.ladder_artifact_hash
        ):
            raise ValueError("direct Phase 7 selected candidate/stage mismatch")
    verification_seed = _phase7_direct_candidate_seed(
        config.seed,
        int(attempt_index),
        identity,
    )
    return _HMCPhase7FixedKernelVerificationInput(
        source_kind="direct_phase5_candidate",
        attempt_index=attempt_index,
        target_scope=scope,
        target_dimension=geometry.target_dimension,
        windowed_stage_artifact_hash=windowed_stage.artifact_hash,
        adapted_mass_artifact_signature=mass_signature,
        fixed_mass_step_stage_artifact_hash=fixed_mass_step_stage.artifact_hash,
        candidate_batch_hash=handoff.handoff_hash,
        candidate_identity=identity,
        candidate_record_hash=record.record_hash,
        operational_selection_signature=None,
        operational_candidate_signature=None,
        trajectory_stage_artifact_hash=None,
        selected_step_hash=record.selected_step_hash,
        step_size=float(record.selected_step_size),
        num_leapfrog_steps=record.num_leapfrog_steps,
        adapter_signature=adapter_signature,
        phase4_adapter_signature=phase4_signature,
        verification_hmc_adapter_signature=verification_signature,
        verification_seed=verification_seed,
        seed_policy=_PHASE7_DIRECT_CANDIDATE_SEED_POLICY,
        coordinate_signature=None,
        metric_signature=None,
        trajectory_signature=None,
        start_bank_signature=None,
    )


def _phase7_operational_selection_verification_input(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_index: int,
    target_scope: str,
) -> _HMCPhase7FixedKernelVerificationInput:
    """Normalize the R5 v2 representative without v1 or Phase 6 lineage."""

    selection = fixed_mass_step_stage._operational_selection
    if selection is None or selection.disposition != "representative_selected":
        raise ValueError("operational verification requires a selected R5 authority")
    representative = selection.representative
    if representative is None or representative.exact_l_retuned_step_size is None:
        raise ValueError("operational verification lost exact-L retuning")
    if not fixed_mass_step_stage.passed:
        raise ValueError("operational verification requires passed Phase 5")
    scope = str(target_scope)
    if not scope or (config.target_scope is not None and scope != config.target_scope):
        raise ValueError("operational verification target scope mismatch")
    (
        _adapted_mass,
        mass_signature,
        phase4_adapter,
        verification_adapter,
        verification_signature,
    ) = _phase7_verification_runtime_context(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        target_scope=scope,
    )
    operational = windowed_stage.operational_warmup_result
    if operational is None:
        raise ValueError("operational verification requires operational warmup")
    _active_bank, active_bank_summary = _phase7_verification_initial_state(
        windowed_stage=windowed_stage,
        phase4_adapter=phase4_adapter,
        verification_adapter=verification_adapter,
        verification_hmc_signature=verification_signature,
    )
    active_start_bank_signature = str(
        active_bank_summary.get("active_signature", "")
    )
    candidate = representative.candidate
    selected_trajectory_policy = WarmupTrajectoryPolicy(
        candidate.num_leapfrog_steps,
        operational.final_kernel_state.trajectory_policy.max_leapfrog_steps,
    )
    if (
        fixed_mass_step_stage.windowed_stage_artifact_hash != windowed_stage.artifact_hash
        or fixed_mass_step_stage.adapted_mass_artifact_signature != mass_signature
        or fixed_mass_step_stage.ladder_hmc_adapter_signature != verification_signature
        or fixed_mass_step_stage.fixed_num_leapfrog_steps
        != candidate.num_leapfrog_steps
        or fixed_mass_step_stage.selected_step_size
        != representative.exact_l_retuned_step_size
        or fixed_mass_step_stage.selected_step_hash is None
        or fixed_mass_step_stage.selected_step_payload is None
        or stable_config_hash(fixed_mass_step_stage.selected_step_payload)
        != fixed_mass_step_stage.selected_step_hash
        or candidate.coordinate_signature
        != operational.final_kernel_state.transform.signature
        or candidate.metric_signature
        != operational.final_kernel_state.momentum_metric.signature
        or candidate.start_bank_signature != active_start_bank_signature
    ):
        raise ValueError("operational verification source lineage mismatch")
    verification_seed = paired_candidate_seed(
        _phase7_attempt_seed(config.seed, int(attempt_index)),
        candidate_signature=candidate.signature,
        replication_index=0,
        domain="independent_final_verification",
    )
    return _HMCPhase7FixedKernelVerificationInput(
        source_kind="operational_selection_v2",
        attempt_index=attempt_index,
        target_scope=scope,
        target_dimension=geometry.target_dimension,
        windowed_stage_artifact_hash=windowed_stage.artifact_hash,
        adapted_mass_artifact_signature=mass_signature,
        fixed_mass_step_stage_artifact_hash=fixed_mass_step_stage.artifact_hash,
        candidate_batch_hash=None,
        candidate_identity=None,
        candidate_record_hash=None,
        operational_selection_signature=selection.signature,
        operational_candidate_signature=candidate.signature,
        trajectory_stage_artifact_hash=None,
        selected_step_hash=fixed_mass_step_stage.selected_step_hash,
        step_size=representative.exact_l_retuned_step_size,
        num_leapfrog_steps=candidate.num_leapfrog_steps,
        adapter_signature=stable_adapter_signature(adapter),
        phase4_adapter_signature=stable_adapter_signature(phase4_adapter),
        verification_hmc_adapter_signature=verification_signature,
        verification_seed=verification_seed,
        seed_policy=_PHASE7_OPERATIONAL_SELECTION_SEED_POLICY,
        coordinate_signature=candidate.coordinate_signature,
        metric_signature=candidate.metric_signature,
        trajectory_signature=selected_trajectory_policy.signature,
        start_bank_signature=candidate.start_bank_signature,
    )


def _phase7_operational_repair_verification_input(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_state: _HMCPhaseAttemptState,
    attempt_index: int,
    target_scope: str,
) -> _HMCPhase7FixedKernelVerificationInput:
    """Change only epsilon while preserving the frozen operational kernel."""

    if not _phase7_should_run_operational_repair_verification(attempt_state):
        raise ValueError("operational repair verification state is incomplete")
    handoff = attempt_state.direct_candidate_handoff
    if handoff is not None and handoff.get("source_kind") == "direct_phase5_candidate":
        base = _phase7_direct_candidate_verification_input(
            adapter=adapter, geometry=geometry, windowed_stage=windowed_stage,
            fixed_mass_step_stage=fixed_mass_step_stage,
            candidate_identity=handoff["candidate_identity"], config=config,
            attempt_index=attempt_index, target_scope=target_scope,
        )
        if any(handoff.get(key) != getattr(base, key) for key in (
            "candidate_batch_hash", "candidate_record_hash", "fixed_mass_step_stage_artifact_hash"
        )):
            raise ValueError("direct repair candidate lineage mismatch")
        # The next global attempt index gives this repair an independent seed.
        # Preserve the source candidate identity, metric and leapfrog count.
        return dataclasses.replace(
            base, step_size=attempt_state.verification_repair_step_size,
            selected_step_hash=attempt_state.verification_repair_step_hash, input_hash="",
        )
    base = _phase7_operational_selection_verification_input(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        fixed_mass_step_stage=fixed_mass_step_stage,
        config=config,
        attempt_index=attempt_index,
        target_scope=target_scope,
    )
    handoff = attempt_state.direct_candidate_handoff
    if handoff is None:
        raise ValueError("operational repair verification lost its private handoff")
    expected_lineage = {
        "operational_selection_signature": base.operational_selection_signature,
        "operational_candidate_signature": base.operational_candidate_signature,
        "coordinate_signature": base.coordinate_signature,
        "metric_signature": base.metric_signature,
        "trajectory_signature": base.trajectory_signature,
        "start_bank_signature": base.start_bank_signature,
    }
    if any(handoff.get(key) != value for key, value in expected_lineage.items()):
        raise ValueError("operational repair verification signature lineage mismatch")
    if (
        attempt_state.verification_repair_step_size is None
        or attempt_state.verification_repair_step_hash is None
    ):
        raise ValueError("operational repair verification lost its repaired epsilon")
    bracket_state = attempt_state.verified_acceptance_bracket_state
    is_midpoint = bool(
        bracket_state is not None
        and bracket_state.get("phase") == "midpoint_pending"
    )
    seed_domain = (
        "verified_bracket_midpoint" if is_midpoint else "repair_verification"
    )
    seed_policy = (
        _PHASE7_OPERATIONAL_BRACKET_MIDPOINT_SEED_POLICY
        if is_midpoint
        else _PHASE7_OPERATIONAL_REPAIR_SEED_POLICY
    )
    verification_seed = paired_candidate_seed(
        _phase7_attempt_seed(config.seed, int(attempt_index)),
        candidate_signature=str(base.operational_candidate_signature),
        replication_index=0,
        domain=seed_domain,
    )
    return dataclasses.replace(
        base,
        selected_step_hash=attempt_state.verification_repair_step_hash,
        step_size=attempt_state.verification_repair_step_size,
        verification_seed=verification_seed,
        seed_policy=seed_policy,
        input_hash="",
    )


def _phase7_operational_evidence_extension_input(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    attempt_index: int,
    target_scope: str,
) -> _HMCPhase7FixedKernelVerificationInput:
    base = _phase7_operational_selection_verification_input(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        fixed_mass_step_stage=fixed_mass_step_stage,
        config=config,
        attempt_index=attempt_index,
        target_scope=target_scope,
    )
    verification_seed = paired_candidate_seed(
        _phase7_attempt_seed(config.seed, int(attempt_index)),
        candidate_signature=str(base.operational_candidate_signature),
        replication_index=0,
        domain="evidence_extension",
    )
    return dataclasses.replace(
        base,
        verification_seed=verification_seed,
        seed_policy=_PHASE7_OPERATIONAL_EVIDENCE_EXTENSION_SEED_POLICY,
        input_hash="",
    )


def _frozen_step_trajectory_public_summary(
    stage: HMCFrozenStepTrajectoryStageResult | None,
) -> Mapping[str, Any] | None:
    """Summarize Phase 6 without exposing candidate grids or HMC mechanics."""

    if stage is None:
        return None
    candidate_results = tuple(stage.candidate_results)
    relation_counts = {
        "below_acceptance_band": 0,
        "inside_acceptance_band": 0,
        "above_acceptance_band": 0,
        "unavailable": 0,
    }
    trajectory_window_relations_seen = tuple(
        sorted(
            {
                str(candidate.get("trajectory_window_relation", "unavailable"))
                for candidate in candidate_results
            }
        )
    )
    for candidate in candidate_results:
        diagnostics = candidate.get("diagnostics")
        acceptance = (
            diagnostics.get("acceptance_rate") if isinstance(diagnostics, Mapping) else None
        )
        relation = _acceptance_relation_to_band(acceptance, stage.config.acceptance_band)
        relation_counts[relation] += 1
    selected_relation = "unavailable"
    if stage.selected_candidate_index is not None:
        selected = candidate_results[int(stage.selected_candidate_index)]
        diagnostics = selected.get("diagnostics")
        selected_relation = _acceptance_relation_to_band(
            diagnostics.get("acceptance_rate") if isinstance(diagnostics, Mapping) else None,
            stage.config.acceptance_band,
        )
    runner_route = stage.diagnostics.get("runner_route_summary")
    route_summary = None
    if isinstance(runner_route, Mapping):
        route_summary = {
            "active_route": runner_route.get("active_route"),
            "reusable_runner_build_count": runner_route.get("reusable_runner_build_count"),
            "distinct_static_runner_contract_count": runner_route.get(
                "distinct_static_runner_contract_count"
            ),
            "single_use_build_count": runner_route.get("single_use_build_count"),
            "injected_runner_call_count": runner_route.get("injected_runner_call_count"),
            "fallback_status": runner_route.get("fallback_status"),
        }
    timeout_closeout = stage.diagnostics.get("public_timeout_closeout")
    public_timeout_closeout = None
    if isinstance(timeout_closeout, Mapping):
        allowed_timeout_keys = {
            "enabled",
            "timeout_budget_s",
            "reserve_s",
            "elapsed_s",
            "remaining_s",
            "within_closeout_window",
            "deadline_clock_scope",
            "stage_elapsed_s",
            "stage_remaining_s",
            "estimated_next_candidate_s",
            "completed_candidate_elapsed_count",
            "closeout_required_before_next_candidate",
            "diagnostic_role",
            "candidate_index",
            "candidate_count",
            "completed_candidate_count",
            "progress_only",
            "public_closeout_artifact_expected",
            "reason",
            "hmc_mechanics_exposed",
            "reports_posterior_convergence",
            "reports_sampler_superiority",
            "reports_default_readiness",
            "reports_gpu_or_xla_readiness",
        }
        public_timeout_closeout = {
            key: timeout_closeout[key]
            for key in allowed_timeout_keys
            if key in timeout_closeout
        }
    return {
        "schema": "bayesfilter.hmc_frozen_step_trajectory_public_summary.v1",
        "final_status": stage.final_status,
        "diagnostic_role": stage.diagnostic_role,
        "candidate_count": int(
            stage.diagnostics.get("expected_candidate_count", len(candidate_results))
        ),
        "completed_candidate_count": int(
            stage.diagnostics.get("completed_candidate_count", len(candidate_results))
        ),
        "skipped_candidate_count": int(
            stage.diagnostics.get("skipped_candidate_count", 0)
        ),
        "passed_candidate_count": int(stage.diagnostics.get("passed_candidate_count", 0)),
        "nomination_candidate_count": int(
            stage.diagnostics.get("nomination_candidate_count", 0)
        ),
        "selected_candidate_index": stage.selected_candidate_index,
        "selected_acceptance_relation": selected_relation,
        "candidate_acceptance_relation_counts": relation_counts,
        "verification_repair_neighborhood_applied": bool(
            stage.candidate_generation.get("verification_repair_neighborhood_applied", False)
        ),
        "hard_vetoes": stage.hard_vetoes,
        "repair_triggers": stage.repair_triggers,
        "phase6_handoff_screen_policy_role": stage.diagnostics.get(
            "phase6_handoff_screen_policy_role",
            _PHASE6_HANDOFF_SCREEN_POLICY_ROLE,
        ),
        "phase6_handoff_screen_is_fresh_final_verification": bool(
            stage.diagnostics.get(
                "phase6_handoff_screen_is_fresh_final_verification",
                False,
            )
        ),
        "phase6_handoff_screen_is_posterior_or_sampler_validity_evidence": bool(
            stage.diagnostics.get(
                "phase6_handoff_screen_is_posterior_or_sampler_validity_evidence",
                False,
            )
        ),
        "handoff_screen_policy": stage.diagnostics.get(
            "handoff_screen_policy",
            stage.config.handoff_screen_policy,
        ),
        "trajectory_window_policy_role": stage.diagnostics.get(
            "trajectory_window_policy_role",
            _TRAJECTORY_WINDOW_POLICY_ROLE,
        ),
        "trajectory_window_viability_gate_active": bool(
            stage.diagnostics.get("trajectory_window_viability_gate_active", True)
        ),
        "trajectory_window_nomination_only": bool(
            stage.diagnostics.get("trajectory_window_nomination_only", False)
        ),
        "trajectory_window_relations_seen": tuple(
            stage.diagnostics.get(
                "trajectory_window_relations_seen",
                trajectory_window_relations_seen,
            )
        ),
        "public_timeout_closeout": public_timeout_closeout,
        "runner_route_public_summary": route_summary,
        "candidate_grid_exposed": False,
        "hmc_mechanics_exposed": False,
        "reports_fresh_final_verification": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": FROZEN_STEP_TRAJECTORY_STAGE_NONCLAIMS,
    }


def _run_phase7_final_verification(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    trajectory_stage: HMCFrozenStepTrajectoryStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_index: int,
    target_scope: str,
    verification_callback: VerificationCallback | None,
    checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None,
    verification_start_callback: Callable[[], None] | None,
    checkpoint_reference_callback: Callable[[Mapping[str, Any]], None] | None,
    run_full_chain: RunFullChainFn,
) -> tuple[
    Mapping[str, Any] | None,
    Mapping[str, Any],
    FixedMassHMCTuningBudgetCallbackResult,
    str,
    str,
    tuple[str, ...],
    tuple[str, ...],
]:
    verification_input = _phase7_historical_verification_input(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        fixed_mass_step_stage=fixed_mass_step_stage,
        trajectory_stage=trajectory_stage,
        config=config,
        attempt_index=attempt_index,
        target_scope=target_scope,
    )
    return _run_phase7_fixed_kernel_verification(
        verification_input=verification_input,
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        config=config,
        budget_policy=budget_policy,
        verification_callback=verification_callback,
        checkpoint_writer_config=checkpoint_writer_config,
        verification_start_callback=verification_start_callback,
        checkpoint_reference_callback=checkpoint_reference_callback,
        run_full_chain=run_full_chain,
    ).historical_tuple()


def _run_phase7_direct_candidate_verification(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    candidate_identity: tuple[int, int, str, int],
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_index: int,
    target_scope: str,
    verification_callback: VerificationCallback | None,
    checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None,
    verification_start_callback: Callable[[], None] | None,
    checkpoint_reference_callback: Callable[[Mapping[str, Any]], None] | None,
    run_full_chain: RunFullChainFn,
) -> _HMCPhase7FixedKernelVerificationOutcome:
    verification_input = _phase7_direct_candidate_verification_input(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        fixed_mass_step_stage=fixed_mass_step_stage,
        config=config,
        attempt_index=attempt_index,
        target_scope=target_scope,
        candidate_identity=candidate_identity,
    )
    return _run_phase7_fixed_kernel_verification(
        verification_input=verification_input,
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        config=config,
        budget_policy=budget_policy,
        verification_callback=verification_callback,
        checkpoint_writer_config=checkpoint_writer_config,
        verification_start_callback=verification_start_callback,
        checkpoint_reference_callback=checkpoint_reference_callback,
        run_full_chain=run_full_chain,
    )


def _run_phase7_operational_selection_verification(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_index: int,
    target_scope: str,
    verification_callback: VerificationCallback | None,
    checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None,
    verification_start_callback: Callable[[], None] | None,
    checkpoint_reference_callback: Callable[[Mapping[str, Any]], None] | None,
    run_full_chain: RunFullChainFn,
) -> _HMCPhase7FixedKernelVerificationOutcome:
    verification_input = _phase7_operational_selection_verification_input(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        fixed_mass_step_stage=fixed_mass_step_stage,
        config=config,
        attempt_index=attempt_index,
        target_scope=target_scope,
    )
    return _run_phase7_fixed_kernel_verification(
        verification_input=verification_input,
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        config=config,
        budget_policy=budget_policy,
        verification_callback=verification_callback,
        checkpoint_writer_config=checkpoint_writer_config,
        verification_start_callback=verification_start_callback,
        checkpoint_reference_callback=checkpoint_reference_callback,
        run_full_chain=run_full_chain,
    )


def _run_phase7_operational_repair_verification(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_state: _HMCPhaseAttemptState,
    attempt_index: int,
    target_scope: str,
    verification_callback: VerificationCallback | None,
    checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None,
    verification_start_callback: Callable[[], None] | None,
    checkpoint_reference_callback: Callable[[Mapping[str, Any]], None] | None,
    run_full_chain: RunFullChainFn,
) -> _HMCPhase7FixedKernelVerificationOutcome:
    verification_input = _phase7_operational_repair_verification_input(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        fixed_mass_step_stage=fixed_mass_step_stage,
        config=config,
        attempt_state=attempt_state,
        attempt_index=attempt_index,
        target_scope=target_scope,
    )
    return _run_phase7_fixed_kernel_verification(
        verification_input=verification_input,
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        config=config,
        budget_policy=budget_policy,
        verification_callback=verification_callback,
        checkpoint_writer_config=checkpoint_writer_config,
        verification_start_callback=verification_start_callback,
        checkpoint_reference_callback=checkpoint_reference_callback,
        run_full_chain=run_full_chain,
    )


def _run_phase7_operational_evidence_extension(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_index: int,
    target_scope: str,
    verification_callback: VerificationCallback | None,
    checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None,
    checkpoint_reference_callback: Callable[[Mapping[str, Any]], None] | None,
    run_full_chain: RunFullChainFn,
) -> _HMCPhase7FixedKernelVerificationOutcome:
    verification_input = _phase7_operational_evidence_extension_input(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        fixed_mass_step_stage=fixed_mass_step_stage,
        config=config,
        attempt_index=attempt_index,
        target_scope=target_scope,
    )
    return _run_phase7_fixed_kernel_verification(
        verification_input=verification_input,
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        config=config,
        budget_policy=budget_policy,
        verification_callback=verification_callback,
        checkpoint_writer_config=checkpoint_writer_config,
        verification_start_callback=None,
        checkpoint_reference_callback=checkpoint_reference_callback,
        run_full_chain=run_full_chain,
    )


def _run_phase7_direct_candidate_queue(
    *,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_index: int,
    target_scope: str,
    verification_callback: VerificationCallback | None,
    checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None,
    progress_callback: LoopProgressCallback | None,
    run_full_chain: RunFullChainFn,
    verification_runner: Callable[
        ...,
        _HMCPhase7FixedKernelVerificationOutcome,
    ] | None = None,
) -> _HMCPhase7DirectCandidateQueueResult:
    """Run the audited two-start serial reference queue."""

    candidate_verifier = (
        _run_phase7_direct_candidate_verification
        if verification_runner is None
        else verification_runner
    )
    plan = _phase7_direct_candidate_queue_plan(
        fixed_mass_step_stage=fixed_mass_step_stage,
        config=config,
        budget_policy=budget_policy,
        attempt_index=attempt_index,
    )
    handoff = _phase5_candidate_batch_handoff(fixed_mass_step_stage)
    if handoff is None or handoff.handoff_hash != plan.candidate_batch_hash:
        raise ValueError("direct candidate queue handoff changed after planning")
    records_by_identity = {
        (
            record.batch_ordinal,
            record.source_round_index,
            record.source_grid_stage,
            record.source_round_candidate_index,
        ): record
        for record in handoff.candidate_records
    }
    candidate_results: list[dict[str, Any]] = [
        {
            "candidate_identity": identity,
            "candidate_record_hash": record_hash,
            "verification_seed": seed,
            "state": "not_run",
            "started": False,
            "not_run_reason": "pending",
            "private_handoff_only": True,
        }
        for identity, record_hash, seed in zip(
            plan.candidate_identities,
            plan.candidate_record_hashes,
            plan.verification_seeds,
            strict=True,
        )
    ]
    completed_elapsed_s: list[float] = []
    stage_start = time.perf_counter()
    started_count = 0
    cost_stopped_count = 0
    promotion_vetoed_count = 0
    admitted_outcome: _HMCPhase7FixedKernelVerificationOutcome | None = None
    repair_outcome: _HMCPhase7FixedKernelVerificationOutcome | None = None
    repair_directions: list[str] = []
    representative_outcome: _HMCPhase7FixedKernelVerificationOutcome | None = None
    timeout_closeout: Mapping[str, Any] | None = None
    shared_hard_vetoes: list[str] = []
    all_repair_triggers: list[str] = []

    _emit_phase7_progress(
        progress_callback,
        "direct_verification_queue_start",
        attempt_index=attempt_index,
        budget_policy=budget_policy,
        started=True,
        extra={
            "candidate_count": plan.candidate_count,
            "maximum_candidate_starts": plan.maximum_candidate_starts,
            "seed_map_precomputed": True,
            "phase6_skipped": True,
            "hmc_mechanics_exposed": False,
        },
    )
    stop_reason: str | None = None
    for queue_index, identity in enumerate(plan.candidate_identities):
        record = records_by_identity.get(identity)
        if record is None or record.record_hash != plan.candidate_record_hashes[queue_index]:
            raise ValueError("direct candidate queue record changed after planning")
        if record.hard_vetoes or record.continuation_vetoes:
            candidate_results[queue_index].update(
                {
                    "state": "candidate_local_hard_veto",
                    "not_run_reason": None,
                    "hard_vetoes": tuple(
                        dict.fromkeys([*record.hard_vetoes, *record.continuation_vetoes])
                    ),
                    "failure_origin": "phase5_candidate_record",
                }
            )
            continue
        if started_count >= plan.maximum_candidate_starts:
            candidate_results[queue_index]["not_run_reason"] = "start_quota_exhausted"
            continue
        timeout_closeout = _phase7_direct_candidate_queue_timeout_closeout(
            config=config,
            attempt_index=attempt_index,
            stage_start_perf_counter_s=stage_start,
            completed_elapsed_s=completed_elapsed_s,
        )
        if timeout_closeout is not None:
            candidate_results[queue_index]["not_run_reason"] = "timeout_closeout"
            stop_reason = "timeout_closeout"
            break

        call_started = time.perf_counter()
        started_count += 1
        candidate_results[queue_index].update(
            {
                "started": True,
                "not_run_reason": None,
                "start_ordinal": started_count - 1,
                "verification_num_results": plan.verification_num_results,
                "verification_num_burnin_steps": plan.verification_num_burnin_steps,
            }
        )
        outcome = candidate_verifier(
            adapter=adapter,
            geometry=geometry,
            windowed_stage=windowed_stage,
            fixed_mass_step_stage=fixed_mass_step_stage,
            candidate_identity=identity,
            config=config,
            budget_policy=budget_policy,
            attempt_index=attempt_index,
            target_scope=target_scope,
            verification_callback=verification_callback,
            checkpoint_writer_config=checkpoint_writer_config,
            verification_start_callback=lambda: _emit_phase7_progress(
                progress_callback,
                "verification_start",
                attempt_index=attempt_index,
                budget_policy=budget_policy,
                started=True,
                extra={
                    "queue_index": queue_index,
                    "started_candidate_count": started_count,
                    "maximum_candidate_starts": plan.maximum_candidate_starts,
                    "phase6_skipped": True,
                    "hmc_mechanics_exposed": False,
                },
            ),
            checkpoint_reference_callback=lambda reference: _emit_phase7_progress(
                progress_callback,
                "verification_checkpoint_written",
                attempt_index=attempt_index,
                budget_policy=budget_policy,
                completed=True,
                extra=_phase7_checkpoint_progress_extra(reference),
            ),
            run_full_chain=run_full_chain,
        )
        elapsed_s = max(0.0, time.perf_counter() - call_started)
        completed_elapsed_s.append(elapsed_s)
        expected_seed = plan.verification_seeds[queue_index]
        if (
            not isinstance(outcome, _HMCPhase7FixedKernelVerificationOutcome)
            or outcome.verification_input.source_kind != "direct_phase5_candidate"
            or outcome.verification_input.candidate_identity != identity
            or outcome.verification_input.candidate_record_hash != record.record_hash
            or outcome.verification_input.candidate_batch_hash != handoff.handoff_hash
            or outcome.verification_input.verification_seed != expected_seed
            or outcome.verification_input.attempt_index != int(attempt_index)
        ):
            raise ValueError("direct candidate verifier returned cross-wired lineage")
        representative_outcome = outcome
        outcome_cost_stop_reasons: tuple[str, ...] = ()
        outcome_cost_stop_scope: str | None = None
        outcome_promotion_vetoes = tuple(outcome.callback_result.promotion_vetoes)
        canonical_acceptance_evidence: Mapping[str, Any] | None = None
        outcome_repair_direction: str | None = None
        outcome_evidence_payload = outcome.diagnostics.get("acceptance_evidence")
        if isinstance(outcome_evidence_payload, Mapping):
            try:
                outcome_evidence = hmc_acceptance_evidence_from_payload(
                    outcome_evidence_payload
                )
            except (TypeError, ValueError):
                outcome_evidence = None
            if outcome_evidence is not None:
                canonical_acceptance_evidence = outcome_evidence.payload()
                outcome_repair_direction = outcome_evidence.repair_direction
                outcome_promotion_vetoes = tuple(
                    dict.fromkeys(
                        [
                            *outcome_promotion_vetoes,
                            *outcome_evidence.candidate_promotion_vetoes,
                        ]
                    )
                )
                outcome_cost_stop_reasons = outcome_evidence.cost_stop_reasons
                outcome_cost_stop_scope = outcome_evidence.cost_stop_scope
        candidate_results[queue_index].update(
            {
                "state": outcome.continuation_scope,
                "final_status": outcome.final_status,
                "diagnostic_role": outcome.diagnostic_role,
                "hard_vetoes": outcome.hard_vetoes,
                "repair_triggers": outcome.repair_triggers,
                "acceptance_evidence": canonical_acceptance_evidence,
                "candidate_promotion_vetoes": outcome_promotion_vetoes,
                "repair_direction": outcome_repair_direction,
                "cost_stop_reasons": outcome_cost_stop_reasons,
                "cost_stop_scope": outcome_cost_stop_scope,
                "verification_input_hash": outcome.verification_input.input_hash,
                "elapsed_s": elapsed_s,
            }
        )
        all_repair_triggers.extend(outcome.repair_triggers)
        _emit_phase7_progress(
            progress_callback,
            "verification_complete",
            attempt_index=attempt_index,
            budget_policy=budget_policy,
            completed=True,
            extra={
                "queue_index": queue_index,
                "final_status": outcome.final_status,
                "diagnostic_role": outcome.diagnostic_role,
                "continuation_scope": outcome.continuation_scope,
                "hard_veto_count": len(outcome.hard_vetoes),
                "repair_trigger_count": len(outcome.repair_triggers),
                "phase6_skipped": True,
                "hmc_mechanics_exposed": False,
            },
        )
        if outcome.continuation_scope == "passed":
            admitted_outcome = outcome
            stop_reason = "first_admission"
            break
        if outcome.continuation_scope == "repair_or_retry":
            if repair_outcome is None:
                repair_outcome = outcome
            if outcome_repair_direction is not None:
                repair_directions.append(outcome_repair_direction)
            continue
        if outcome.continuation_scope == "candidate_local_hard_veto":
            continue
        if outcome.continuation_scope == "candidate_local_cost_stop":
            cost_stopped_count += 1
            continue
        if outcome.continuation_scope == "candidate_local_promotion_veto":
            promotion_vetoed_count += 1
            continue
        shared_hard_vetoes.extend(outcome.hard_vetoes)
        if not outcome.hard_vetoes:
            shared_hard_vetoes.append("phase7_direct_queue_shared_continuation_veto")
        stop_reason = "shared_continuation_veto"
        break

    for result in candidate_results:
        if result["state"] != "not_run" or result["not_run_reason"] != "pending":
            continue
        result["not_run_reason"] = stop_reason or "queue_not_started"

    if admitted_outcome is not None:
        final_status = "passed"
        diagnostic_role = admitted_outcome.diagnostic_role
        representative_outcome = admitted_outcome
    elif shared_hard_vetoes:
        final_status = "hard_veto"
        diagnostic_role = "hard_veto"
    elif repair_outcome is not None and _phase7_direct_queue_acceptance_conflict(
        candidate_results, repair_directions,
    ):
        final_status = "repair_or_retry"
        diagnostic_role = "verification_acceptance_conflict"
        representative_outcome = repair_outcome
        all_repair_triggers.append("verification_acceptance_inconclusive_conflict")
    elif repair_outcome is not None:
        final_status = "repair_or_retry"
        diagnostic_role = repair_outcome.diagnostic_role
        representative_outcome = repair_outcome
    elif timeout_closeout is not None:
        final_status = "budget_exhausted"
        diagnostic_role = "phase7_direct_queue_timeout_closeout"
        all_repair_triggers.append("phase7_direct_queue_timeout_closeout")
    elif cost_stopped_count and promotion_vetoed_count:
        final_status = "budget_exhausted"
        diagnostic_role = "candidate_local_nonpromotion_exhausted"
    elif cost_stopped_count:
        final_status = "budget_exhausted"
        diagnostic_role = "candidate_cost_stop_nonpromoting"
    elif promotion_vetoed_count:
        final_status = "budget_exhausted"
        diagnostic_role = "candidate_promotion_veto_nonpromoting"
    else:
        final_status = "architecture_blocked"
        diagnostic_role = "architecture_blocked"
        all_repair_triggers.append("phase7_direct_queue_no_finite_repair_handoff")

    result = _HMCPhase7DirectCandidateQueueResult(
        plan=plan,
        candidate_results=tuple(candidate_results),
        representative_outcome=representative_outcome,
        admitted_outcome=admitted_outcome,
        repair_outcome=repair_outcome,
        repair_directions=tuple(repair_directions),
        final_status=final_status,
        diagnostic_role=diagnostic_role,
        hard_vetoes=tuple(shared_hard_vetoes),
        repair_triggers=tuple(dict.fromkeys(all_repair_triggers)),
        timeout_closeout=timeout_closeout,
    )
    _emit_phase7_progress(
        progress_callback,
        "direct_verification_queue_complete",
        attempt_index=attempt_index,
        budget_policy=budget_policy,
        completed=True,
        extra={
            "final_status": result.final_status,
            "diagnostic_role": result.diagnostic_role,
            "candidate_count": plan.candidate_count,
            "started_count": result.started_count,
            "not_run_count": result.not_run_count,
            "maximum_candidate_starts": plan.maximum_candidate_starts,
            "phase6_skipped": True,
            "hmc_mechanics_exposed": False,
        },
    )
    return result


def _run_phase7_fixed_kernel_verification(
    *,
    verification_input: _HMCPhase7FixedKernelVerificationInput,
    adapter: Any,
    geometry: HMCGeometryInitializationResult,
    windowed_stage: HMCWindowedMassStageResult,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    verification_callback: VerificationCallback | None,
    checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None,
    verification_start_callback: Callable[[], None] | None,
    checkpoint_reference_callback: Callable[[Mapping[str, Any]], None] | None,
    run_full_chain: RunFullChainFn,
) -> _HMCPhase7FixedKernelVerificationOutcome:
    if not isinstance(
        verification_input,
        _HMCPhase7FixedKernelVerificationInput,
    ):
        raise TypeError("verification_input has invalid type")
    if verification_input.input_hash != stable_config_hash(verification_input.payload()):
        raise ValueError("Phase 7 verification input hash mismatch")
    if verification_input.attempt_index != int(budget_policy.attempt_index):
        raise ValueError("Phase 7 verification attempt/budget mismatch")
    if verification_input.target_dimension != int(budget_policy.target_dimension):
        raise ValueError("Phase 7 verification dimension/budget mismatch")
    if (
        config.target_scope is not None
        and verification_input.target_scope != config.target_scope
    ):
        raise ValueError("Phase 7 verification config target scope mismatch")
    (
        adapted_mass,
        mass_signature,
        phase4_adapter,
        verification_adapter,
        verification_hmc_signature,
    ) = _phase7_verification_runtime_context(
        adapter=adapter,
        geometry=geometry,
        windowed_stage=windowed_stage,
        target_scope=verification_input.target_scope,
    )
    expected_runtime = {
        "target_dimension": geometry.target_dimension,
        "windowed_stage_artifact_hash": windowed_stage.artifact_hash,
        "adapted_mass_artifact_signature": mass_signature,
        "adapter_signature": stable_adapter_signature(adapter),
        "phase4_adapter_signature": stable_adapter_signature(phase4_adapter),
        "verification_hmc_adapter_signature": verification_hmc_signature,
    }
    for name, expected in expected_runtime.items():
        if getattr(verification_input, name) != expected:
            raise ValueError(f"Phase 7 normalized runtime mismatch: {name}")
    if run_full_chain is run_full_chain_tfp_hmc:
        execution = _run_phase7_sequential_rhat_final_verification(
            verification_input=verification_input,
            windowed_stage=windowed_stage,
            adapted_mass=adapted_mass,
            mass_signature=mass_signature,
            verification_adapter=verification_adapter,
            verification_hmc_signature=verification_hmc_signature,
            phase4_adapter=phase4_adapter,
            config=config,
            budget_policy=budget_policy,
            verification_callback=verification_callback,
            checkpoint_writer_config=checkpoint_writer_config,
            verification_start_callback=verification_start_callback,
            checkpoint_reference_callback=checkpoint_reference_callback,
        )
    else:
        execution = _run_phase7_injected_final_verification(
            verification_input=verification_input,
            adapted_mass=adapted_mass,
            mass_signature=mass_signature,
            verification_adapter=verification_adapter,
            verification_hmc_signature=verification_hmc_signature,
            phase4_adapter=phase4_adapter,
            config=config,
            budget_policy=budget_policy,
            verification_callback=verification_callback,
            verification_start_callback=verification_start_callback,
            run_full_chain=run_full_chain,
        )
    return _finalize_phase7_fixed_kernel_verification(
        verification_input=verification_input,
        adapted_mass=adapted_mass,
        config=config,
        execution=execution,
    )


def _run_phase7_injected_final_verification(
    *,
    verification_input: _HMCPhase7FixedKernelVerificationInput,
    adapted_mass: PrecomputedMassArtifact,
    mass_signature: str,
    verification_adapter: Any,
    verification_hmc_signature: str,
    phase4_adapter: Any,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    verification_callback: VerificationCallback | None,
    verification_start_callback: Callable[[], None] | None,
    run_full_chain: RunFullChainFn,
) -> _HMCPhase7FixedKernelVerificationExecution:
    step = verification_input.step_size
    leapfrog = verification_input.num_leapfrog_steps
    verification_seed = verification_input.verification_seed
    verification_config = FullChainHMCConfig(
        num_results=_phase7_verification_num_results(config, budget_policy),
        num_burnin_steps=_phase7_verification_num_burnin_steps(
            config,
            budget_policy,
        ),
        step_size=step,
        num_leapfrog_steps=int(leapfrog),
        seed=verification_seed,
        use_xla=config.use_xla,
        trace_policy="standard",
        target_status_trace_policy=config.target_status_trace_policy,
        target_scope=verification_input.target_scope,
        chain_execution_mode=config.chain_execution_mode,
        capture_first_failure=config.chain_execution_mode == "tf_function" and not config.use_xla,
        failure_capture_role="verification",
    )
    runner_cache: dict[str, Any] = {}
    runner_contract_payloads: dict[str, Mapping[str, Any]] = {}
    runner_route_events: list[Mapping[str, Any]] = []
    run_result: FullChainHMCRunResult | None = None
    run_error: Exception | None = None
    try:
        if verification_start_callback is not None:
            verification_start_callback()
        run_result = _run_kernel_stage_with_optional_reusable_route(
            run_full_chain=run_full_chain,
            runner_cache=runner_cache,
            runner_contract_payloads=runner_contract_payloads,
            route_events=runner_route_events,
            route_name="phase7_final_verification_scoped_reusable_runner",
            route_scope="phase7_fresh_fixed_kernel_verification",
            adapter=verification_adapter,
            initial_state=_float64_tensor((0.0,) * adapted_mass.dimension),
            config=verification_config,
            hmc_adapter_signature=verification_hmc_signature,
            target_dimension=verification_input.target_dimension,
            mass_signature=mass_signature,
            event_payload={
                "attempt_index": int(verification_input.attempt_index),
                "num_leapfrog_steps": int(leapfrog),
                "step_size": step,
                "verification_num_results": int(
                    _phase7_verification_num_results(config, budget_policy)
                ),
                "verification_num_burnin_steps": int(
                    _phase7_verification_num_burnin_steps(config, budget_policy)
                ),
            },
        )
        diagnostics = dict(_bootstrap_diagnostics_payload(run_result))
    except Exception as exc:  # noqa: BLE001 - final verification is fail-closed.
        run_error = exc
        diagnostics = dict(_bootstrap_error_diagnostics(exc))
    diagnostics["diagnostic_context"] = "phase7_fresh_fixed_kernel_verification"
    diagnostics["nonclaims"] = TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS
    diagnostics["verification_budget"] = budget_policy.payload()
    diagnostics["runner_route_summary"] = _kernel_stage_runner_route_summary(
        active_route=(
            "phase7_final_verification_scoped_reusable_runner"
            if run_full_chain is run_full_chain_tfp_hmc
            and config.chain_execution_mode == "tf_function"
            else "single_use_or_injected_runner"
        ),
        events=tuple(runner_route_events),
        contract_payloads=runner_contract_payloads,
        semantic_source="_run_phase7_final_verification",
        reuse_nonclaim=(
            "fresh final verification is one call per attempt, so this route is "
            "primarily consistency and regression protection rather than warm-call reuse"
        ),
    )
    callback_samples = None
    sample_conversion_error: Exception | None = None
    if run_result is not None:
        try:
            callback_samples = verification_adapter.latent_to_position(
                run_result.samples
            )
        except Exception as exc:  # noqa: BLE001 - sample conversion is shared invalidity.
            run_error = exc
            sample_conversion_error = exc
            diagnostics.update(_bootstrap_error_diagnostics(exc))
    if sample_conversion_error is not None:
        callback_result = FixedMassHMCTuningBudgetCallbackResult()
        callback_error = None
    else:
        callback_result, callback_error = _call_phase7_verification_callback(
            verification_callback,
            round_payload={
                "attempt_index": verification_input.attempt_index,
                "seed": verification_seed,
                "step_size": step,
                "num_leapfrog_steps": int(leapfrog),
                "trajectory_length": float(step) * int(leapfrog),
                "verification_config_payload": {
                    **verification_config.signature_payload(),
                    "acceptance_band": tuple(float(item) for item in config.acceptance_band),
                },
                "adapter_signature": stable_adapter_signature(phase4_adapter),
                "hmc_adapter_signature": verification_hmc_signature,
                "mass_artifact_signature": mass_signature,
                "sample_space": "phase4_latent_position",
                "hmc_sample_space": "adapted_mass_latent",
                "diagnostic_role": "fresh_fixed_kernel_verification",
            },
            samples=callback_samples,
            diagnostics=diagnostics,
        )
    return _HMCPhase7FixedKernelVerificationExecution(
        verification_config_payload={
            **verification_config.signature_payload(),
            "acceptance_band": tuple(float(item) for item in config.acceptance_band),
        },
        diagnostics=diagnostics,
        callback_result=callback_result,
        runner_error=run_error,
        runner_error_origin=None if run_error is None else "runner",
        callback_error=callback_error,
        observed_step_size=verification_config.step_size,
        observed_num_leapfrog_steps=verification_config.num_leapfrog_steps,
    )


def _run_phase7_sequential_rhat_final_verification(
    *,
    verification_input: _HMCPhase7FixedKernelVerificationInput,
    windowed_stage: HMCWindowedMassStageResult,
    adapted_mass: PrecomputedMassArtifact,
    mass_signature: str,
    verification_adapter: Any,
    verification_hmc_signature: str,
    phase4_adapter: Any,
    config: HMCTuneVerifyRepairLoopConfig,
    budget_policy: _HMCAttemptBudgetPolicy,
    verification_callback: VerificationCallback | None,
    checkpoint_writer_config: SequentialRHatCheckpointWriterConfig | None,
    verification_start_callback: Callable[[], None] | None,
    checkpoint_reference_callback: Callable[[Mapping[str, Any]], None] | None,
) -> _HMCPhase7FixedKernelVerificationExecution:
    step = verification_input.step_size
    leapfrog = verification_input.num_leapfrog_steps
    verification_seed = verification_input.verification_seed
    attempt_index = verification_input.attempt_index
    sequential_target_scope = (
        config.target_scope
        if verification_input.source_kind == "historical_phase6"
        else verification_input.target_scope
    )
    max_results = _phase7_verification_num_results(config, budget_policy)
    configured_chunk = config.verification_chunk_max_results
    check_interval = min(
        64 if configured_chunk is None else int(configured_chunk),
        max_results,
    )
    min_retained_for_pass = (
        check_interval
        if config.verification_min_retained_results_for_pass is None
        else min(int(config.verification_min_retained_results_for_pass), max_results)
    )
    acceptance_policy = HMCAcceptancePolicy(
        target=config.target_accept_prob,
        practical_region=config.acceptance_band,
        repair_region=config.repair_band,
    )
    sequential_config = SequentialRHatHMCVerificationConfig(
        check_interval=check_interval,
        max_results=max_results,
        num_burnin_steps=_phase7_verification_num_burnin_steps(
            config,
            budget_policy,
        ),
        step_size=step,
        num_leapfrog_steps=int(leapfrog),
        seed=verification_seed,
        min_retained_results_for_pass=min_retained_for_pass,
        chain_count=4,
        rhat_threshold=HMC_TUNING_ORDINARY_RHAT_THRESHOLD,
        rhat_role="tuning_explanatory_only",
        acceptance_policy=acceptance_policy,
        use_xla=config.use_xla,
        target_scope=sequential_target_scope,
        chain_execution_mode=config.chain_execution_mode,
    )
    verifier = None
    verifier_error: Exception | None = None
    verification_initial_state = _float64_tensor((0.0,) * adapted_mass.dimension)
    start_bank_summary: Mapping[str, Any] = {
        "source": "unavailable",
        "count": 0,
        "frozen_post_warmup_bank_consumed": False,
        "raw_values_exposed": False,
        "reports_operational_start_lineage": False,
    }
    try:
        verification_initial_state, start_bank_summary = _phase7_verification_initial_state(
            windowed_stage=windowed_stage,
            phase4_adapter=phase4_adapter,
            verification_adapter=verification_adapter,
            verification_hmc_signature=verification_hmc_signature,
        )
        verifier = build_sequential_rhat_hmc_verifier(
            verification_adapter,
            verification_initial_state,
            sequential_config,
        )
        verifier._configure_retained_target_health_policy(
            config.target_status_trace_policy
        )
    except Exception as exc:  # noqa: BLE001 - verifier construction is shared invalidity.
        verifier_error = exc
    checkpoint_references: list[Mapping[str, Any]] = []
    checkpoint_error: Exception | None = None
    if verifier_error is None and checkpoint_writer_config is not None:
        if verification_input.source_kind == "historical_phase6":
            selected_kernel_private_payload = {
                "attempt_index": int(attempt_index),
                "target_scope": config.target_scope,
                "target_dimension": int(adapted_mass.dimension),
                "step_size": float(step),
                "num_leapfrog_steps": int(leapfrog),
                "trajectory_length": float(step) * int(leapfrog),
                "verification_seed": tuple(int(item) for item in verification_seed),
                "mass_artifact_signature": mass_signature,
                "hmc_adapter_signature": verification_hmc_signature,
                "fixed_mass_step_stage_artifact_hash": (
                    verification_input.fixed_mass_step_stage_artifact_hash
                ),
                "frozen_step_trajectory_stage_artifact_hash": (
                    verification_input.trajectory_stage_artifact_hash
                ),
                "private_handoff_only": True,
                "public_progress_exposes_hmc_mechanics": False,
            }
        else:
            selected_kernel_private_payload = {
                "attempt_index": int(attempt_index),
                "target_scope": verification_input.target_scope,
                "target_dimension": int(adapted_mass.dimension),
                "step_size": float(step),
                "num_leapfrog_steps": int(leapfrog),
                "trajectory_length": float(step) * int(leapfrog),
                "verification_seed": tuple(int(item) for item in verification_seed),
                "mass_artifact_signature": mass_signature,
                "hmc_adapter_signature": verification_hmc_signature,
                "fixed_mass_step_stage_artifact_hash": (
                    verification_input.fixed_mass_step_stage_artifact_hash
                ),
                "phase5_candidate_batch_hash": verification_input.candidate_batch_hash,
                "phase5_candidate_identity": verification_input.candidate_identity,
                "phase5_candidate_record_hash": (
                    verification_input.candidate_record_hash
                ),
                "operational_selection_signature": (
                    verification_input.operational_selection_signature
                ),
                "operational_candidate_signature": (
                    verification_input.operational_candidate_signature
                ),
                "coordinate_signature": verification_input.coordinate_signature,
                "metric_signature": verification_input.metric_signature,
                "trajectory_signature": verification_input.trajectory_signature,
                "start_bank_signature": verification_input.start_bank_signature,
                "verification_source_kind": verification_input.source_kind,
                "verification_seed_policy": verification_input.seed_policy,
                "verification_input_hash": verification_input.input_hash,
                "private_handoff_only": True,
                "public_progress_exposes_hmc_mechanics": False,
            }
        try:
            pre_verification_reference = write_sequential_rhat_pre_verification_handoff_checkpoint(
                writer_config=checkpoint_writer_config,
                adapter=verification_adapter,
                config_private_payload=sequential_config.signature_payload(),
                selected_kernel_private_payload=selected_kernel_private_payload,
                mass_payload=adapted_mass.to_payload(include_arrays=True),
                final_state=verification_initial_state,
                retained_count=0,
            )
            checkpoint_references.append(pre_verification_reference)
            if checkpoint_reference_callback is not None:
                checkpoint_reference_callback(pre_verification_reference)
        except Exception as exc:  # noqa: BLE001 - checkpoint failure is shared invalidity.
            checkpoint_error = exc
    if (
        verifier_error is None
        and checkpoint_error is None
        and verification_start_callback is not None
    ):
        verification_start_callback()
    run_error: Exception | None = verifier_error or checkpoint_error
    if run_error is None:
        try:
            def record_checkpoint_reference(reference: Mapping[str, Any]) -> None:
                checkpoint_references.append(reference)
                if checkpoint_reference_callback is not None:
                    checkpoint_reference_callback(reference)

            if verifier is None:
                raise RuntimeError("Phase 7 sequential verifier is unavailable")
            result = verifier.run(
                checkpoint_writer_config=checkpoint_writer_config,
                checkpoint_reference_callback=(
                    None
                    if checkpoint_writer_config is None
                    else record_checkpoint_reference
                ),
            )
            diagnostics = dict(result.diagnostics)
        except Exception as exc:  # noqa: BLE001 - final verification is fail-closed.
            run_error = exc
            diagnostics = dict(_bootstrap_error_diagnostics(exc))
    else:
        diagnostics = dict(_bootstrap_error_diagnostics(run_error))
    if run_error is not None:
        diagnostics["sequential_rhat_verification"] = True
        diagnostics["rhat_role"] = sequential_config.rhat_role
        diagnostics["rhat_threshold"] = HMC_TUNING_ORDINARY_RHAT_THRESHOLD
        diagnostics["check_interval"] = check_interval
        diagnostics["max_results"] = max_results
        diagnostics["verification_min_retained_results_for_pass"] = (
            min_retained_for_pass
        )
    retained_count = _scalar_or_none(diagnostics.get("retained_sample_count"))
    retained_count_int = 0 if retained_count is None else int(retained_count)
    # Preserve the computed R-hat value and pass flag verbatim.  The minimum
    # retained-draw requirement is an independent health/admission check;
    # rewriting a true R-hat result to false conflates the diagnostic with
    # that separate requirement.
    diagnostics["rhat_passed_before_minimum_retained_count"] = bool(
        diagnostics.get("all_finite_rhat_at_or_below_threshold") is True
        and retained_count_int < int(min_retained_for_pass)
    )
    diagnostics["verification_min_retained_results_for_pass"] = int(
        min_retained_for_pass
    )
    diagnostics["verification_retained_sample_count"] = int(retained_count_int)
    diagnostics["verification_min_retained_pass_gate_satisfied"] = bool(
        retained_count_int >= int(min_retained_for_pass)
    )
    diagnostics["diagnostic_context"] = "phase7_sequential_rhat_fixed_kernel_verification"
    diagnostics["nonclaims"] = TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS
    diagnostics["verification_budget"] = budget_policy.payload()
    diagnostics["phase7_checkpointing_enabled"] = checkpoint_writer_config is not None
    diagnostics["phase7_checkpoint_count"] = len(checkpoint_references)
    diagnostics["phase7_checkpoint_references"] = tuple(checkpoint_references)
    diagnostics["verification_start_bank"] = dict(start_bank_summary)
    diagnostics["sequential_rhat_policy"] = {
        "check_interval": check_interval,
        "rhat_threshold": HMC_TUNING_ORDINARY_RHAT_THRESHOLD,
        "rhat_definition": diagnostics.get("rhat_definition"),
        "max_results": max_results,
        "verification_chunk_max_results": configured_chunk,
        "minimum_retained_results_for_pass": int(min_retained_for_pass),
        "retained_sample_count": int(retained_count_int),
        "minimum_retained_pass_gate_satisfied": bool(
            retained_count_int >= int(min_retained_for_pass)
        ),
        "rhat_threshold_role": "tuning_explanatory_only",
        "handoff_gate": (
            "dependence_aware_acceptance_evidence_hard_health_minimum_draws"
        ),
        "stopping_rule": (
            "stop_on_nonpromoting_acceptance_or_first_checkpoint_passing_acceptance_health_minimum_draws"
        ),
        "cap_rule": "stop_inconclusive_at_budget_policy_verification_num_results",
        "acceptance_policy": acceptance_policy.payload(),
        "target_status_trace_policy": config.target_status_trace_policy,
        "retained_target_health_policy": (
            "finite_value_and_score_per_retained_chain_batch"
        ),
        "early_rhat_pass_before_minimum_retained_count": (
            "R-hat is explanatory; minimum retained count remains required"
        ),
        "mechanics_publicized": False,
    }
    diagnostics["runner_route_summary"] = {
        "active_route": "phase7_sequential_rhat_fixed_size_chunk_verifier",
        "single_use_build_count": 0,
        "single_use_call_count": 0,
        "injected_runner_call_count": 0,
        "fallback_status": "none",
        "semantic_source": "_run_phase7_sequential_rhat_final_verification",
        "route_nonclaims": (
            "sequential R-hat final verification uses fixed-size TF/TFP chunks",
            "R-hat is explanatory only and does not gate this tuning handoff",
        ),
        "evidence_role": "fixed_kernel_tuning_admission",
        "promotion_role": "handoff_gate",
        "stopping_rule_role": "acceptance_health_and_minimum_draws_only",
        "rhat_role": "tuning_explanatory_only",
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
    }
    verification_payload = {
        "verification_policy": "sequential_rhat",
        "check_interval": check_interval,
        "max_results": max_results,
        "minimum_retained_results_for_pass": int(min_retained_for_pass),
        "num_burnin_steps": sequential_config.num_burnin_steps,
        "chain_count": sequential_config.chain_count,
        "rhat_threshold": sequential_config.rhat_threshold,
        "rhat_threshold_role": "tuning_explanatory_only",
        "rhat_role": sequential_config.rhat_role,
        "rhat_definition": (
            "max(rank-normalized split R-hat, "
            "folded rank-normalized split R-hat)"
        ),
        "acceptance_band": tuple(float(item) for item in config.acceptance_band),
        "acceptance_policy": acceptance_policy.payload(),
        "use_xla": sequential_config.use_xla,
        "chain_execution_mode": sequential_config.chain_execution_mode,
        "target_scope": sequential_config.target_scope,
        "target_status_trace_policy": config.target_status_trace_policy,
        "retained_target_health_policy": (
            "finite_value_and_score_per_retained_chain_batch"
        ),
        "trace_policy": "private_standard_trace_public_sanitized_v2_evidence",
        "adaptation_policy": "fixed_kernel_no_adaptation",
        "hmc_mechanics_publicized": False,
        "internal_policy_only": True,
    }
    if verifier_error is not None or checkpoint_error is not None:
        callback_result = FixedMassHMCTuningBudgetCallbackResult()
        callback_error = None
    else:
        callback_result, callback_error = _call_phase7_verification_callback(
            verification_callback,
            round_payload={
                "attempt_index": attempt_index,
                "verification_config_payload": verification_payload,
                "adapter_signature": stable_adapter_signature(phase4_adapter),
                "hmc_adapter_signature": verification_hmc_signature,
                "mass_artifact_signature": mass_signature,
                "sample_space": "phase4_latent_position",
                "hmc_sample_space": "adapted_mass_latent",
                "diagnostic_role": "sequential_rhat_fixed_kernel_verification",
                "kernel_mechanics_publicized": False,
            },
            samples=None,
            diagnostics=diagnostics,
        )
    return _HMCPhase7FixedKernelVerificationExecution(
        verification_config_payload=verification_payload,
        diagnostics=diagnostics,
        callback_result=callback_result,
        runner_error=run_error,
        runner_error_origin=(
            None
            if run_error is None
            else "checkpoint"
            if checkpoint_error is not None
            else "runner"
        ),
        callback_error=callback_error,
        observed_step_size=sequential_config.step_size,
        observed_num_leapfrog_steps=sequential_config.num_leapfrog_steps,
    )


def _finalize_phase7_fixed_kernel_verification(
    *,
    verification_input: _HMCPhase7FixedKernelVerificationInput,
    adapted_mass: PrecomputedMassArtifact,
    config: HMCTuneVerifyRepairLoopConfig,
    execution: _HMCPhase7FixedKernelVerificationExecution,
) -> _HMCPhase7FixedKernelVerificationOutcome:
    """Classify once, enforce fixed mechanics once, and assign private scope."""

    diagnostics = dict(execution.diagnostics)
    (
        final_status,
        diagnostic_role,
        hard_vetoes,
        repair_triggers,
    ) = _classify_phase7_final_verification(
        config,
        diagnostics=diagnostics,
        screen_error=execution.runner_error,
        callback_result=execution.callback_result,
    )
    after_mass_signature = _mass_artifact_signature(adapted_mass)
    mass_signature_unchanged = (
        verification_input.adapted_mass_artifact_signature == after_mass_signature
    )
    observed_step = _strict_finite_scalar_or_none(execution.observed_step_size)
    step_size_unchanged = observed_step == verification_input.step_size
    observed_l = _strict_scalar_int_or_none(
        execution.observed_num_leapfrog_steps
    )
    num_leapfrog_steps_unchanged = (
        observed_l == verification_input.num_leapfrog_steps
    )
    invariant = {
        "mass_signature_unchanged": mass_signature_unchanged,
        "kernel_scale_unchanged": step_size_unchanged,
        "trajectory_count_unchanged": num_leapfrog_steps_unchanged,
        "kernel_mechanics_publicized": False,
        "role": "hard_veto",
    }
    diagnostics["frozen_kernel_invariant"] = invariant
    invariant_vetoes: list[str] = []
    if not mass_signature_unchanged:
        invariant_vetoes.append("verification_mass_signature_mutated")
    if not step_size_unchanged:
        invariant_vetoes.append("verification_step_size_mutated")
    if not num_leapfrog_steps_unchanged:
        invariant_vetoes.append("verification_leapfrog_count_mutated")
    if invariant_vetoes:
        final_status = "hard_veto"
        diagnostic_role = "hard_veto"
        hard_vetoes = tuple(dict.fromkeys([*hard_vetoes, *invariant_vetoes]))
        repair_triggers = ()

    if final_status == "passed":
        continuation_scope = "passed"
    elif final_status == "repair_or_retry":
        continuation_scope = "repair_or_retry"
    elif final_status == "budget_exhausted":
        continuation_scope = (
            "candidate_local_cost_stop"
            if diagnostic_role == "candidate_cost_stop_nonpromoting"
            else "candidate_local_promotion_veto"
        )
    elif (
        execution.runner_error is not None
        or execution.callback_error is not None
        or execution.callback_result.continuation_vetoes
        or invariant_vetoes
        or diagnostic_role == "shared_invalidity"
    ):
        continuation_scope = "shared_continuation_veto"
    else:
        continuation_scope = "candidate_local_hard_veto"

    repair_evidence: Mapping[str, Any] | None = None
    acceptance = _scalar_or_none(diagnostics.get("acceptance_rate"))
    acceptance_relation = _acceptance_relation_to_band(
        acceptance,
        config.acceptance_band,
    )
    acceptance_evidence_payload = diagnostics.get("acceptance_evidence")
    acceptance_decision = None
    if isinstance(acceptance_evidence_payload, Mapping):
        try:
            parsed_evidence = hmc_acceptance_evidence_from_payload(
                acceptance_evidence_payload
            )
            acceptance_decision = parsed_evidence.acceptance_decision
        except (TypeError, ValueError):
            acceptance_decision = "invalid"
    if (
        verification_input.source_kind
        in {"direct_phase5_candidate", "operational_selection_v2"}
        and final_status == "repair_or_retry"
        and acceptance is not None
        and math.isfinite(acceptance)
    ):
        repair_evidence = {
            **dict(verification_input.source_identity),
            "fixed_mass_step_stage_artifact_hash": (
                verification_input.fixed_mass_step_stage_artifact_hash
            ),
            "windowed_stage_artifact_hash": (
                verification_input.windowed_stage_artifact_hash
            ),
            "observed_acceptance_rate": float(acceptance),
            "acceptance_band": tuple(float(item) for item in config.acceptance_band),
            "acceptance_relation": acceptance_relation,
            "acceptance_evidence_decision": acceptance_decision,
            "repair_triggers": tuple(repair_triggers),
            "selected_step_hash": verification_input.selected_step_hash,
            "step_size": verification_input.step_size,
            "num_leapfrog_steps": verification_input.num_leapfrog_steps,
            "input_hash": verification_input.input_hash,
            "private_handoff_only": True,
        }
    return _HMCPhase7FixedKernelVerificationOutcome(
        verification_input=verification_input,
        verification_config_payload=execution.verification_config_payload,
        diagnostics=diagnostics,
        callback_result=execution.callback_result,
        final_status=final_status,
        diagnostic_role=diagnostic_role,
        hard_vetoes=hard_vetoes,
        continuation_scope=continuation_scope,
        repair_triggers=repair_triggers,
        repair_evidence=repair_evidence,
    )


def _classify_phase7_final_verification(
    config: HMCTuneVerifyRepairLoopConfig,
    *,
    diagnostics: Mapping[str, Any],
    screen_error: Exception | None,
    callback_result: FixedMassHMCTuningBudgetCallbackResult,
) -> tuple[str, str, tuple[str, ...], tuple[str, ...]]:
    if diagnostics.get("sequential_rhat_verification") is True:
        return _classify_phase7_acceptance_evidence_verification(
            diagnostics=diagnostics,
            screen_error=screen_error,
            callback_result=callback_result,
        )

    # Injected and historical test-only runners retain their v1 compatibility
    # classifier. The repaired operational route above cannot use point estimates.
    hard_vetoes: list[str] = []
    if screen_error is not None:
        hard_vetoes.append("verification_hmc_error")
    acceptance = diagnostics.get("acceptance_rate")
    if acceptance is None or not _finite_number(acceptance):
        hard_vetoes.append("verification_acceptance_missing_or_nonfinite")
    if diagnostics.get("runtime_finite") is not True:
        hard_vetoes.append("verification_runtime_missing_or_nonfinite")
    if not _verification_acceptance_log_health_passed(diagnostics):
        hard_vetoes.append("verification_log_accept_nonfinite_or_missing")
    if diagnostics.get("samples_all_finite") is not True:
        hard_vetoes.append("verification_samples_nonfinite_or_missing")
    if not _verification_target_value_health_passed(diagnostics):
        hard_vetoes.append("verification_target_log_prob_nonfinite_or_missing")
    telemetry = diagnostics.get("target_status_telemetry")
    if isinstance(telemetry, Mapping) and telemetry.get("telemetry_failure_veto_bool"):
        hard_vetoes.append("verification_target_status_telemetry_failure")
    hard_vetoes.extend(callback_result.hard_vetoes)
    if hard_vetoes:
        return "hard_veto", "hard_veto", tuple(dict.fromkeys(hard_vetoes)), ()
    if callback_result.continuation_vetoes:
        return (
            "hard_veto",
            "hard_veto",
            tuple(
                dict.fromkeys(
                    ["verification_callback_continuation_veto", *callback_result.continuation_vetoes]
                )
            ),
            (),
        )
    repair_triggers: list[str] = []
    if callback_result.promotion_vetoes:
        repair_triggers.extend(callback_result.promotion_vetoes)
    if callback_result.repair_triggers:
        repair_triggers.extend(callback_result.repair_triggers)
    if repair_triggers:
        return (
            "repair_or_retry",
            "repair_trigger",
            (),
            tuple(dict.fromkeys(repair_triggers)),
        )
    acceptance_value = float(acceptance)
    if config.acceptance_band[0] <= acceptance_value <= config.acceptance_band[1]:
        return "passed", "fresh_fixed_kernel_verification_passed", (), ()
    return (
        "repair_or_retry",
        "verification_acceptance_repair_trigger",
        (),
        ("verification_acceptance_outside_pass_band",),
    )


def _classify_phase7_acceptance_evidence_verification(
    *,
    diagnostics: Mapping[str, Any],
    screen_error: Exception | None,
    callback_result: FixedMassHMCTuningBudgetCallbackResult,
) -> tuple[str, str, tuple[str, ...], tuple[str, ...]]:
    """Classify operational verification from role-separated v5 evidence."""

    if screen_error is not None:
        return (
            "hard_veto",
            "shared_invalidity",
            ("verification_hmc_error",),
            (),
        )
    if diagnostics.get("runtime_finite") is not True:
        return (
            "hard_veto",
            "shared_invalidity",
            ("verification_runtime_missing_or_nonfinite",),
            (),
        )
    payload = diagnostics.get("acceptance_evidence")
    try:
        evidence = hmc_acceptance_evidence_from_payload(payload)
    except (TypeError, ValueError):
        return (
            "hard_veto",
            "shared_invalidity",
            ("verification_acceptance_evidence_missing_or_invalid",),
            (),
        )
    if evidence.evidence_validity == "valid":
        raw_retained_count = diagnostics.get("retained_sample_count")
        retained_count = _strict_scalar_int_or_none(raw_retained_count)
        if retained_count is None:
            return (
                "hard_veto", "shared_invalidity",
                ("verification_retained_sample_count_invalid",), (),
            )
        evidence_count = (
            evidence.usable_decisions_per_chain
            + evidence.excluded_remainder_per_chain
        )
        if retained_count != evidence_count:
            return (
                "hard_veto", "shared_invalidity",
                ("verification_acceptance_evidence_count_mismatch",), (),
            )
        reported_acceptance = _strict_finite_scalar_or_none(diagnostics.get("acceptance_rate"))
        if reported_acceptance is None:
            return (
                "hard_veto", "shared_invalidity",
                ("verification_acceptance_missing_or_nonfinite",), (),
            )
        if (
            evidence.pooled_mean is not None
            and abs(reported_acceptance - evidence.pooled_mean)
            > 1.0e-12 + 1.0e-12 * abs(evidence.pooled_mean)
        ):
            return (
                "hard_veto",
                "shared_invalidity",
                ("verification_acceptance_evidence_mean_mismatch",),
                (),
            )
    if evidence.evidence_validity == "shared_execution_invalid":
        return (
            "hard_veto",
            "shared_invalidity",
            tuple(
                dict.fromkeys(
                    [
                        "verification_acceptance_shared_invalidity",
                        *evidence.engineering_invalidity_reasons,
                    ]
                )
            ),
            (),
        )
    if callback_result.continuation_vetoes:
        return (
            "hard_veto",
            "shared_invalidity",
            tuple(
                dict.fromkeys(
                    [
                        "verification_callback_continuation_veto",
                        *callback_result.continuation_vetoes,
                    ]
                )
            ),
            (),
        )
    if evidence.evidence_validity == "candidate_data_invalid":
        return (
            "hard_veto",
            "candidate_data_invalid",
            tuple(
                dict.fromkeys(
                    [
                        "verification_acceptance_candidate_data_invalid",
                        *evidence.engineering_invalidity_reasons,
                    ]
                )
            ),
            (),
        )
    if callback_result.hard_vetoes:
        return (
            "hard_veto",
            "candidate_local_hard_veto",
            tuple(dict.fromkeys(callback_result.hard_vetoes)),
            (),
        )
    if (
        evidence.promotion_eligible
        and diagnostics.get("verification_min_retained_pass_gate_satisfied") is not True
    ):
        return (
            "repair_or_retry",
            "verification_minimum_retained_repair_trigger",
            (),
            ("verification_minimum_retained_results_not_reached",),
        )

    callback_repairs = tuple(dict.fromkeys(callback_result.repair_triggers))
    if callback_repairs:
        return "repair_or_retry", "repair_trigger", (), callback_repairs
    if evidence.acceptance_decision in {
        "repair_step_lower",
        "repair_step_higher",
    }:
        return (
            "repair_or_retry",
            "verification_acceptance_repair_trigger",
            (),
            (_PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER,),
        )
    if evidence.acceptance_decision == "repair_trajectory":
        return (
            "repair_or_retry",
            "verification_trajectory_repair_trigger",
            (),
            ("verification_trajectory_repair_required",),
        )
    if evidence.tuning_repair_triggers:
        raise AssertionError("validated tuning repair trigger was not classified")
    if evidence.cost_stop_reasons:
        return (
            "budget_exhausted",
            "candidate_cost_stop_nonpromoting",
            (),
            (),
        )
    if callback_result.promotion_vetoes or evidence.candidate_promotion_vetoes:
        return (
            "budget_exhausted",
            "candidate_promotion_veto_nonpromoting",
            (),
            (),
        )
    if evidence.promotion_eligible:
        # Completion checks describe tuning evidence, not the R-hat result.
        if diagnostics.get("rhat_role") != "tuning_explanatory_only":
            return (
                "hard_veto",
                "shared_invalidity",
                ("verification_tuning_role_missing_or_invalid",),
                (),
            )
        if (
            diagnostics.get("passed") is not True
            or diagnostics.get("cap_hit") is not False
        ):
            return (
                "hard_veto",
                "shared_invalidity",
                ("verification_completion_inconsistent",),
                (),
            )
        return (
            "passed",
            "acceptance_health_fixed_kernel_verification_passed",
            (),
            (),
        )
    if evidence.acceptance_decision == "passed":
        raise AssertionError("nonpromoting passed evidence lost its typed reason")
    if evidence.acceptance_decision == "inconclusive_conflict":
        return (
            "repair_or_retry",
            "verification_acceptance_conflict",
            (),
            ("verification_acceptance_inconclusive_conflict",),
        )
    if evidence.acceptance_decision == "inconclusive_evidence":
        return (
            "repair_or_retry",
            "verification_acceptance_inconclusive",
            (),
            ("verification_acceptance_evidence_inconclusive",),
        )
    raise AssertionError("validated acceptance evidence decision was not classified")


def _phase7_attempt_state_from_stages(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult | None,
    frozen_step_trajectory_stage: HMCFrozenStepTrajectoryStageResult | None,
    verification_config_payload: Mapping[str, Any] | None = None,
    verification_diagnostics: Mapping[str, Any] | None = None,
    verification_final_status: str | None = None,
    verification_diagnostic_role: str | None = None,
    verification_repair_triggers: Sequence[str] = (),
    incoming_state: _HMCPhaseAttemptState | None = None,
    repair_verification_reserved: bool = False,
) -> _HMCPhaseAttemptState:
    mass_artifact = _phase4_adapted_mass_artifact(windowed_stage)
    operational = windowed_stage.operational_warmup_result
    canonical_theta_state = (
        None
        if operational is None
        else operational.final_kernel_state.canonical_theta
    )
    private_start_bank_theta = (
        None if operational is None else operational.private_start_bank_theta
    )
    private_start_bank_signature = (
        None if operational is None else operational.private_start_bank_signature
    )
    step_size = None
    step_hash = None
    fixed_mass_bracket_state = None
    handoff_stage = "phase4"
    leapfrog = None
    if fixed_mass_step_stage is not None:
        if fixed_mass_step_stage.passed:
            step_size = fixed_mass_step_stage.selected_step_size
            step_hash = fixed_mass_step_stage.selected_step_hash
            handoff_stage = "phase5_selected"
        else:
            step_size = fixed_mass_step_stage.repair_step_size
            step_hash = fixed_mass_step_stage.repair_step_hash
            if fixed_mass_step_stage.repair_step_payload is not None:
                raw_bracket_state = fixed_mass_step_stage.repair_step_payload.get(
                    "fixed_mass_bracket_state"
                )
                if isinstance(raw_bracket_state, Mapping):
                    fixed_mass_bracket_state = raw_bracket_state
            handoff_stage = "phase5_repair"
        if fixed_mass_step_stage._operational_selection is not None:
            leapfrog = int(fixed_mass_step_stage.fixed_num_leapfrog_steps)
    trajectory_hash = None
    phase6_retry_l = None
    phase6_retry_anchor_source = None
    if frozen_step_trajectory_stage is not None:
        leapfrog = frozen_step_trajectory_stage.selected_num_leapfrog_steps
        trajectory_hash = frozen_step_trajectory_stage.selected_trajectory_hash
        if frozen_step_trajectory_stage.passed:
            handoff_stage = "phase6"
        else:
            retry_anchor = _phase6_retry_l_anchor_payload(
                config=config,
                frozen_step_trajectory_stage=frozen_step_trajectory_stage,
            )
            phase6_retry_l = retry_anchor["phase6_retry_num_leapfrog_steps"]
            phase6_retry_anchor_source = retry_anchor["phase6_retry_anchor_source"]
    verification_repair = _phase7_verification_repair_handoff_payload(
        config=config,
        selected_step_size=step_size,
        selected_step_hash=step_hash,
        verification_config_payload=verification_config_payload,
        verification_diagnostics=verification_diagnostics,
        verification_final_status=verification_final_status,
        verification_diagnostic_role=verification_diagnostic_role,
        verification_repair_triggers=verification_repair_triggers,
        direction_history=(
            () if incoming_state is None else incoming_state.repair_direction_history
        ),
        repaired_step_history=(
            () if incoming_state is None else incoming_state.repaired_step_history
        ),
        verification_reserved=repair_verification_reserved,
    )
    if (
        not verification_repair["verification_repair_applied"]
        and frozen_step_trajectory_stage is not None
        and (
            verification_config_payload is None
            or (verification_diagnostics or {}).get("not_run") is True
        )
    ):
        verification_repair = _phase6_trajectory_repair_handoff_payload(
            config=config,
            selected_step_size=step_size,
            selected_step_hash=step_hash,
            frozen_step_trajectory_stage=frozen_step_trajectory_stage,
        )
    phase6_bracket_state = verification_repair.get("fixed_mass_bracket_state")
    if isinstance(phase6_bracket_state, Mapping):
        fixed_mass_bracket_state = phase6_bracket_state
    verification_budget_results = None
    if verification_config_payload is not None:
        verification_budget_results = _scalar_or_none(
            verification_config_payload.get("max_results")
            or verification_config_payload.get("num_results")
        )
    return _HMCPhaseAttemptState(
        mass_artifact_payload=mass_artifact.to_payload(include_arrays=True),
        mass_artifact_signature=_mass_artifact_signature(mass_artifact),
        canonical_theta_state=canonical_theta_state,
        private_start_bank_theta=private_start_bank_theta,
        private_start_bank_signature=private_start_bank_signature,
        selected_step_size=step_size,
        selected_step_hash=step_hash,
        selected_num_leapfrog_steps=leapfrog,
        selected_trajectory_hash=trajectory_hash,
        phase6_retry_num_leapfrog_steps=phase6_retry_l,
        phase6_retry_anchor_source=phase6_retry_anchor_source,
        verification_acceptance_rate=verification_repair["verification_acceptance_rate"],
        verification_acceptance_relation=verification_repair["verification_acceptance_relation"],
        verification_repair_trigger=verification_repair["verification_repair_trigger"],
        verification_repair_source=verification_repair["verification_repair_source"],
        verification_repair_step_size=verification_repair["verification_repair_step_size"],
        verification_repair_step_hash=verification_repair["verification_repair_step_hash"],
        verification_repair_applied=verification_repair["verification_repair_applied"],
        verification_repair_max_step_size=verification_repair.get(
            "verification_repair_max_step_size"
        ),
        verification_repair_direction=verification_repair.get(
            "verification_repair_direction"
        ),
        verification_repair_disposition=verification_repair.get(
            "verification_repair_disposition",
            "not_requested",
        ),
        repair_direction_history=verification_repair.get(
            "repair_direction_history",
            () if incoming_state is None else incoming_state.repair_direction_history,
        ),
        repaired_step_history=verification_repair.get(
            "repaired_step_history",
            () if incoming_state is None else incoming_state.repaired_step_history,
        ),
        repair_verification_reserved=verification_repair.get(
            "repair_verification_reserved",
            False,
        ),
        verification_budget_results=None
        if verification_budget_results is None
        else int(verification_budget_results),
        fixed_mass_bracket_state=fixed_mass_bracket_state,
        handoff_stage=handoff_stage,
    )


def _phase7_attempt_state_from_direct_outcome(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    windowed_stage: HMCWindowedMassStageResult,
    outcome: _HMCPhase7FixedKernelVerificationOutcome,
    incoming_state: _HMCPhaseAttemptState | None = None,
    repair_verification_reserved: bool = False,
    suppress_scalar_repair_disposition: str | None = None,
) -> _HMCPhaseAttemptState:
    """Build truthful retry/final state from a Phase 5 candidate, not Phase 6."""

    if not isinstance(outcome, _HMCPhase7FixedKernelVerificationOutcome):
        raise TypeError("direct attempt state requires a normalized outcome")
    verification_input = outcome.verification_input
    if verification_input.source_kind not in {
        "direct_phase5_candidate",
        "operational_selection_v2",
    }:
        raise ValueError("direct attempt state requires a direct private source")
    is_operational = verification_input.source_kind == "operational_selection_v2"
    if (
        verification_input.windowed_stage_artifact_hash != windowed_stage.artifact_hash
        or verification_input.target_dimension != windowed_stage.target_dimension
        or verification_input.adapted_mass_artifact_signature
        != windowed_stage.adapted_mass_artifact_signature
        or verification_input.trajectory_stage_artifact_hash is not None
    ):
        raise ValueError("direct attempt state source lineage mismatch")
    if is_operational:
        if (
            verification_input.operational_selection_signature is None
            or verification_input.operational_candidate_signature is None
            or any(
                value is not None
                for value in (
                    verification_input.candidate_batch_hash,
                    verification_input.candidate_identity,
                    verification_input.candidate_record_hash,
                )
            )
        ):
            raise ValueError("operational attempt state source lineage mismatch")
    elif (
        verification_input.candidate_batch_hash is None
        or verification_input.candidate_identity is None
        or verification_input.candidate_record_hash is None
    ):
        raise ValueError("direct candidate attempt state lineage is incomplete")
    mass_artifact = _phase4_adapted_mass_artifact(windowed_stage)
    operational = windowed_stage.operational_warmup_result
    if _mass_artifact_signature(mass_artifact) != (
        verification_input.adapted_mass_artifact_signature
    ):
        raise ValueError("direct attempt state mass signature mismatch")
    if (
        is_operational
        and config.operational_verification_bracket_policy
        == _OPERATIONAL_VERIFICATION_BRACKET_POLICY_ONE_LOG_MIDPOINT
    ):
        verification_repair = (
            _phase7_operational_verified_bracket_repair_handoff_payload(
                config=config,
                verification_input=verification_input,
                outcome=outcome,
                incoming_state=incoming_state,
                verification_reserved=repair_verification_reserved,
            )
        )
    else:
        verification_repair = _phase7_verification_repair_handoff_payload(
            config=config,
            selected_step_size=verification_input.step_size,
            selected_step_hash=verification_input.selected_step_hash,
            verification_config_payload=outcome.verification_config_payload,
            verification_diagnostics=outcome.diagnostics,
            verification_final_status=outcome.final_status,
            verification_diagnostic_role=outcome.diagnostic_role,
            verification_repair_triggers=outcome.repair_triggers,
            direction_history=(
                () if incoming_state is None else incoming_state.repair_direction_history
            ),
            repaired_step_history=(
                () if incoming_state is None else incoming_state.repaired_step_history
            ),
            verification_reserved=repair_verification_reserved,
            enforce_reservation=is_operational,
            use_directional_trust_region=is_operational,
        )
    if suppress_scalar_repair_disposition is not None:
        disposition = str(suppress_scalar_repair_disposition)
        if disposition != "inconclusive_conflict":
            raise ValueError("unsupported direct queue scalar-repair suppression")
        verification_repair = {
            **dict(verification_repair),
            "verification_acceptance_relation": "unavailable",
            "verification_repair_trigger": None,
            "verification_repair_source": None,
            "verification_repair_step_size": None,
            "verification_repair_step_hash": None,
            "verification_repair_applied": False,
            "verification_repair_direction": None,
            "verification_repair_disposition": disposition,
            "repair_direction_history": (
                () if incoming_state is None else incoming_state.repair_direction_history
            ),
            "repaired_step_history": (
                () if incoming_state is None else incoming_state.repaired_step_history
            ),
            "repair_verification_reserved": False,
            "fixed_mass_bracket_state": None,
            "verified_acceptance_bracket_state": None,
        }
    verification_budget_results = None
    if outcome.verification_config_payload is not None:
        verification_budget_results = _scalar_or_none(
            outcome.verification_config_payload.get("max_results")
            or outcome.verification_config_payload.get("num_results")
        )
    direct_handoff = {
        "source_kind": verification_input.source_kind,
        "fixed_mass_step_stage_artifact_hash": (
            verification_input.fixed_mass_step_stage_artifact_hash
        ),
        "candidate_batch_hash": verification_input.candidate_batch_hash,
        "candidate_identity": verification_input.candidate_identity,
        "candidate_record_hash": verification_input.candidate_record_hash,
        "operational_selection_signature": (
            verification_input.operational_selection_signature
        ),
        "operational_candidate_signature": (
            verification_input.operational_candidate_signature
        ),
        "verification_input_hash": verification_input.input_hash,
        "verification_seed_policy": verification_input.seed_policy,
        "verification_seed": verification_input.verification_seed,
        "coordinate_signature": verification_input.coordinate_signature,
        "metric_signature": verification_input.metric_signature,
        "trajectory_signature": verification_input.trajectory_signature,
        "start_bank_signature": verification_input.start_bank_signature,
        "private_handoff_only": True,
    }
    return _HMCPhaseAttemptState(
        mass_artifact_payload=mass_artifact.to_payload(include_arrays=True),
        mass_artifact_signature=_mass_artifact_signature(mass_artifact),
        canonical_theta_state=(
            None
            if operational is None
            else operational.final_kernel_state.canonical_theta
        ),
        private_start_bank_theta=(
            None if operational is None else operational.private_start_bank_theta
        ),
        private_start_bank_signature=(
            None if operational is None else operational.private_start_bank_signature
        ),
        selected_step_size=verification_input.step_size,
        selected_step_hash=verification_input.selected_step_hash,
        selected_num_leapfrog_steps=verification_input.num_leapfrog_steps,
        selected_trajectory_hash=None,
        verification_acceptance_rate=verification_repair[
            "verification_acceptance_rate"
        ],
        verification_acceptance_relation=verification_repair[
            "verification_acceptance_relation"
        ],
        verification_repair_trigger=verification_repair[
            "verification_repair_trigger"
        ],
        verification_repair_source=verification_repair[
            "verification_repair_source"
        ],
        verification_repair_step_size=verification_repair[
            "verification_repair_step_size"
        ],
        verification_repair_step_hash=verification_repair[
            "verification_repair_step_hash"
        ],
        verification_repair_applied=verification_repair[
            "verification_repair_applied"
        ],
        verification_repair_max_step_size=verification_repair.get(
            "verification_repair_max_step_size"
        ),
        verification_repair_direction=verification_repair.get(
            "verification_repair_direction"
        ),
        verification_repair_disposition=verification_repair.get(
            "verification_repair_disposition",
            "not_requested",
        ),
        repair_direction_history=verification_repair.get(
            "repair_direction_history",
            () if incoming_state is None else incoming_state.repair_direction_history,
        ),
        repaired_step_history=verification_repair.get(
            "repaired_step_history",
            () if incoming_state is None else incoming_state.repaired_step_history,
        ),
        repair_verification_reserved=verification_repair.get(
            "repair_verification_reserved",
            False,
        ),
        fixed_mass_bracket_state=verification_repair.get(
            "fixed_mass_bracket_state"
        ),
        verified_acceptance_bracket_state=verification_repair.get(
            "verified_acceptance_bracket_state"
        ),
        verification_budget_results=(
            None
            if verification_budget_results is None
            else int(verification_budget_results)
        ),
        handoff_stage="phase7_direct",
        direct_candidate_handoff=direct_handoff,
    )


def _phase7_operational_verified_bracket_repair_handoff_payload(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    verification_input: _HMCPhase7FixedKernelVerificationInput,
    outcome: _HMCPhase7FixedKernelVerificationOutcome,
    incoming_state: _HMCPhaseAttemptState | None,
    verification_reserved: bool,
) -> Mapping[str, Any]:
    """Build one bounded empirical bracket from frozen-kernel verifications."""

    diagnostics = dict(outcome.diagnostics)
    acceptance = _scalar_or_none(diagnostics.get("acceptance_rate"))
    evidence: HMCAcceptanceEvidence | None = None
    evidence_payload = diagnostics.get("acceptance_evidence")
    if isinstance(evidence_payload, Mapping):
        try:
            evidence = hmc_acceptance_evidence_from_payload(evidence_payload)
        except (TypeError, ValueError):
            evidence = None
    relation = "unavailable"
    if evidence is not None and evidence.evidence_validity == "valid":
        if evidence.acceptance_decision == "repair_step_lower":
            relation = "below_acceptance_band"
        elif evidence.acceptance_decision == "repair_step_higher":
            relation = "above_acceptance_band"
        elif evidence.acceptance_decision == "passed":
            relation = "inside_acceptance_band"
    triggers = tuple(str(item) for item in outcome.repair_triggers)
    trigger = (
        _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER
        if _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER in triggers
        else None
    )
    direction_history = (
        () if incoming_state is None else incoming_state.repair_direction_history
    )
    step_history = (
        () if incoming_state is None else incoming_state.repaired_step_history
    )
    prior_bracket = (
        None
        if incoming_state is None
        else incoming_state.verified_acceptance_bracket_state
    )
    prior_bracket = _coerce_phase7_verified_acceptance_bracket_state(prior_bracket)

    base_result = {
        "verification_acceptance_rate": acceptance,
        "verification_acceptance_relation": relation,
        "verification_repair_trigger": trigger,
        "verification_repair_source": None,
        "verification_repair_step_size": None,
        "verification_repair_step_hash": None,
        "verification_repair_applied": False,
        "verification_repair_max_step_size": None,
        "verification_repair_direction": None,
        "verification_repair_disposition": (
            "inconclusive_evidence" if trigger is not None else "not_requested"
        ),
        "repair_direction_history": direction_history,
        "repaired_step_history": step_history,
        "repair_verification_reserved": False,
        "fixed_mass_bracket_state": None,
        "verified_acceptance_bracket_state": prior_bracket,
    }

    if prior_bracket is not None and prior_bracket["phase"] == "midpoint_consumed":
        raise ValueError("verified bracket midpoint cannot be reused")
    if prior_bracket is not None and prior_bracket["phase"] == "midpoint_pending":
        if (
            verification_input.seed_policy
            != _PHASE7_OPERATIONAL_BRACKET_MIDPOINT_SEED_POLICY
            or not _all_close(
                verification_input.step_size,
                prior_bracket["midpoint_step_size"],
                rtol=1.0e-12,
                atol=0.0,
            )
            or verification_input.selected_step_hash
            != prior_bracket["midpoint_step_hash"]
        ):
            raise ValueError("verified bracket midpoint input mismatch")
        endpoint = (
            prior_bracket["high_acceptance_endpoint"]
            or prior_bracket["low_acceptance_endpoint"]
        )
        if any(
            endpoint[key] != getattr(verification_input, key)
            for key in _PHASE7_VERIFIED_BRACKET_LINEAGE_KEYS
        ):
            raise ValueError("verified bracket midpoint lineage drift")
        consumed = _phase7_verified_acceptance_bracket_payload(
            high_endpoint=prior_bracket["high_acceptance_endpoint"],
            low_endpoint=prior_bracket["low_acceptance_endpoint"],
            phase="midpoint_consumed",
            midpoint_step_size=prior_bracket["midpoint_step_size"],
            midpoint_step_hash=prior_bracket["midpoint_step_hash"],
            midpoint_verification_input_hash=verification_input.input_hash,
        )
        return {
            **base_result,
            "verified_acceptance_bracket_state": consumed,
        }

    if (
        trigger is None
        or evidence is None
        or evidence.evidence_validity != "valid"
        or evidence.repair_direction not in {"lower_epsilon", "higher_epsilon"}
    ):
        return base_result
    if prior_bracket is None:
        if verification_input.seed_policy != _PHASE7_OPERATIONAL_SELECTION_SEED_POLICY:
            raise ValueError("initial verified endpoint seed policy mismatch")
        current_endpoint = _phase7_verified_endpoint_payload(
            verification_input=verification_input,
            evidence=evidence,
        )
        repair = aggregate_bracketed_step_repair(
            (evidence,),
            base_step_size=verification_input.step_size,
            repair_factor=config.step_repair_factor,
            direction_history=direction_history,
            repaired_step_history=step_history,
            verification_reserved=verification_reserved,
        )
        high_endpoint = (
            current_endpoint
            if current_endpoint["relation"] == "high_acceptance"
            else None
        )
        low_endpoint = (
            current_endpoint
            if current_endpoint["relation"] == "low_acceptance"
            else None
        )
        next_bracket = _phase7_verified_acceptance_bracket_payload(
            high_endpoint=high_endpoint,
            low_endpoint=low_endpoint,
            phase="one_endpoint",
        )
    else:
        if prior_bracket["phase"] != "one_endpoint":
            raise ValueError("verified acceptance bracket phase is not repairable")
        if (
            incoming_state is None
            or incoming_state.verification_repair_step_size is None
            or incoming_state.verification_repair_step_hash is None
            or verification_input.seed_policy
            != _PHASE7_OPERATIONAL_REPAIR_SEED_POLICY
            or not _all_close(
                verification_input.step_size,
                incoming_state.verification_repair_step_size,
                rtol=1.0e-12,
                atol=0.0,
            )
            or verification_input.selected_step_hash
            != incoming_state.verification_repair_step_hash
        ):
            raise ValueError("verified bracket scalar-repair input mismatch")
        current_endpoint = _phase7_verified_endpoint_payload(
            verification_input=verification_input,
            evidence=evidence,
        )
        existing_endpoint = (
            prior_bracket["high_acceptance_endpoint"]
            or prior_bracket["low_acceptance_endpoint"]
        )
        if any(
            existing_endpoint[key] != current_endpoint[key]
            for key in _PHASE7_VERIFIED_BRACKET_LINEAGE_KEYS
        ):
            raise ValueError("verified acceptance endpoint lineage drift")
        if current_endpoint["relation"] == existing_endpoint["relation"]:
            return base_result
        high_endpoint = (
            current_endpoint
            if current_endpoint["relation"] == "high_acceptance"
            else existing_endpoint
        )
        low_endpoint = (
            current_endpoint
            if current_endpoint["relation"] == "low_acceptance"
            else existing_endpoint
        )
        repair = aggregate_bracketed_step_repair(
            (evidence,),
            base_step_size=verification_input.step_size,
            repair_factor=config.step_repair_factor,
            empirical_bracket=(
                float(high_endpoint["step_size"]),
                float(low_endpoint["step_size"]),
            ),
            direction_history=direction_history,
            repaired_step_history=step_history,
            verification_reserved=verification_reserved,
        )
        next_bracket = None

    if repair.disposition != "repair_step":
        return {
            **base_result,
            "verification_repair_disposition": repair.disposition,
            "verified_acceptance_bracket_state": (
                prior_bracket if prior_bracket is not None else next_bracket
            ),
        }
    if (
        repair.repaired_step_size is None
        or repair.direction is None
        or repair.factor is None
    ):
        raise AssertionError("verified bracket repair lost typed mechanics")
    proposal_payload = {
        "schema": "bayesfilter.hmc_phase7_verified_bracket_step_proposal.v1",
        "policy": config.operational_verification_bracket_policy,
        "base_verification_input_hash": verification_input.input_hash,
        "acceptance_evidence_hash": stable_config_hash(evidence.payload()),
        "repair_direction": repair.direction,
        "step_size": repair.repaired_step_size,
        "endpoint_hashes": tuple(
            endpoint["endpoint_hash"]
            for endpoint in (high_endpoint, low_endpoint)
            if endpoint is not None
        ),
        "private_handoff_only": True,
    }
    repair_step_hash = stable_config_hash(proposal_payload)
    if high_endpoint is not None and low_endpoint is not None:
        next_bracket = _phase7_verified_acceptance_bracket_payload(
            high_endpoint=high_endpoint,
            low_endpoint=low_endpoint,
            phase="midpoint_pending",
            midpoint_step_size=repair.repaired_step_size,
            midpoint_step_hash=repair_step_hash,
        )
        repair_source = "phase7_verified_acceptance_bracket_midpoint"
    else:
        repair_source = "phase7_final_verification_acceptance"
    return {
        **base_result,
        "verification_repair_source": repair_source,
        "verification_repair_step_size": repair.repaired_step_size,
        "verification_repair_step_hash": repair_step_hash,
        "verification_repair_applied": True,
        "verification_repair_direction": repair.direction,
        "verification_repair_disposition": repair.disposition,
        "repair_direction_history": (*direction_history, repair.direction),
        "repaired_step_history": (*step_history, repair.repaired_step_size),
        "repair_verification_reserved": bool(verification_reserved),
        "verified_acceptance_bracket_state": next_bracket,
    }


def _phase7_verification_repair_handoff_payload(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    selected_step_size: float | None,
    selected_step_hash: str | None,
    verification_config_payload: Mapping[str, Any] | None,
    verification_diagnostics: Mapping[str, Any] | None,
    verification_final_status: str | None,
    verification_diagnostic_role: str | None,
    verification_repair_triggers: Sequence[str],
    direction_history: Sequence[str] = (),
    repaired_step_history: Sequence[float] = (),
    verification_reserved: bool = False,
    enforce_reservation: bool = False,
    use_directional_trust_region: bool = False,
) -> Mapping[str, Any]:
    diagnostics = {} if verification_diagnostics is None else dict(verification_diagnostics)
    acceptance = _scalar_or_none(diagnostics.get("acceptance_rate"))
    evidence: HMCAcceptanceEvidence | None = None
    evidence_payload = diagnostics.get("acceptance_evidence")
    if isinstance(evidence_payload, Mapping):
        try:
            evidence = hmc_acceptance_evidence_from_payload(evidence_payload)
        except (TypeError, ValueError):
            evidence = None
    relation = "unavailable"
    if (
        evidence is not None
        and evidence.evidence_validity == "valid"
        and evidence.acceptance_decision == "repair_step_lower"
    ):
        relation = "below_acceptance_band"
    elif (
        evidence is not None
        and evidence.evidence_validity == "valid"
        and evidence.acceptance_decision == "repair_step_higher"
    ):
        relation = "above_acceptance_band"
    elif (
        evidence is not None
        and evidence.evidence_validity == "valid"
        and evidence.acceptance_decision == "passed"
    ):
        relation = "inside_acceptance_band"
    elif evidence is None and not enforce_reservation and acceptance is not None:
        if acceptance < float(config.acceptance_band[0]):
            relation = "below_acceptance_band"
        elif acceptance > float(config.acceptance_band[1]):
            relation = "above_acceptance_band"
        else:
            relation = "inside_acceptance_band"
    triggers = tuple(str(item) for item in verification_repair_triggers)
    trigger = (
        _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER
        if _PHASE7_VERIFICATION_ACCEPTANCE_REPAIR_TRIGGER in triggers
        else None
    )
    repair_step_size = None
    repair_step_hash = None
    repair_source = None
    repair_applied = False
    repair_direction = None
    repair_disposition = "not_requested"
    bracket_state = None
    next_direction_history = tuple(str(item) for item in direction_history)
    next_step_history = tuple(float(item) for item in repaired_step_history)
    if (
        trigger is not None
        and relation in {"below_acceptance_band", "above_acceptance_band"}
        and selected_step_size is not None
    ):
        base_step = float(selected_step_size)
        trust_bracket = (
            (base_step / 2.0, base_step * 2.0)
            if use_directional_trust_region
            else (None, None)
        )
        effective_reservation = bool(verification_reserved or not enforce_reservation)
        if evidence is not None:
            repair = aggregate_step_repair(
                (evidence,),
                base_step_size=base_step,
                repair_factor=config.step_repair_factor,
                bracket=trust_bracket,
                direction_history=next_direction_history,
                repaired_step_history=next_step_history,
                verification_reserved=effective_reservation,
            )
            repair_disposition = repair.disposition
            repair_direction = repair.direction
            repair_step_size = repair.repaired_step_size
            directional_factor = repair.factor
        elif not enforce_reservation:
            repair_direction = (
                "lower_epsilon"
                if relation == "below_acceptance_band"
                else "higher_epsilon"
            )
            directional_factor = float(
                min(2.0, max(config.step_repair_min_directional_factor, config.step_repair_factor))
            )
            repair_multiplier = (
                1.0 / directional_factor
                if repair_direction == "lower_epsilon"
                else directional_factor
            )
            repair_step_size = base_step * repair_multiplier
            if trust_bracket[0] is not None:
                repair_step_size = max(repair_step_size, trust_bracket[0])
            if trust_bracket[1] is not None:
                repair_step_size = min(repair_step_size, trust_bracket[1])
            repair_step_size = float(repair_step_size)
            repair_disposition = (
                "repair_step" if effective_reservation else "inconclusive_evidence"
            )
            if not effective_reservation:
                repair_step_size = None
                repair_direction = None
                directional_factor = None
        else:
            raise ValueError(
                "operational verification repair requires validated v3 evidence"
            )
        if repair_disposition != "repair_step":
            return {
                "verification_acceptance_rate": acceptance,
                "verification_acceptance_relation": relation,
                "verification_repair_trigger": trigger,
                "verification_repair_source": None,
                "verification_repair_step_size": None,
                "verification_repair_step_hash": None,
                "verification_repair_applied": False,
                "verification_repair_max_step_size": None,
                "verification_repair_direction": None,
                "verification_repair_disposition": repair_disposition,
                "repair_direction_history": next_direction_history,
                "repaired_step_history": next_step_history,
                "repair_verification_reserved": bool(verification_reserved),
                "fixed_mass_bracket_state": None,
            }
        if repair_step_size is None or directional_factor is None or repair_direction is None:
            raise AssertionError("applied repair lost its typed mechanics")
        if not math.isfinite(repair_step_size) or repair_step_size <= 0.0:
            raise ValueError("verification repair step size must be positive and finite")
        repair_multiplier = repair_step_size / base_step
        next_direction_history = (*next_direction_history, repair_direction)
        next_step_history = (*next_step_history, repair_step_size)
        if use_directional_trust_region:
            bracket_state = {
                "schema": "bayesfilter.fixed_mass_bracket_state.v1",
                "next_step_size": repair_step_size,
                "high_acceptance_step_lower_bound": trust_bracket[0],
                "low_acceptance_step_upper_bound": trust_bracket[1],
                "repair_action": repair_direction,
                "bracket_role": "local_directional_trust_region_not_empirical_acceptance_bracket",
            }
        repair_payload = {
            "runtime": "bayesfilter.inference.hmc_kernel_tuning.phase7_verification_repair",
            "repair_source": "phase7_final_verification_acceptance",
            "verification_final_status": verification_final_status,
            "verification_diagnostic_role": verification_diagnostic_role,
            "verification_repair_trigger": trigger,
            "verification_acceptance_rate": acceptance,
            "verification_acceptance_relation": relation,
            "acceptance_band": tuple(float(item) for item in config.acceptance_band),
            "base_step_size": base_step,
            "base_step_hash": selected_step_hash,
            "acceptance_evidence_decision": (
                None if evidence is None else evidence.acceptance_decision
            ),
            "acceptance_evidence_validity": (
                None if evidence is None else evidence.evidence_validity
            ),
            "repair_factor": directional_factor,
            "repair_multiplier": repair_multiplier,
            "repair_direction": repair_direction,
            "step_size": repair_step_size,
            "fixed_mass_bracket_state": bracket_state,
            "repair_direction_history": next_direction_history,
            "repaired_step_history": next_step_history,
            "repair_verification_reserved": bool(verification_reserved),
            "verification_config_payload": (
                None
                if verification_config_payload is None
                else dict(verification_config_payload)
            ),
            "private_handoff_only": True,
            "public_progress_exposes_step": False,
        }
        repair_step_hash = stable_config_hash(repair_payload)
        repair_source = "phase7_final_verification_acceptance"
        repair_applied = True
        return {
            "verification_acceptance_rate": acceptance,
            "verification_acceptance_relation": relation,
            "verification_repair_trigger": trigger,
            "verification_repair_source": repair_source,
            "verification_repair_step_size": repair_step_size,
            "verification_repair_step_hash": repair_step_hash,
            "verification_repair_applied": repair_applied,
            "verification_repair_max_step_size": None,
            "verification_repair_direction": repair_direction,
            "verification_repair_disposition": repair_disposition,
            "repair_direction_history": next_direction_history,
            "repaired_step_history": next_step_history,
            "repair_verification_reserved": bool(verification_reserved),
            "fixed_mass_bracket_state": bracket_state,
        }
    return {
        "verification_acceptance_rate": acceptance,
        "verification_acceptance_relation": relation,
        "verification_repair_trigger": trigger,
        "verification_repair_source": repair_source,
        "verification_repair_step_size": repair_step_size,
        "verification_repair_step_hash": repair_step_hash,
        "verification_repair_applied": repair_applied,
        "verification_repair_max_step_size": None,
        "verification_repair_direction": None,
        "verification_repair_disposition": repair_disposition,
        "repair_direction_history": next_direction_history,
        "repaired_step_history": next_step_history,
        "repair_verification_reserved": bool(verification_reserved),
        "fixed_mass_bracket_state": None,
    }


def _phase6_retry_l_anchor_payload(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    frozen_step_trajectory_stage: HMCFrozenStepTrajectoryStageResult,
) -> Mapping[str, Any]:
    """Choose a private Phase 6 retry L anchor from failed candidates.

    A failed Phase 6 stage has no selected final trajectory.  The retry still
    needs a private, non-public anchor so the next candidate grid can refine
    the informative failed region instead of rebuilding around only the new
    formula center.  This anchor is diagnostic handoff state only; it is not a
    final kernel selection.
    """

    if (
        frozen_step_trajectory_stage.final_status != "repair_or_retry"
        or not frozen_step_trajectory_stage.candidate_results
    ):
        return {
            "phase6_retry_num_leapfrog_steps": None,
            "phase6_retry_anchor_source": None,
        }
    candidates = tuple(
        candidate
        for candidate in frozen_step_trajectory_stage.candidate_results
        if candidate.get("classification") == "repair_or_retry"
        and candidate.get("num_leapfrog_steps") is not None
    )
    if not candidates:
        return {
            "phase6_retry_num_leapfrog_steps": None,
            "phase6_retry_anchor_source": None,
        }

    def candidate_distance(candidate: Mapping[str, Any]) -> tuple[float, int]:
        explicit_distance = _scalar_or_none(candidate.get("target_trajectory_distance"))
        if explicit_distance is None:
            trajectory = _scalar_or_none(candidate.get("trajectory_length"))
            target = _scalar_or_none(candidate.get("target_trajectory_length"))
            explicit_distance = (
                abs(float(trajectory) - float(target))
                if trajectory is not None and target is not None
                else float("inf")
            )
        return (
            float(explicit_distance),
            int(candidate.get("num_leapfrog_steps")),
        )

    def acceptance_relation(candidate: Mapping[str, Any]) -> str:
        diagnostics = candidate.get("diagnostics")
        acceptance = (
            diagnostics.get("acceptance_rate")
            if isinstance(diagnostics, Mapping)
            else None
        )
        return _acceptance_relation_to_band(acceptance, config.acceptance_band)

    inside_acceptance = tuple(
        candidate
        for candidate in candidates
        if acceptance_relation(candidate) == "inside_acceptance_band"
    )
    if inside_acceptance:
        selected = min(inside_acceptance, key=candidate_distance)
        source = "phase6_failed_candidate_inside_acceptance_nearest_tau"
    else:
        selected = min(candidates, key=candidate_distance)
        source = "phase6_failed_candidate_nearest_tau"
    return {
        "phase6_retry_num_leapfrog_steps": int(selected["num_leapfrog_steps"]),
        "phase6_retry_anchor_source": source,
    }


def _phase6_trajectory_feasible_step_interval(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    frozen_step_trajectory_stage: HMCFrozenStepTrajectoryStageResult,
) -> tuple[float | None, float | None, float | None, float | None]:
    """Private feasible step interval implied by ``tau = L * step``."""

    window = frozen_step_trajectory_stage.candidate_generation.get(
        "trajectory_window"
    )
    if not isinstance(window, Sequence) or len(window) < 2:
        return None, None, None, None
    tau_min = float(window[0])
    tau_max = float(window[1])
    if (
        not math.isfinite(tau_min)
        or not math.isfinite(tau_max)
        or tau_min <= 0.0
        or tau_max <= 0.0
        or tau_min > tau_max
    ):
        return None, None, None, None
    max_l = int(
        frozen_step_trajectory_stage.candidate_generation.get(
            "max_leapfrog_steps",
            config.max_leapfrog_steps,
        )
    )
    max_l = _validate_max_leapfrog_steps(max_l)
    min_l = int(
        frozen_step_trajectory_stage.candidate_generation.get(
            "internal_min_leapfrog",
            _GEOMETRY_MIN_LEAPFROG,
        )
    )
    min_l = max(_GEOMETRY_MIN_LEAPFROG, int(min_l))
    if min_l > max_l:
        min_l = max_l
    lower = tau_min / float(max_l)
    upper = tau_max / float(min_l)
    if (
        not math.isfinite(lower)
        or not math.isfinite(upper)
        or lower <= 0.0
        or upper <= 0.0
    ):
        return None, None, tau_min, tau_max
    if lower > upper:
        return None, None, tau_min, tau_max
    return float(lower), float(upper), float(tau_min), float(tau_max)


def _phase6_clamp_repair_step_to_feasible_tau(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    frozen_step_trajectory_stage: HMCFrozenStepTrajectoryStageResult,
    repair_step_size: float,
) -> tuple[float, Mapping[str, Any]]:
    step = float(repair_step_size)
    if not math.isfinite(step) or step <= 0.0:
        raise ValueError("Phase 6 trajectory repair step size must be positive and finite")
    lower, upper, tau_min, tau_max = _phase6_trajectory_feasible_step_interval(
        config=config,
        frozen_step_trajectory_stage=frozen_step_trajectory_stage,
    )
    if lower is None or upper is None:
        return step, {
            "tau_feasible_step_interval_available": False,
            "tau_feasible_step_floor": lower,
            "tau_feasible_step_ceiling": upper,
            "tau_min": tau_min,
            "tau_max": tau_max,
            "step_floor_applied": False,
            "step_ceiling_applied": False,
        }
    clamped = float(min(upper, max(lower, step)))
    if not math.isfinite(clamped) or clamped <= 0.0:
        raise ValueError(
            "Phase 6 trajectory tau-clamped repair step must be positive and finite"
        )
    return clamped, {
        "tau_feasible_step_interval_available": True,
        "tau_feasible_step_floor": lower,
        "tau_feasible_step_ceiling": upper,
        "tau_min": tau_min,
        "tau_max": tau_max,
        "step_floor_applied": bool(clamped > step),
        "step_ceiling_applied": bool(clamped < step),
    }


def _phase6_fixed_mass_bracket_state_payload(
    *,
    repair_step_size: float,
    acceptance_relation: str,
    repair_source: str,
    tau_feasible_payload: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Private handoff that makes the next fixed-mass stage screen directly."""

    step = float(repair_step_size)
    if not math.isfinite(step) or step <= 0.0:
        raise ValueError("Phase 6 fixed-mass repair step must be positive and finite")
    if acceptance_relation == "above_acceptance_band":
        high_bound: float | None = step
        low_bound: float | None = None
        repair_action = "phase6_high_acceptance_direct_screen"
    elif acceptance_relation == "below_acceptance_band":
        high_bound = None
        low_bound = step
        repair_action = "phase6_low_acceptance_direct_screen"
    else:
        high_bound = None
        low_bound = None
        repair_action = "phase6_trajectory_direct_screen"
    return {
        "schema": "bayesfilter.fixed_mass_bracket_state.v1",
        "next_step_size": step,
        "high_acceptance_step_lower_bound": high_bound,
        "low_acceptance_step_upper_bound": low_bound,
        "bracketed": False,
        "repair_action": repair_action,
        "repair_source": str(repair_source),
        "tau_feasible_handoff": dict(tau_feasible_payload),
        "private_handoff_only": True,
        "public_progress_exposes_step": False,
        "reports_posterior_convergence": False,
    }


def _phase6_trajectory_repair_handoff_payload(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    selected_step_size: float | None,
    selected_step_hash: str | None,
    frozen_step_trajectory_stage: HMCFrozenStepTrajectoryStageResult,
) -> Mapping[str, Any]:
    """Build a private step repair when Phase 6 fails directionally.

    If every completed frozen-step trajectory candidate is on the same side of
    the acceptance pass band, changing only ``L`` cannot repair the observed
    acceptance regime.  The retry therefore adjusts the next Phase 5 initial
    step privately while leaving the public Phase 6 artifact redacted.
    """

    if (
        frozen_step_trajectory_stage.final_status != "repair_or_retry"
        or selected_step_size is None
        or not frozen_step_trajectory_stage.candidate_results
    ):
        return {
            "verification_acceptance_rate": None,
            "verification_acceptance_relation": "unavailable",
            "verification_repair_trigger": None,
            "verification_repair_source": None,
            "verification_repair_step_size": None,
            "verification_repair_step_hash": None,
            "verification_repair_applied": False,
            "verification_repair_max_step_size": None,
        }
    repair_candidates = tuple(
        candidate
        for candidate in frozen_step_trajectory_stage.candidate_results
        if candidate.get("classification") == "repair_or_retry"
    )
    if len(repair_candidates) != len(frozen_step_trajectory_stage.candidate_results):
        return {
            "verification_acceptance_rate": None,
            "verification_acceptance_relation": "unavailable",
            "verification_repair_trigger": None,
            "verification_repair_source": None,
            "verification_repair_step_size": None,
            "verification_repair_step_hash": None,
            "verification_repair_applied": False,
            "verification_repair_max_step_size": None,
        }
    underreach_candidates = tuple(
        candidate
        for candidate in repair_candidates
        if candidate.get("trajectory_window_relation") == "below_trajectory_window"
        or "high_acceptance_trajectory_underreach" in tuple(candidate.get("repair_triggers", ()))
        or "trajectory_length_below_window" in tuple(candidate.get("repair_triggers", ()))
    )
    if len(underreach_candidates) == len(repair_candidates):
        max_l = int(
            frozen_step_trajectory_stage.candidate_generation.get(
                "max_leapfrog_steps",
                config.max_leapfrog_steps,
            )
        )
        max_l = _validate_max_leapfrog_steps(max_l)
        tau_floor_values = tuple(
            _scalar_or_none(candidate.get("minimum_step_size_for_tau_floor"))
            for candidate in underreach_candidates
        )
        tau_floor_values = tuple(
            float(item) for item in tau_floor_values if item is not None
        )
        if not tau_floor_values:
            window = frozen_step_trajectory_stage.candidate_generation.get(
                "trajectory_window"
            )
            if isinstance(window, Sequence) and len(window) >= 1:
                tau_floor_values = (float(window[0]) / max_l,)
        if not tau_floor_values:
            return {
                "verification_acceptance_rate": None,
                "verification_acceptance_relation": "unavailable",
                "verification_repair_trigger": None,
                "verification_repair_source": None,
                "verification_repair_step_size": None,
                "verification_repair_step_hash": None,
                "verification_repair_applied": False,
                "verification_repair_max_step_size": None,
            }
        minimum_step_size_for_tau_floor = max(tau_floor_values)
        repair_step_size = max(float(selected_step_size), minimum_step_size_for_tau_floor)
        if repair_step_size <= float(selected_step_size):
            repair_step_size = max(
                float(selected_step_size) * 2.0,
                minimum_step_size_for_tau_floor,
            )
        if not math.isfinite(repair_step_size) or repair_step_size <= 0.0:
            raise ValueError("Phase 6 trajectory tau repair step size must be positive and finite")
        acceptance_relations = tuple(
            _acceptance_relation_to_band(
                candidate.get("diagnostics", {}).get("acceptance_rate")
                if isinstance(candidate.get("diagnostics"), Mapping)
                else None,
                config.acceptance_band,
            )
            for candidate in underreach_candidates
        )
        unique_acceptance_relations = tuple(dict.fromkeys(acceptance_relations))
        relation = (
            unique_acceptance_relations[0]
            if len(unique_acceptance_relations) == 1
            else "unavailable"
        )
        repair_step_size, tau_feasible_payload = _phase6_clamp_repair_step_to_feasible_tau(
            config=config,
            frozen_step_trajectory_stage=frozen_step_trajectory_stage,
            repair_step_size=repair_step_size,
        )
        repair_source = "phase6_frozen_step_trajectory_underreach"
        bracket_state = _phase6_fixed_mass_bracket_state_payload(
            repair_step_size=repair_step_size,
            acceptance_relation=relation,
            repair_source=repair_source,
            tau_feasible_payload=tau_feasible_payload,
        )
        repair_payload = {
            "runtime": "bayesfilter.inference.hmc_kernel_tuning.phase6_trajectory_repair",
            "repair_source": repair_source,
            "trajectory_final_status": frozen_step_trajectory_stage.final_status,
            "trajectory_diagnostic_role": frozen_step_trajectory_stage.diagnostic_role,
            "verification_repair_trigger": _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
            "verification_acceptance_relation": relation,
            "underreach_acceptance_relations": unique_acceptance_relations,
            "trajectory_candidate_count": len(frozen_step_trajectory_stage.candidate_results),
            "underreach_candidate_count": len(underreach_candidates),
            "acceptance_band": tuple(float(item) for item in config.acceptance_band),
            "base_step_size": float(selected_step_size),
            "base_step_hash": selected_step_hash,
            "minimum_step_size_for_tau_floor": minimum_step_size_for_tau_floor,
            "max_leapfrog_steps": max_l,
            "required_next_l_policy": "include_L_equals_max_or_recompute_ceil_tau_min_over_step",
            "step_size": repair_step_size,
            "tau_feasible_handoff": tau_feasible_payload,
            "fixed_mass_bracket_state": bracket_state,
            "trajectory_stage_artifact_hash": frozen_step_trajectory_stage.artifact_hash,
            "private_handoff_only": True,
            "public_progress_exposes_step": False,
            "public_progress_exposes_candidate_grid": False,
        }
        return {
            "verification_acceptance_rate": None,
            "verification_acceptance_relation": relation,
            "verification_repair_trigger": _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
            "verification_repair_source": repair_source,
            "verification_repair_step_size": repair_step_size,
            "verification_repair_step_hash": stable_config_hash(repair_payload),
            "verification_repair_applied": True,
            "verification_repair_max_step_size": None,
            "fixed_mass_bracket_state": bracket_state,
        }
    overreach_candidates = tuple(
        candidate
        for candidate in repair_candidates
        if candidate.get("trajectory_window_relation") == "above_trajectory_window"
        or "trajectory_length_above_window" in tuple(candidate.get("repair_triggers", ()))
    )
    if len(overreach_candidates) == len(repair_candidates):
        min_l_values = tuple(
            int(candidate.get("num_leapfrog_steps"))
            for candidate in overreach_candidates
            if candidate.get("num_leapfrog_steps") is not None
        )
        min_l = min(min_l_values) if min_l_values else _GEOMETRY_MIN_LEAPFROG
        min_l = max(_GEOMETRY_MIN_LEAPFROG, int(min_l))
        tau_ceiling_values = tuple(
            float(candidate.get("trajectory_window")[1])
            for candidate in overreach_candidates
            if isinstance(candidate.get("trajectory_window"), Sequence)
            and len(candidate.get("trajectory_window")) >= 2
        )
        if not tau_ceiling_values:
            window = frozen_step_trajectory_stage.candidate_generation.get(
                "trajectory_window"
            )
            if isinstance(window, Sequence) and len(window) >= 2:
                tau_ceiling_values = (float(window[1]),)
        if not tau_ceiling_values:
            return {
                "verification_acceptance_rate": None,
                "verification_acceptance_relation": "unavailable",
                "verification_repair_trigger": None,
                "verification_repair_source": None,
                "verification_repair_step_size": None,
                "verification_repair_step_hash": None,
                "verification_repair_applied": False,
                "verification_repair_max_step_size": None,
            }
        maximum_step_size_for_tau_ceiling = min(tau_ceiling_values) / float(min_l)
        repair_step_size = min(
            float(selected_step_size) / 2.0,
            maximum_step_size_for_tau_ceiling,
        )
        if not math.isfinite(repair_step_size) or repair_step_size <= 0.0:
            raise ValueError("Phase 6 trajectory tau-overreach repair step size must be positive and finite")
        acceptance_relations = tuple(
            _acceptance_relation_to_band(
                candidate.get("diagnostics", {}).get("acceptance_rate")
                if isinstance(candidate.get("diagnostics"), Mapping)
                else None,
                config.acceptance_band,
            )
            for candidate in overreach_candidates
        )
        unique_acceptance_relations = tuple(dict.fromkeys(acceptance_relations))
        relation = (
            unique_acceptance_relations[0]
            if len(unique_acceptance_relations) == 1
            else "unavailable"
        )
        repair_step_size, tau_feasible_payload = _phase6_clamp_repair_step_to_feasible_tau(
            config=config,
            frozen_step_trajectory_stage=frozen_step_trajectory_stage,
            repair_step_size=repair_step_size,
        )
        repair_source = "phase6_frozen_step_trajectory_overreach"
        bracket_state = _phase6_fixed_mass_bracket_state_payload(
            repair_step_size=repair_step_size,
            acceptance_relation=relation,
            repair_source=repair_source,
            tau_feasible_payload=tau_feasible_payload,
        )
        repair_payload = {
            "runtime": "bayesfilter.inference.hmc_kernel_tuning.phase6_trajectory_repair",
            "repair_source": repair_source,
            "trajectory_final_status": frozen_step_trajectory_stage.final_status,
            "trajectory_diagnostic_role": frozen_step_trajectory_stage.diagnostic_role,
            "verification_repair_trigger": _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
            "verification_acceptance_relation": relation,
            "overreach_acceptance_relations": unique_acceptance_relations,
            "trajectory_candidate_count": len(frozen_step_trajectory_stage.candidate_results),
            "overreach_candidate_count": len(overreach_candidates),
            "acceptance_band": tuple(float(item) for item in config.acceptance_band),
            "base_step_size": float(selected_step_size),
            "base_step_hash": selected_step_hash,
            "minimum_candidate_leapfrog_steps": min_l,
            "maximum_step_size_for_tau_ceiling": maximum_step_size_for_tau_ceiling,
            "required_next_l_policy": "include_L_equals_min_or_recompute_ceil_tau_over_step",
            "step_size": repair_step_size,
            "tau_feasible_handoff": tau_feasible_payload,
            "fixed_mass_bracket_state": bracket_state,
            "trajectory_stage_artifact_hash": frozen_step_trajectory_stage.artifact_hash,
            "private_handoff_only": True,
            "public_progress_exposes_step": False,
            "public_progress_exposes_candidate_grid": False,
        }
        return {
            "verification_acceptance_rate": None,
            "verification_acceptance_relation": relation,
            "verification_repair_trigger": _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
            "verification_repair_source": repair_source,
            "verification_repair_step_size": repair_step_size,
            "verification_repair_step_hash": stable_config_hash(repair_payload),
            "verification_repair_applied": True,
            "verification_repair_max_step_size": maximum_step_size_for_tau_ceiling,
            "fixed_mass_bracket_state": bracket_state,
        }
    relations = [
        _acceptance_relation_to_band(
            candidate.get("diagnostics", {}).get("acceptance_rate")
            if isinstance(candidate.get("diagnostics"), Mapping)
            else None,
            config.acceptance_band,
        )
        for candidate in repair_candidates
    ]
    unique_relations = set(relations)
    inside_window_candidates = tuple(
        candidate
        for candidate in repair_candidates
        if candidate.get("trajectory_window_relation") == "inside_trajectory_window"
    )
    if (
        inside_window_candidates
        and len(inside_window_candidates) < len(repair_candidates)
        and unique_relations
        not in (
            {"below_acceptance_band"},
            {"above_acceptance_band"},
        )
    ):
        inside_relations = [
            _acceptance_relation_to_band(
                candidate.get("diagnostics", {}).get("acceptance_rate")
                if isinstance(candidate.get("diagnostics"), Mapping)
                else None,
                config.acceptance_band,
            )
            for candidate in inside_window_candidates
        ]
        inside_unique_relations = set(inside_relations)
        if inside_unique_relations in (
            {"below_acceptance_band"},
            {"above_acceptance_band"},
        ):
            relation = next(iter(inside_unique_relations))
            factor = (
                1.0 / float(config.step_repair_factor)
                if relation == "below_acceptance_band"
                else float(config.step_repair_high_acceptance_directional_factor)
            )
            repair_step_size = float(selected_step_size) * factor
            if not math.isfinite(repair_step_size) or repair_step_size <= 0.0:
                raise ValueError(
                    "Phase 6 trajectory inside-window repair step size must be "
                    "positive and finite"
                )
            inside_acceptance_values = tuple(
                float(candidate["diagnostics"]["acceptance_rate"])
                for candidate in inside_window_candidates
                if isinstance(candidate.get("diagnostics"), Mapping)
                and _finite_number(candidate["diagnostics"].get("acceptance_rate"))
            )
            acceptance_summary = None
            if inside_acceptance_values:
                acceptance_summary = {
                    "count": len(inside_acceptance_values),
                    "min": min(inside_acceptance_values),
                    "max": max(inside_acceptance_values),
                }
            repair_step_size, tau_feasible_payload = _phase6_clamp_repair_step_to_feasible_tau(
                config=config,
                frozen_step_trajectory_stage=frozen_step_trajectory_stage,
                repair_step_size=repair_step_size,
            )
            repair_source = "phase6_frozen_step_trajectory_inside_window_acceptance"
            bracket_state = _phase6_fixed_mass_bracket_state_payload(
                repair_step_size=repair_step_size,
                acceptance_relation=relation,
                repair_source=repair_source,
                tau_feasible_payload=tau_feasible_payload,
            )
            repair_payload = {
                "runtime": "bayesfilter.inference.hmc_kernel_tuning.phase6_trajectory_repair",
                "repair_source": repair_source,
                "trajectory_final_status": frozen_step_trajectory_stage.final_status,
                "trajectory_diagnostic_role": frozen_step_trajectory_stage.diagnostic_role,
                "verification_repair_trigger": _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
                "verification_acceptance_relation": relation,
                "trajectory_candidate_count": len(frozen_step_trajectory_stage.candidate_results),
                "inside_window_candidate_count": len(inside_window_candidates),
                "inside_window_acceptance_summary": acceptance_summary,
                "all_candidate_acceptance_relations": tuple(dict.fromkeys(relations)),
                "inside_window_acceptance_relations": tuple(
                    dict.fromkeys(inside_relations)
                ),
                "acceptance_band": tuple(float(item) for item in config.acceptance_band),
                "base_step_size": float(selected_step_size),
                "base_step_hash": selected_step_hash,
                "repair_factor": factor,
                "step_size": repair_step_size,
                "tau_feasible_handoff": tau_feasible_payload,
                "fixed_mass_bracket_state": bracket_state,
                "trajectory_stage_artifact_hash": frozen_step_trajectory_stage.artifact_hash,
                "private_handoff_only": True,
                "public_progress_exposes_step": False,
                "public_progress_exposes_candidate_grid": False,
            }
            return {
                "verification_acceptance_rate": None,
                "verification_acceptance_relation": relation,
                "verification_repair_trigger": _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
                "verification_repair_source": repair_source,
                "verification_repair_step_size": repair_step_size,
                "verification_repair_step_hash": stable_config_hash(repair_payload),
                "verification_repair_applied": True,
                "verification_repair_max_step_size": (
                    repair_step_size
                    if tau_feasible_payload.get("step_ceiling_applied") is True
                    else None
                ),
                "fixed_mass_bracket_state": bracket_state,
            }
    if len(relations) != len(repair_candidates) or unique_relations not in (
        {"below_acceptance_band"},
        {"above_acceptance_band"},
    ):
        return {
            "verification_acceptance_rate": None,
            "verification_acceptance_relation": "unavailable",
            "verification_repair_trigger": None,
            "verification_repair_source": None,
            "verification_repair_step_size": None,
            "verification_repair_step_hash": None,
            "verification_repair_applied": False,
            "verification_repair_max_step_size": None,
        }
    relation = next(iter(unique_relations))
    factor = 0.5 if relation == "below_acceptance_band" else 2.0
    repair_step_size = float(selected_step_size) * factor
    if not math.isfinite(repair_step_size) or repair_step_size <= 0.0:
        raise ValueError("Phase 6 trajectory repair step size must be positive and finite")
    acceptance_values = tuple(
        float(candidate["diagnostics"]["acceptance_rate"])
        for candidate in frozen_step_trajectory_stage.candidate_results
        if isinstance(candidate.get("diagnostics"), Mapping)
        and _finite_number(candidate["diagnostics"].get("acceptance_rate"))
    )
    acceptance_summary = None
    if acceptance_values:
        acceptance_summary = {
            "count": len(acceptance_values),
            "min": min(acceptance_values),
            "max": max(acceptance_values),
        }
    repair_step_size, tau_feasible_payload = _phase6_clamp_repair_step_to_feasible_tau(
        config=config,
        frozen_step_trajectory_stage=frozen_step_trajectory_stage,
        repair_step_size=repair_step_size,
    )
    repair_source = "phase6_frozen_step_trajectory_acceptance"
    bracket_state = _phase6_fixed_mass_bracket_state_payload(
        repair_step_size=repair_step_size,
        acceptance_relation=relation,
        repair_source=repair_source,
        tau_feasible_payload=tau_feasible_payload,
    )
    repair_payload = {
        "runtime": "bayesfilter.inference.hmc_kernel_tuning.phase6_trajectory_repair",
        "repair_source": repair_source,
        "trajectory_final_status": frozen_step_trajectory_stage.final_status,
        "trajectory_diagnostic_role": frozen_step_trajectory_stage.diagnostic_role,
        "verification_repair_trigger": _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
        "verification_acceptance_relation": relation,
        "trajectory_candidate_count": len(frozen_step_trajectory_stage.candidate_results),
        "trajectory_acceptance_summary": acceptance_summary,
        "acceptance_band": tuple(float(item) for item in config.acceptance_band),
        "base_step_size": float(selected_step_size),
        "base_step_hash": selected_step_hash,
        "repair_factor": factor,
        "step_size": repair_step_size,
        "tau_feasible_handoff": tau_feasible_payload,
        "fixed_mass_bracket_state": bracket_state,
        "trajectory_stage_artifact_hash": frozen_step_trajectory_stage.artifact_hash,
        "private_handoff_only": True,
        "public_progress_exposes_step": False,
        "public_progress_exposes_candidate_grid": False,
    }
    return {
        "verification_acceptance_rate": None,
        "verification_acceptance_relation": relation,
        "verification_repair_trigger": _PHASE6_TRAJECTORY_ACCEPTANCE_REPAIR_TRIGGER,
        "verification_repair_source": repair_source,
        "verification_repair_step_size": repair_step_size,
        "verification_repair_step_hash": stable_config_hash(repair_payload),
        "verification_repair_applied": True,
        "verification_repair_max_step_size": (
            repair_step_size
            if tau_feasible_payload.get("step_ceiling_applied") is True
            else None
        ),
        "fixed_mass_bracket_state": bracket_state,
    }


def _phase7_final_kernel_payload(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    trajectory_stage: HMCFrozenStepTrajectoryStageResult,
    verification_config_payload: Mapping[str, Any] | None,
    verification_diagnostics: Mapping[str, Any],
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_index: int,
    target_scope: str,
) -> Mapping[str, Any]:
    adapted_mass = _phase4_adapted_mass_artifact(windowed_stage)
    if config.mass_policy == "fixed_identity":
        if windowed_stage.config.mass_policy != "fixed_identity":
            raise ValueError("fixed identity final kernel lost Phase 4 policy")
        if fixed_mass_step_stage.config.mass_policy != "fixed_identity":
            raise ValueError("fixed identity final kernel lost Phase 5 policy")
        if trajectory_stage.config.mass_policy != "fixed_identity":
            raise ValueError("fixed identity final kernel lost Phase 6 policy")
        if _mass_artifact_signature(adapted_mass) != windowed_stage.initial_mass_artifact_signature:
            raise ValueError("fixed identity final kernel mass signature mutated")
    step = _required_selected_step_size(fixed_mass_step_stage)
    leapfrog = trajectory_stage.selected_num_leapfrog_steps
    if leapfrog is None:
        raise ValueError("final kernel payload requires selected L")
    return {
        "runtime": "bayesfilter.inference.run_hmc_tune_verify_repair_loop",
        "schema": "bayesfilter.hmc_frozen_kernel_handoff.v1",
        "attempt_index": int(attempt_index),
        "target_scope": target_scope,
        "target_dimension": geometry.target_dimension,
        "adapted_mass_artifact_payload": adapted_mass.to_payload(include_arrays=True),
        "adapted_mass_artifact_signature": _mass_artifact_signature(adapted_mass),
        "mass_policy": config.mass_policy,
        "step_size": float(step),
        "num_leapfrog_steps": int(leapfrog),
        "trajectory_length": float(step) * int(leapfrog),
        "target_accept_prob": config.target_accept_prob,
        "acceptance_band": config.acceptance_band,
        "geometry_artifact_hash": geometry.artifact_hash,
        "bootstrap_artifact_hash": bootstrap.artifact_hash,
        "windowed_stage_artifact_hash": windowed_stage.artifact_hash,
        "fixed_mass_step_stage_artifact_hash": fixed_mass_step_stage.artifact_hash,
        "frozen_step_trajectory_stage_artifact_hash": trajectory_stage.artifact_hash,
        "selected_step_hash": fixed_mass_step_stage.selected_step_hash,
        "selected_trajectory_hash": trajectory_stage.selected_trajectory_hash,
        "verification_config_payload": verification_config_payload,
        "verification_acceptance_rate": verification_diagnostics.get("acceptance_rate"),
        "budget_policy": budget_policy.payload(),
        "fresh_fixed_kernel_verification_passed": True,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _phase7_direct_final_kernel_payload(
    *,
    config: HMCTuneVerifyRepairLoopConfig,
    geometry: HMCGeometryInitializationResult,
    bootstrap: HMCBootstrapScreenResult,
    windowed_stage: HMCWindowedMassStageResult,
    fixed_mass_step_stage: HMCFixedMassStepStageResult,
    outcome: _HMCPhase7FixedKernelVerificationOutcome,
    budget_policy: _HMCAttemptBudgetPolicy,
    attempt_index: int,
    target_scope: str,
) -> Mapping[str, Any]:
    """Emit a replayable private kernel without fabricating Phase 6 lineage."""

    if not isinstance(outcome, _HMCPhase7FixedKernelVerificationOutcome):
        raise TypeError("direct final kernel requires a normalized outcome")
    if outcome.final_status != "passed" or outcome.continuation_scope != "passed":
        raise ValueError("direct final kernel requires an admitted candidate")
    verification_input = outcome.verification_input
    if (
        verification_input.source_kind not in {
            "direct_phase5_candidate",
            "operational_selection_v2",
        }
        or verification_input.attempt_index != int(attempt_index)
        or verification_input.target_scope != str(target_scope)
        or verification_input.target_dimension != geometry.target_dimension
        or verification_input.windowed_stage_artifact_hash != windowed_stage.artifact_hash
        or verification_input.fixed_mass_step_stage_artifact_hash
        != fixed_mass_step_stage.artifact_hash
        or verification_input.trajectory_stage_artifact_hash is not None
    ):
        raise ValueError("direct final kernel source lineage mismatch")
    if verification_input.source_kind == "direct_phase5_candidate":
        if (
            verification_input.candidate_batch_hash is None
            or verification_input.candidate_identity is None
            or verification_input.candidate_record_hash is None
        ):
            raise ValueError("direct final kernel candidate lineage is incomplete")
    elif (
        verification_input.operational_selection_signature is None
        or verification_input.operational_candidate_signature is None
    ):
        raise ValueError("operational final kernel lineage is incomplete")
    adapted_mass = _phase4_adapted_mass_artifact(windowed_stage)
    mass_signature = _mass_artifact_signature(adapted_mass)
    if config.mass_policy == "fixed_identity":
        if (
            windowed_stage.config.mass_policy != "fixed_identity"
            or fixed_mass_step_stage.config.mass_policy != "fixed_identity"
            or mass_signature != windowed_stage.initial_mass_artifact_signature
        ):
            raise ValueError("fixed identity direct final kernel mass signature mutated")
    if mass_signature != verification_input.adapted_mass_artifact_signature:
        raise ValueError("direct final kernel mass signature mismatch")
    step = verification_input.step_size
    leapfrog = verification_input.num_leapfrog_steps
    return {
        "runtime": "bayesfilter.inference.run_hmc_tune_verify_repair_loop",
        "schema": "bayesfilter.hmc_frozen_kernel_handoff.v1",
        "attempt_index": int(attempt_index),
        "target_scope": target_scope,
        "target_dimension": geometry.target_dimension,
        "adapted_mass_artifact_payload": adapted_mass.to_payload(include_arrays=True),
        "adapted_mass_artifact_signature": mass_signature,
        "mass_policy": config.mass_policy,
        "step_size": float(step),
        "num_leapfrog_steps": int(leapfrog),
        "trajectory_length": float(step) * int(leapfrog),
        "target_accept_prob": config.target_accept_prob,
        "acceptance_band": config.acceptance_band,
        "geometry_artifact_hash": geometry.artifact_hash,
        "bootstrap_artifact_hash": bootstrap.artifact_hash,
        "windowed_stage_artifact_hash": windowed_stage.artifact_hash,
        "fixed_mass_step_stage_artifact_hash": fixed_mass_step_stage.artifact_hash,
        "frozen_step_trajectory_stage_artifact_hash": None,
        "selected_step_hash": verification_input.selected_step_hash,
        "selected_trajectory_hash": None,
        "verification_config_payload": outcome.verification_config_payload,
        "verification_acceptance_rate": outcome.diagnostics.get("acceptance_rate"),
        "budget_policy": budget_policy.payload(),
        "verification_source_kind": verification_input.source_kind,
        "verification_hmc_adapter_signature": (
            verification_input.verification_hmc_adapter_signature
        ),
        "phase5_candidate_batch_hash": verification_input.candidate_batch_hash,
        "phase5_candidate_identity": verification_input.candidate_identity,
        "phase5_candidate_record_hash": verification_input.candidate_record_hash,
        "operational_selection_signature": (
            verification_input.operational_selection_signature
        ),
        "operational_candidate_signature": (
            verification_input.operational_candidate_signature
        ),
        "verification_input_hash": verification_input.input_hash,
        "direct_source_private_handoff_only": True,
        "fresh_fixed_kernel_verification_passed": True,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_external_client_scientific_claim": False,
        "reports_gpu_or_xla_readiness": False,
        "nonclaims": TUNE_VERIFY_REPAIR_LOOP_NONCLAIMS,
    }


def _validate_value_score_shapes(*, theta: Any, value: Any, score: Any) -> None:
    theta_shape = theta.shape
    value_shape = value.shape
    score_shape = score.shape
    if theta_shape.rank == 1:
        parameter_dim = theta_shape[-1]
        if parameter_dim is None:
            raise ValueError("scalar theta must have static parameter dimension")
        if value_shape.rank not in (0, None):
            raise ValueError("scalar target value must be rank 0")
        if score_shape.rank != 1:
            raise ValueError("scalar target score must have rank 1")
        if score_shape[-1] is not None and int(score_shape[-1]) != int(parameter_dim):
            raise ValueError("scalar target score parameter dimension mismatch")
        return
    if theta_shape.rank == 2:
        batch_size = theta_shape[0]
        parameter_dim = theta_shape[1]
        if batch_size is None or parameter_dim is None:
            raise ValueError("batched theta must have static batch and parameter dimensions")
        if value_shape.rank != 1:
            raise ValueError("batched target value must be rank 1")
        if score_shape.rank != 2:
            raise ValueError("batched target score must be rank 2")
        if value_shape[0] is not None and int(value_shape[0]) != int(batch_size):
            raise ValueError("batched target value leading dimension mismatch")
        if score_shape[0] is not None and int(score_shape[0]) != int(batch_size):
            raise ValueError("batched target score leading dimension mismatch")
        if score_shape[1] is not None and int(score_shape[1]) != int(parameter_dim):
            raise ValueError("batched target score parameter dimension mismatch")
        return
    raise ValueError("theta must have rank 1 [parameter] or rank 2 [batch, parameter]")
















def _public_failure_diagnostics(*, stage: str, exc: Exception) -> Mapping[str, Any]:
    message = str(exc)
    if len(message) > 2000:
        message = message[:1997] + "..."
    return {
        "schema": "bayesfilter.hmc_tuning_failure_diagnostics.v1",
        "stage": str(stage),
        "exception_type": type(exc).__name__,
        "exception_message": message,
        **({"first_failure_captured": True}
           if getattr(exc, "failure_record", None) is not None else {}),
        "role": "diagnostic_exception_provenance_not_scientific_evidence",
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
    }


def _public_bootstrap_failure_diagnostics(
    bootstrap: HMCBootstrapScreenResult,
) -> Mapping[str, Any]:
    """Summarize a returned bootstrap hard veto without exposing HMC mechanics."""

    last_round = bootstrap.rounds[-1]
    diagnostics = dict(last_round.diagnostics)
    message = diagnostics.get("error_message")
    if message is not None:
        message = str(message)
        if len(message) > 2000:
            message = message[:1997] + "..."
    error_type = diagnostics.get("error_type")
    return {
        "schema": "bayesfilter.hmc_tuning_failure_diagnostics.v1",
        "stage": "bootstrap",
        "diagnostic_stage": str(last_round.diagnostic_role),
        "round_index": int(last_round.round_index),
        "exception_type": None if error_type is None else str(error_type),
        "exception_message": message,
        **({"first_failure_captured": True}
           if diagnostics.get("first_failure") is not None else {}),
        "hard_vetoes": tuple(str(veto) for veto in last_round.hard_vetoes),
        "repair_triggers": tuple(
            str(trigger) for trigger in last_round.repair_triggers
        ),
        "role": "diagnostic_exception_provenance_not_scientific_evidence",
        "hmc_mechanics_exposed": False,
        "reports_posterior_convergence": False,
        "reports_sampler_superiority": False,
        "reports_default_readiness": False,
        "reports_gpu_or_xla_readiness": False,
    }


def _singleton_metadata_value(value: Any) -> Any:
    """Materialize exactly one metadata element without truncating arrays."""

    if value is None:
        return None
    while isinstance(value, (tuple, list)):
        if len(value) != 1:
            return None
        value = value[0]
    if isinstance(value, (bool, int, float, str, bytes)) or value is None:
        return value
    import tensorflow as tf

    tensor = tf.convert_to_tensor(value)
    if int(tf.size(tensor)) != 1:
        return None
    scalar = tf.reshape(tensor, []).numpy()
    return scalar.item() if hasattr(scalar, "item") else scalar


def _strict_scalar_int_or_none(value: Any) -> int | None:
    scalar = _singleton_metadata_value(value)
    if isinstance(scalar, bool):
        return None
    return int(scalar) if isinstance(scalar, Integral) else None


def _strict_finite_scalar_or_none(value: Any) -> float | None:
    scalar = _singleton_metadata_value(value)
    if isinstance(scalar, bool):
        return None
    try:
        result = float(scalar)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if math.isfinite(result) else None
