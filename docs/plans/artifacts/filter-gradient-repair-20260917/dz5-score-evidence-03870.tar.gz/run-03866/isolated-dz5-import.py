
import hashlib
import importlib
import json
import math
import os
import sys
import traceback
from pathlib import Path

BF = Path('/home/ubuntu/workspace/BayesFilter')
MF = Path('/home/ubuntu/workspace/MacroFinance-dz5-neutra')
OUT = Path('/tmp/dz5-output')
sys.path[:0] = [str(MF), str(BF)]
report = {'schema': 'filter_repair_dz5_snapshot_import.v1', 'passed': False,
    'role': 'isolated_CPU_import_and_fixture_reference_only',
    'target_evaluated': False, 'adapter_admitted': False,
    'nonclaims': ['No target, initializer, transition, timing or retained qualification.']}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def diagnostic_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: diagnostic_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [diagnostic_json(item) for item in value]
    return value

try:
    manifest = json.loads(Path('/tmp/dz5-source/manifest.json').read_text())
    report['snapshot_manifest_sha256'] = sha('/tmp/dz5-source/manifest.json')
    expected = {path: entry['sha256'] for path, entry in manifest['sources'].items()}
    assert all(sha(path) == digest for path, digest in expected.items())
    gpu = os.environ['CUDA_VISIBLE_DEVICES'] != '-1'
    assert os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] == 'true'
    import tensorflow as tf
    from bayesfilter.runtime.gpu_memory_policy import configure_tensorflow_gpu_memory_growth
    memory = configure_tensorflow_gpu_memory_growth(tf, require_gpu=gpu)
    devices = tf.config.list_physical_devices('GPU')
    assert len(devices) == (1 if gpu else 0)
    report.update(device='GPU' if gpu else 'CPU',
        trust_basis='owner_designated_managed_session_visible_gpu_trusted' if gpu else 'CPU_reference',
        physical_gpus=[device.name for device in devices])
    report.update(gpu_memory_policy=memory, tensorflow=tf.__version__,
        cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'])

    from bayesfilter_estimation import audit_sources, declared_source_closure
    from two_currency_double_zlb_credit_estimation import (
        TFP_SPECIAL, TFP_SPECIAL_SHA, credit_fixture_identity)
    from two_currency_double_zlb_credit_fixtures import credit_fixture
    from two_currency_double_zlb_credit_target import CREDIT_FILTER_CONTRACT
    importlib.import_module('bayesfilter_estimation_initialization')
    importlib.import_module('two_currency_double_zlb_credit_recovery')
    importlib.import_module('bayesfilter.inference.dense_initializer_seeded_tf')
    importlib.import_module('bayesfilter.inference.tensor_npz_archive')
    assert sha(TFP_SPECIAL) == TFP_SPECIAL_SHA
    fixture = credit_fixture('CDF', n_steps=96)
    identity = credit_fixture_identity(fixture)
    assert identity == 'e116fe853c8579369036ab2ce57724ba07544524d0920fa0a706d76714f75d8a'
    assert len(fixture.parameter_names) == 23 and fixture.observations.shape[0] == 96
    assert CREDIT_FILTER_CONTRACT == 'rectangular_srukf_full_rank_identity_prepared_cir_v2'
    closure = audit_sources(declared_source_closure((
        MF / 'scripts/prepare_dz5_cdf_proposal.py',
        BF / 'bayesfilter/runtime/runner.py')))
    assert all(expected.get(path) == digest for path, digest in closure.items())
    loaded, unexpected = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if not filename:
            continue
        path = Path(filename).resolve()
        named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
        owned = path.is_relative_to(BF) or path.is_relative_to(MF)
        if named or owned:
            digest = sha(path)
            loaded[name] = {'path': str(path), 'sha256': digest}
            if not owned or expected.get(str(path)) != digest:
                unexpected[name] = loaded[name]
    report.update(loaded_modules=loaded, unexpected_modules=unexpected,
        source_closure=closure, fixture_identity=identity,
        parameter_names=fixture.parameter_names, observation_shape=list(fixture.observations.shape),
        filter_contract=CREDIT_FILTER_CONTRACT, tfp_special_sha256=TFP_SPECIAL_SHA)
    assert not unexpected, unexpected
    mounts = {}
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        fields = line.split()
        if fields[4] in (str(BF), str(MF)):
            mounts[fields[4]] = fields[5].split(',')
    report['source_mount_options'] = mounts
    assert set(mounts) == {str(BF), str(MF)}
    assert all('ro' in options for options in mounts.values())
    assert all(sha(path) == digest for path, digest in expected.items())
    expected_sources = expected.copy()

    import resource
    import threading
    import time
    import numpy as np  # Independent finite-difference diagnostic only.
    from two_currency_double_zlb_credit_target import (
        credit_target_value_and_score, credit_target_numeric_outputs)
    jit = os.environ['FILTER_REPAIR_DZ5_SCORE_JIT'] == '1'
    tf.config.experimental.enable_op_determinism()
    tf.config.experimental.enable_tensor_float_32_execution(False)
    qualifier = MF / 'scripts/qualify_dz5_cdf_runtime.py'
    assert sha(qualifier) == manifest['frozen_qualifier_sha256']
    center, scale = np.asarray(fixture.parameter_truth), np.asarray(fixture.prior_scale)
    steps = (1e-3, 5e-4)
    offsets = np.diag(scale)
    bank = np.concatenate((center[None], *(center + multiplier * step * offsets
        for step in steps for multiplier in (-2, -1, 1, 2))))
    assert bank.shape == (185, 23) and bank.dtype == np.float64
    target_device = '/GPU:0' if gpu else '/CPU:0'
    with tf.device(target_device):
        positions = tf.constant(bank)
    def numeric(p):
        if jit:
            fields = credit_target_numeric_outputs(p, fixture)
            return fields[0], fields[1], fields[3], fields[5]
        value, score, diagnostics = credit_target_value_and_score(p, fixture,
            jit_compile=False, evaluation_policy='hmc_rejection')
        return value, score, diagnostics['valid_pre_regularized_score'], diagnostics['branch_status_code']
    kernel = tf.function(numeric, input_signature=[tf.TensorSpec([185, 23], tf.float64)],
        jit_compile=jit, autograph=False)
    report.update(role='fresh_DZ5_independent_five_point_score_oracle',
        source_role=manifest['role'], jit_compile=jit, batch=185,
        target_evaluated=False, target_execution_attempted=True,
        frozen_qualifier_sha256=sha(qualifier), bayesfilter_commit=manifest['bayesfilter_commit'],
        nonclaims=['No new adapter admission, initializer, HMC, posterior or performance qualification.'],
        cpu_reference_exception=not gpu, graph_reference_exception=not jit,
        op_determinism_enabled=True,
        tf32_enabled=tf.config.experimental.tensor_float_32_execution_enabled(),
        affinity=sorted(os.sched_getaffinity(0)))
    def rss():
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):
                return int(line.split()[1]) * 1024
        raise RuntimeError('VmRSS unavailable')
    samples = [rss()]
    stop = threading.Event()
    def sample_memory():
        while not stop.wait(.05):
            samples.append(rss())
    sampler = threading.Thread(target=sample_memory, daemon=True)
    sampler.start()
    try:
        tick = time.monotonic()
        with tf.device(target_device):
            result = kernel(positions)
        arrays = tuple(tensor.numpy() for tensor in result)
        report['cold_seconds'] = time.monotonic() - tick
        report['target_evaluated'] = True
        report['result_device'] = result[0].device
        assert ('DEVICE:GPU:0' if gpu else 'DEVICE:CPU:0') in result[0].device.upper()
        values, scores, validity, branch_status = arrays
        checks = []
        for index, step in enumerate(steps):
            blocks = np.split(values[1 + 92 * index:1 + 92 * (index + 1)], 4)
            finite_difference = (blocks[0] - 8 * blocks[1] + 8 * blocks[2] - blocks[3]) / (12 * step * scale)
            difference = np.abs(scores[0] - finite_difference)
            allowed = 1e-8 + 1e-7 * np.abs(finite_difference)
            checks.append({'step_prior_sd': step, 'finite_difference': finite_difference.tolist(),
                'absolute_error': difference.tolist(), 'allowed_error': allowed.tolist(),
                'max_absolute_error': float(np.max(difference)),
                'max_scaled_error': float(np.max(difference / allowed)),
                'passed': bool(np.all(difference <= allowed))})
        oracle = {'schema': 'filter_repair_dz5_fresh_score_oracle.v1',
            'bank': bank.tolist(), 'values': values.tolist(), 'scores': scores.tolist(),
            'validity': validity.tolist(), 'branch_status': branch_status.tolist(),
            'parameter_names': fixture.parameter_names, 'prior_scale': scale.tolist(),
            'checks': checks, 'jit_compile': jit, 'device': report['device'],
            'snapshot_manifest_sha256': report['snapshot_manifest_sha256'],
            'frozen_qualifier_sha256': report['frozen_qualifier_sha256']}
        # Save actual residuals before enforcing the unchanged gate.
        (OUT / 'dz5-score-oracle.json').write_text(json.dumps(diagnostic_json(oracle), indent=2, allow_nan=False) + '\n')
        report['score_checks'] = checks
        assert np.isfinite(values).all() and np.isfinite(scores).all()
        assert validity.all(), 'An oracle row was rejected'
        assert all(check['passed'] for check in checks), checks
        tick = time.monotonic()
        with tf.device(target_device):
            replay = kernel(positions)
        replay_arrays = tuple(tensor.numpy() for tensor in replay)
        report['replay_seconds'] = time.monotonic() - tick
        replay_record = {'values': replay_arrays[0].tolist(), 'scores': replay_arrays[1].tolist(),
            'validity': replay_arrays[2].tolist(), 'branch_status': replay_arrays[3].tolist(),
            'value_max_absolute_error': float(np.max(np.abs(arrays[0] - replay_arrays[0]))),
            'score_max_absolute_error': float(np.max(np.abs(arrays[1] - replay_arrays[1])))}
        (OUT / 'dz5-score-replay.json').write_text(json.dumps(diagnostic_json(replay_record), indent=2, allow_nan=False) + '\n')
        for left, right in zip(arrays, replay_arrays, strict=True):
            np.testing.assert_array_equal(left, right)
        report['replay_exact'] = True
        assert kernel.experimental_get_tracing_count() == 1
        definition = kernel.get_concrete_function().graph.as_graph_def()
        nodes = [*definition.node, *(node for function in definition.library.function for node in function.node_def)]
        forbidden = sorted({node.op for node in nodes if any(term in node.op.lower() for term in
            ('pyfunc', 'sylvester', 'principalsqrt', 'xlahostcompute'))})
        assert not forbidden, forbidden
        report.update(trace_count=1, host_callbacks=forbidden, graph_node_count=len(nodes))
        if jit:
            with tf.device(target_device):
                hlo = kernel.experimental_get_compiler_ir(positions)(stage='hlo', device_name=target_device)
            (OUT / 'dz5-score-oracle.hlo.txt').write_text(hlo)
            report['hlo_sha256'] = hashlib.sha256(hlo.encode()).hexdigest()
    finally:
        stop.set()
        sampler.join(timeout=2)
        samples.append(rss())
        report.update(sampled_rss_before_bytes=samples[0], sampled_peak_rss_bytes=max(samples),
            sampled_rss_after_bytes=samples[-1], rss_sample_count=len(samples),
            host_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        try:
            report['allocator'] = tf.config.experimental.get_memory_info('GPU:0' if gpu else 'CPU:0')
        except (ValueError, RuntimeError) as error:
            report['allocator'] = {'available': False, 'reason': str(error)}
    # Re-audit all actual project imports after tracing numerical callbacks.
    unexpected, loaded_after = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            owned = path.is_relative_to(BF) or path.is_relative_to(MF)
            named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
            if owned or named:
                loaded_after[name] = {'path': str(path), 'sha256': sha(path)}
                if not owned or expected_sources.get(str(path)) != sha(path):
                    unexpected[name] = str(path)
    report['post_target_loaded_modules'] = loaded_after
    report['post_target_unexpected_modules'] = unexpected
    assert not unexpected, unexpected
    assert all(sha(path) == digest for path, digest in expected_sources.items())

    report['passed'] = True
except BaseException as error:
    report.update(error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
finally:
    (OUT / 'dz5-snapshot-import.json').write_text(json.dumps(diagnostic_json(report), indent=2, allow_nan=False)+'\n')
sys.exit(0 if report['passed'] else 1)
