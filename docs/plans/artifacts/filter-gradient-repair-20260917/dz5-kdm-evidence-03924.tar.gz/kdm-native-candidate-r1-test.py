"""Independent diagnostics and execution gates for the KDM auxiliary.

NumPy is used only to preserve and compare test evidence. No KDM result here
admits an LEDH algorithm, trained transport, or HMC route.
"""

import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path
from types import ModuleType

import numpy as np
import pytest
import tensorflow as tf

from bayesfilter.highdim import ledh_canonical_score_tf as score_module
from bayesfilter.highdim import ledh_younis_kdm_tf as kdm_module
from bayesfilter.highdim.ledh_canonical_reset_score_tf import (
    sinkhorn_contract_e_reset_triple_with_tangent,
)


def _fixture_module():
    path = Path(__file__).parent / "highdim/test_ledh_younis_kdm_tf.py"
    spec = importlib.util.spec_from_file_location("_kdm_fixture_diagnostic", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _original():
    path = "bayesfilter/highdim/ledh_younis_kdm_tf.py"
    source = subprocess.check_output([
        "git", "show", f"ab431169d:{path}",
    ], cwd=Path(__file__).resolve().parents[1], text=True)
    module = ModuleType("_kdm_auxiliary_frozen_reference")
    exec(compile(source, "<frozen-kdm-reference>", "exec"), module.__dict__)  # noqa: S102
    return module, hashlib.sha256(source.encode()).hexdigest()


def _fixture(reset_steps=8):
    model = _fixture_module()._trace_model()
    dtype = tf.float64
    rng = np.random.default_rng(131)
    inputs = (
        tf.constant([0.6], dtype),
        tf.constant(rng.normal(size=(4, 2)), dtype),
        tf.eye(2, batch_shape=[4], dtype=dtype),
        tf.constant(rng.normal(size=(2, 4, 2)), dtype),
        tf.constant(rng.normal(size=(2, 2)), dtype),
        tf.eye(2, dtype=dtype), tf.zeros([2, 2], dtype),
        0.25 * tf.eye(2, batch_shape=[2, 4], dtype=dtype),
        tf.zeros([2, 4, 2, 2], dtype),
    )
    options = {
        "flow_substeps": 2, "reset_policy": "contract_e",
        "reset_design": tf.constant([[1., 0.], [-1., 0.], [0., 1.], [0., -1.]], dtype),
        "reset_epsilon": 2., "reset_sinkhorn_steps": reset_steps,
        "reset_balance_steps": reset_steps, "correction_steps": 4,
        "correction_strength": 0.2, "correction_lm_damping": 1.e-2,
        "correction_lm_scale_floor": 1.e-4, "correction_trust_radius": 0.5,
        "pairwise_steps": 4, "pairwise_strength": 0.02, "pairwise_rms_cap": 2.,
        "coordinate_cap": 0.98, "coordinate_cap_power": 8,
    }
    return model, inputs, options


def _json(value):
    if tf.is_tensor(value):
        return _json(value.numpy())
    if isinstance(value, np.ndarray):
        return _json(value.tolist())
    if isinstance(value, np.generic):
        return _json(value.item())
    if isinstance(value, dict):
        return {key: _json(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json(item) for item in value]
    if isinstance(value, float) and not np.isfinite(value):
        return str(value)
    return value


def test_baseline_auxiliary_rejection_localization(monkeypatch, request):
    """Preserve the unchanged failing seed-131 test and each rejecting layer."""
    fixture = _fixture_module()
    captured = {"kernels": []}
    original_score = score_module.canonical_value_and_analytical_score
    frozen, _ = _original()
    original_factory = frozen.make_linear_gaussian_kdm_normalizer_kernel
    original_auxiliary = frozen.canonical_linear_gaussian_kdm_auxiliary

    def capture_score(*args, **kwargs):
        result = original_score(*args, **kwargs)
        captured["canonical"] = result
        captured["canonical_options"] = kwargs
        captured["canonical_inputs"] = args[1:]
        return result

    def capture_factory(**kwargs):
        kernel = original_factory(**kwargs)

        def capture_kernel(*args):
            result = kernel(*args)
            captured["kernels"].append({
                "bandwidth_is_zero": kwargs["bandwidth_is_zero"],
                "inputs": args, "result": result,
            })
            return result

        return capture_kernel

    def capture_auxiliary(*args, **kwargs):
        result = original_auxiliary(*args, **kwargs)
        captured["auxiliary"] = result
        return result

    monkeypatch.setattr(score_module, "canonical_value_and_analytical_score", capture_score)
    monkeypatch.setattr(frozen, "make_linear_gaussian_kdm_normalizer_kernel", capture_factory)
    monkeypatch.setattr(fixture, "canonical_linear_gaussian_kdm_auxiliary", capture_auxiliary)
    try:
        fixture.test_auxiliary_api_uses_canonical_trace_and_has_no_feedback()
    except AssertionError:
        captured["legacy_assertion_failed"] = True
    else:
        captured["legacy_assertion_failed"] = False

    resets = []
    options = captured["canonical_options"]
    for record in captured["canonical"][2]:
        reset = sinkhorn_contract_e_reset_triple_with_tangent(
            record["children"], record["d_children"], record["post_covariances"],
            record["d_post_covariances"], record["posterior_weights"],
            record["d_posterior_weights"], options["reset_design"],
            epsilon=options["reset_epsilon"], sinkhorn_steps=options["reset_sinkhorn_steps"],
            balance_steps=options["reset_balance_steps"], ridge=options.get("reset_ridge", 1.e-5),
        )
        transport = record["reset_transport"]
        resets.append({
            "recomputed_outputs": reset,
            "row_error": tf.reduce_max(tf.abs(tf.reduce_sum(transport, axis=1) - 1.0)),
            "column_tv_error": 0.5 * tf.reduce_sum(tf.abs(
                tf.reduce_mean(transport, axis=0) - record["posterior_weights"])),
        })
    captured["resets"] = resets
    captured["role"] = "baseline_rejection_localization_only"
    output = Path(request.config.getoption("xmlpath")).parent / "kdm-baseline-rejection.json"
    output.write_text(json.dumps(_json(captured), indent=2, allow_nan=False) + "\n")
    assert captured["legacy_assertion_failed"]
    assert not bool(captured["auxiliary"]["valid"].numpy())
    assert len(captured["kernels"]) == 4
    assert len(resets) == 2


def _assert_record_equal(actual, expected, *, atol=2.e-10, rtol=2.e-10):
    assert type(actual) is type(expected)
    if isinstance(expected, dict):
        assert actual.keys() == expected.keys()
        for key in expected:
            _assert_record_equal(actual[key], expected[key], atol=atol, rtol=rtol)
    elif isinstance(expected, (list, tuple)):
        assert len(actual) == len(expected)
        for left, right in zip(actual, expected):
            _assert_record_equal(left, right, atol=atol, rtol=rtol)
    elif tf.is_tensor(expected):
        if expected.dtype.is_floating:
            np.testing.assert_allclose(actual.numpy(), expected.numpy(), atol=atol, rtol=rtol)
        else:
            np.testing.assert_array_equal(actual.numpy(), expected.numpy())
    else:
        assert actual == expected


@pytest.mark.parametrize("reset_steps", [2, 8])
def test_original_auxiliary_valid_and_rejected_controls(reset_steps, request):
    original, source_sha = _original()
    model, inputs, options = _fixture(reset_steps)
    reference = original.canonical_linear_gaussian_kdm_auxiliary(
        model, *inputs, canonical_options=options, jit_compile=False)
    value, score, trace = score_module.canonical_value_and_analytical_score(
        model, *inputs[:5], with_score=True, return_trace=True, **options)
    artifact = {"reference_source_commit": "ab431169d", "reference_sha256": source_sha,
                "reset_steps": reset_steps, "inputs": inputs, "options": options,
                "reference": reference, "canonical": (value, score, trace)}
    if reset_steps == 8:
        epsilon = 2.e-5
        plus = original.canonical_linear_gaussian_kdm_auxiliary(
            model, inputs[0] + epsilon, *inputs[1:], canonical_options=options, jit_compile=False)
        minus = original.canonical_linear_gaussian_kdm_auxiliary(
            model, inputs[0] - epsilon, *inputs[1:], canonical_options=options, jit_compile=False)
        finite_difference = (plus["kdm_auxiliary_value"] - minus["kdm_auxiliary_value"]) / (2 * epsilon)
        artifact["finite_difference"] = finite_difference
    output = Path(request.config.getoption("xmlpath")).parent / f"kdm-reference-{reset_steps}.json"
    output.write_text(json.dumps(_json(artifact), indent=2, allow_nan=False) + "\n")
    assert bool(reference["valid"].numpy()) == (reset_steps == 8)
    assert bool(tf.reduce_all([r["program_valid"] for r in trace]).numpy()) == (reset_steps == 8)
    if reset_steps == 8:
        np.testing.assert_allclose(reference["kdm_auxiliary_score"].numpy()[0],
                                   finite_difference.numpy(), rtol=4.e-4, atol=4.e-5)
    else:
        assert np.isneginf(value.numpy())
        np.testing.assert_array_equal(score.numpy(), [0.])


def _owner(model, inputs, options, jit_compile):
    return kdm_module.make_canonical_linear_gaussian_kdm_auxiliary_program(
        model, theta_shape=tuple(inputs[0].shape), particle_count=4, state_dimension=2,
        observation_dimension=2, horizon=2, canonical_options=options,
        dtype=tf.float64, jit_compile=jit_compile)


def _public_record(numerical):
    result = dict(numerical)
    result.pop("model_valid")
    steps = result.pop("steps")
    return {"route_id": kdm_module.AUXILIARY_ROUTE_ID,
            "route_role": kdm_module.AUXILIARY_ROLE,
            "canonical_target_label": kdm_module.ATOM_FINITE_TARGET,
            "auxiliary_target_label": kdm_module.KDM_FINITE_TARGET,
            **result,
            "steps": tuple({"time_index": i, **{k: v[i] for k, v in steps.items()}}
                           for i in range(2))}


@pytest.mark.parametrize("jit_compile", [False, True], ids=["graph", "xla"])
@pytest.mark.parametrize("reset_steps", [2, 8])
def test_native_auxiliary_complete_records(reset_steps, jit_compile, request):
    original, source_sha = _original()
    model, inputs, options = _fixture(reset_steps)
    reference = original.canonical_linear_gaussian_kdm_auxiliary(
        model, *inputs, canonical_options=options, jit_compile=False)
    owner = _owner(model, inputs, options, jit_compile)
    first = owner(*inputs)
    replay = owner(*inputs)
    public = kdm_module.canonical_linear_gaussian_kdm_auxiliary(
        model, *inputs, canonical_options=options, jit_compile=jit_compile)
    changed = (*inputs[:4], inputs[4] + tf.constant(0.01, tf.float64), *inputs[5:])
    changed_result = owner(*changed)
    changed_reference = original.canonical_linear_gaussian_kdm_auxiliary(
        model, *changed, canonical_options=options, jit_compile=False)
    definition = owner.get_concrete_function().graph.as_graph_def()
    nodes = [*definition.node, *(node for function in definition.library.function
                                for node in function.node_def)]
    artifact = {"reference_sha256": source_sha, "jit_compile": jit_compile,
                "reset_steps": reset_steps, "reference": reference, "first": first,
                "replay": replay, "public": public, "changed": changed_result,
                "changed_reference": changed_reference,
                "traces": owner.experimental_get_tracing_count(),
                "ops": sorted({node.op for node in nodes})}
    output = Path(request.config.getoption("xmlpath")).parent
    stem = f"kdm-native-{reset_steps}-{jit_compile}"
    (output / f"{stem}.pb").write_bytes(definition.SerializeToString())
    if jit_compile:
        hlo = owner.experimental_get_compiler_ir(*inputs)(stage="hlo")
        (output / f"{stem}.hlo").write_text(hlo)
        artifact["hlo_sha256"] = hashlib.sha256(hlo.encode()).hexdigest()
    (output / f"{stem}.json").write_text(json.dumps(_json(artifact), indent=2, allow_nan=False) + "\n")
    _assert_record_equal(_public_record(first), reference)
    _assert_record_equal(public, reference)
    _assert_record_equal(_public_record(changed_result), changed_reference)
    _assert_record_equal(replay, first, atol=0., rtol=0.)
    assert bool(first["valid"].numpy()) == (reset_steps == 8)
    assert owner.experimental_get_tracing_count() == 1
    assert not {"PyFunc", "PyFuncStateless", "EagerPyFunc"}.intersection(artifact["ops"])
    assert {"While", "StatelessWhile"}.intersection(artifact["ops"])
    if reset_steps == 8:
        epsilon = 2.e-5
        plus = owner(inputs[0] + epsilon, *inputs[1:])
        minus = owner(inputs[0] - epsilon, *inputs[1:])
        derivative = (plus["kdm_auxiliary_value"] - minus["kdm_auxiliary_value"]) / (2 * epsilon)
        np.testing.assert_allclose(first["kdm_auxiliary_score"].numpy()[0],
                                  derivative.numpy(), rtol=4.e-4, atol=4.e-5)
    invalid_inputs = (*inputs[:5], inputs[5] * 2., *inputs[6:])
    invalid = owner(*invalid_inputs)
    assert not bool(invalid["model_valid"].numpy())
    assert not bool(invalid["valid"].numpy())
    assert bool(tf.math.is_nan(invalid["kdm_auxiliary_value"]).numpy())
