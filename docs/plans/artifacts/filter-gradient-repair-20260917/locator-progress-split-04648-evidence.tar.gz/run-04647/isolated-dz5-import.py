
import hashlib
import importlib
import json
import math
import os
import sys
import traceback
from pathlib import Path

BF = Path('/home/ubuntu/workspace/BayesFilter')
MF = Path('/home/ubuntu/workspace/MacroFinance-dz5-neutra')
OUT = Path('/tmp/dz5-output')
sys.path[:0] = [str(MF), str(BF)]
report = {'schema': 'filter_repair_dz5_snapshot_import.v1', 'passed': False,
    'role': 'isolated_CPU_import_and_fixture_reference_only',
    'target_evaluated': False, 'adapter_admitted': False,
    'nonclaims': ['No target, initializer, transition, timing or retained qualification.']}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def diagnostic_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: diagnostic_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [diagnostic_json(item) for item in value]
    return value

try:
    manifest = json.loads(Path('/tmp/dz5-source/manifest.json').read_text())
    report['snapshot_manifest_sha256'] = sha('/tmp/dz5-source/manifest.json')
    expected = {path: entry['sha256'] for path, entry in manifest['sources'].items()}
    assert all(sha(path) == digest for path, digest in expected.items())
    gpu = os.environ['CUDA_VISIBLE_DEVICES'] != '-1'
    assert os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] == 'true'
    import tensorflow as tf
    from bayesfilter.runtime.gpu_memory_policy import configure_tensorflow_gpu_memory_growth
    memory = configure_tensorflow_gpu_memory_growth(tf, require_gpu=gpu)
    devices = tf.config.list_physical_devices('GPU')
    assert len(devices) == (1 if gpu else 0)
    report.update(device='GPU' if gpu else 'CPU',
        trust_basis='owner_designated_managed_session_visible_gpu_trusted' if gpu else 'CPU_reference',
        physical_gpus=[device.name for device in devices])
    report.update(gpu_memory_policy=memory, tensorflow=tf.__version__,
        cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'])

    from bayesfilter_estimation import audit_sources, declared_source_closure
    from two_currency_double_zlb_credit_estimation import (
        TFP_SPECIAL, TFP_SPECIAL_SHA, credit_fixture_identity)
    from two_currency_double_zlb_credit_fixtures import credit_fixture
    from two_currency_double_zlb_credit_target import CREDIT_FILTER_CONTRACT
    importlib.import_module('bayesfilter_estimation_initialization')
    importlib.import_module('two_currency_double_zlb_credit_recovery')
    importlib.import_module('bayesfilter.inference.dense_initializer_seeded_tf')
    importlib.import_module('bayesfilter.inference.tensor_npz_archive')
    assert sha(TFP_SPECIAL) == TFP_SPECIAL_SHA
    fixture = credit_fixture('CDF', n_steps=96)
    identity = credit_fixture_identity(fixture)
    assert identity == 'e116fe853c8579369036ab2ce57724ba07544524d0920fa0a706d76714f75d8a'
    assert len(fixture.parameter_names) == 23 and fixture.observations.shape[0] == 96
    assert CREDIT_FILTER_CONTRACT == 'rectangular_srukf_full_rank_identity_prepared_cir_v2'
    closure = audit_sources(declared_source_closure((
        MF / 'scripts/prepare_dz5_cdf_proposal.py',
        BF / 'bayesfilter/runtime/runner.py')))
    assert all(expected.get(path) == digest for path, digest in closure.items())
    loaded, unexpected = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if not filename:
            continue
        path = Path(filename).resolve()
        named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
        owned = path.is_relative_to(BF) or path.is_relative_to(MF)
        if named or owned:
            digest = sha(path)
            loaded[name] = {'path': str(path), 'sha256': digest}
            if not owned or expected.get(str(path)) != digest:
                unexpected[name] = loaded[name]
    report.update(loaded_modules=loaded, unexpected_modules=unexpected,
        source_closure=closure, fixture_identity=identity,
        parameter_names=fixture.parameter_names, observation_shape=list(fixture.observations.shape),
        filter_contract=CREDIT_FILTER_CONTRACT, tfp_special_sha256=TFP_SPECIAL_SHA)
    assert not unexpected, unexpected
    mounts = {}
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        fields = line.split()
        if fields[4] in (str(BF), str(MF)):
            mounts[fields[4]] = fields[5].split(',')
    report['source_mount_options'] = mounts
    assert set(mounts) == {str(BF), str(MF)}
    assert all('ro' in options for options in mounts.values())
    assert all(sha(path) == digest for path, digest in expected.items())
    expected_sources = expected.copy()

    import contextlib
    import gc
    import resource
    import time
    import weakref
    from dataclasses import replace
    from types import SimpleNamespace
    from bayesfilter_estimation import EstimationRecipe
    from bayesfilter_estimation_initialization import initialize_dense_local
    from two_currency_double_zlb_credit_estimation import credit_model
    from two_currency_double_zlb_credit_recovery import CreditTrainingTarget
    from bayesfilter.inference import dense_initializer_seeded_tf as seeded
    tf.config.experimental.enable_tensor_float_32_execution(False)
    recipe_path = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917/dz5-initializer-accepted-inputs-20260928-r1/recipe.json')
    admission_path = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917/dz5-initializer-adapter-target-admission-20260928-r1.json')
    recipe = EstimationRecipe(**json.loads(recipe_path.read_text()))
    admission = json.loads(admission_path.read_text())
    assert admission['role'] == 'fresh_target_only_isolated_initializer_regression'
    assert admission['snapshot_manifest_sha256'] == report['snapshot_manifest_sha256']
    assert not any(admission[key] for key in ('old_admission_reused', 'training_authorized',
        'hmc_authorized', 'retained_authorized'))
    model = credit_model(stage='CDF', qualification=admission_path, recipe=recipe)
    base = model.sampling_target
    assert base.fixture_identity_sha256 == report['fixture_identity']
    model = replace(model, training_target=CreditTrainingTarget(base, base.fixture.prior_mean, model.data_identity))
    if True:
        replay_started = time.monotonic()
        inputs_root = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917/dz5-initializer-accepted-inputs-20260928-r1')
        inputs = json.loads((inputs_root / 'manifest.json').read_text())
        assert all(sha(row['saved']) == row['sha256'] for row in inputs['files'].values())
        point_row = inputs['files']['start_point']
        point = json.loads(Path(point_row['saved']).read_text())
        assert point['fixture_identity'] == base.fixture_identity_sha256
        assert point['admission_sha256'] == inputs['files']['original_admission']['sha256']
        assert point['optimizer_state_reused'] is False
        for source, digest in point['artifacts'].items():
            rows = [row for row in inputs['files'].values() if row['source'] == source]
            assert len(rows) == 1 and rows[0]['sha256'] == digest
        with tf.device('/GPU:0' if gpu else '/CPU:0'):
            position = tf.constant([point['point']], tf.float64)
            value, score, status, valid, *_ = base._evaluate(position)
        assert bool(tf.reduce_all(valid & (status == 0)))
        tf.debugging.assert_less_equal(tf.abs(value - tf.constant([point['value']], tf.float64)),
            tf.constant(1e-8, tf.float64) + tf.constant(1e-9, tf.float64) * tf.abs(tf.constant([point['value']], tf.float64)))
        tf.debugging.assert_less_equal(tf.abs(score - tf.constant([point['score']], tf.float64)),
            tf.constant(1e-8, tf.float64) + tf.constant(1e-7, tf.float64) * tf.abs(tf.constant([point['score']], tf.float64)))
        fresh_point = {'role': 'fresh_value_score_replay_of_frozen_prior_origin_initializer_start',
            'point': position[0].numpy().tolist(), 'value': float(value[0]), 'score': score[0].numpy().tolist(),
            'original_point_sha256': point_row['sha256'],
            'original_admission_sha256': point['admission_sha256'],
            'current_admission_sha256': sha(admission_path), 'fixture_identity': base.fixture_identity_sha256,
            'optimizer_state_reused': False, 'training_or_HMC_authorized': False}
        (OUT / 'initializer-start-replay.json').write_text(json.dumps(fresh_point, indent=2, allow_nan=False) + '\n')
        model = replace(model, initial_position=position[0])
        report.update(start_replay_seconds=time.monotonic() - replay_started,
            accepted_input_manifest_sha256=sha(inputs_root / 'manifest.json'),
            start_replay=fresh_point)

    import dataclasses
    import types
    from bayesfilter.inference.batched_local_center import BatchedLocalCenterResult
    from bayesfilter.inference.batched_local_center_tf import BatchedLocalCenterProgram
    from bayesfilter.inference.tensor_npz_archive import write_tensor_npz
    from bayesfilter_estimation_runtime import initializer_configurations
    assert not gpu
    source = '"""Opt-in, fixed-batch TF/TFP location diagnostic with exact incumbent replay.\n\nEach independent start uses theta = anchor + scale * R*tanh(u/R).\nThe minimized objective is -ell(theta), with gradient\n-(scale * score_theta) * (1-tanh(u/R)**2). This optimizer chart contributes\nno density Jacobian. Native batched TFP L-BFGS implements the search; bounded\nre-anchoring is not a quadratic trust-region method or a MAP certificate.\n\nSearch, stopping, selection, and replay decisions stay in TensorFlow. Host\nmaterialization occurs only in result reporting. No covariance, transport,\ntraining, HMC, or posterior-convergence claim follows from an accepted center.\n"""\n\nfrom __future__ import annotations\n\nimport math\nimport operator\nfrom collections.abc import Callable\nfrom dataclasses import asdict, dataclass, fields\nfrom typing import Any\n\nimport tensorflow as tf\nimport tensorflow_probability as tfp\n\nBATCHED_LOCAL_CENTER_NONCLAIMS = (\n    "bounded location diagnostic, not certified local/global MAP",\n    "not posterior support or mode-coverage evidence",\n    "not Hessian, covariance, or mass-matrix evidence",\n    "not NeuTra training, whitening, or HMC readiness",\n    "not GPU/default readiness, convergence, or identification evidence",\n)\n\n_STATUSES = (\n    "initial_target_invalid",\n    "callback_cap_exhausted",\n    "replay_mismatch",\n    "selected_optimizer_failed",\n    "localized",\n    "stationary",\n)\n\n\n@dataclass(frozen=True)\nclass BatchedLocalCenterConfig:\n    """Frozen search limits and componentwise deterministic replay tolerances.\n\n    The box radius is per coordinate in caller-supplied diagonal scale units,\n    not a posterior standard deviation. Re-anchoring does not estimate that scale.\n    The callback cap excludes one initial batch and endpoint/final replays.\n    """\n\n    box_radius: float = 4.0\n    trust_refinement_rounds: int = 2\n    num_correction_pairs: int = 10\n    max_iterations: int = 50\n    max_line_search_iterations: int = 20\n    gradient_tolerance: float = 1e-8\n    max_optimizer_callback_batches_per_round: int = 64\n    replay_atol: float = 1e-10\n    replay_rtol: float = 1e-10\n    movement_tolerance: float = 1e-12\n    jit_compile: bool = True\n    stop_when_no_row_moves: bool = True\n\n    def __post_init__(self) -> None:\n        for name in (\n            "box_radius",\n            "gradient_tolerance",\n            "replay_atol",\n            "replay_rtol",\n            "movement_tolerance",\n        ):\n            value = getattr(self, name)\n            if not math.isfinite(value) or value <= 0:\n                raise ValueError(f"{name} must be positive and finite")\n        for name in (\n            "trust_refinement_rounds",\n            "num_correction_pairs",\n            "max_iterations",\n            "max_line_search_iterations",\n            "max_optimizer_callback_batches_per_round",\n        ):\n            if operator.index(getattr(self, name)) <= 0:\n                raise ValueError(f"{name} must be a positive integer")\n\n    @property\n    def maximum_physical_rows_multiplier(self) -> int:\n        return 2 + self.trust_refinement_rounds * (\n            self.max_optimizer_callback_batches_per_round + 1\n        )\n\n    def payload(self) -> dict[str, Any]:\n        return {\n            **asdict(self),\n            "maximum_physical_rows_multiplier": self.maximum_physical_rows_multiplier,\n        }\n\n\n@dataclass(frozen=True)\nclass BatchedLocalCenterResult:\n    """Tensor decisions and sufficient per-start exact-maxima ledger.\n\n    Evaluation indices are zero-based flattened target-call/row indices. Strict\n    improvements preserve earliest ties. Validation replays never replace records.\n    An accepted nonstationary result is only a finite, reproducible location.\n    """\n\n    status_code: tf.Tensor\n    accepted: tf.Tensor\n    center: tf.Tensor\n    center_value: tf.Tensor\n    center_score: tf.Tensor\n    selected_evaluation_index: tf.Tensor\n    valid_rows: tf.Tensor\n    best_values: tf.Tensor\n    best_positions: tf.Tensor\n    best_scores: tf.Tensor\n    best_evaluation_indices: tf.Tensor\n    endpoint_positions: tf.Tensor\n    endpoint_values: tf.Tensor\n    endpoint_valid: tf.Tensor\n    endpoint_accepted: tf.Tensor\n    optimizer_converged: tf.Tensor\n    optimizer_failed: tf.Tensor\n    chart_saturated: tf.Tensor\n    rounds_completed: tf.Tensor\n    target_callback_batches: tf.Tensor\n    physical_target_rows: tf.Tensor\n    optimizer_callback_attempts: tf.Tensor\n    optimizer_target_batches: tf.Tensor\n    replay_batches: tf.Tensor\n    invalid_target_rows: tf.Tensor\n    cap_exhausted: tf.Tensor\n    replay_consistent: tf.Tensor\n    trace_count: int\n    nonclaims: tuple[str, ...] = BATCHED_LOCAL_CENTER_NONCLAIMS\n\n    @property\n    def status(self) -> str:\n        return _STATUSES[int(self.status_code.numpy())]\n\n    def payload(self) -> dict[str, Any]:\n        """Materialize reporting only; absent/nonfinite numbers become null."""\n\n        def convert(value: Any) -> Any:\n            if tf.is_tensor(value):\n                return convert(value.numpy().tolist())\n            if isinstance(value, (tuple, list)):\n                return [convert(item) for item in value]\n            if isinstance(value, float) and not math.isfinite(value):\n                return None\n            return value\n\n        return {\n            "schema": "bayesfilter.batched_local_center.result.v1",\n            "status": self.status,\n            **{\n                field.name: convert(getattr(self, field.name)) for field in fields(self)\n            },\n        }\n\n\ndef _bounded_chart(\n    anchor: tf.Tensor,\n    scale: tf.Tensor,\n    unconstrained: tf.Tensor,\n    radius: float,\n) -> tuple[tf.Tensor, tf.Tensor]:\n    """Return raw positions and diagonal d(theta)/du, with R cancellation."""\n    tangent = tf.math.tanh(unconstrained / radius)\n    return anchor + scale * (radius * tangent), scale * (1 - tf.square(tangent))\n\n\ndef locate_batched_local_center(\n    batched_value_score_eligibility_fn: Callable[\n        [tf.Tensor], tuple[tf.Tensor, tf.Tensor, tf.Tensor]\n    ],\n    initial_positions: Any,\n    scale: Any,\n    *,\n    config: BatchedLocalCenterConfig | None = None,\n) -> BatchedLocalCenterResult:\n    """Find the highest exact eligible point from independent [B,D] starts.\n\n    The deterministic, row-independent callback takes float64 [B,D] and returns\n    float64 values [B], raw scores [B,D], and bool eligibility [B]. All calls use\n    the same shape, including duplicate final replay rows (not search starts).\n    Native Tensor inputs must already be float64. Scale is positive [D].\n\n    Invalid rows receive +inf optimizer objective and zero gradient but cannot\n    be reported stationary. Exceptions propagate: callers must record the failure,\n    not substitute another target or silently retry. Default JIT applies to the\n    entire search/replay program, not just its target objective.\n    """\n    cfg = BatchedLocalCenterConfig() if config is None else config\n    initial = tf.convert_to_tensor(initial_positions, dtype=tf.float64)\n    scale_tensor = tf.convert_to_tensor(scale, dtype=tf.float64)\n    if initial.shape.rank != 2 or not initial.shape.is_fully_defined():\n        raise ValueError("initial_positions must have static rank-2 shape [B,D]")\n    batch_size, dimension = initial.shape\n    if batch_size <= 0 or dimension <= 0:\n        raise ValueError("initial_positions must have positive dimensions")\n    if scale_tensor.shape != tf.TensorShape([dimension]):\n        raise ValueError("scale must have static shape [D]")\n    tf.debugging.assert_all_finite(initial, "initial_positions must be finite")\n    tf.debugging.assert_all_finite(scale_tensor, "scale must be finite")\n    tf.debugging.assert_positive(scale_tensor, message="scale must be positive")\n\n    def variable(value: Any, dtype: tf.DType) -> tf.Variable:\n        return tf.Variable(value, trainable=False, dtype=dtype)\n\n    negative_infinity = tf.constant(-math.inf, tf.float64)\n    budget_abort = tf.constant(math.nan, tf.float64)\n    best_values = variable(tf.fill([batch_size], negative_infinity), tf.float64)\n    best_positions = variable(initial, tf.float64)\n    best_scores = variable(tf.zeros_like(initial), tf.float64)\n    best_indices = variable(tf.fill([batch_size], -1), tf.int32)\n    calls = variable(0, tf.int32)\n    attempts = variable(0, tf.int32)\n    optimizer_calls = variable(0, tf.int32)\n    round_calls = variable(0, tf.int32)\n    replays = variable(0, tf.int32)\n    invalid_rows = variable(0, tf.int32)\n    capped = variable(False, tf.bool)\n    mismatch = variable(False, tf.bool)\n    endpoint_positions = variable(initial, tf.float64)\n    endpoint_values = variable(tf.fill([batch_size], negative_infinity), tf.float64)\n    endpoint_valid = variable(tf.zeros([batch_size], tf.bool), tf.bool)\n    endpoint_accepted = variable(tf.zeros([batch_size], tf.bool), tf.bool)\n    optimizer_converged = variable(tf.zeros([batch_size], tf.bool), tf.bool)\n    optimizer_failed = variable(tf.zeros([batch_size], tf.bool), tf.bool)\n    saturated = variable(tf.zeros([batch_size], tf.bool), tf.bool)\n\n    def close(actual: tf.Tensor, expected: tf.Tensor) -> tf.Tensor:\n        return (\n            tf.math.is_finite(actual)\n            & tf.math.is_finite(expected)\n            & (\n                tf.abs(actual - expected)\n                <= cfg.replay_atol + cfg.replay_rtol * tf.abs(expected)\n            )\n        )\n\n    def evaluate(positions: tf.Tensor) -> tuple[tf.Tensor, tf.Tensor, tf.Tensor]:\n        positions = tf.ensure_shape(positions, [batch_size, dimension])\n        call_number = calls.assign_add(1)\n        with tf.control_dependencies([call_number]):\n            values, scores, eligible = batched_value_score_eligibility_fn(positions)\n            values = tf.ensure_shape(\n                tf.convert_to_tensor(values, tf.float64), [batch_size]\n            )\n            scores = tf.ensure_shape(\n                tf.convert_to_tensor(scores, tf.float64), initial.shape\n            )\n            eligible = tf.ensure_shape(\n                tf.convert_to_tensor(eligible, tf.bool), [batch_size]\n            )\n            valid = (\n                eligible\n                & tf.math.is_finite(values)\n                & tf.reduce_all(tf.math.is_finite(scores), axis=1)\n                & tf.reduce_all(tf.math.is_finite(positions), axis=1)\n            )\n            invalid_rows.assign_add(tf.reduce_sum(tf.cast(~valid, tf.int32)))\n        return (\n            tf.where(valid, values, negative_infinity),\n            tf.where(valid[:, None], scores, tf.zeros_like(scores)),\n            valid,\n        )\n\n    def record(\n        positions: tf.Tensor, values: tf.Tensor, scores: tf.Tensor, valid: tf.Tensor\n    ) -> tf.Tensor:\n        improve = valid & (values > best_values.read_value())\n        indices = (calls.read_value() - 1) * batch_size + tf.range(batch_size)\n        updates = (\n            best_values.assign(tf.where(improve, values, best_values)),\n            best_positions.assign(\n                tf.where(improve[:, None], positions, best_positions)\n            ),\n            best_scores.assign(tf.where(improve[:, None], scores, best_scores)),\n            best_indices.assign(tf.where(improve, indices, best_indices)),\n        )\n        with tf.control_dependencies(updates):\n            return tf.identity(values)\n\n    def search_round(round_index, anchor, anchor_values, continuing):\n        del continuing\n        round_calls.assign(0)\n\n        def objective(unconstrained):\n            attempts.assign_add(1)\n            positions, derivative = _bounded_chart(\n                anchor,\n                scale_tensor,\n                unconstrained,\n                cfg.box_radius,\n            )\n\n            def available():\n                round_calls.assign_add(1)\n                optimizer_calls.assign_add(1)\n                values, scores, valid = evaluate(positions)\n                values = record(positions, values, scores, valid)\n                return -values, tf.where(valid[:, None], -scores * derivative, 0.0)\n\n            def exhausted():\n                """Abort Hager-Zhang with NaN, not its bisectable +inf endpoint.\n\n                This optimizer-only failure signal never enters target records.\n                The separate cap veto rejects even a finite replayed incumbent.\n                Invalid support remains +inf and may still be searched around.\n                """\n                capped.assign(True)\n                return tf.fill([batch_size], budget_abort), tf.zeros_like(initial)\n\n            return tf.cond(\n                round_calls < cfg.max_optimizer_callback_batches_per_round,\n                available,\n                exhausted,\n            )\n\n        optimizer = tfp.optimizer.lbfgs_minimize(\n            objective,\n            initial_position=tf.zeros_like(initial),\n            num_correction_pairs=cfg.num_correction_pairs,\n            tolerance=tf.constant(cfg.gradient_tolerance, tf.float64),\n            max_iterations=cfg.max_iterations,\n            max_line_search_iterations=cfg.max_line_search_iterations,\n            parallel_iterations=1,\n            stopping_condition=tfp.optimizer.converged_all,\n        )\n        positions, derivative = _bounded_chart(\n            anchor,\n            scale_tensor,\n            optimizer.position,\n            cfg.box_radius,\n        )\n        replays.assign_add(1)\n        values, scores, valid = evaluate(positions)\n        reported_valid = (\n            tf.math.is_finite(optimizer.objective_value)\n            & tf.reduce_all(tf.math.is_finite(optimizer.objective_gradient), axis=1)\n            & tf.reduce_all(tf.math.is_finite(optimizer.position), axis=1)\n        )\n        consistent = (valid == reported_valid) & (\n            ~valid\n            | (\n                close(values, -optimizer.objective_value)\n                & tf.reduce_all(\n                    close(-scores * derivative, optimizer.objective_gradient), axis=1\n                )\n            )\n        )\n        mismatch.assign(mismatch | tf.reduce_any(~consistent))\n        failed = optimizer.failed | ~valid | ~reported_valid\n        accepted = valid & consistent & ~failed & ~capped & (values >= anchor_values)\n        moved = accepted & (\n            tf.reduce_max(tf.abs((positions - anchor) / scale_tensor), axis=1)\n            > cfg.movement_tolerance\n        )\n        scaled_score_norm = tf.reduce_max(tf.abs(scores * scale_tensor), axis=1)\n        endpoint_positions.assign(positions)\n        endpoint_values.assign(values)\n        endpoint_valid.assign(valid)\n        endpoint_accepted.assign(accepted)\n        optimizer_failed.assign(failed)\n        optimizer_converged.assign(\n            optimizer.converged\n            & valid\n            & consistent\n            & ~failed\n            & ~capped\n            & (scaled_score_norm <= cfg.gradient_tolerance)\n        )\n        saturated.assign(\n            valid\n            & (tf.reduce_min(tf.abs(derivative / scale_tensor), axis=1) <= 1e-8)\n            & (scaled_score_norm > cfg.gradient_tolerance)\n        )\n        continuing = ~capped & ~mismatch\n        if cfg.stop_when_no_row_moves:\n            continuing = continuing & tf.reduce_any(moved)\n        return (\n            round_index + 1,\n            tf.where(accepted[:, None], positions, anchor),\n            tf.where(accepted, values, anchor_values),\n            continuing,\n        )\n\n    def run():\n        values, scores, valid = evaluate(initial)\n        values = record(initial, values, scores, valid)\n        rounds, _, _, _ = tf.while_loop(\n            lambda count, anchor, anchor_values, continuing: (\n                (count < cfg.trust_refinement_rounds) & continuing\n            ),\n            search_round,\n            (tf.constant(0), initial, values, tf.reduce_any(valid)),\n            parallel_iterations=1,\n        )\n        valid_rows = best_indices >= 0\n        has_incumbent = tf.reduce_any(valid_rows)\n        highest = tf.reduce_max(best_values)\n        tied_indices = tf.where(\n            valid_rows & (best_values == highest),\n            best_indices,\n            2147483647,\n        )\n        selected = tf.argmin(tied_indices, output_type=tf.int32)\n        center = tf.gather(best_positions, selected)\n        center_value = tf.gather(best_values, selected)\n        center_score = tf.gather(best_scores, selected)\n\n        def replay():\n            replays.assign_add(1)\n            repeated = tf.broadcast_to(center, initial.shape)\n            replay_values, replay_scores, replay_valid = evaluate(repeated)\n            return tf.reduce_all(replay_valid & close(replay_values, center_value)) & (\n                tf.reduce_all(close(replay_scores, center_score))\n            )\n\n        consistent = (\n            tf.cond(has_incumbent, replay, lambda: tf.constant(False)) & ~mismatch\n        )\n        selected_failed = tf.gather(optimizer_failed, selected)\n        accepted = has_incumbent & consistent & ~capped & ~selected_failed\n        stationary = (\n            tf.reduce_max(tf.abs(center_score * scale_tensor)) <= cfg.gradient_tolerance\n        )\n        status = tf.where(stationary, 5, 4)\n        status = tf.where(selected_failed, 3, status)\n        status = tf.where(~consistent, 2, status)\n        status = tf.where(capped, 1, status)\n        status = tf.where(~has_incumbent, 0, status)\n        return {\n            "status_code": status,\n            "accepted": accepted,\n            "center": center,\n            "center_value": center_value,\n            "center_score": center_score,\n            "selected_evaluation_index": tf.gather(best_indices, selected),\n            "valid_rows": valid_rows,\n            "best_values": best_values.read_value(),\n            "best_positions": best_positions.read_value(),\n            "best_scores": best_scores.read_value(),\n            "best_evaluation_indices": best_indices.read_value(),\n            "endpoint_positions": endpoint_positions.read_value(),\n            "endpoint_values": endpoint_values.read_value(),\n            "endpoint_valid": endpoint_valid.read_value(),\n            "endpoint_accepted": endpoint_accepted.read_value(),\n            "optimizer_converged": optimizer_converged.read_value(),\n            "optimizer_failed": optimizer_failed.read_value(),\n            "chart_saturated": saturated.read_value(),\n            "rounds_completed": rounds,\n            "target_callback_batches": calls.read_value(),\n            "physical_target_rows": calls * batch_size,\n            "optimizer_callback_attempts": attempts.read_value(),\n            "optimizer_target_batches": optimizer_calls.read_value(),\n            "replay_batches": replays.read_value(),\n            "invalid_target_rows": invalid_rows.read_value(),\n            "cap_exhausted": capped.read_value(),\n            "replay_consistent": consistent,\n        }\n\n    compiled = tf.function(run, jit_compile=cfg.jit_compile, autograph=False)\n    tensors = compiled()\n    return BatchedLocalCenterResult(\n        **tensors, trace_count=compiled.experimental_get_tracing_count()\n    )\n'
    assert hashlib.sha256(source.encode()).hexdigest() == '575e044f8e33f20b6fc13be1f48b3356110e0ec77799378d0cc738e89ddfc40f'
    baseline_source = source
    if 'candidate' == 'original_operands':
        replacements = {
            '    def run():': '    def run(initial_operand, scale_operand):\n        nonlocal initial, scale_tensor\n        initial, scale_tensor = initial_operand, scale_operand',
            'compiled = tf.function(run, jit_compile=cfg.jit_compile, autograph=False)':
                'compiled = tf.function(run, input_signature=[tf.TensorSpec(initial.shape, tf.float64), tf.TensorSpec(scale_tensor.shape, tf.float64)], jit_compile=cfg.jit_compile, autograph=False)',
            '    tensors = compiled()': '    tensors = compiled(initial, scale_tensor)',
        }
        for before, after in replacements.items():
            assert source.count(before) == 1
            source = source.replace(before, after)
        (OUT / 'pinned-original-batched-local-center.py').write_text(baseline_source)
    (OUT / 'original-batched-local-center.py').write_text(source)
    original = types.ModuleType('pinned_original_batched_locator_diagnostic')
    original.__file__ = str(OUT / 'original-batched-local-center.py')
    sys.modules[original.__name__] = original
    exec(compile(source, original.__file__, 'exec'), original.__dict__)
    observed = []
    class ObservedTF:
        def __getattr__(self, name):
            if name == 'function':
                def function(*args, **kwargs):
                    compiled = tf.function(*args, **kwargs)
                    observed.append(compiled)
                    return compiled
                return function
            return getattr(tf, name)
    original.tf = ObservedTF()
    configuration, _, _ = initializer_configurations(recipe)
    locator = configuration.locator_config
    settings = dict(box_radius=configuration.locator_box_radius, trust_refinement_rounds=1,
        num_correction_pairs=locator.num_correction_pairs, max_iterations=locator.max_iterations,
        max_line_search_iterations=locator.max_line_search_iterations,
        gradient_tolerance=locator.gradient_tolerance,
        max_optimizer_callback_batches_per_round=locator.max_objective_evaluations, jit_compile=True)
    capacity = configuration.max_exact_evaluations
    calls = tf.Variable(0, dtype=tf.int64, trainable=False)
    trace_positions = tf.Variable(tf.zeros([capacity, 23], tf.float64), trainable=False)
    trace_values = tf.Variable(tf.zeros([capacity], tf.float64), trainable=False)
    trace_scores = tf.Variable(tf.zeros([capacity, 23], tf.float64), trainable=False)
    trace_valid = tf.Variable(tf.zeros([capacity], tf.bool), trainable=False)
    callback = model.training_target.batch_value_score_and_validity
    use_barriers = 'candidate'.endswith('_barrier')
    from tensorflow.compiler.tf2xla.ops.gen_xla_ops import xla_optimization_barrier
    def measured_callback(points):
        assert points.shape == (1, 23)
        if use_barriers:
            points = xla_optimization_barrier(input=[points])[0]
        value, score, valid = callback(points)
        if use_barriers:
            value, score, valid = xla_optimization_barrier(input=[value, score, valid])
        index = calls.assign_add(1) - 1
        indices = tf.reshape(index, [1, 1])
        writes = (trace_positions.scatter_nd_update(indices, points),
            trace_values.scatter_nd_update(indices, value),
            trace_scores.scatter_nd_update(indices, score),
            trace_valid.scatter_nd_update(indices, valid))
        with tf.control_dependencies(writes):
            return tf.identity(value), tf.identity(score), tf.identity(valid)
    initial = tf.constant(model.initial_position, tf.float64)[None, :]
    scale = tf.constant(model.coordinate_scale, tf.float64)
    report.update(role='frozen_CDF_locator_first_divergence_localization', arm='candidate',
        jit_compile=True, cpu_reference_exception=True, target_execution_attempted=True,
        original_locator_sha256='575e044f8e33f20b6fc13be1f48b3356110e0ec77799378d0cc738e89ddfc40f', settings=settings,
        executed_original_source_sha256=hashlib.sha256(source.encode()).hexdigest(),
        original_operand_binding_diagnostic='candidate' == 'original_operands',
        callback_optimization_barriers='inputs_and_outputs' if use_barriers else 'none',
        observer='fixed_capacity_TensorFlow_callback_trace; no numerical output changed',
        nonclaims=['No current SVD source admission, complete initializer, training, HMC or matched timing.'])
    # Diagnostic dispatch only: evaluate the first objective once.
    from types import SimpleNamespace
    from bayesfilter.inference import batched_local_center_tf as candidate_module
    probe_source = "def one_iteration(value_and_gradients_function, initial_position, **kwargs):\n    kwargs['max_iterations'] = 1\n    return real_lbfgs_minimize(value_and_gradients_function,\n        initial_position=initial_position, **kwargs)\n"
    (OUT / 'diagnostic-optimizer-dispatch.py').write_text(probe_source)
    namespace = {'tf': tf, 'SimpleNamespace': SimpleNamespace, 'real_lbfgs_minimize': original.tfp.optimizer.lbfgs_minimize}
    exec(compile(probe_source, '<single_objective_diagnostic>', 'exec'), namespace)
    proxy = SimpleNamespace(optimizer=SimpleNamespace(
        lbfgs_minimize=namespace['one_iteration'],
        converged_all=original.tfp.optimizer.converged_all))
    original.tfp = proxy
    candidate_module.tfp = proxy

    import ast
    candidate_source = Path(candidate_module.__file__).read_text()
    needles = ('        attempts = variable(0, tf.int64)', '        optimizer_calls = variable(0, tf.int64)', '        replays = variable(0, tf.int64)')
    diagnostic_source = candidate_source
    for needle in needles:
        assert diagnostic_source.count(needle) == 1
        diagnostic_source = diagnostic_source.replace(needle, needle.replace('tf.int64', 'tf.int32'))
    class AccountingDtype(ast.NodeTransformer):
        count = 0
        def generic_visit(self, node):
            for needle in needles:
                parsed = ast.parse(needle.strip()).body[0]
                target = parsed.value if isinstance(parsed, ast.Expr) else parsed
                if ast.dump(node, include_attributes=False) == ast.dump(target, include_attributes=False):
                    self.count += needle.count('tf.int64')
                    changed = ast.parse(needle.strip().replace('tf.int64', 'tf.int32')).body[0]
                    return changed.value if isinstance(changed, ast.Expr) else changed
            return super().generic_visit(node)
    change = AccountingDtype()
    changed_tree = change.visit(ast.parse(candidate_source))
    assert change.count == 3
    assert ast.dump(changed_tree, include_attributes=False) == ast.dump(ast.parse(diagnostic_source), include_attributes=False)
    diagnostic_path = OUT / 'cpu-progress-reporting-diagnostic.py'
    diagnostic_path.write_text(diagnostic_source)
    (OUT / 'frozen-candidate-locator.py').write_text(candidate_source)
    diagnostic_module = types.ModuleType('cpu_int32_locator_context_diagnostic')
    diagnostic_module.__file__ = str(diagnostic_path)
    exec(compile(diagnostic_source, str(diagnostic_path), 'exec'), diagnostic_module.__dict__)
    diagnostic_module.tfp = proxy
    BatchedLocalCenterProgram = diagnostic_module.BatchedLocalCenterProgram
    report['counter_context_patch'] = {
        'family': 'reporting', 'original_sha256': hashlib.sha256(candidate_source.encode()).hexdigest(),
        'diagnostic_sha256': hashlib.sha256(diagnostic_source.encode()).hexdigest(),
        'changed_dtype_attributes': change.count,
        'only_selected_family_AST_change': True,
        'cpu_diagnostic_only_not_GPU_candidate': True}
    report['role'] = 'genuine_one_iteration_optimizer_context_diagnostic'
    report['probe_dispatch_sha256'] = hashlib.sha256(probe_source.encode()).hexdigest()
    report['nonclaims'].append('Real L-BFGS is limited to one iteration; no full optimization, convergence or runtime repair.')
    tick = time.monotonic()
    if 'candidate'.startswith('original'):
        location = original.locate_batched_local_center(measured_callback, initial, scale,
            config=original.BatchedLocalCenterConfig(**settings))
        assert len(observed) == 1
        compiled = observed[0]
    else:
        from bayesfilter.inference.batched_local_center import BatchedLocalCenterConfig
        owner = BatchedLocalCenterProgram(measured_callback, 1, 23, BatchedLocalCenterConfig(**settings))
        tensors = owner(initial, scale)
        compiled = owner.compiled
        location = BatchedLocalCenterResult(**tensors,
            trace_count=compiled.experimental_get_tracing_count())
    payload = location.payload()
    report['locator_seconds'] = time.monotonic() - tick
    count = int(calls)
    assert 0 < count <= capacity
    trace = {'positions': trace_positions[:count], 'values': trace_values[:count],
        'scores': trace_scores[:count], 'valid': trace_valid[:count]}
    with (OUT / 'locator-callbacks.npz').open('xb') as stream:
        write_tensor_npz(stream, trace)
    (OUT / 'locator-result.json').write_text(json.dumps(diagnostic_json(payload), indent=2, allow_nan=False) + '\n')
    report.update(target_evaluated=True, locator_result=payload, callback_rows=count,
        callbacks_sha256=sha(OUT / 'locator-callbacks.npz'),
        trace_count=compiled.experimental_get_tracing_count(),
        input_signature=str(compiled.input_signature),
        target_trace_counts={str(key): value.experimental_get_tracing_count() for key, value in base._compiled.items()},
        host_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    assert count == int(location.physical_target_rows)
    assert report['trace_count'] == 1
    assert compiled.function_spec.jit_compile
    concrete = compiled.get_concrete_function() if 'candidate'.startswith('original') else compiled.get_concrete_function(initial, scale)
    definition = concrete.graph.as_graph_def()
    nodes = [*definition.node, *(node for f in definition.library.function for node in f.node_def)]
    report['host_callbacks'] = sorted({node.op for node in nodes if any(term in node.op.lower()
        for term in ('pyfunc', 'xlahostcompute'))})
    report['graph_bytes'] = definition.ByteSize()
    report['graph_sha256'] = hashlib.sha256(definition.SerializeToString()).hexdigest()
    assert not report['host_callbacks']
    # Preserve compiler context without running an optimizer trajectory.
    arguments = () if 'candidate'.startswith('original') else (initial, scale)
    hlo = compiled.experimental_get_compiler_ir(*arguments)(stage='hlo')
    (OUT / 'first-objective-context.hlo.txt').write_text(hlo)
    report['context_hlo_sha256'] = hashlib.sha256(hlo.encode()).hexdigest()
    report['context_hlo_bytes'] = len(hlo.encode())
    report['optimizer_callback_batches'] = int(location.optimizer_target_batches)
    assert 1 <= report['optimizer_callback_batches'] <= 128
    assert base.assert_source_pinned()
    # Re-audit all actual project imports after tracing numerical callbacks.
    unexpected, loaded_after = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            owned = path.is_relative_to(BF) or path.is_relative_to(MF)
            named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
            if owned or named:
                loaded_after[name] = {'path': str(path), 'sha256': sha(path)}
                if not owned or expected_sources.get(str(path)) != sha(path):
                    unexpected[name] = str(path)
    report['post_target_loaded_modules'] = loaded_after
    report['post_target_unexpected_modules'] = unexpected
    assert not unexpected, unexpected
    assert all(sha(path) == digest for path, digest in expected_sources.items())


    forbidden_modules = [name for name in sys.modules if any(
        name == prefix or name.startswith(prefix + '.') for prefix in
        ('filters', 'inference.hmc', 'inference.mass_matrix', 'inference.posterior_adapter'))]
    report['forbidden_local_runtime_imports'] = forbidden_modules
    assert not forbidden_modules, forbidden_modules
    report['passed'] = True
except BaseException as error:
    report.update(error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
finally:
    (OUT / 'dz5-snapshot-import.json').write_text(json.dumps(diagnostic_json(report), indent=2, allow_nan=False)+'\n')
sys.exit(0 if report['passed'] else 1)
