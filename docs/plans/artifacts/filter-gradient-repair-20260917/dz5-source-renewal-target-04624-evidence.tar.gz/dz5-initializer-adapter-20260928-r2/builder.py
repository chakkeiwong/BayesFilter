"""Freeze an isolated adapter candidate; execute only after the capacity cohort."""

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

WORK = Path('/tmp/bayesfilter-filter-gradient-xla-validation-20260918')
BF = Path('/home/ubuntu/workspace/BayesFilter')
MF = Path('/home/ubuntu/workspace/MacroFinance-dz5-neutra')
RAW = BF / 'docs/plans/artifacts/filter-gradient-repair-20260917'
PREVIOUS = RAW / 'dz5-candidate-source-score-4c37f9f40-r1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--name', required=True)
    parser.add_argument('--adapter', type=Path, required=True)
    args = parser.parse_args()
    if Path(args.name).name != args.name or not args.name.startswith('dz5-initializer-adapter-'):
        parser.error('name must be a unique dz5-initializer-adapter-* directory name')
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
    subprocess.run(['git', 'diff', '--exit-code', 'HEAD', '--', 'bayesfilter'], cwd=WORK, check=True)
    prior = json.loads((PREVIOUS / 'manifest.json').read_text())
    output = RAW / args.name
    output.mkdir()
    sources, inputs, differences = {}, {}, {}

    def copy_file(path, canonical, destination):
        path, canonical = Path(path), Path(canonical)
        saved = output / str(canonical).lstrip('/')
        saved.parent.mkdir(parents=True, exist_ok=True)
        with saved.open('xb') as stream:
            stream.write(path.read_bytes())
        destination[str(canonical)] = {'saved': str(saved), 'sha256': sha(saved), 'origin': str(path)}
        assert sha(saved) == sha(path)

    adapter_path = MF / 'bayesfilter_estimation_initialization.py'
    for canonical, row in prior['sources'].items():
        origin = Path(row['saved'])
        assert sha(origin) == row['sha256'], canonical
        if Path(canonical).is_relative_to(MF):
            copy_file(args.adapter if Path(canonical) == adapter_path else origin, canonical, sources)
    assert str(adapter_path) in sources
    tracked = subprocess.check_output(['git', 'ls-files', 'bayesfilter', 'AGENTS.md',
        'docs/reference/neutra-implementation.md'], cwd=WORK, text=True).splitlines()
    for relative in tracked:
        copy_file(WORK / relative, BF / relative, sources)
    binary = str(BF / 'bayesfilter/ops/_symmetric_sylvester_ops.so')
    if binary not in sources:
        row = prior['sources'][binary]
        assert sha(Path(row['saved'])) == row['sha256']
        copy_file(row['saved'], binary, sources)
    for canonical, row in prior['inputs'].items():
        assert sha(Path(row['saved'])) == row['sha256'], canonical
        copy_file(row['saved'], canonical, inputs)
    for name in prior['sources'].keys() | sources.keys():
        before = prior['sources'].get(name, {}).get('sha256')
        after = sources.get(name, {}).get('sha256')
        if before != after:
            differences[name] = {'previous': before, 'candidate': after}
    manifest = {key: value for key, value in prior.items()
        if key not in ('sources', 'inputs', 'bayesfilter_commit', 'bayesfilter_dirty_status',
            'previous_snapshot_manifest', 'previous_snapshot_manifest_sha256')}
    (output / 'builder.py').write_bytes(Path(__file__).read_bytes())
    manifest.update(sources=sources, inputs=inputs, bayesfilter_commit=commit,
        bayesfilter_dirty_status=subprocess.check_output(['git', 'status', '--short'], cwd=WORK, text=True).splitlines(),
        previous_snapshot_manifest=str(PREVIOUS / 'manifest.json'),
        previous_snapshot_manifest_sha256=sha(PREVIOUS / 'manifest.json'),
        source_differences=differences,
        role='isolated_initializer_adapter_candidate_not_qualified',
        actual_loaded_module_audit='not checked on this snapshot',
        target_admission='old source admission remains stale; no admission issued',
        canonical_neutra_architecture='bayesfilter_neutra_iaf_author_v1',
        legacy_maps_and_recipes='historical_unfaithful_not_current_canonical_evidence',
        adapter_source_sha256=sha(args.adapter), builder_sha256=sha(Path(__file__)),
        numerical_qualification='not executed; current plan requires complete adapter and actual target evidence')
    with (output / 'manifest.json').open('x') as stream:
        json.dump(manifest, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'snapshot': str(output), 'manifest_sha256': sha(output / 'manifest.json'),
        'sources': len(sources), 'inputs': len(inputs), 'differences': len(differences)}))


if __name__ == '__main__':
    main()
