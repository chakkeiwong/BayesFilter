"""Source-bound readback of the full-filter state-layout intervention."""

import collections
import hashlib
import json
import re
from pathlib import Path

from scripts.analyze_filter_repair_locator_optimized_hlo import comparison, computations
from tests.test_filter_repair_ledh_seeded_readback import _load, _provenance
from tests.test_filter_repair_nonlinear_scope import RAW, ROOT, _latest


def _observation_loop(hlo, records, horizon):
    lines = hlo.splitlines()
    entry = next(row for row in records if row['entry'])
    candidates = [line for line in lines[entry['line']-1:entry['end_line']]
                  if ' while(' in line and f'f64[{horizon}]' in line and 'f64[64,2,2]' in line]
    assert len(candidates) == 1
    body = re.search(r'body=%([^, ]+)', candidates[0]).group(1)
    by_name = {row['name']: row for row in records}
    seen, pending = set(), [body]
    counts = collections.Counter()
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        counts.update(by_name[name]['opcodes'])
        pending.extend(by_name[name]['callees'])
    return {'instruction': candidates[0].strip(), 'reachable_computations': len(seen),
            'unique_reachable_opcodes': dict(counts),
            'limitation': 'Static unique-body counts, not executed multiplicities.'}


def test_streaming_state_layout_readback(request):
    qualification, run = _latest('streaming_state_qualification_cpu')
    assert run['state'] == 'passed' and run['test_evidence']['tests'] == 9
    assert run['test_evidence']['failure'] == run['test_evidence']['error'] == run['test_evidence']['skipped'] == 0
    for case in ('composed', 'annealed', 'dual_trust', 'invalid_initial',
                 'invalid_prediction', 'first_invalid_prediction', 'time_dependent', 'large_seeds'):
        report = _load(qualification, f'streamed-{case}.json')
        assert report['graph']['trace_count'] == 1
        assert all(row['exact_final_philox_state'] for row in report['records'])
    reports = []
    for horizon in (32, 128):
        arms = {}
        for arm in ('vector', 'scalar'):
            number, manifest = _latest(f'streaming_state_cost_{horizon}_{arm}_cpu')
            assert manifest['state'] == 'passed' and manifest['device'] == 'CPU'
            assert manifest['test_evidence'] == {'passed': True, 'tests': 1, 'failure': 0, 'error': 0, 'skipped': 0}
            result = _load(number, 'streaming-state-layout.json')
            assert result['horizon'] == horizon and result['arm'] == arm
            assert result['complete_records_exact'] and result['record']['program_valid']
            assert result['timing_excludes_comparator_and_hlo']
            assert len(result['warm_seconds']) == 30 and min(result['warm_seconds']) > 0
            assert result['graph']['trace_count'] == 1 and result['graph']['jit_compile']
            assert result['graph']['process_buffer_occurrences'] == 0
            for name, digest in manifest['source_sha256'].items():
                if name.startswith('bayesfilter/'):
                    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, (number, name)
            directory = RAW/f'run-{number:05d}'
            hlo = (directory/'state-layout-optimized.hlo.txt').read_text()
            assert hashlib.sha256(hlo.encode()).hexdigest() == result['graph']['hlo_sha256']
            for name, key in (('vector-state-source.py', 'baseline_source_sha256'),
                              ('scalar-state-source.py', 'candidate_source_sha256')):
                assert hashlib.sha256((directory/name).read_bytes()).hexdigest() == result[key]
            provenance = _provenance(number)
            assert provenance['trust_basis'] == 'explicit_cpu_reference'
            parsed = computations(hlo.splitlines())
            arms[arm] = {'run': number, 'manifest': manifest, 'result': result,
                         'provenance': provenance, 'parsed_hlo': parsed,
                         'observation_loop': _observation_loop(hlo, parsed, horizon)}
        left, right = arms['vector']['result'], arms['scalar']['result']
        for key in ('input_sha256', 'controls', 'baseline_commit', 'baseline_source_sha256',
                    'candidate_source_sha256', 'cpu_affinity', 'record'):
            assert left[key] == right[key], key
        assert arms['vector']['manifest']['environment'] == arms['scalar']['manifest']['environment']
        assert arms['vector']['manifest']['source_sha256'] == arms['scalar']['manifest']['source_sha256']
        assert arms['vector']['provenance'] == arms['scalar']['provenance']
        structure = comparison(arms['vector']['parsed_hlo'], arms['scalar']['parsed_hlo'])
        reports.append({'horizon': horizon, 'runs': {arm: row['run'] for arm, row in arms.items()},
            'warm_median_seconds': {arm: row['result']['warm_median_seconds'] for arm, row in arms.items()},
            'scalar_over_vector_warm_ratio': right['warm_median_seconds']/left['warm_median_seconds'],
            'scalar_over_vector_cold_ratio': right['cold_seconds']/left['cold_seconds'],
            'memory': {arm: row['result']['memory'] for arm, row in arms.items()},
            'hlo_counts': {arm: row['result']['graph'] for arm, row in arms.items()},
            'observation_loop': {arm: row['observation_loop'] for arm, row in arms.items()},
            'structural_comparison': structure, 'exact_full_record_parity': True})
    summary = {'schema': 'filter_repair_streaming_state_layout_summary.v1', 'qualification': qualification,
        'comparisons': reports, 'performance_accepted': False,
        'nonclaims': ['One process per arm; no statistical speed or GPU/default-readiness claim.',
                      'Static HLO differences alone do not establish performance causation.']}
    (Path(request.config.getoption('xmlpath')).parent/'streaming-state-layout-readback.json').write_text(
        json.dumps(summary, indent=2)+'\n')
