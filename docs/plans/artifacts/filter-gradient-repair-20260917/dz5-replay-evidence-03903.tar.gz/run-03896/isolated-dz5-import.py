
import hashlib
import importlib
import json
import math
import os
import sys
import traceback
from pathlib import Path

BF = Path('/home/ubuntu/workspace/BayesFilter')
MF = Path('/home/ubuntu/workspace/MacroFinance-dz5-neutra')
OUT = Path('/tmp/dz5-output')
sys.path[:0] = [str(MF), str(BF)]
report = {'schema': 'filter_repair_dz5_snapshot_import.v1', 'passed': False,
    'role': 'isolated_CPU_import_and_fixture_reference_only',
    'target_evaluated': False, 'adapter_admitted': False,
    'nonclaims': ['No target, initializer, transition, timing or retained qualification.']}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def diagnostic_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: diagnostic_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [diagnostic_json(item) for item in value]
    return value

try:
    manifest = json.loads(Path('/tmp/dz5-source/manifest.json').read_text())
    report['snapshot_manifest_sha256'] = sha('/tmp/dz5-source/manifest.json')
    expected = {path: entry['sha256'] for path, entry in manifest['sources'].items()}
    assert all(sha(path) == digest for path, digest in expected.items())
    gpu = os.environ['CUDA_VISIBLE_DEVICES'] != '-1'
    assert os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] == 'true'
    import tensorflow as tf
    from bayesfilter.runtime.gpu_memory_policy import configure_tensorflow_gpu_memory_growth
    memory = configure_tensorflow_gpu_memory_growth(tf, require_gpu=gpu)
    devices = tf.config.list_physical_devices('GPU')
    assert len(devices) == (1 if gpu else 0)
    report.update(device='GPU' if gpu else 'CPU',
        trust_basis='owner_designated_managed_session_visible_gpu_trusted' if gpu else 'CPU_reference',
        physical_gpus=[device.name for device in devices])
    report.update(gpu_memory_policy=memory, tensorflow=tf.__version__,
        cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'])

    from bayesfilter_estimation import audit_sources, declared_source_closure
    from two_currency_double_zlb_credit_estimation import (
        TFP_SPECIAL, TFP_SPECIAL_SHA, credit_fixture_identity)
    from two_currency_double_zlb_credit_fixtures import credit_fixture
    from two_currency_double_zlb_credit_target import CREDIT_FILTER_CONTRACT
    importlib.import_module('bayesfilter_estimation_initialization')
    importlib.import_module('two_currency_double_zlb_credit_recovery')
    importlib.import_module('bayesfilter.inference.dense_initializer_seeded_tf')
    importlib.import_module('bayesfilter.inference.tensor_npz_archive')
    assert sha(TFP_SPECIAL) == TFP_SPECIAL_SHA
    fixture = credit_fixture('CDF', n_steps=96)
    identity = credit_fixture_identity(fixture)
    assert identity == 'e116fe853c8579369036ab2ce57724ba07544524d0920fa0a706d76714f75d8a'
    assert len(fixture.parameter_names) == 23 and fixture.observations.shape[0] == 96
    assert CREDIT_FILTER_CONTRACT == 'rectangular_srukf_full_rank_identity_prepared_cir_v2'
    closure = audit_sources(declared_source_closure((
        MF / 'scripts/prepare_dz5_cdf_proposal.py',
        BF / 'bayesfilter/runtime/runner.py')))
    assert all(expected.get(path) == digest for path, digest in closure.items())
    loaded, unexpected = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if not filename:
            continue
        path = Path(filename).resolve()
        named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
        owned = path.is_relative_to(BF) or path.is_relative_to(MF)
        if named or owned:
            digest = sha(path)
            loaded[name] = {'path': str(path), 'sha256': digest}
            if not owned or expected.get(str(path)) != digest:
                unexpected[name] = loaded[name]
    report.update(loaded_modules=loaded, unexpected_modules=unexpected,
        source_closure=closure, fixture_identity=identity,
        parameter_names=fixture.parameter_names, observation_shape=list(fixture.observations.shape),
        filter_contract=CREDIT_FILTER_CONTRACT, tfp_special_sha256=TFP_SPECIAL_SHA)
    assert not unexpected, unexpected
    mounts = {}
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        fields = line.split()
        if fields[4] in (str(BF), str(MF)):
            mounts[fields[4]] = fields[5].split(',')
    report['source_mount_options'] = mounts
    assert set(mounts) == {str(BF), str(MF)}
    assert all('ro' in options for options in mounts.values())
    assert all(sha(path) == digest for path, digest in expected.items())
    expected_sources = expected.copy()

    import resource
    import time
    import numpy as np  # Independent replay inspection/serialization only.
    from two_currency_double_zlb_credit_target import (
        build_credit_factor_model_and_derivatives, credit_fixed_branch,
        credit_target_value_and_score)
    from bayesfilter.nonlinear.rectangular_srukf_tf import tf_rectangular_srukf_value_and_score
    assert not gpu
    tf.config.experimental.enable_op_determinism()
    tf.config.experimental.enable_tensor_float_32_execution(False)
    horizon = int(os.environ['FILTER_REPAIR_DZ5_PREFIX'])
    route = os.environ['FILTER_REPAIR_DZ5_REPLAY_ROUTE']
    assert route in ('direct', 'public', 'public_tuple') and 1 <= horizon <= 96
    prepared = fixture.likelihood_observations()
    class PrefixFixture:
        def likelihood_observations(self):
            return prepared[:horizon]
        def __getattr__(self, name):
            return getattr(fixture, name)
    prefix_fixture = PrefixFixture()
    np.testing.assert_array_equal(prefix_fixture.likelihood_observations(), prepared[:horizon])
    center, scale = np.asarray(fixture.parameter_truth), np.asarray(fixture.prior_scale)
    bank = np.concatenate((center[None], *(center + multiplier * step * np.diag(scale)
        for step in (1e-3, 5e-4) for multiplier in (-2, -1, 1, 2))))
    assert bank.shape == (185, 23)
    def evaluate(parameters):
        if route in ('public', 'public_tuple'):
            value, score, diagnostics = credit_target_value_and_score(
                parameters, prefix_fixture, jit_compile=False, evaluation_policy='hmc_rejection')
            if route == 'public_tuple':
                return value, score, diagnostics['valid_pre_regularized_score'], diagnostics['branch_status_code']
            return {'value': value, 'score': score,
                'valid': diagnostics['valid_pre_regularized_score'],
                'branch_status': diagnostics['branch_status_code']}
        model, derivatives = build_credit_factor_model_and_derivatives(
            parameters, fixture, prepare_fixed_cir_points=True)
        observations = tf.constant(prefix_fixture.likelihood_observations(), tf.float64)
        result = tf_rectangular_srukf_value_and_score(
            tf.broadcast_to(observations, [185, *observations.shape.as_list()]),
            model, derivatives, branch=credit_fixed_branch(fixture), jit_compile=False)
        return {'initial_mean': model.initial_mean, 'initial_factor': model.initial_factor,
            'd_initial_mean': derivatives.d_initial_mean, 'd_initial_factor': derivatives.d_initial_factor,
            'value': result.log_likelihood, 'score': result.score, 'mean': result.filtered_mean,
            'factor': result.filtered_factor, 'd_mean': result.d_filtered_mean,
            'd_factor': result.d_filtered_factor, 'valid': result.diagnostics['score_valid'],
            'branch_status': result.diagnostics['branch_status_code']}

    original_while_loop = tf.while_loop
    capture = {}
    state_names = ('mean', 'factor', 'd_mean', 'd_factor', 'value', 'score',
        'valid', 'minimum_pivot', 'maximum_chart_residual', 'maximum_support_residual')
    def instrumented_while_loop(cond, body, loop_vars, **kwargs):
        if body.__qualname__ != 'tf_rectangular_srukf_value_and_score.<locals>.run.<locals>.body':
            return original_while_loop(cond, body, loop_vars, **kwargs)
        assert len(loop_vars) == 11 and not capture
        buffers = tuple(tf.TensorArray(x.dtype, size=horizon, element_shape=x.shape)
            for x in loop_vars[1:])
        def recorded_body(*args):
            following = body(*args[:-1])
            updated = tuple(buf.write(args[0], x) for buf, x in zip(args[-1], following[1:], strict=True))
            return (*following, updated)
        recorded = original_while_loop(lambda *args: cond(*args[:-1]), recorded_body,
            (*loop_vars, buffers), **kwargs)
        capture.update({f'history_{name}': buf.stack()
            for name, buf in zip(state_names, recorded[-1], strict=True)})
        return recorded[:-1]
    plain_evaluate = evaluate
    def evaluate(parameters):
        tf.while_loop = instrumented_while_loop
        try:
            result = plain_evaluate(parameters)
            assert len(capture) == 10
            return {**result, **capture}
        finally:
            tf.while_loop = original_while_loop

    kernel = tf.function(evaluate, input_signature=[tf.TensorSpec([185, 23], tf.float64)],
        jit_compile=False, autograph=False)
    def rss():
        return next(int(line.split()[1]) * 1024 for line in
            Path('/proc/self/status').read_text().splitlines() if line.startswith('VmRSS:'))
    report.update(role='CPU_graph_carried_history_replay_explanatory_only', route=route,
        threads=int(os.environ['TF_NUM_INTRAOP_THREADS']), jit_compile=False,
        op_determinism_enabled=True, tf32_enabled=False, original_fixture_observations=96,
        evaluated_observations=horizon, batch=185, affinity=sorted(os.sched_getaffinity(0)),
        rss_before_bytes=rss(), replay_summaries=[], call_seconds=[],
        input_tensor_policy='same_tensor_reused_and_verified_unchanged',
        nonclaims=['No full-horizon score oracle, admission, HMC or performance qualification.'])
    first = None
    positions = tf.constant(bank)
    retained_first_tensors = None
    for repeat in range(3):
        tick = time.monotonic()
        with tf.device('/CPU:0'):
            returned = kernel(positions)
        if route == 'public_tuple':
            returned = dict(zip(('value', 'score', 'valid', 'branch_status'), returned, strict=True))
        current = {key: value.numpy() for key, value in returned.items()}
        report['call_seconds'].append(time.monotonic() - tick)
        report['target_evaluated'] = True
        np.testing.assert_array_equal(positions.numpy(), bank)
        np.savez_compressed(OUT / f'prefix-replay-{repeat}.npz', bank=bank,
            prepared_observations=prepared[:horizon], **current)
        assert all(np.isfinite(value).all() for value in current.values())
        assert current['valid'].all() and not current['branch_status'].any()
        if first is None:
            first = current
            retained_first_tensors = returned
        else:
            report['replay_summaries'].append({key: {
                'changed_elements': int(np.count_nonzero(value != first[key])),
                'max_absolute_error': float(np.max(np.abs(value.astype(float) - first[key].astype(float))))}
                for key, value in current.items()})

        assert current['history_valid'].all()
        report['first_differing_time'] = {key: {
            'observation': (int(np.flatnonzero(np.any(value != first[key], axis=tuple(range(1, value.ndim))))[0]) + 1)
                if np.any(value != first[key]) else None,
            'changed_by_time': np.count_nonzero(value != first[key], axis=tuple(range(1, value.ndim))).tolist()}
            for key, value in current.items() if key.startswith('history_')}
        (OUT / 'dz5-prefix-replay.json').write_text(json.dumps(report, indent=2) + '\n')
    assert kernel.experimental_get_tracing_count() == 1
    definition = kernel.get_concrete_function().graph.as_graph_def()
    nodes = [*definition.node, *(node for function in definition.library.function for node in function.node_def)]
    forbidden = sorted({node.op for node in nodes if any(term in node.op.lower() for term in
        ('pyfunc', 'sylvester', 'principalsqrt', 'xlahostcompute'))})
    assert not forbidden, forbidden
    report.update(trace_count=1, host_callbacks=forbidden, graph_node_count=len(nodes),
        graph_sha256=hashlib.sha256(definition.SerializeToString()).hexdigest(),
        replay_exact=all(row['changed_elements'] == 0 for summary in report['replay_summaries']
            for row in summary.values()), rss_after_bytes=rss(),
        host_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    (OUT / 'dz5-prefix-replay.json').write_text(json.dumps(report, indent=2) + '\n')
    # Re-audit all actual project imports after tracing numerical callbacks.
    unexpected, loaded_after = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            owned = path.is_relative_to(BF) or path.is_relative_to(MF)
            named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
            if owned or named:
                loaded_after[name] = {'path': str(path), 'sha256': sha(path)}
                if not owned or expected_sources.get(str(path)) != sha(path):
                    unexpected[name] = str(path)
    report['post_target_loaded_modules'] = loaded_after
    report['post_target_unexpected_modules'] = unexpected
    assert not unexpected, unexpected
    assert all(sha(path) == digest for path, digest in expected_sources.items())

    report['passed'] = True
except BaseException as error:
    report.update(error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
finally:
    (OUT / 'dz5-snapshot-import.json').write_text(json.dumps(diagnostic_json(report), indent=2, allow_nan=False)+'\n')
sys.exit(0 if report['passed'] else 1)
