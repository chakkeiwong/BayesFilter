import ctypes, json, time
from pathlib import Path
start = time.monotonic()
cuda = ctypes.CDLL("libcuda.so.1")
status = cuda.cuInit(0)
result = {"role": "CUDA initialization only, no contexts or numerical tensors", "cuInit_status": status, "elapsed_seconds": time.monotonic()-start}
Path("/tmp/dz5-output/result.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result))
