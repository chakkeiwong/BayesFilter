"""Bounded GPU trace compatibility and worst-resolution repair cost check."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import time
import traceback
import run_sqmc_expanded_comparison as campaign
import run_sqmc_expanded_repair as repair

def main(out):
    repair.configure_profile()
    started=time.perf_counter()
    out.mkdir(parents=True,exist_ok=False)
    meta=campaign.manifest()
    result=dict(status='running',program='FP64 GPU/XLA repair mechanics and cost only',records=[])
    tf=None
    try:
        inventory=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name','--format=csv,noheader'],text=True)
        meta['compute_apps_before']=inventory
        if 'GPU-68251639-fe82-8f81-3ccc-2953c32e805b' in inventory:
            raise RuntimeError('selected GPU already has a compute process')
        tf,gpu_meta=campaign.configure_gpu();meta.update(gpu_meta)
        from bayesfilter.highdim.sqmc_full_lgssm_tf import FullLGSSMSpec
        from bayesfilter.highdim.sqmc_campaign_tf import random_inputs,value_and_score
        for d,horizon,route,seed,epsilons in [(3,2,'iid_dual_cap',195002,repair.EPSILON_GRID),
                                            (10,120,'repaired_permutation',179003,(repair.EPSILON_GRID[-1],))]:
            spec=FullLGSSMSpec('full_matrix',d);theta=spec.default_theta(tf.float64)
            obs=spec.simulate(theta,horizon,seed,jit_compile=True)
            inputs=random_inputs(route,seed,1020,d,horizon,tf.float64)
            for epsilon in epsilons:
                controls=dict(campaign.CONTROLS[-1],reset_epsilon=epsilon)
                kernel=repair.trace_summary_kernel(spec,route,controls,1020,horizon)
                tick=time.perf_counter()
                row=repair.summarize_trace(kernel(theta,*inputs,obs))
                row.update(stage='trace',d=d,horizon=horizon,route=route,epsilon=epsilon,
                    wall_seconds=time.perf_counter()-tick)
                result['records'].append(row)
                campaign.dump(out/'result.json',result)
                print(json.dumps({k:v for k,v in row.items() if k!='per_time'}),flush=True)
                if d==3 and epsilon==.4:
                    saved=campaign.ROOT/'docs/plans/artifacts/sqmc-expanded-20260928/renewal-01/run-01/full_d3_T2__iid_dual_cap'
                    data=json.loads((saved/'data.json').read_text())
                    designs=json.loads((saved/'random_designs.json').read_text())[str(seed)]
                    if obs.numpy().tolist()!=data['datasets'][str(seed)]['observations']:
                        raise RuntimeError('failed-case observations do not reproduce')
                    for key,tensor in zip(('initial','process_noise','ancestor_uniforms'),inputs):
                        if hashlib.sha256(tf.io.serialize_tensor(tensor).numpy()).hexdigest()!=designs[key]['sha256']:
                            raise RuntimeError('failed-case random-design hash mismatch')
                    with tf.device('/CPU:0'):
                        cpu_kernel=tf.function(kernel.python_function,input_signature=kernel.input_signature,
                            jit_compile=False,autograph=False)
                        cpu_row=repair.summarize_trace(cpu_kernel(theta,*inputs,obs))
                    result['identical_input_cpu_reference']=cpu_row
                    result['saved_observation_and_design_hashes_verified']=True
                    if row['valid'] or cpu_row['valid'] or abs(row['maximum_column_tv']-cpu_row['maximum_column_tv'])>1e-10:
                        raise RuntimeError('identical-input CPU/GPU localization mismatch')
                if epsilon==repair.EPSILON_GRID[-1] and not row['nomination_pass']:
                    raise RuntimeError('bounded high-resolution trace does not pass')
        spec=FullLGSSMSpec('full_matrix',10);theta=spec.default_theta(tf.float64)
        observations=spec.simulate(theta,2,179001,jit_compile=True)
        for route in ('iid_dual_cap','repaired_permutation'):
            inputs=random_inputs(route,179002,1020,10,2,tf.float64)
            for base_controls in campaign.CONTROLS:
                controls=dict(base_controls,reset_epsilon=repair.EPSILON_GRID[-1])
                for phase in ('cold','warm'):
                    tick=time.perf_counter()
                    value,score,valid=value_and_score(spec,route,controls,theta,observations,
                        179002,1020,jit_compile=True,inputs=inputs)
                    score.numpy()
                    row=dict(stage='cost',route=route,flow_substeps=controls['flow_substeps'],
                        epsilon=repair.EPSILON_GRID[-1],phase=phase,wall_seconds=time.perf_counter()-tick,
                        valid=bool(valid.numpy()),value=float(value.numpy()),score=score.numpy().tolist())
                    result['records'].append(row)
                    campaign.dump(out/'result.json',result)
                    print(json.dumps({k:v for k,v in row.items() if k!='score'}),flush=True)
                    if not row['valid']:raise RuntimeError('cost fixture invalid')
        costs=[r for r in result['records'] if r['stage']=='cost']
        warm=max(r['wall_seconds'] for r in costs if r['phase']=='warm')
        cold=max(r['wall_seconds'] for r in costs if r['phase']=='cold')
        trace_time=max(r['wall_seconds'] for r in result['records'] if r['stage']=='trace')
        estimates=[]
        for scope,family,d,t,n in campaign.SCOPES:
            parameters=d*d+d*(d+1)//2+2
            # Eight scalar nominations per unit at the measured full-T120 trace cost.
            seconds=4*(9*warm*(t/2)*(parameters/157)+2*cold+15+8*trace_time)
            estimates.append(dict(scope=scope,estimated_seconds=seconds))
        base=sum(r['estimated_seconds'] for r in estimates)
        result.update(status='passed',projection=dict(scope_estimates=estimates,base_seconds=base,
            conservative_seconds=1.5*base,
            assumptions='Largest-epsilon full-score timing; linear horizon/direction scaling; eight scalar nominations each charged full-T120 cold trace time; 50% margin.'))
        if campaign.source_hashes()!=meta['source_sha256']:raise RuntimeError('source changed during repair check')
        meta['status']='passed'
    except BaseException as error:
        result.update(status='check_failed',error=repr(error))
        if str(error) in ('bounded high-resolution trace does not pass','cost fixture invalid'):
            result['failure_class']='numerical_candidate_rejected'
        meta.update(status='check_failed',error=repr(error))
        traceback.print_exc()
        raise
    finally:
        meta.update(finished_utc=campaign.now(),wall_seconds=time.perf_counter()-started)
        if tf is not None:meta['gpu_allocator_bytes']=tf.config.experimental.get_memory_info('GPU:0')
        campaign.dump(out/'result.json',result)
        campaign.dump(out/'manifest.json',meta)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True)
    main(Path(parser.parse_args().output).resolve())
