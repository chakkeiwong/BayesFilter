"""Post-run diagnostic for complete public single-locator CPU/GPU costs."""

import argparse
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path


def differences(actual, expected, path="result"):
    if isinstance(expected, dict):
        assert actual.keys() == expected.keys(), path
        return [item for key in expected for item in differences(actual[key], expected[key], path + "." + key)]
    if isinstance(expected, list):
        assert len(actual) == len(expected), path
        return [item for index, (left, right) in enumerate(zip(actual, expected, strict=True))
                for item in differences(left, right, f"{path}[{index}]")]
    if isinstance(expected, float):
        assert math.isfinite(actual) and math.isfinite(expected), path
        equal = abs(actual - expected) <= 1e-10 + 1e-10 * abs(expected)
    else:
        equal = actual == expected
    return [] if equal else [{"path": path, "actual": actual, "expected": expected}]


def analyze(checkout, root, numbers):
    sys.path.insert(0, str(checkout / "scripts"))
    from filter_repair_cost_provenance import (
        require_same_physical_gpu,
        validate_cost_device,
    )

    rows, closure, identities, reference_records, uuids = {}, None, {}, {}, []
    environment = None
    for number in numbers:
        directory = root / f"run-{number:05d}"
        run = json.loads((directory / "run.json").read_text())
        data = json.loads((directory / "joint-public-cost.json").read_text())
        assert run["state"] == "passed" and run["test_evidence"] == {
            "passed": True, "tests": 1, "failure": 0, "error": 0, "skipped": 0}
        assert data["candidate_installed_publicly"]
        assert data["numerical_authority"] == data["mechanism_baseline"] == "3582b4ac"
        provenance, = [json.loads(line) for line in (directory / "process.log").read_text().splitlines()
                       if line.startswith('{"tensorflow_version":')]
        uuids.append(validate_cost_device(run, provenance, data["gpu_process_observation"]))
        if closure is None:
            closure, environment = run["source_sha256"], (run["environment"], provenance)
        assert run["source_sha256"] == closure, "Source drift"
        assert (run["environment"], provenance) == environment, "Environment drift"
        arm, dimension = data["arm"], data["dimension"]
        identity = (data["input_sha256"], data["changed_input_sha256"], data["config"],
                    data["original_source_sha256"], data["original_compatibility"])
        identities.setdefault(dimension, identity)
        assert identity == identities[dimension], "Changed inputs/settings/reference"
        original = data["original_records"]
        xla_reference = data["cross_mode_original_records"] if arm == "graph" else original
        reference_records.setdefault(dimension, xla_reference)
        assert not differences(xla_reference, reference_records[dimension]), "Reference drift"
        mismatches, cross_mode = [], []
        for index, label in enumerate(("result", "changed_result")):
            mismatches += differences(data[label], original[index], label)
            cross_mode += differences(data[label], {**xla_reference[index], "jit_compile": arm != "graph"}, label)
            assert data[label]["endpoint_accepted"]
        assert not mismatches, mismatches
        assert len(data["samples"]) == 3
        programs = {} if data["program"] is None else {"locate": data["program"]}
        for program in programs.values():
            assert program["trace_count"] == 1 and program["jit_compile"] is (arm == "xla")
            if arm == "xla":
                assert program["hlo_unchanged"]
        rss = {key: value["rollup"]["Rss"] / 2**20 for key, value in data["stages"].items()}
        observed = [*data["stages"].values(), data["cold"]["memory"], data["changed_cost"]["memory"],
                    *(sample["memory"] for sample in data["samples"])]
        key = dimension, arm
        assert key not in rows
        rows[key] = {"run": number, "arm": arm, "dimension": dimension,
            "same_mode_full_records_passed": True, "cross_mode_differences": cross_mode,
            "cold_seconds": data["cold"]["seconds"],
            "median_warm_ms": 1000 * statistics.median(sample["seconds"] for sample in data["samples"]),
            "rss_mib": rss, "warm_growth_mib": rss["warm"] - rss["cold"],
            "observed_max_rss_mib": max(sample["rollup"]["Rss"] for sample in observed) / 2**20,
            "gpu_allocator_peak": max((sample["gpu"]["peak"] for sample in observed if sample["gpu"]), default=None),
            "programs": programs, "artifact_sha256": {
                name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                for name in ("run.json", "joint-public-cost.json", "process.log", "junit.xml")}}
    assert set(rows) == {(dimension, arm) for dimension in (1, 3) for arm in ("prior", "graph", "xla")}
    require_same_physical_gpu(uuids)
    comparisons = []
    for dimension in (1, 3):
        before, after = rows[dimension, "prior"], rows[dimension, "xla"]
        cold = after["cold_seconds"] / before["cold_seconds"]
        warm = after["median_warm_ms"] / before["median_warm_ms"]
        extra_rss = after["observed_max_rss_mib"] - before["observed_max_rss_mib"]
        triggers = []
        if cold > 2:
            triggers.append("cold_above_2x")
        if warm > 1.2:
            triggers.append("warm_above_1.2x")
        if extra_rss > 256 or after["observed_max_rss_mib"] > 2 * before["observed_max_rss_mib"]:
            triggers.append("host_rss_above_256MiB_or_2x")
        if before["gpu_allocator_peak"] and after["gpu_allocator_peak"] > 2 * before["gpu_allocator_peak"]:
            triggers.append("gpu_allocator_peak_above_2x")
        comparisons.append({"dimension": dimension, "xla_vs_prior_cold_ratio": cold,
            "xla_vs_prior_warm_ratio": warm, "xla_extra_observed_rss_mib": extra_rss, "triggers": triggers})
    return {"schema": "filter_joint_public_cost_analysis.v1", "rows": list(rows.values()),
        "comparisons": comparisons, "gpu_uuids": uuids,
        "source_closure_sha256": hashlib.sha256(json.dumps(closure, sort_keys=True).encode()).hexdigest(),
        "limits": ["One process per arm/extent; three warm calls; descriptive observations only.",
            "Original reconstructs the optimizer on every call. This is not an identical-graph compiler ablation.",
            "Mode-dependent selection differences remain explicit; no graph/XLA equal-result ranking.",
            "Observed RSS and allocator checkpoints do not establish exact peaks or native executable eviction."]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--runs", type=int, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    options = parser.parse_args()
    result = analyze(options.checkout, options.root, options.runs)
    with options.output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"output": str(options.output), "comparisons": result["comparisons"]}))
