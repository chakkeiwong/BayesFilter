"""Post-run FP64 comparison; never changes the existing per-field bounds."""
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917')
rows = []
for reference_number, case_runs in (
        (4135, (4114, 4115, 4116, 4117, 4126, 4127, 4128)),
        (4136, (4118, 4119, 4120, 4121, 4129, 4130, 4131)),
        (4137, (4122, 4123, 4124, 4125, 4132, 4133, 4134))):
    directory = ROOT / f'run-{reference_number:05d}'
    metadata = json.loads((directory/'genut-capacity-fp64.json').read_text())
    run = json.loads((directory/'run.json').read_text())
    assert run['state'] == 'passed'
    path = directory/'genut-capacity-fp64-arrays.npz'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == metadata['arrays_sha256']
    reference = dict(np.load(path, allow_pickle=False))
    source_directory = ROOT/f"run-{metadata['source_run']:05d}"
    assert hashlib.sha256((source_directory/'genut-capacity-arrays.npz').read_bytes()).hexdigest() == metadata['saved_fp32_arrays_sha256']
    source_cost = json.loads((source_directory/'genut-capacity.json').read_text())
    for number in case_runs:
        candidate_directory = ROOT/f'run-{number:05d}'
        cost = json.loads((candidate_directory/'genut-capacity.json').read_text())
        candidate_run = json.loads((candidate_directory/'run.json').read_text())
        assert candidate_run['state'] == 'passed'
        assert cost['input_sha256'] == source_cost['input_sha256']
        assert cost['reference_sha256'] == metadata['reference_sha256']
        path = candidate_directory/'genut-capacity-arrays.npz'
        assert hashlib.sha256(path.read_bytes()).hexdigest() == cost['arrays_sha256']
        actual = dict(np.load(path, allow_pickle=False))
        comparison = {key: dict(
            passed=bool(np.allclose(actual[key],value,atol=2e-5,rtol=2e-5)),
            max_abs_error=float(np.max(np.abs(actual[key].astype(np.float64)-value.astype(np.float64)))))
            for key,value in reference.items()}
        rows.append(dict(run=number, reference_run=reference_number, device=candidate_run['device'],
            arm=cost['arm'], mode=cost['mode'], count=cost['count'], dimension=cost['dimension'],
            comparison=comparison, failed_fields=[key for key,item in comparison.items() if not item['passed']],
            complete_record_passed=all(item['passed'] for item in comparison.values())))
report=dict(rows=rows,threshold_report_excluded_from_pass=False,
    scope='FP64 independent full-program diagnostic; every field reported at unchanged 2e-5 bounds',
    terminal_acceptance=False)
target=ROOT/'genut-capacity-precision-04137.json'
with target.open('x') as output:
    json.dump(report,output,indent=2,allow_nan=False)
    output.write('\n')
print('native failures',sorted({key for row in rows if row['arm']=='native' for key in row['failed_fields']}))
print('original non-report failures',[(row['run'],[key for key in row['failed_fields'] if key!='fraction_coordinatewise_cap_active']) for row in rows if row['arm']=='original'])
print('saved',target)
