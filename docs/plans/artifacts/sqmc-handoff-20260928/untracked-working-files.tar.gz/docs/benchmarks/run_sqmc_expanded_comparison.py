"""Bounded FP64 GPU/XLA diagnostic against Kalman; no method promotion.

The supervisor uses only the standard library. Each scope/route worker
configures GPU memory growth before importing algorithmic modules.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
PLAN = 'docs/plans/sqmc-expanded-comparison-20260926.md'
RESULT_NOTE = 'docs/benchmarks/sqmc-expanded-results-20260926.md'
GPU_UUID = 'GPU-68251639-fe82-8f81-3ccc-2953c32e805b'
ROUTES = ('iid_dual_cap', 'previous_inverse_cdf', 'repaired_permutation',
          'repaired_permutation_ablation')
CAL = (195001, 195002)
VAL = (196001,)
CLAIM = (197001, 197002)
FILTER = (198001, 198002)
SCOPES = (('p44_d3_T10', 'p44', 3, 10, 1008),
          ('p44_d3_T120', 'p44', 3, 120, 1008),
          ('full_d3_T2', 'full_matrix', 3, 2, 1020),
          ('full_d3_T10', 'full_matrix', 3, 10, 1020),
          ('full_d3_T120', 'full_matrix', 3, 120, 1020),
          ('full_d10_T2', 'full_matrix', 10, 2, 1020),
          ('full_d10_T10', 'full_matrix', 10, 10, 1020),
          ('full_d10_T120', 'full_matrix', 10, 120, 1020))
CONTROLS = [dict(flow_substeps=steps, reset_epsilon=.4, reset_sinkhorn_steps=24,
                 reset_balance_steps=12, correction_steps=1, correction_strength=.12,
                 pairwise_steps=1, pairwise_strength=.03) for steps in (2, 8)]


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def source_hashes():
    paths = (list((ROOT/'bayesfilter/highdim').glob('*.py')) +
             list((ROOT/'bayesfilter/runtime').glob('*.py')) + [Path(__file__), ROOT/PLAN])
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(paths)}


def final_pairs():
    return tuple(itertools.product(CLAIM, FILTER))


def l2_error(estimate, reference):
    if len(estimate) != len(reference):
        raise ValueError('score dimensions differ')
    return math.sqrt(math.fsum((a-b)**2 for a, b in zip(estimate, reference)))


def attach_heuristics(row, oracle, first):
    # Both baselines are estimators of the full-horizon score.
    row['heuristic_zero_score_l2_error'] = l2_error([0.]*len(oracle), oracle)
    row['heuristic_first_observation_only_l2_error'] = l2_error(first, oracle)
    if row.get('valid'):
        loss = row['score_l2_error']
        row['heuristic_dominance'] = {
            'zero_score': 'observed_loss' if loss > row['heuristic_zero_score_l2_error'] else 'no_observed_loss',
            'first_observation_only': 'observed_loss' if loss > row['heuristic_first_observation_only_l2_error'] else 'no_observed_loss',
            'evidence_class': 'descriptive_only; observed loss vetoes promotion, no superiority inference'}
    else:
        row['heuristic_dominance'] = {'verdict': 'not_evaluable_invalid_candidate'}
    return row


def manifest():
    return dict(schema='bayesfilter.sqmc_expanded_manifest.v2', started_utc=now(),
                command=[sys.executable, *sys.argv], cwd=str(ROOT), plan=PLAN,
                result_note=RESULT_NOTE, python=sys.executable,
                git_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                branch=subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip(),
                working_tree_status=subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True).splitlines(),
                source_sha256=source_hashes(), status='running',
                seed_partitions=dict(calibration=CAL, validation=VAL, final_data=CLAIM, final_filter=FILTER),
                precision_exception='FP64 comparison; not FP32/TF32 production evidence',
                oracle_exception='independent CPU/non-XLA Kalman reference',
                final_partition_note='Two pilot diagonal pairs were already observed; no controls were adjusted using pilot final errors. Repetition is not independent evidence.')


def worker(out, scope_name, route):
    started = time.perf_counter()
    out.mkdir(parents=True, exist_ok=False)
    meta = manifest()
    dump(out/'manifest.json', meta)
    result = dict(scope=scope_name, route=route, status='running', rows=[])
    dump(out/'result.json', result)
    tf = None
    try:
        os.environ['CUDA_VISIBLE_DEVICES'] = GPU_UUID
        os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] = 'true'
        os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
        os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '4')
        os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
        sys.path.insert(0, str(ROOT))
        import tensorflow as tf
        from bayesfilter.runtime.gpu_memory_policy import configure_tensorflow_gpu_memory_growth
        growth = configure_tensorflow_gpu_memory_growth(tf)
        if not tf.config.list_physical_devices('GPU'):
            raise RuntimeError('trusted GPU worker has no visible GPU')
        tf.config.experimental.enable_tensor_float_32_execution(False)
        with tf.device('/GPU:0'):
            probe = tf.reduce_sum(tf.ones([2, 2], tf.float64))
        if 'GPU' not in probe.device:
            raise RuntimeError('framework probe did not execute on GPU')
        meta.update(tensorflow=tf.__version__, gpu_memory_policy=growth, gpu_uuid=GPU_UUID,
                    cpu_gpu_status='GPU particle kernel; CPU Kalman oracle', tf32=False, jit_compile=True,
                    framework_gpu_probe=dict(device=probe.device, value=float(probe.numpy())),
                    gpu_inventory=subprocess.check_output(['nvidia-smi', '--query-gpu=uuid,name,memory.used,memory.total,utilization.gpu', '--format=csv,noheader'], text=True).strip())
        dump(out/'manifest.json', meta)
        from bayesfilter.highdim.sqmc_lgssm_tf import LGSSMSpec
        from bayesfilter.highdim.sqmc_full_lgssm_tf import FullLGSSMSpec
        from bayesfilter.highdim.sqmc_campaign_tf import random_inputs
        from bayesfilter.highdim.sqmc_campaign_tuning import tune_campaign, evaluate_untouched
        _, family, d, horizon, n = next(s for s in SCOPES if s[0] == scope_name)
        spec = FullLGSSMSpec(family, d) if family == 'full_matrix' else LGSSMSpec(family, d)
        theta = spec.default_theta(tf.float64)
        names = (spec.parameter_names if family == 'full_matrix' else
                 ['persistence_coordinate', 'log_Q_scale', 'log_R_scale', 'initial_mean_scale'])
        result.update(target_id=spec.target_id, dimension=d, horizon=horizon, particle_count=n,
                      parameter_count=spec.parameter_count, parameter_names=names, theta=theta.numpy().tolist())
        data = {}
        for seed in (*CAL, *VAL, *CLAIM):
            observations = spec.simulate(theta, horizon, seed, jit_compile=True)
            value, score = spec.reference_value_and_score(theta, observations)
            first = spec.reference_value_and_score(theta, observations[:1])[1]
            data[str(seed)] = dict(observations=observations.numpy().tolist(), oracle_value=float(value.numpy()),
                                   oracle_score=score.numpy().tolist(), first_observation_score=first.numpy().tolist())
        dump(out/'data.json', dict(theta=theta.numpy().tolist(), datasets=data))
        meta['data_version'] = dict(path='data.json', sha256=digest(out/'data.json'), generator=spec.target_id)
        designs = {}
        for seed in (*CAL, *VAL, *FILTER):
            tensors = random_inputs(route, seed, n, d, horizon, tf.float64)
            designs[str(seed)] = {key: dict(shape=t.shape.as_list(), dtype=t.dtype.name,
                sha256=hashlib.sha256(tf.io.serialize_tensor(t).numpy()).hexdigest())
                for key, t in zip(('initial', 'process_noise', 'ancestor_uniforms'), tensors)}
        dump(out/'random_designs.json', designs)
        meta['random_designs_sha256'] = digest(out/'random_designs.json')
        dump(out/'manifest.json', meta)

        def progress(stage, controls, row):
            record = dict(stage=stage, flow_substeps=controls['flow_substeps'], seed=row['seed'],
                          valid=row['valid'], wall_seconds=row['wall_seconds'], score_l2_error=row.get('score_l2_error'))
            with (out/'progress.jsonl').open('a') as stream:
                stream.write(json.dumps(record, allow_nan=False) + '\n')
            print(json.dumps(record), flush=True)

        artifact, tuning = tune_campaign(spec, route, CONTROLS, theta, horizon, n, CAL, VAL, CLAIM,
                                         jit_compile=True, on_result=progress)
        dump(out/'tuning.json', tuning)
        result['tuning_path'] = 'tuning.json'
        result['selected_controls'] = tuning.get('selected_controls')
        if artifact is None:
            result.update(status='tuning_failed', tuning_decision=tuning['decision'])
        else:
            for data_seed, filter_seed in final_pairs():
                row = evaluate_untouched(spec, route, artifact, theta, horizon, n, data_seed,
                                         jit_compile=True, filter_seed=filter_seed)
                row.pop('scope', None)  # Exact scope is checked by the evaluator and saved in tuning.json.
                reference = data[str(data_seed)]
                if row.get('oracle_score') is not None and l2_error(row['oracle_score'], reference['oracle_score']) > 1e-10:
                    raise RuntimeError('final evaluator disagrees with saved Kalman oracle')
                attach_heuristics(row, reference['oracle_score'], reference['first_observation_score'])
                result['rows'].append(row)
                dump(out/'result.json', result)
                progress('final', result['selected_controls'], row)
            result['status'] = 'complete' if all(r['valid'] for r in result['rows']) else 'complete_with_invalid_cells'
        if source_hashes() != meta['source_sha256']:
            raise RuntimeError('source changed during worker execution')
        meta['source_unchanged'] = True
        meta['status'] = result['status']
    except BaseException as error:
        meta.update(status='infrastructure_or_harness_failure', error=repr(error))
        result.update(status=meta['status'], error=repr(error))
        traceback.print_exc()
        raise
    finally:
        meta.update(finished_utc=now(), wall_seconds=time.perf_counter()-started)
        if tf is not None:
            try:
                meta['gpu_allocator_bytes'] = tf.config.experimental.get_memory_info('GPU:0')
            except (ValueError, RuntimeError) as error:
                meta['gpu_allocator_unavailable'] = str(error)
        result['wall_seconds'] = meta['wall_seconds']
        dump(out/'manifest.json', meta)
        dump(out/'result.json', result)


def assemble(out, cases):
    lookup = {(case['scope'], row['data_seed'], row['filter_seed']): row
              for case in cases if case['route'] == 'iid_dual_cap' for row in case['rows']}
    fields = ('scope', 'route', 'data_seed', 'filter_seed', 'coordinate', 'exact_score', 'estimated_score', 'signed_error', 'absolute_error')
    with (out/'scores.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for case in cases:
            for row in case['rows']:
                if not row['valid']:
                    continue
                iid = lookup.get((case['scope'], row['data_seed'], row['filter_seed']))
                if iid and iid['valid']:
                    row['heuristic_dominance']['iid'] = ('baseline' if case['route']=='iid_dual_cap' else
                        'observed_loss' if row['score_l2_error'] > iid['score_l2_error'] else 'no_observed_loss')
                errors = [a-b for a,b in zip(row['score'],row['oracle_score'])]
                d = case['dimension']
                blocks = ({'A': (0,d*d), 'Cholesky_Q': (d*d,len(errors)-2), 'R': (len(errors)-2,len(errors)-1), 'm0':(len(errors)-1,len(errors))}
                          if case['scope'].startswith('full_') else {name:(i,i+1) for i,name in enumerate(case['parameter_names'])})
                row['block_score_rmse'] = {name: math.sqrt(statistics.fmean(e*e for e in errors[a:b])) for name,(a,b) in blocks.items()}
                for name, exact, estimate in zip(case['parameter_names'], row['oracle_score'], row['score']):
                    writer.writerow(dict(scope=case['scope'], route=case['route'], data_seed=row['data_seed'],
                        filter_seed=row['filter_seed'], coordinate=name, exact_score=exact, estimated_score=estimate,
                        signed_error=estimate-exact, absolute_error=abs(estimate-exact)))
    dump(out/'results.json', dict(schema='bayesfilter.sqmc_expanded_results.v2', cases=cases,
         inference_status='descriptive_only; two data sets and two random designs do not establish ranking',
         expected_units=32, completed_units=len(cases), expected_final_cells=128,
         recorded_final_cells=sum(len(c['rows']) for c in cases)))


def supervisor(out, budget_seconds):
    out.mkdir(parents=True, exist_ok=False)
    (out/'logs').mkdir()
    started = time.perf_counter()
    meta = manifest()
    meta.update(budget_seconds=budget_seconds, prior_gpu_seconds_reserved=1200, units=[])
    cases = []
    dump(out/'manifest.json', meta)
    try:
        for scope, *_ in SCOPES:
            for route in ROUTES:
                remaining = budget_seconds-(time.perf_counter()-started)
                if remaining < 60:
                    meta['status'] = 'budget_exhausted'
                    return
                if source_hashes() != meta['source_sha256']:
                    raise RuntimeError('source changed during campaign')
                unit = f'{scope}__{route}'
                command = [sys.executable, str(Path(__file__).resolve()), '--output', str(out/unit),
                           '--worker-scope', scope, '--worker-route', route]
                entry = dict(unit=unit, command=command, started_utc=now(), status='running')
                meta['units'].append(entry)
                dump(out/'manifest.json', meta)
                tick = time.perf_counter()
                with (out/'logs'/f'{unit}.log').open('w') as log:
                    process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                    entry['pid'] = process.pid
                    dump(out/'manifest.json', meta)
                    try:
                        code = process.wait(timeout=min(5400, remaining))
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                        entry['status'] = 'timeout'
                        code = process.returncode
                entry.update(return_code=code, wall_seconds=time.perf_counter()-tick, finished_utc=now())
                if code:
                    entry['status'] = 'worker_failure'
                    raise RuntimeError(f'{unit} exited {code}; preserve and repair before retry')
                case = json.loads((out/unit/'result.json').read_text())
                case['artifact_directory'] = unit
                entry['status'] = case['status']
                cases.append(case)
                assemble(out, cases)
                dump(out/'manifest.json', meta)
                print(json.dumps(dict(unit=unit,status=case['status'],wall_seconds=entry['wall_seconds'])), flush=True)
        meta['status'] = 'complete' if all(c['status']=='complete' for c in cases) else 'complete_with_candidate_failures'
    except BaseException as error:
        meta.update(status='infrastructure_or_harness_failure', error=repr(error))
        raise
    finally:
        meta.update(finished_utc=now(), wall_seconds=time.perf_counter()-started)
        dump(out/'manifest.json', meta)
        assemble(out, cases)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--worker-scope', choices=[s[0] for s in SCOPES])
    parser.add_argument('--worker-route', choices=ROUTES)
    parser.add_argument('--budget-seconds', type=float, default=42000)
    args = parser.parse_args()
    if bool(args.worker_scope) != bool(args.worker_route):
        parser.error('worker requires both scope and route')
    if args.worker_scope:
        worker(Path(args.output).resolve(), args.worker_scope, args.worker_route)
    else:
        supervisor(Path(args.output).resolve(), args.budget_seconds)


if __name__ == '__main__':
    main()
