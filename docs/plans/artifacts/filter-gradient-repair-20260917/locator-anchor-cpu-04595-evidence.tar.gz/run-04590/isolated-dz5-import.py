
import hashlib
import importlib
import json
import math
import os
import sys
import traceback
from pathlib import Path

BF = Path('/home/ubuntu/workspace/BayesFilter')
MF = Path('/home/ubuntu/workspace/MacroFinance-dz5-neutra')
OUT = Path('/tmp/dz5-output')
sys.path[:0] = [str(MF), str(BF)]
report = {'schema': 'filter_repair_dz5_snapshot_import.v1', 'passed': False,
    'role': 'isolated_CPU_import_and_fixture_reference_only',
    'target_evaluated': False, 'adapter_admitted': False,
    'nonclaims': ['No target, initializer, transition, timing or retained qualification.']}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def diagnostic_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: diagnostic_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [diagnostic_json(item) for item in value]
    return value

try:
    manifest = json.loads(Path('/tmp/dz5-source/manifest.json').read_text())
    report['snapshot_manifest_sha256'] = sha('/tmp/dz5-source/manifest.json')
    expected = {path: entry['sha256'] for path, entry in manifest['sources'].items()}
    assert all(sha(path) == digest for path, digest in expected.items())
    gpu = os.environ['CUDA_VISIBLE_DEVICES'] != '-1'
    assert os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] == 'true'
    import tensorflow as tf
    from bayesfilter.runtime.gpu_memory_policy import configure_tensorflow_gpu_memory_growth
    memory = configure_tensorflow_gpu_memory_growth(tf, require_gpu=gpu)
    devices = tf.config.list_physical_devices('GPU')
    assert len(devices) == (1 if gpu else 0)
    report.update(device='GPU' if gpu else 'CPU',
        trust_basis='owner_designated_managed_session_visible_gpu_trusted' if gpu else 'CPU_reference',
        physical_gpus=[device.name for device in devices])
    report.update(gpu_memory_policy=memory, tensorflow=tf.__version__,
        cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'])

    from bayesfilter_estimation import audit_sources, declared_source_closure
    from two_currency_double_zlb_credit_estimation import (
        TFP_SPECIAL, TFP_SPECIAL_SHA, credit_fixture_identity)
    from two_currency_double_zlb_credit_fixtures import credit_fixture
    from two_currency_double_zlb_credit_target import CREDIT_FILTER_CONTRACT
    importlib.import_module('bayesfilter_estimation_initialization')
    importlib.import_module('two_currency_double_zlb_credit_recovery')
    importlib.import_module('bayesfilter.inference.dense_initializer_seeded_tf')
    importlib.import_module('bayesfilter.inference.tensor_npz_archive')
    assert sha(TFP_SPECIAL) == TFP_SPECIAL_SHA
    fixture = credit_fixture('CDF', n_steps=96)
    identity = credit_fixture_identity(fixture)
    assert identity == 'e116fe853c8579369036ab2ce57724ba07544524d0920fa0a706d76714f75d8a'
    assert len(fixture.parameter_names) == 23 and fixture.observations.shape[0] == 96
    assert CREDIT_FILTER_CONTRACT == 'rectangular_srukf_full_rank_identity_prepared_cir_v2'
    closure = audit_sources(declared_source_closure((
        MF / 'scripts/prepare_dz5_cdf_proposal.py',
        BF / 'bayesfilter/runtime/runner.py')))
    assert all(expected.get(path) == digest for path, digest in closure.items())
    loaded, unexpected = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if not filename:
            continue
        path = Path(filename).resolve()
        named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
        owned = path.is_relative_to(BF) or path.is_relative_to(MF)
        if named or owned:
            digest = sha(path)
            loaded[name] = {'path': str(path), 'sha256': digest}
            if not owned or expected.get(str(path)) != digest:
                unexpected[name] = loaded[name]
    report.update(loaded_modules=loaded, unexpected_modules=unexpected,
        source_closure=closure, fixture_identity=identity,
        parameter_names=fixture.parameter_names, observation_shape=list(fixture.observations.shape),
        filter_contract=CREDIT_FILTER_CONTRACT, tfp_special_sha256=TFP_SPECIAL_SHA)
    assert not unexpected, unexpected
    mounts = {}
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        fields = line.split()
        if fields[4] in (str(BF), str(MF)):
            mounts[fields[4]] = fields[5].split(',')
    report['source_mount_options'] = mounts
    assert set(mounts) == {str(BF), str(MF)}
    assert all('ro' in options for options in mounts.values())
    assert all(sha(path) == digest for path, digest in expected.items())
    expected_sources = expected.copy()

    import contextlib
    import gc
    import resource
    import time
    import weakref
    from dataclasses import replace
    from types import SimpleNamespace
    from bayesfilter_estimation import EstimationRecipe
    from bayesfilter_estimation_initialization import initialize_dense_local
    from two_currency_double_zlb_credit_estimation import credit_model
    from two_currency_double_zlb_credit_recovery import CreditTrainingTarget
    from bayesfilter.inference import dense_initializer_seeded_tf as seeded
    tf.config.experimental.enable_tensor_float_32_execution(False)
    recipe_path = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917/dz5-initializer-accepted-inputs-20260928-r1/recipe.json')
    admission_path = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917/dz5-initializer-adapter-target-admission-20260928-r1.json')
    recipe = EstimationRecipe(**json.loads(recipe_path.read_text()))
    admission = json.loads(admission_path.read_text())
    assert admission['role'] == 'fresh_target_only_isolated_initializer_regression'
    assert admission['snapshot_manifest_sha256'] == report['snapshot_manifest_sha256']
    assert not any(admission[key] for key in ('old_admission_reused', 'training_authorized',
        'hmc_authorized', 'retained_authorized'))
    model = credit_model(stage='CDF', qualification=admission_path, recipe=recipe)
    base = model.sampling_target
    assert base.fixture_identity_sha256 == report['fixture_identity']
    model = replace(model, training_target=CreditTrainingTarget(base, base.fixture.prior_mean, model.data_identity))
    if True:
        replay_started = time.monotonic()
        inputs_root = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917/dz5-initializer-accepted-inputs-20260928-r1')
        inputs = json.loads((inputs_root / 'manifest.json').read_text())
        assert all(sha(row['saved']) == row['sha256'] for row in inputs['files'].values())
        point_row = inputs['files']['start_point']
        point = json.loads(Path(point_row['saved']).read_text())
        assert point['fixture_identity'] == base.fixture_identity_sha256
        assert point['admission_sha256'] == inputs['files']['original_admission']['sha256']
        assert point['optimizer_state_reused'] is False
        for source, digest in point['artifacts'].items():
            rows = [row for row in inputs['files'].values() if row['source'] == source]
            assert len(rows) == 1 and rows[0]['sha256'] == digest
        with tf.device('/GPU:0' if gpu else '/CPU:0'):
            position = tf.constant([point['point']], tf.float64)
            value, score, status, valid, *_ = base._evaluate(position)
        assert bool(tf.reduce_all(valid & (status == 0)))
        tf.debugging.assert_less_equal(tf.abs(value - tf.constant([point['value']], tf.float64)),
            tf.constant(1e-8, tf.float64) + tf.constant(1e-9, tf.float64) * tf.abs(tf.constant([point['value']], tf.float64)))
        tf.debugging.assert_less_equal(tf.abs(score - tf.constant([point['score']], tf.float64)),
            tf.constant(1e-8, tf.float64) + tf.constant(1e-7, tf.float64) * tf.abs(tf.constant([point['score']], tf.float64)))
        fresh_point = {'role': 'fresh_value_score_replay_of_frozen_prior_origin_initializer_start',
            'point': position[0].numpy().tolist(), 'value': float(value[0]), 'score': score[0].numpy().tolist(),
            'original_point_sha256': point_row['sha256'],
            'original_admission_sha256': point['admission_sha256'],
            'current_admission_sha256': sha(admission_path), 'fixture_identity': base.fixture_identity_sha256,
            'optimizer_state_reused': False, 'training_or_HMC_authorized': False}
        (OUT / 'initializer-start-replay.json').write_text(json.dumps(fresh_point, indent=2, allow_nan=False) + '\n')
        model = replace(model, initial_position=position[0])
        report.update(start_replay_seconds=time.monotonic() - replay_started,
            accepted_input_manifest_sha256=sha(inputs_root / 'manifest.json'),
            start_replay=fresh_point)

    from two_currency_double_zlb_credit_target import credit_target_value_and_score
    assert not gpu
    evidence_path = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917/run-04586/dz5-locator-first-divergence.json')
    evidence = json.loads(evidence_path.read_text())
    assert evidence['source_runs'] == [4584, 4585]
    assert json.loads((evidence_path.parent / 'run.json').read_text())['state'] == 'passed'
    cases = []
    for row in evidence['first_difference_rows']:
        for arm in ('original', 'candidate'):
            cases.append({'label': f"{arm}_{row['callback_index']}", **row[arm]})
    for arm, number in (('original', 4584), ('candidate', 4585)):
        locator = json.loads((evidence_path.parent.parent / f'run-{number:05d}' / 'locator-result.json').read_text())
        cases.append({'label': arm + '_selected_center', 'positions': locator['center'],
            'values': locator['center_value'], 'scores': locator['center_score'], 'valid': locator['accepted']})
    signature = [tf.TensorSpec([1, 23], tf.float64)]
    callback = tf.function(model.training_target.batch_value_score_and_validity,
        input_signature=signature, jit_compile=True, autograph=False)
    @tf.function(input_signature=signature, jit_compile=False, autograph=False)
    def graph_reference(points):
        value, score, diagnostics = credit_target_value_and_score(points, base.fixture,
            jit_compile=False, evaluation_policy='hmc_rejection')
        return value, score, diagnostics['valid_pre_regularized_score'], diagnostics['branch_status_code']
    rows, failures = [], []
    report.update(role='same_position_CDF_trajectory_reference_replay',
        evidence_sha256=sha(evidence_path), target_execution_attempted=True,
        cpu_reference_exception=True, jit_compile=True,
        reference='explicit graph analytical value/score path of the same frozen source',
        comparisons=rows, replay_failures=failures,
        nonclaims=['No bitwise trajectory equivalence, source admission, optimizer repair or scientific promotion.'])
    def error(left, right):
        delta = tf.abs(left - right)
        target_bound = tf.constant(1e-8, tf.float64) + tf.constant(1e-7, tf.float64) * tf.abs(right)
        strict_bound = tf.constant(1e-10, tf.float64) + tf.constant(1e-10, tf.float64) * tf.abs(right)
        finite = bool(tf.reduce_all(tf.math.is_finite(left) & tf.math.is_finite(right)))
        return {'max_absolute_error': float(tf.reduce_max(delta)),
            'max_target_bound_ratio': float(tf.reduce_max(delta / target_bound)),
            'within_target_bounds': finite and bool(tf.reduce_all(delta <= target_bound)),
            'within_strict_record_bounds': finite and bool(tf.reduce_all(delta <= strict_bound))}
    for case in cases:
        points = tf.constant([case['positions']], tf.float64)
        tick = time.monotonic()
        actual = callback(points)
        expected = graph_reference(points)
        comparisons = {}
        for name, index in (('values', 0), ('scores', 1)):
            saved = tf.constant([case[name]], tf.float64)
            comparisons[name] = {
                'standalone_vs_graph': error(actual[index], expected[index]),
                'saved_vs_graph': error(saved, expected[index]),
                'saved_vs_standalone': error(saved, actual[index])}
            for context, result in comparisons[name].items():
                if not result['within_target_bounds']:
                    failures.append({'case': case['label'], 'field': name, 'context': context, **result})
        valid = bool(tf.reduce_all(actual[2] & expected[2] & (expected[3] == 0)))
        if valid != case['valid'] or not valid:
            failures.append({'case': case['label'], 'failure': 'validity_or_branch_status'})
        rows.append({'label': case['label'], 'positions': case['positions'],
            'value': actual[0].numpy().tolist(), 'score': actual[1].numpy().tolist(),
            'reference_value': expected[0].numpy().tolist(), 'reference_score': expected[1].numpy().tolist(),
            'valid': valid, 'comparisons': comparisons, 'elapsed_seconds': time.monotonic() - tick})
    report.update(target_evaluated=True, trace_count=callback.experimental_get_tracing_count(),
        reference_trace_count=graph_reference.experimental_get_tracing_count(),
        host_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    assert report['trace_count'] == report['reference_trace_count'] == 1
    definition = callback.get_concrete_function().graph.as_graph_def()
    nodes = [*definition.node, *(node for f in definition.library.function for node in f.node_def)]
    report['host_callbacks'] = sorted({node.op for node in nodes if any(term in node.op.lower()
        for term in ('pyfunc', 'xlahostcompute'))})
    assert not report['host_callbacks']
    assert base.assert_source_pinned()
    assert not failures, failures
    # Re-audit all actual project imports after tracing numerical callbacks.
    unexpected, loaded_after = {}, {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            owned = path.is_relative_to(BF) or path.is_relative_to(MF)
            named = name.startswith(('bayesfilter', 'two_currency_double_zlb'))
            if owned or named:
                loaded_after[name] = {'path': str(path), 'sha256': sha(path)}
                if not owned or expected_sources.get(str(path)) != sha(path):
                    unexpected[name] = str(path)
    report['post_target_loaded_modules'] = loaded_after
    report['post_target_unexpected_modules'] = unexpected
    assert not unexpected, unexpected
    assert all(sha(path) == digest for path, digest in expected_sources.items())


    forbidden_modules = [name for name in sys.modules if any(
        name == prefix or name.startswith(prefix + '.') for prefix in
        ('filters', 'inference.hmc', 'inference.mass_matrix', 'inference.posterior_adapter'))]
    report['forbidden_local_runtime_imports'] = forbidden_modules
    assert not forbidden_modules, forbidden_modules
    report['passed'] = True
except BaseException as error:
    report.update(error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
finally:
    (OUT / 'dz5-snapshot-import.json').write_text(json.dumps(diagnostic_json(report), indent=2, allow_nan=False)+'\n')
sys.exit(0 if report['passed'] else 1)
