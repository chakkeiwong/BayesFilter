"""Post-run independent diagnostic analysis of the untouched GenUT cohort."""
import hashlib
import json
import statistics
from pathlib import Path

import numpy as np

ROOT = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917')
rows = []
sources = None
references = {}
for number in range(4114, 4135):
    directory = ROOT / f'run-{number:05d}'
    run = json.loads((directory / 'run.json').read_text())
    cost = json.loads((directory / 'genut-capacity.json').read_text())
    assert run['state'] == 'passed' and run['test_evidence']['passed']
    if sources is None:
        sources = run['source_sha256']
    assert sources == run['source_sha256'], number
    array_path = directory / 'genut-capacity-arrays.npz'
    assert hashlib.sha256(array_path.read_bytes()).hexdigest() == cost['arrays_sha256']
    arrays = dict(np.load(array_path, allow_pickle=False))
    case = (run['device'], cost['count'], cost['dimension'])
    if cost['arm'] == 'original' and cost['mode'] == 'graph':
        references[case] = (cost, arrays)
    baseline, base_arrays = references[case]
    assert cost['input_sha256'] == baseline['input_sha256']
    assert cost['reference_sha256'] == baseline['reference_sha256']
    assert arrays.keys() == base_arrays.keys()
    comparison = {}
    for key in arrays:
        value, prior = arrays[key], base_arrays[key]
        if key in ('source', 'weights', 'reset'):
            assert np.array_equal(value, prior), key
        else:
            comparison[key] = dict(passed=bool(np.allclose(value, prior, atol=2e-5, rtol=2e-5)),
                max_abs_error=float(np.max(np.abs(value.astype(np.float64)-prior.astype(np.float64)))))
    device = cost['device_provenance']
    assert device['uuid'] == baseline['device_provenance']['uuid']
    assert not device['errors']
    sharing = any(process['pid'] != device['pid'] for sample in device['samples']
                  for process in sample['processes']) if device['enabled'] else None
    current, peak = (None, None) if cost['compiled']['gpu'] is None else (
        cost['compiled']['gpu']['current'], cost['warm']['gpu']['peak'])
    rows.append(dict(run=number, device=run['device'], arm=cost['arm'], mode=cost['mode'],
        count=cost['count'], dimension=cost['dimension'], numerical_qualified=cost['numerical_qualified'],
        independent_moment_max_error=cost['independent_moment_max_error'],
        cold_seconds=cost['cold_seconds'], warm_median_ms=statistics.median(cost['warm_seconds'])*1000,
        rss_compiled_mib=cost['compiled']['status']['VmRSS']/2**20,
        rss_peak_mib=cost['warm']['status']['VmHWM']/2**20,
        warm_rss_increase_kib=(cost['warm']['status']['VmRSS']-cost['compiled']['status']['VmRSS'])/1024,
        gpu_allocator_current_bytes=current, gpu_allocator_peak_bytes=peak,
        gpu_uuid=device['uuid'], observed_sharing=sharing,
        original_graph_comparison=comparison,
        complete_record_matches_original_graph=all(item['passed'] for item in comparison.values()),
        run_sha256=hashlib.sha256((directory/'run.json').read_bytes()).hexdigest(),
        cost_sha256=hashlib.sha256((directory/'genut-capacity.json').read_bytes()).hexdigest()))
report = dict(schema='genut_capacity_analysis.v1', rows=rows, source_file_count=len(sources),
    role='descriptive_controlled_capacity_not_full_target_or_speed_ranking',
    complete_program_qualification=False, reporting_gate_waived=False)
target = ROOT/'genut-capacity-summary-04134.json'
with target.open('x') as output:
    json.dump(report, output, indent=2, allow_nan=False)
    output.write('\n')
for row in rows:
    selected={key: row[key] for key in ('run','device','arm','mode','count','dimension','numerical_qualified',
        'cold_seconds','warm_median_ms','rss_compiled_mib','warm_rss_increase_kib','gpu_allocator_peak_bytes',
        'observed_sharing','complete_record_matches_original_graph')}
    selected['failed_fields']=[key for key,item in row['original_graph_comparison'].items() if not item['passed']]
    print(selected)
print('source_file_count', len(sources), 'summary', target)
