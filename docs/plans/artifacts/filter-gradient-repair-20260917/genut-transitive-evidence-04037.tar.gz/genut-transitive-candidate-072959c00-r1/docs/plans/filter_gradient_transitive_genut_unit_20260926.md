# Transitive GenUT execution repair and import audit

Question: do the uncovered GenUT correction and model-callback operations
preserve their existing finite outputs when executed in one enclosing XLA
program, without Python numerical iteration? Import discovery through run
03993 found 17 modules outside the guard. This is a search overapproximation,
not proof that all 17 execute from every endpoint. Classify each construct and
record actual consumer relationships before extending coverage.

The first bounded numerical unit converts the diagonal and pairwise iteration
in `dual_cap_genut_primal_tf` to sequential `tf.while_loop`, and the Austria
callback's infectious-coordinate matrix to batched `tf.one_hot`. Baseline is
the exact Git source at `072959c00`, evaluated afresh. Preserve update order,
all controls, ridges, caps, validity thresholds, output fields and supplied
random inputs. The reduced primal correction is not the canonical LEDH
trust-region algorithm; repairing it grants no canonical admission. Its
existing callers and canonical-claim blocks must remain explicit.

Primary gates: complete frozen-source records for FP64 and FP32, same-mode
original/candidate parity, cross-mode diagnostics, scalar-state pairwise no-op,
zero iterations, nonuniform weights, changed operands, exact repeated calls,
one trace and enclosing HLO without host callbacks. Independently verify
restoration of weighted mean/covariance, the radial-cap bound and infectious
coordinate selection. The correction is primal-only: autodiff, if used in a
test, is an independent diagnostic and cannot establish an analytical score.
Exercise the real reset consumer with policy-compliant K=N and preserve its
candidate identity. Reference tolerances are fixed before execution at
2e-10 absolute/relative in FP64 and 2e-5 in FP32 for these full-record
comparisons; discrete outputs and exact replay must match exactly. These are
new local fixture bounds, not changes to any existing acceptance test.

Use N=72,d=3 and d=1 standard-normal primitive fixtures (seeds 101/102,
103/104,105/106) evaluated anew. These dimensions/seeds come from an existing
primitive fixture; no old LEDH result is reused. They are execution fixtures,
not calibrated numerical settings or evidence of scientific superiority.
Include a second changed cloud/weight operand. A small, full-rank covariance
keeps factorization failure from obscuring loop conversion; scalar and zero
iteration cases expose accidental body execution or changed accumulator
identities. For cost diagnostics, use identical frozen inputs and retained
owners in fresh original-graph/original-XLA/native-graph/native-XLA processes,
20 exact replays, recording cold/warm time, trace/HLO size, host RSS and TF
allocator current/peak. One cohort per device is descriptive, not a ranking.

Classify the remaining metadata, shape and diagnostic constructs individually.
Only exact host-schema/reporting allowances are eligible; no blanket module or
numerical-loop waiver. The SIR simulation needs its own source-anchor/time and
clip-semantics review before changing it. KR transport numerical host loops
remain open until actual runtime/reference consumers are established; a
diagnostic module title alone is insufficient. Neither route is silently
declared repaired by this first unit.

Budget: at most 16 CPU and 12 GPU supervised invocations, 3600 CPU and 3600 GPU
process-seconds, inside the unchanged cumulative 56/52-hour caps. Through
04004, 32.548484 CPU and 30.689271 GPU hours remain. Use the stable campaign
runner, one numerical worker at a time, immutable per-attempt source snapshots
and versioned output under the existing campaign root. Check non-display GPU
availability and verified memory growth. Freeze numerical sources during runs.
Preserve failures and localize them under the same gates; unexplained output
or decision changes block adoption. Source drift, invalid evidence, missing
provenance or exhausted budget stop the affected comparison.

Skeptical review: Python-unrolled and native-loop graphs may be optimized
differently; compare same-mode outputs as well as graph references and report
any TF32 effect rather than relaxing a failed gate. Zero-step bodies can still
be traced by XLA. Reduced primal-route parity must not imply a canonical
algorithm rebuild. Fixture throughput cannot answer target-scale capacity or
native cache eviction. Existing original precision, DZ5, initializer,
reporting/isotropic and terminal F01--F20 gaps remain open. This plan answers
the execution question with fresh original source comparisons and independent
moment checks; it does not promote any old LEDH result or change a numerical
method. Review passes for this bounded execution-only scope.
