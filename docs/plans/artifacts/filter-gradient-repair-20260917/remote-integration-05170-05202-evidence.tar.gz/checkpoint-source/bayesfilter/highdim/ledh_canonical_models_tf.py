"""Canonical-lane model adapters (P5 model onboarding).

Builds ``NonlinearScoreModel`` and ``CanonicalModelCallbacks`` instances
for the six leaderboard models WITHOUT placeholder Gaussians: process and
observation covariances come from the model specification (model_exact) or
sigma-point propagation; the C-10 provenance guard enforces this at
construction.

First onboarded models: LGSSM (exact) and Austria SIR (RK4 dynamics with
analytical parameter tangent reused from the batch adapter derivation;
observation model 100*exp(2*theta_2)*I_9 on infectious compartments —
model-exact, theta-dependent). Remaining models (predator-prey, 3 SV
variants) follow the same template; each addition must extend
`test_ledh_canonical_models.py` with its S-1-class gate.
"""

from __future__ import annotations

import math

import tensorflow as tf

from bayesfilter.highdim.ledh_canonical_score_tf import NonlinearScoreModel

Tensor = tf.Tensor
DTYPE = tf.float64


def austria_sir_canonical_model(theta_fixed: Tensor, dtype: tf.DType = DTYPE) -> NonlinearScoreModel:
    """Austria SIR with real (non-placeholder) Gaussian inputs.

    theta enters the RK4 dynamics (kappa, nu) and the observation
    covariance (100*exp(2*theta_2)). The direction for the score is the
    caller's choice; tangent callbacks close over the direction index via
    the standard one-hot convention at the score assembly level.

    Provenance: process noise is the model's additive noise (model_exact,
    identity scale in the latent parameterization per the frozen target's
    process_noise tensors); observation covariance is the model's stated
    100*exp(2*theta_2)*I_9 (model_exact). The flow linearization H is the
    model's linear infectious-compartment extraction (model_exact). No
    identity placeholder stands in for a derived quantity: the transition
    JACOBIAN enters through the UKF sigma-point propagation of the real
    RK4 dynamics rather than an eye() transition matrix.
    """

    from bayesfilter.highdim.models import _zhao_cui_sir_austria_adjacency_xla

    adjacency = tf.cast(_zhao_cui_sir_austria_adjacency_xla(), dtype)
    degree = tf.reduce_sum(adjacency, axis=1)
    step = tf.constant(0.005, dtype)
    infectious_matrix = tf.one_hot(2 * tf.range(9) + 1, 18, dtype=dtype)

    def physical(theta):
        return (
            0.1 * tf.exp(theta[..., 0]),
            18.0 * tf.exp(theta[..., 1]),
        )

    def rhs(theta, state):
        kappa, nu = physical(theta)
        susceptible = state[:, 0::2]
        infectious = state[:, 1::2]
        neighbor_s = (
            tf.einsum("nj,kj->nk", susceptible, adjacency)
            - susceptible * degree
        )
        neighbor_i = (
            tf.einsum("nj,kj->nk", infectious, adjacency)
            - infectious * degree
        )
        infection = kappa * susceptible * infectious
        rhs_s = -infection + 0.5 * neighbor_s
        rhs_i = infection - nu * infectious + 0.5 * neighbor_i
        return tf.reshape(
            tf.stack([rhs_s, rhs_i], axis=2), [tf.shape(state)[0], 18]
        )

    def rhs_tangent(theta, state, d_state, d_theta):
        kappa, nu = physical(theta)
        d_kappa = kappa * d_theta[..., 0]
        d_nu = nu * d_theta[..., 1]
        susceptible = state[:, 0::2]
        infectious = state[:, 1::2]
        d_susceptible = d_state[:, 0::2]
        d_infectious = d_state[:, 1::2]
        d_neighbor_s = (
            tf.einsum("nj,kj->nk", d_susceptible, adjacency)
            - d_susceptible * degree
        )
        d_neighbor_i = (
            tf.einsum("nj,kj->nk", d_infectious, adjacency)
            - d_infectious * degree
        )
        infection = kappa * susceptible * infectious
        d_infection = (
            d_kappa * susceptible * infectious
            + kappa * d_susceptible * infectious
            + kappa * susceptible * d_infectious
        )
        d_rhs_s = -d_infection + 0.5 * d_neighbor_s
        d_rhs_i = (
            d_infection
            - d_nu * infectious
            - nu * d_infectious
            + 0.5 * d_neighbor_i
        )
        return tf.reshape(
            tf.stack([d_rhs_s, d_rhs_i], axis=2), [tf.shape(state)[0], 18]
        )

    def transition_mean_fn(theta, points):
        def body(index, current):
            k1 = rhs(theta, current)
            k2 = rhs(theta, current + 0.5 * step * k1)
            k3 = rhs(theta, current + 0.5 * step * k2)
            # SOURCE HALF-STEP k4 (reference adapter quirk, see
            # vendored gate 2026-08-24): k4 at 0.5*step, not step.
            k4 = rhs(theta, current + 0.5 * step * k3)
            current = current + step / 6.0 * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
            return index + 1, current

        _, current = tf.while_loop(
            lambda index, current: index < 4,
            body,
            (tf.constant(0), points),
            parallel_iterations=1,
        )
        return current

    def transition_mean_tangent_fn(theta, points, d_points):
        # d(RK4)/d(theta,state) chained through the four stages; the
        # parameter direction is the one-hot the score assembly selects —
        # here bound to direction 0..2 via theta_fixed closure convention:
        # the assembly calls with d_points carrying the state tangent and
        # the parameter direction is fixed per call (d_theta one-hot).
        d_theta = _current_direction[0]
        def body(index, current, d_current):
            k1 = rhs(theta, current)
            d1 = rhs_tangent(theta, current, d_current, d_theta)
            k2 = rhs(theta, current + 0.5 * step * k1)
            d2 = rhs_tangent(
                theta,
                current + 0.5 * step * k1,
                d_current + 0.5 * step * d1,
                d_theta,
            )
            k3 = rhs(theta, current + 0.5 * step * k2)
            d3 = rhs_tangent(
                theta,
                current + 0.5 * step * k2,
                d_current + 0.5 * step * d2,
                d_theta,
            )
            # SOURCE HALF-STEP k4 (reference adapter quirk, see
            # vendored gate 2026-08-24): k4 at 0.5*step, not step.
            k4 = rhs(theta, current + 0.5 * step * k3)
            d4 = rhs_tangent(
                theta,
                current + 0.5 * step * k3,
                d_current + 0.5 * step * d3,
                d_theta,
            )
            current = current + step / 6.0 * (
                k1 + 2.0 * k2 + 2.0 * k3 + k4
            )
            d_current = d_current + step / 6.0 * (
                d1 + 2.0 * d2 + 2.0 * d3 + d4
            )
            return index + 1, current, d_current

        _, _, d_current = tf.while_loop(
            lambda index, current, d_current: index < 4,
            body,
            (tf.constant(0), points, d_points),
            parallel_iterations=1,
        )
        return d_current

    _current_direction = [tf.constant([1.0, 0.0, 0.0], dtype)]

    def set_score_direction(direction: Tensor) -> None:
        _current_direction[0] = tf.convert_to_tensor(direction, dtype)

    def observation_fn(points):
        return tf.einsum("oi,ni->no", infectious_matrix, points)

    def observation_jacobian_fn(points):
        return tf.broadcast_to(
            infectious_matrix, [tf.shape(points)[0], 9, 18]
        )

    def observation_tangent_fn(points, d_points):
        return tf.einsum("oi,ni->no", infectious_matrix, d_points)

    theta_fixed = tf.convert_to_tensor(theta_fixed, dtype)
    observation_covariance = (
        100.0 * tf.exp(2.0 * theta_fixed[2]) * tf.eye(9, dtype=dtype)
    )

    # theta_2-bearing observation density (Q2 Curve-7 wiring, 2026-08-24):
    # R(theta) = 100*exp(2*theta_2)*I_9. The Gaussian FALLBACK density in
    # the score assembly carries no dR term, so a model with R(theta)
    # must supply the density callback pair and the covariance tangent
    # (same convention as the dlgssm q/r wiring).
    log_two_pi = tf.constant(math.log(2.0 * math.pi), dtype)

    def observation_log_density_fn(theta, points, observation):
        observed = tf.einsum("oi,ni->no", infectious_matrix, points)
        residual = observation[None, :] - observed
        log_variance = (
            tf.math.log(tf.constant(100.0, dtype)) + 2.0 * theta[2]
        )
        variance = tf.exp(log_variance)
        return -0.5 * (
            tf.reduce_sum(tf.square(residual), axis=1) / variance
            + 9.0 * (log_two_pi + log_variance)
        )

    def observation_log_density_tangent_fn(theta, points, observation, d_points):
        # d log p = (r . d_observed)/V + (||r||^2/V - 9) d_theta_2
        d_theta = _current_direction[0]
        observed = tf.einsum("oi,ni->no", infectious_matrix, points)
        d_observed = tf.einsum("oi,ni->no", infectious_matrix, d_points)
        residual = observation[None, :] - observed
        variance = tf.constant(100.0, dtype) * tf.exp(2.0 * theta[2])
        quad = tf.reduce_sum(tf.square(residual), axis=1)
        return (
            tf.reduce_sum(residual * d_observed, axis=1) / variance
            + (quad / variance - 9.0) * d_theta[2]
        )

    def observation_covariance_tangent_fn(theta):
        d_theta = _current_direction[0]
        return (
            200.0
            * tf.exp(2.0 * theta[2])
            * d_theta[2]
            * tf.eye(9, dtype=dtype)
        )

    model = NonlinearScoreModel(
        transition_mean_fn=transition_mean_fn,
        transition_mean_tangent_fn=transition_mean_tangent_fn,
        observation_fn=observation_fn,
        observation_jacobian_fn=observation_jacobian_fn,
        observation_tangent_fn=observation_tangent_fn,
        process_covariance=tf.eye(18, dtype=dtype),
        # ^ PROVENANCE: model_exact, NOT a placeholder. The frozen Austria
        # target adds process noise at unit scale (batch adapter line 254:
        # `rk4(...) + noise`), i.e. Q = I_18 by model definition. The
        # 2026-08 placeholder defect was feeding I to the FLOW as the
        # PREDICTED covariance; here the predicted covariance comes from
        # the UKF sigma-point propagation of the real RK4 dynamics, and I
        # enters only as the true additive-noise covariance.
        observation_covariance=observation_covariance,
        observation_log_density_fn=observation_log_density_fn,
        observation_log_density_tangent_fn=observation_log_density_tangent_fn,
        observation_covariance_tangent_fn=observation_covariance_tangent_fn,
    )
    # NonlinearScoreModel is frozen; the direction setter travels alongside.
    return model, set_score_direction


__all__ = ["austria_sir_canonical_model"]








def generalized_sv_canonical_model(theta_fixed: Tensor):
    """Native generalized SV — CORRECTED 2026-08-23.

    Reference (`NativeGeneralizedSVSSM`): 2-state AR(1) pair
    (s' = rho_s s + sigma_s eta, h' = rho_h h + sigma_h eta) and
    HETEROSKEDASTIC observation y ~ N(beta*s, exp(h)). The previous
    onboarding used fixed observation variance 1 — wrong relative to the
    reference (same fidelity class as the KSC defect). The weight/value
    path now uses the exact heteroskedastic density with its analytical
    tangent; the Gaussian (H=[beta,0], R=1) remains the FLOW's
    proposal-design input only.
    """

    theta_fixed = tf.convert_to_tensor(theta_fixed, DTYPE)
    sigma_s = tf.exp(theta_fixed[2])
    sigma_h = tf.exp(theta_fixed[3])
    beta_ref = tf.exp(theta_fixed[4])

    def transition_mean_fn(theta, points):
        r_s = tf.tanh(theta[0])
        r_h = tf.tanh(theta[1])
        return tf.stack(
            [r_s * points[:, 0], r_h * points[:, 1]], axis=1
        )

    _direction = [tf.zeros([5], DTYPE)]

    def set_score_direction(direction: Tensor) -> None:
        _direction[0] = tf.convert_to_tensor(direction, DTYPE)

    def transition_mean_tangent_fn(theta, points, d_points):
        d_theta = _direction[0]
        r_s = tf.tanh(theta[0])
        r_h = tf.tanh(theta[1])
        dr_s = (1.0 - tf.square(r_s)) * d_theta[0]
        dr_h = (1.0 - tf.square(r_h)) * d_theta[1]
        return tf.stack(
            [
                dr_s * points[:, 0] + r_s * d_points[:, 0],
                dr_h * points[:, 1] + r_h * d_points[:, 1],
            ],
            axis=1,
        )

    def observation_log_density_fn(theta, points, observation):
        beta = tf.exp(theta[4])
        s = points[:, 0]
        h = points[:, 1]
        residual = observation[0] - beta * s
        return -0.5 * (
            tf.square(residual) * tf.exp(-h)
            + h
            + tf.constant(math.log(2.0 * math.pi), DTYPE)
        )

    def observation_log_density_tangent_fn(theta, points, observation, d_points):
        d_theta = _direction[0]
        beta = tf.exp(theta[4])
        d_beta = beta * d_theta[4]
        s = points[:, 0]
        h = points[:, 1]
        d_s = d_points[:, 0]
        d_h = d_points[:, 1]
        residual = observation[0] - beta * s
        d_residual = -(d_beta * s + beta * d_s)
        exp_neg_h = tf.exp(-h)
        return (
            -residual * d_residual * exp_neg_h
            + 0.5 * d_h * (tf.square(residual) * exp_neg_h - 1.0)
        )

    h_matrix = tf.stack([beta_ref, tf.constant(0.0, DTYPE)])[None, :]

    model = NonlinearScoreModel(
        transition_mean_fn=transition_mean_fn,
        transition_mean_tangent_fn=transition_mean_tangent_fn,
        observation_fn=lambda points: tf.einsum(
            "od,nd->no", h_matrix, points
        ),
        observation_jacobian_fn=lambda points: tf.broadcast_to(
            h_matrix, [tf.shape(points)[0], 1, 2]
        ),
        observation_tangent_fn=lambda points, d_points: tf.einsum(
            "od,nd->no", h_matrix, d_points
        ),
        process_covariance=tf.linalg.diag(
            tf.stack([tf.square(sigma_s), tf.square(sigma_h)])
        ),
        observation_covariance=tf.ones([1, 1], DTYPE),
        observation_log_density_fn=observation_log_density_fn,
        observation_log_density_tangent_fn=observation_log_density_tangent_fn,
    )
    return model, set_score_direction


__all__ = ["austria_sir_canonical_model"]


def predator_prey_canonical_model(theta_fixed: Tensor):
    """Six-parameter predator-prey; RK4 dynamics (20 x dt=0.1), process
    noise scale 2 (model_exact), direct-state observation with R = 4*I_2
    (model_exact). Ported from the verified batch adapter; tangent is the
    total derivative through the RK4 stages for the direction set via the
    returned setter (same convention as Austria)."""

    theta_fixed = tf.convert_to_tensor(theta_fixed, DTYPE)
    step = tf.constant(0.1, DTYPE)

    def rhs(theta, state):
        r, capacity, half_sat, s_rate, u_rate, v_rate = tf.unstack(theta)
        prey, predator = state[:, 0], state[:, 1]
        denominator = half_sat + prey
        interaction = prey * predator / denominator
        logistic = prey * (1.0 - prey / capacity)
        return tf.stack(
            [
                r * logistic - s_rate * interaction,
                u_rate * interaction - v_rate * predator,
            ],
            axis=1,
        )

    def rhs_tangent(theta, state, d_state, d_theta):
        r, capacity, half_sat, s_rate, u_rate, v_rate = tf.unstack(theta)
        dr, dcap, dhalf, ds_r, du_r, dv_r = tf.unstack(d_theta)
        prey, predator = state[:, 0], state[:, 1]
        d_prey, d_predator = d_state[:, 0], d_state[:, 1]
        denominator = half_sat + prey
        interaction = prey * predator / denominator
        d_interaction = (
            predator * half_sat / tf.square(denominator) * d_prey
            + prey / denominator * d_predator
            - prey * predator / tf.square(denominator) * dhalf
        )
        logistic = prey * (1.0 - prey / capacity)
        d_logistic = (
            (1.0 - 2.0 * prey / capacity) * d_prey
            + tf.square(prey) / tf.square(capacity) * dcap
        )
        return tf.stack(
            [
                dr * logistic
                + r * d_logistic
                - ds_r * interaction
                - s_rate * d_interaction,
                du_r * interaction
                + u_rate * d_interaction
                - dv_r * predator
                - v_rate * d_predator,
            ],
            axis=1,
        )

    def transition_mean_fn(theta, points):
        def body(index, current):
            k1 = rhs(theta, current)
            k2 = rhs(theta, current + 0.5 * step * k1)
            k3 = rhs(theta, current + 0.5 * step * k2)
            k4 = rhs(theta, current + step * k3)
            current = current + step / 6.0 * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
            return index + 1, current

        _, current = tf.while_loop(
            lambda index, current: index < 20,
            body,
            (tf.constant(0), points),
            parallel_iterations=1,
        )
        return current

    _direction = [tf.zeros([6], DTYPE)]

    def set_score_direction(direction: Tensor) -> None:
        _direction[0] = tf.convert_to_tensor(direction, DTYPE)

    def transition_mean_tangent_fn(theta, points, d_points):
        d_theta = _direction[0]
        def body(index, current, d_current):
            k1 = rhs(theta, current)
            d1 = rhs_tangent(theta, current, d_current, d_theta)
            k2 = rhs(theta, current + 0.5 * step * k1)
            d2 = rhs_tangent(
                theta, current + 0.5 * step * k1,
                d_current + 0.5 * step * d1, d_theta,
            )
            k3 = rhs(theta, current + 0.5 * step * k2)
            d3 = rhs_tangent(
                theta, current + 0.5 * step * k2,
                d_current + 0.5 * step * d2, d_theta,
            )
            k4 = rhs(theta, current + step * k3)
            d4 = rhs_tangent(
                theta, current + step * k3,
                d_current + step * d3, d_theta,
            )
            current = current + step / 6.0 * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
            d_current = d_current + step / 6.0 * (d1 + 2.0 * d2 + 2.0 * d3 + d4)
            return index + 1, current, d_current

        _, _, d_current = tf.while_loop(
            lambda index, current, d_current: index < 20,
            body,
            (tf.constant(0), points, d_points),
            parallel_iterations=1,
        )
        return d_current

    model = NonlinearScoreModel(
        transition_mean_fn=transition_mean_fn,
        transition_mean_tangent_fn=transition_mean_tangent_fn,
        observation_fn=lambda points: points,
        observation_jacobian_fn=lambda points: tf.broadcast_to(
            tf.eye(2, dtype=DTYPE), [tf.shape(points)[0], 2, 2]
        ),
        observation_tangent_fn=lambda points, d_points: d_points,
        # process noise scale 2 => covariance 4*I (adapter adds 2*noise)
        process_covariance=4.0 * tf.eye(2, dtype=DTYPE),
        observation_covariance=4.0 * tf.eye(2, dtype=DTYPE),
    )
    return model, set_score_direction


def diagonal_lgssm_canonical_model(theta_fixed: Tensor):
    """Five-parameter diagonal LGSSM (phi_1..3, q_scale, obs_scale) with a
    3x3 observation matrix; everything model_exact and linear (UKF ==
    Kalman on this model, giving an exact-reference lane)."""

    theta_fixed = tf.convert_to_tensor(theta_fixed, DTYPE)
    # Reference observation matrix (frozen target `_LGSSM_MATRIX`;
    # previously WRONGLY eye(3) — fidelity defect fixed 2026-08-23):
    obs_matrix = tf.constant(
        [[1.0, 0.25, -0.15], [0.2, 1.1, 0.3], [-0.1, 0.35, 0.9]], DTYPE
    )
    phi = theta_fixed[:3]
    q_scale = theta_fixed[3]
    r_scale = theta_fixed[4]

    def transition_mean_fn(theta, points):
        return points * theta[:3][None, :]

    _direction = [tf.zeros([5], DTYPE)]

    def set_score_direction(direction: Tensor) -> None:
        _direction[0] = tf.convert_to_tensor(direction, DTYPE)

    def transition_mean_tangent_fn(theta, points, d_points):
        d_theta = _direction[0]
        return d_points * theta[:3][None, :] + points * d_theta[:3][None, :]

    log_two_pi = tf.constant(math.log(2.0 * math.pi), DTYPE)

    def _scaled_gaussian(points, means, scale):
        residual = points - means
        return -0.5 * (
            tf.reduce_sum(tf.square(residual), axis=1) / tf.square(scale)
            + 3.0 * (log_two_pi + 2.0 * tf.math.log(scale))
        )

    def _scaled_gaussian_tangent(points, means, d_points, d_means, scale, d_scale):
        residual = points - means
        d_residual = d_points - d_means
        quad = tf.reduce_sum(tf.square(residual), axis=1)
        return (
            -tf.reduce_sum(residual * d_residual, axis=1) / tf.square(scale)
            + quad / tf.pow(scale, 3) * d_scale
            - 3.0 / scale * d_scale
        )

    def transition_log_density_fn(theta, points, ancestors_mean):
        return _scaled_gaussian(points, ancestors_mean, theta[3])

    def transition_log_density_tangent_fn(theta, points, ancestors_mean, d_points, d_means):
        d_theta = _direction[0]
        return _scaled_gaussian_tangent(
            points, ancestors_mean, d_points, d_means, theta[3], d_theta[3]
        )

    def observation_log_density_fn(theta, points, observation):
        observed = tf.einsum("od,nd->no", obs_matrix, points)
        target = tf.broadcast_to(observation[None, :], tf.shape(observed))
        return _scaled_gaussian(target, observed, theta[4])

    def observation_log_density_tangent_fn(theta, points, observation, d_points):
        d_theta = _direction[0]
        observed = tf.einsum("od,nd->no", obs_matrix, points)
        d_observed = tf.einsum("od,nd->no", obs_matrix, d_points)
        target = tf.broadcast_to(observation[None, :], tf.shape(observed))
        return _scaled_gaussian_tangent(
            target, observed, tf.zeros_like(target), d_observed,
            theta[4], d_theta[4],
        )

    def process_covariance_tangent_fn(theta):
        d_theta = _direction[0]
        return 2.0 * theta[3] * d_theta[3] * tf.eye(3, dtype=DTYPE)

    def observation_covariance_tangent_fn(theta):
        d_theta = _direction[0]
        return 2.0 * theta[4] * d_theta[4] * tf.eye(3, dtype=DTYPE)

    model = NonlinearScoreModel(
        transition_mean_fn=transition_mean_fn,
        transition_mean_tangent_fn=transition_mean_tangent_fn,
        observation_fn=lambda points: tf.einsum(
            "od,nd->no", obs_matrix, points
        ),
        observation_jacobian_fn=lambda points: tf.broadcast_to(
            obs_matrix, [tf.shape(points)[0], 3, 3]
        ),
        observation_tangent_fn=lambda points, d_points: tf.einsum(
            "od,nd->no", obs_matrix, d_points
        ),
        process_covariance=tf.square(q_scale) * tf.eye(3, dtype=DTYPE),
        observation_covariance=tf.square(r_scale) * tf.eye(3, dtype=DTYPE),
        observation_log_density_fn=observation_log_density_fn,
        observation_log_density_tangent_fn=observation_log_density_tangent_fn,
        process_covariance_tangent_fn=process_covariance_tangent_fn,
        observation_covariance_tangent_fn=observation_covariance_tangent_fn,
        transition_log_density_fn=transition_log_density_fn,
        transition_log_density_tangent_fn=transition_log_density_tangent_fn,
    )
    return model, set_score_direction


def ksc_sv_canonical_model(theta_fixed: Tensor):
    """KSC mixture SV — CORRECTED 2026-08-23.

    STATE IS 1-DIMENSIONAL: the log-volatility AR(1) h' = gamma*h + eta,
    matching the reference adapter (`dimension=1` in the frozen target).
    `log_beta` is a PARAMETER (theta[1]), entering the observation offset
    as 2*log_beta — the previous onboarding wrongly promoted it to a
    second state with a fabricated near-deterministic transition
    (Q22=1e-8), which made the transition density price the flow's
    legitimate displacement at 1/1e-8 and produced the wrong -19283 value
    (registry note: onboarding error, not an algorithm property).

    Flow input: moment-matched Gaussian of the KSC log-chi-square mixture
    (derived constants); the observed quantity is h + 2*log_beta +
    mixture_noise, so H = [1] and the mixture mean enters the offset.
    The likelihood below retains all seven mixture components. Gaussian
    moment matching is used only for the proposal flow. A transformation
    Jacobian preserves scores within this density family; it does not make
    the mixture exact for native SV or make a Gaussian Kalman filter an
    exact mixture-likelihood oracle.
    """

    import math

    theta_fixed = tf.convert_to_tensor(theta_fixed, DTYPE)
    weights = tf.constant(
        [0.00730, 0.10556, 0.00002, 0.04395, 0.34001, 0.24566, 0.25750],
        DTYPE,
    )
    means = tf.constant(
        [-10.12999, -3.97281, -8.56686, 2.77786, 0.61942, 1.79518, -1.08819],
        DTYPE,
    ) - tf.constant(1.2704, DTYPE)
    variances = tf.constant(
        [5.79596, 2.61369, 5.17950, 0.16735, 0.64009, 0.34023, 1.26261],
        DTYPE,
    )
    mixture_mean = tf.reduce_sum(weights * means)
    mixture_var = tf.reduce_sum(
        weights * (variances + tf.square(means))
    ) - tf.square(mixture_mean)

    def gamma_of(theta):
        return 0.5 * (
            1.0 + tf.math.erf(theta[0] / tf.sqrt(tf.constant(2.0, DTYPE)))
        )

    def transition_mean_fn(theta, points):
        return gamma_of(theta) * points

    _direction = [tf.zeros([2], DTYPE)]

    def set_score_direction(direction: Tensor) -> None:
        _direction[0] = tf.convert_to_tensor(direction, DTYPE)

    def transition_mean_tangent_fn(theta, points, d_points):
        d_theta = _direction[0]
        gamma = gamma_of(theta)
        normalizer = tf.constant(1.0 / math.sqrt(2.0 * math.pi), DTYPE)
        dgamma = normalizer * tf.exp(-0.5 * tf.square(theta[0])) * d_theta[0]
        return dgamma * points + gamma * d_points

    # Observation: y_transformed = h + 2*log_beta + mixture noise.
    # log_beta = theta[1] contributes a THETA-DEPENDENT offset; for the
    # linear-H flow input the offset enters through observation_fn and its
    # theta-derivative through both the flow and the weight densities.
    two_log_beta = 2.0 * theta_fixed[1]

    def observation_log_density_fn(theta, points, observation):
        # REFERENCE mixture density (7-component KSC logsumexp), matching
        # the vendored adapter's observation_value. w = y - 2*log_beta - h.
        w = observation[0] - 2.0 * theta[1] - points[:, 0]
        terms = (
            tf.math.log(weights)[None, :]
            - 0.5
            * (
                tf.square(w[:, None] - means[None, :]) / variances[None, :]
                + tf.math.log(variances)[None, :]
                + tf.constant(math.log(2.0 * math.pi), DTYPE)
            )
        )
        return tf.reduce_logsumexp(terms, axis=1)

    def observation_log_density_tangent_fn(theta, points, observation, d_points):
        d_theta = _direction[0]
        w = observation[0] - 2.0 * theta[1] - points[:, 0]
        terms = (
            tf.math.log(weights)[None, :]
            - 0.5
            * (
                tf.square(w[:, None] - means[None, :]) / variances[None, :]
                + tf.math.log(variances)[None, :]
                + tf.constant(math.log(2.0 * math.pi), DTYPE)
            )
        )
        responsibilities = tf.nn.softmax(terms, axis=1)
        location_score = tf.reduce_sum(
            responsibilities * (w[:, None] - means[None, :]) / variances[None, :],
            axis=1,
        )
        d_w = -d_points[:, 0] - 2.0 * d_theta[1]
        # d logp / dw = -sum_k resp_k (w - m_k)/v_k = -location_score
        return -location_score * d_w

    model = NonlinearScoreModel(
        transition_mean_fn=transition_mean_fn,
        transition_mean_tangent_fn=transition_mean_tangent_fn,
        observation_fn=lambda points: points + mixture_mean + two_log_beta,
        observation_jacobian_fn=lambda points: tf.ones(
            [tf.shape(points)[0], 1, 1], DTYPE
        ),
        observation_tangent_fn=lambda points, d_points: d_points + 2.0 * _direction[0][1],
        process_covariance=tf.ones([1, 1], DTYPE),
        observation_covariance=mixture_var[None, None],
        observation_log_density_fn=observation_log_density_fn,
        observation_log_density_tangent_fn=observation_log_density_tangent_fn,
    )
    return model, set_score_direction


__all__ = [
    "austria_sir_canonical_model",
    "predator_prey_canonical_model",
    "diagonal_lgssm_canonical_model",
    "ksc_sv_canonical_model",
    "generalized_sv_canonical_model",
]
