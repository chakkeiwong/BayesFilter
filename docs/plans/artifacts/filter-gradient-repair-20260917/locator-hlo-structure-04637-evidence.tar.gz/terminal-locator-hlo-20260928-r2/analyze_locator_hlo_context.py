"""Bounded diagnostic structural comparison of saved, unoptimized HLO."""
import collections
import hashlib
import json
import re
import time
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917')
OUT = ROOT / 'terminal-locator-hlo-20260928-r2'
HEADER = re.compile(r'^(?:ENTRY )?%([^ ]+) \(')
DEFINITION = re.compile(r'^\s*(?:ROOT )?%([^ ]+) = ')
SYMBOL = re.compile(r'%([A-Za-z0-9_.-]+)')
METADATA = re.compile(r', metadata=\{[^}]*\}')


def computations(lines):
    functions, records, local = {}, [], {}
    body, record = [], None
    for number, raw in enumerate(lines, 1):
        header = HEADER.match(raw)
        if header:
            assert record is None
            name = header.group(1)
            assert name not in functions
            functions[name] = None
            record = {'name': name, 'line': number, 'entry': raw.startswith('ENTRY ')}
            body, local = [], {}
        elif record is not None and raw.rstrip() == '}':
            record['normalized_sha256'] = hashlib.sha256('\n'.join(body).encode()).hexdigest()
            functions[record['name']] = record['normalized_sha256']
            record['instruction_count'] = len(body)
            record['body'] = body
            records.append(record)
            record = None
        elif record is not None and raw.strip():
            match = DEFINITION.match(raw)
            assert match, (number, raw[:150])
            name = match.group(1)
            assert name not in local
            local[name] = f'V{len(local)}'
            line = METADATA.sub('', raw.strip())
            assert 'metadata=' not in line, (number, 'Unparsed source metadata')

            def replace(symbol):
                key = symbol.group(1)
                assert key in local or key in functions, (number, key)
                if key in local:
                    return '%' + local[key]
                assert functions[key] is not None, (number, 'Forward/recursive computation', key)
                return '%callee_' + functions[key]

            body.append(SYMBOL.sub(replace, line))
    assert record is None and records
    return records


def self_check():
    first = ['%f (x: f64[]) -> f64[] {\n', '  %x = f64[] parameter(0)\n',
        '  %c = f64[] constant(2)\n', '  ROOT %y = f64[] multiply(f64[] %x, f64[] %c)\n', '}\n']
    renamed = [line.replace('%x', '%a').replace('%c', '%b').replace('%y', '%z')
        for line in first]
    changed = [line.replace('constant(2)', 'constant(3)') for line in renamed]
    assert computations(first)[0]['normalized_sha256'] == computations(renamed)[0]['normalized_sha256']
    assert computations(first)[0]['normalized_sha256'] != computations(changed)[0]['normalized_sha256']
    caller = ['ENTRY %main (z: f64[]) -> f64[] {\n', '  %z = f64[] parameter(0)\n',
        '  ROOT %answer = f64[] call(f64[] %z), to_apply=%f\n', '}\n']
    assert computations(first + caller)[-1]['normalized_sha256'] != computations(changed + caller)[-1]['normalized_sha256']


def compare(left, right):
    counts_a = collections.Counter(row['normalized_sha256'] for row in left)
    counts_b = collections.Counter(row['normalized_sha256'] for row in right)
    unique_a, unique_b = counts_a - counts_b, counts_b - counts_a
    def unmatched(rows, counts):
        remaining, found = counts.copy(), []
        for row in rows:
            digest = row['normalized_sha256']
            if remaining[digest]:
                found.append({k: v for k, v in row.items() if k != 'body'})
                remaining[digest] -= 1
        return found
    return {'original_computations': len(left), 'candidate_computations': len(right),
        'matched_by_content_and_multiplicity': sum((counts_a & counts_b).values()),
        'original_unmatched': unmatched(left, unique_a), 'candidate_unmatched': unmatched(right, unique_b)}


def main():
    OUT.mkdir(exist_ok=False)
    source = Path(__file__).read_bytes()
    (OUT / Path(__file__).name).write_bytes(source)
    started = time.monotonic()
    record = {'device': 'CPU', 'state': 'running', 'timeout_seconds': 120,
        'command': ['timeout', '120', '/home/ubuntu/miniforge3/envs/tf-gpu/bin/python', __file__],
        'reader_sha256': hashlib.sha256(source).hexdigest()}
    (OUT / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
    try:
        self_check()
        parsed, provenance = {}, {}
        for number in (4635, 4636):
            path = ROOT / f'run-{number:05d}/first-objective-context.hlo.txt'
            provenance[str(number)] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                'bytes': path.stat().st_size}
            with path.open() as stream:
                parsed[number] = computations(stream)
        comparison = compare(parsed[4635], parsed[4636])
        report = {'schema': 'filter_locator_hlo_structure.v1', 'inputs': provenance,
            'comparison': comparison,
            'nonclaims': ['Unoptimized HLO structure is not optimized-code or numerical equivalence.',
                'SSA names/source metadata removed; instruction order, attributes, operand relations and callee content retained.']}
        (OUT / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
        record['state'] = 'passed'
        print(json.dumps({k: v if isinstance(v, int) else len(v) for k, v in comparison.items()}))
    except BaseException as error:
        record['state'] = 'failed'
        record['error'] = repr(error)
        raise
    finally:
        record['elapsed_seconds'] = time.monotonic() - started
        (OUT / 'run.json').write_text(json.dumps(record, indent=2) + '\n')


if __name__ == '__main__':
    main()
