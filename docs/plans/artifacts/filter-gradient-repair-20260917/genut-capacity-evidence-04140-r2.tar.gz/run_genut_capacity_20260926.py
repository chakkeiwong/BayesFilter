"""Bounded sequential driver for the documented GenUT capacity cohort."""
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/tmp/bayesfilter-filter-gradient-xla-validation-20260918')
PYTHON = '/home/ubuntu/miniforge3/envs/tf-gpu/bin/python'
sys.path.insert(0, str(ROOT / 'scripts'))
spec = importlib.util.spec_from_file_location('capacity_campaign', ROOT / 'scripts/run_filter_repair_campaign.py')
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)
frozen = campaign.source_hashes()
charged = {'CPU': 0., 'GPU': 0.}
for device in ('CPU', 'GPU'):
    for count, dimension in ((1000, 3), (10000, 3), (10000, 18)):
        for arm, mode in (('original', 'graph'), ('original', 'xla'), ('native', 'graph'), ('native', 'xla')):
            if device == 'GPU' and arm == 'original' and mode == 'xla':
                continue
            assert campaign.source_hashes() == frozen, 'Source drift; stop cohort'
            assert charged[device] + 300 <= 1800, 'Capacity reservation exhausted'
            group = f'genut_transitive_capacity_{arm}_{mode}_{count}_{dimension}_{device.lower()}'
            print(group, flush=True)
            completed = subprocess.run([PYTHON, 'scripts/run_filter_repair_campaign.py', 'test',
                '--group', group, '--device', device, '--test-timeout-seconds', '300'], cwd=ROOT)
            records = sorted(campaign.OUTPUT.glob('run-*/run.json'))
            row = json.loads(records[-1].read_text())
            assert row['key'][1] == group, 'Unexpected last worker'
            charged[device] += row.get('elapsed_seconds', 300.)
            if completed.returncode:
                raise SystemExit(completed.returncode)
print('unit elapsed seconds', charged, flush=True)
