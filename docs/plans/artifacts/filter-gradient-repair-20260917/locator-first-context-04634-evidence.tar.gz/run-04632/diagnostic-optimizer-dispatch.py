def single_objective(value_and_gradients_function, initial_position, **kwargs):
    value, gradient = value_and_gradients_function(initial_position)
    shape = tf.shape(initial_position)[:-1]
    return SimpleNamespace(position=initial_position, objective_value=value,
        objective_gradient=gradient, converged=tf.zeros(shape, tf.bool),
        failed=tf.zeros(shape, tf.bool))
