"""Diagnostic localization of an empty result from the non-default graph path."""

from dataclasses import replace

import numpy as np
import pytest
import tensorflow as tf

from bayesfilter.inference.joint_center_tf import make_joint_center_program
from bayesfilter.inference.posterior_initializer_controller_tf import PreparedPosteriorInitializer
from bayesfilter.inference.posterior_local_initializer import _EligibilityTrackingEvaluator
from bayesfilter.inference.posterior_movement_tf import make_posterior_movement_program
from bayesfilter.inference.program_cache_scope import ProgramCacheScope
from tests.test_filter_repair_geometry_control import clean, save
from tests.test_filter_repair_posterior_initializer_controller import original_module
from tests.test_filter_repair_quadratic_batches import _equal_records
from tests.test_posterior_local_initializer import (
    _gaussian_callbacks,
    _initializer_config,
    _movement_config,
    _thresholds,
)

D = tf.float64


@pytest.mark.parametrize("mode", ["full", "no_meta", "locator", "movement", "full_xla"])
def test_empty_graph_result_localization(mode, request):
    # Optimizer options are diagnostic in this fresh process, never a runtime repair.
    if mode == "no_meta":
        tf.config.optimizer.set_experimental_options({"disable_meta_optimizer": True})
    scalar, batch = _gaussian_callbacks(np.array([.6]), np.array([[.4]]))
    config = _initializer_config(locator_gradient_tolerance=1e6)
    if mode == "full_xla":
        config = replace(config, locator_config=replace(config.locator_config, jit_compile=True))
    movement = _movement_config(seed=20260826)
    thresholds = _thresholds(1)
    initial, scale = tf.constant([0.], D), tf.constant([1.], D)
    owner = PreparedPosteriorInitializer(scalar, 1, config, movement, thresholds, batched_callback=batch)
    prepared = owner.prepare_clouds()
    if mode == "locator":
        def chart(point):
            tanh = tf.math.tanh(point / config.locator_box_radius)
            value, score = scalar(initial + scale * config.locator_box_radius * tanh)
            return value, score * scale * (1. - tanh**2)
        program = make_joint_center_program(chart, 1, config.locator_config, jit_compile=False)
        args = initial, scale
    elif mode == "movement":
        evaluator = _EligibilityTrackingEvaluator(scalar, dimension=1,
            max_rows=config.max_exact_evaluations, batched_fn=batch)
        with ProgramCacheScope().activate():
            program = make_posterior_movement_program(evaluator, 1, config, movement, jit_compile=False)
        value, score = scalar(initial)
        args = initial, value, score, scale, prepared["directions"], prepared["movement_offsets"], prepared["permutation_keys"]
    else:
        program = owner.compiled
        args = initial, scale, prepared["directions"], prepared["movement_offsets"], prepared["permutation_keys"], prepared["curvature_offsets"]
    raw = program(*args)
    specs = tf.nest.map_structure(lambda x: {"dtype": x.dtype.name, "shape": x.shape.as_list()}, raw)
    wanted_specs = tf.nest.map_structure(lambda x: {"dtype": x.dtype.name, "shape": x.shape.as_list()},
        program.get_concrete_function().structured_outputs)
    save(request, f"posterior-graph-localization-{mode}.json", {"mode": mode,
        "actual_specs": specs, "declared_specs": wanted_specs, "raw": clean(raw),
        "optimizer_options": tf.config.optimizer.get_experimental_options()})
    _equal_records(specs, wanted_specs)
    if mode in ("full", "no_meta", "full_xla"):
        from bayesfilter.inference.posterior_initializer_reporting import posterior_initializer_result
        reference, hashes = original_module()
        actual = posterior_initializer_result(raw, config, movement, thresholds).payload(include_arrays=True)
        expected = reference.initialize_posterior_local_location_scale(scalar, initial, scale=scale,
            batched_value_and_score_fn=batch, config=config, movement_config=movement,
            curvature_thresholds=thresholds).payload(include_arrays=True)
        save(request, f"posterior-graph-localization-records-{mode}.json", {
            "reference_sha256": hashes, "actual": clean(actual), "expected": clean(expected)})
        _equal_records(clean(actual), clean(expected))
