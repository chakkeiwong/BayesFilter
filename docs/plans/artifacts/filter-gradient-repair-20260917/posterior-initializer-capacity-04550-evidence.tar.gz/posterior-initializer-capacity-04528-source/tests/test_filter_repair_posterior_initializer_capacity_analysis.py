"""Independent corruption checks for complete-initializer capacity evidence."""

from copy import deepcopy

import pytest

from scripts.analyze_filter_repair_posterior_initializer_capacity import (
    memory_trajectory,
    validate_capacity,
)


def fixture(kind="reuse", arm="xla"):
    payload = {"accepted": True, "center": [.13], "covariance_theta": [[.64]],
        "status": "accepted", "condition_number": 3.}
    result = {"schema": "filter_posterior_initializer_capacity.v1", "reference_revision": "031692a0b",
        "dimension": 1, "kind": kind, "arm": arm,
        "independent_gaussian": {"mean": [.13], "covariance": [[.64]]}}
    if kind == "reuse":
        result.update(warm_calls=20, records=[deepcopy(payload) for _ in range(22)],
            original_records=[deepcopy(payload) for _ in range(2)], elapsed_seconds=[.1] * 22,
            stages={key: {} for key in ("prepared", "cold", "changed", "warm_1", "warm_5", "warm_10", "warm_15", "warm_20")},
            program=None if arm == "prior" else {"jit_compile": arm == "xla", "trace_count": 1,
                "hlo_unchanged": True, "hlo_bytes": 100, "host_callback_ops": [], "nested_xla_function_count": 1},
            reuse=[] if arm == "prior" else [{"owner_reused": True, "traces": 1, "dependency_count": 10} for _ in range(20)])
    else:
        result.update(owner_count=4, records=[deepcopy(payload) for _ in range(4)],
            original_records=[deepcopy(payload)], elapsed_seconds=[.1] * 4,
            superseded_collection=[[[True] * 4 for _ in range(i)] for i in range(4)],
            final_collection=[[True] * 4 for _ in range(4)],
            programs=[{"jit_compile": True, "traces": 1, "dependency_count": 10} for _ in range(4)])
    return result


@pytest.mark.parametrize("kind,arm", [("reuse", "prior"), ("reuse", "graph"), ("reuse", "xla"), ("owner_replacement", "xla")])
def test_valid_capacity_records(kind, arm):
    validate_capacity(fixture(kind, arm))


@pytest.mark.parametrize("failure", ["short", "replay", "original", "gaussian", "trace", "callback", "hlo", "owner", "dependencies", "timing"])
def test_reuse_corruption_is_rejected(failure):
    result = fixture()
    if failure == "short":
        result["records"].pop()
    elif failure == "replay":
        result["records"][10]["center"] = [.14]
    elif failure == "original":
        result["original_records"][0]["condition_number"] = 4.
    elif failure == "gaussian":
        result["independent_gaussian"]["covariance"] = [[.63]]
    elif failure == "trace":
        result["reuse"][3]["traces"] = 2
    elif failure == "callback":
        result["program"]["host_callback_ops"] = ["PyFunc"]
    elif failure == "hlo":
        result["program"]["hlo_unchanged"] = False
    elif failure == "owner":
        result["reuse"][4]["owner_reused"] = False
    elif failure == "dependencies":
        result["reuse"][7]["dependency_count"] += 1
    else:
        result["elapsed_seconds"][0] = float("nan")
    with pytest.raises(AssertionError):
        validate_capacity(result)


@pytest.mark.parametrize("failure", ["retained", "short", "superseded", "trace"])
def test_successful_owner_corruption_is_rejected(failure):
    result = fixture("owner_replacement")
    if failure == "retained":
        result["final_collection"][1][0] = False
    elif failure == "short":
        result["superseded_collection"][3].pop()
    elif failure == "superseded":
        result["superseded_collection"][2][0][2] = False
    else:
        result["programs"][3]["traces"] = 2
    with pytest.raises(AssertionError):
        validate_capacity(result)


def test_capacity_memory_units_and_unavailable_allocator():
    result = {"stages": {"cpu": {"rollup": {"Rss": 2 * 1024**2}, "map_count": 5, "gpu": None},
        "gpu": {"rollup": {"Rss": 3 * 1024**2}, "map_count": 6, "gpu": {"current": 10, "peak": 20}}}}
    rows = memory_trajectory(result)
    assert rows[0]["rss_mib"] == 2 and rows[0]["gpu_current_bytes"] is None
    assert rows[1]["rss_mib"] == 3 and rows[1]["gpu_current_bytes"] == 10
    assert rows[1]["gpu_peak_bytes"] == 20
