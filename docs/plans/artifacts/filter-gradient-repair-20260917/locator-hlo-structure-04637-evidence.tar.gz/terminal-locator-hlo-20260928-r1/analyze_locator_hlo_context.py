"""Bounded diagnostic structural comparison of saved, unoptimized HLO."""
import collections
import hashlib
import json
import re
import time
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917')
OUT = ROOT / 'terminal-locator-hlo-20260928-r1'
HEADER = re.compile(r'^(?:ENTRY )?%([^ ]+) \(')
DEFINITION = re.compile(r'^\s*(?:ROOT )?%([^ ]+) = ')
SYMBOL = re.compile(r'%([A-Za-z0-9_.-]+)')
METADATA = re.compile(r', metadata=\{[^}]*\}')


def computations(lines):
    functions, records, local = {}, [], {}
    body, record = [], None
    for number, raw in enumerate(lines, 1):
        header = HEADER.match(raw)
        if header:
            assert record is None
            name = header.group(1)
            assert name not in functions
            functions[name] = f'C{len(functions)}'
            record = {'name': name, 'line': number, 'entry': raw.startswith('ENTRY ')}
            body, local = [], {}
        elif record is not None and raw.rstrip() == '}':
            record['normalized_sha256'] = hashlib.sha256('\n'.join(body).encode()).hexdigest()
            record['instruction_count'] = len(body)
            record['body'] = body
            records.append(record)
            record = None
        elif record is not None and raw.strip():
            match = DEFINITION.match(raw)
            assert match, (number, raw[:150])
            name = match.group(1)
            assert name not in local
            local[name] = f'V{len(local)}'
            line = METADATA.sub('', raw.strip())
            assert 'metadata=' not in line, (number, 'Unparsed source metadata')

            def replace(symbol):
                key = symbol.group(1)
                assert key in local or key in functions, (number, key)
                return '%' + (local[key] if key in local else functions[key])

            body.append(SYMBOL.sub(replace, line))
    assert record is None and records
    return records


def self_check():
    first = ['%f (x: f64[]) -> f64[] {\n', '  %x = f64[] parameter(0)\n',
        '  %c = f64[] constant(2)\n', '  ROOT %y = f64[] multiply(f64[] %x, f64[] %c)\n', '}\n']
    renamed = [line.replace('%x', '%a').replace('%c', '%b').replace('%y', '%z')
        for line in first]
    changed = [line.replace('constant(2)', 'constant(3)') for line in renamed]
    assert computations(first)[0]['normalized_sha256'] == computations(renamed)[0]['normalized_sha256']
    assert computations(first)[0]['normalized_sha256'] != computations(changed)[0]['normalized_sha256']


def compare(left, right):
    assert len(left) == len(right), 'Computation ordering/count needs manual correspondence'
    rows = []
    for index, (a, b) in enumerate(zip(left, right, strict=True)):
        same = a['normalized_sha256'] == b['normalized_sha256']
        row = {'ordinal': index, 'original': {k: v for k, v in a.items() if k != 'body'},
            'candidate': {k: v for k, v in b.items() if k != 'body'}, 'same_normalized_body': same}
        if not same:
            count_a, count_b = collections.Counter(a['body']), collections.Counter(b['body'])
            row['original_only_instruction_samples'] = list((count_a - count_b).elements())[:16]
            row['candidate_only_instruction_samples'] = list((count_b - count_a).elements())[:16]
        rows.append(row)
    return rows


def main():
    OUT.mkdir(exist_ok=False)
    source = Path(__file__).read_bytes()
    (OUT / Path(__file__).name).write_bytes(source)
    started = time.monotonic()
    record = {'device': 'CPU', 'state': 'running', 'timeout_seconds': 120,
        'command': ['/home/ubuntu/miniforge3/envs/tf-gpu/bin/python', __file__],
        'reader_sha256': hashlib.sha256(source).hexdigest()}
    (OUT / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
    try:
        self_check()
        parsed, provenance = {}, {}
        for number in (4635, 4636):
            path = ROOT / f'run-{number:05d}/first-objective-context.hlo.txt'
            provenance[str(number)] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                'bytes': path.stat().st_size}
            with path.open() as stream:
                parsed[number] = computations(stream)
        rows = compare(parsed[4635], parsed[4636])
        report = {'schema': 'filter_locator_hlo_structure.v1', 'inputs': provenance,
            'computations': rows, 'same_bodies': sum(r['same_normalized_body'] for r in rows),
            'different_bodies': sum(not r['same_normalized_body'] for r in rows),
            'nonclaims': ['Unoptimized HLO structure is not optimized-code or numerical equivalence.',
                'Declaration-order correspondence and removed source metadata are explicit diagnostic assumptions.']}
        (OUT / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
        record['state'] = 'passed'
        print(json.dumps({k: report[k] for k in ('same_bodies', 'different_bodies')}))
    except BaseException as error:
        record['state'] = 'failed'
        record['error'] = repr(error)
        raise
    finally:
        record['elapsed_seconds'] = time.monotonic() - started
        (OUT / 'run.json').write_text(json.dumps(record, indent=2) + '\n')


if __name__ == '__main__':
    main()
