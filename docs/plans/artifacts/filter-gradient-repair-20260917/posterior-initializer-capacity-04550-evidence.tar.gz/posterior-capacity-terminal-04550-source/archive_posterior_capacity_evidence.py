"""Archive and reopen all recorded capacity evidence without overwriting it."""

import argparse
import hashlib
import json
import tarfile
from pathlib import Path

WORK = Path('/tmp/bayesfilter-filter-gradient-xla-validation-20260918')
RAW = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--last-run', type=int, required=True)
    args = parser.parse_args()
    output = WORK / 'docs/plans/artifacts/filter-gradient-repair-20260917'
    name = f'posterior-initializer-capacity-{args.last_run:05d}'
    archive, receipt = output / f'{name}-evidence.tar.gz', output / f'{name}-verification.json'
    assert not archive.exists() and not receipt.exists()
    paths, runs, charges = [], [], {'CPU': 0., 'GPU': 0.}
    for number in range(4528, args.last_run + 1):
        directory = RAW / f'run-{number:05d}'
        run = json.loads((directory / 'run.json').read_text())
        assert run['state'] != 'running'
        assert run['key'][1].startswith('posterior_initializer_capacity_') or run['key'][1] == 'policy'
        paths.extend(p for p in directory.rglob('*') if p.is_file())
        charges[run['device']] += run['elapsed_seconds']
        runs.append({'run': number, 'group': run['key'][1], 'state': run['state'],
            'elapsed_seconds': run['elapsed_seconds'], 'device': run['device']})
    for folder in ('posterior-initializer-capacity-04528-source',
            'posterior-capacity-crash-04537-source', 'posterior-capacity-analysis-04538-source',
            f'posterior-capacity-terminal-{args.last_run:05d}-source'):
        directory = RAW / folder
        assert directory.is_dir(), directory
        paths.extend(p for p in directory.rglob('*') if p.is_file())
    paths.extend(RAW.glob('posterior-initializer-capacity-*.json'))
    files = {}
    with tarfile.open(archive, 'x:gz') as stream:
        for path in sorted(set(paths)):
            relative = str(path.relative_to(RAW))
            files[relative] = sha(path)
            stream.add(path, arcname=relative)
    with tarfile.open(archive, 'r:gz') as stream:
        assert {m.name for m in stream.getmembers() if m.isfile()} == set(files)
        for member in stream.getmembers():
            if member.isfile():
                assert hashlib.sha256(stream.extractfile(member).read()).hexdigest() == files[member.name]
    record = {'schema': 'filter_repair_evidence_verification.v1', 'archive': archive.name,
        'sha256': sha(archive), 'files': files, 'runs': runs, 'charged_seconds': charges,
        'reopened_all_members_match': True, 'no_terminal_acceptance': True,
        'failed_comparator_run': 4536, 'explanatory_crash_run': 4537,
        'empty_late_map_monitor_is_not_evidence': True}
    with receipt.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'archive': str(archive), 'members': len(files), 'bytes': archive.stat().st_size,
        'sha256': record['sha256'], 'charged_seconds': charges}))


if __name__ == '__main__':
    main()
