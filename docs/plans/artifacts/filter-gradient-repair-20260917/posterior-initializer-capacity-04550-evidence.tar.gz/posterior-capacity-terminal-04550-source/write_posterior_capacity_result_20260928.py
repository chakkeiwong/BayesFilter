"""Render the completed capacity dispositions from independently checked data."""

import argparse
import json
from pathlib import Path

WORK = Path('/tmp/bayesfilter-filter-gradient-xla-validation-20260918')
RAW = Path('/home/ubuntu/workspace/BayesFilter/docs/plans/artifacts/filter-gradient-repair-20260917')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--last-run', type=int, required=True)
    parser.add_argument('--analysis', type=Path, required=True)
    args = parser.parse_args()
    report = json.loads(args.analysis.read_text())
    assert report['schema'] == 'filter_posterior_initializer_capacity_analysis.v3'
    assert len(report['results']) == 16 and len(report['observer_controls']) == 2
    rows = sorted(report['results'], key=lambda r: (r['device'], r['dimension'], r['kind'], r['arm']))
    text = ['# Complete posterior initializer capacity result', '',
        'The repaired graph/XLA initializer passes all eight CPU/GPU reuse cases,',
        'with full original records, independent Gaussian checks, exact twenty-call',
        'replay and one stable owner/trace. Repeated owner replacement passes Python',
        'collection but leaves substantial native host memory. The frozen prior CPU',
        'D3 implementation crashes; that cell remains failed and supplies no capacity',
        'ratio. This unit closes the bounded capacity investigation, not the whole',
        'repair program or actual-consumer lifecycle qualification.', '',
        'The [plan](filter_gradient_posterior_initializer_capacity_20260927.md) uses',
        'D1/D3 factor_max=1 identifiable Gaussian fixtures and frozen Git 031692a0b',
        'complete reference records. Numerical runtime is unchanged from 352776f63.',
        'The earlier [36-worker cost cohort](filter_gradient_posterior_initializer_cost_result_20260927.md)',
        'remains sealed. These single-process trajectories are descriptive, without',
        'a statistical ranking or a general memory bound. Graph control retains the',
        'original compiled dependencies; it is not an entirely non-XLA program.', '',
        '| Device / D | Arm / run | Cold RSS MiB | After twenty warm calls MiB | Final GPU current / maximum per-call peak bytes |',
        '|---|---|---:|---:|---|']
    for row in rows:
        if row['kind'] != 'reuse':
            continue
        if not row['valid']:
            assert row['run'] == 4536
            text.append(f"| {row['device']} / {row['dimension']} | {row['arm']} / {row['run']:05d} | unavailable | failed | unavailable |")
            continue
        memory = {entry['stage']: entry for entry in row['memory']}
        end = memory['warm_20']
        device_memory = 'CPU reference'
        if row['device'] == 'GPU':
            peak = max(entry['gpu']['peak'] for entry in row['call_memory'])
            device_memory = f"{end['gpu_current_bytes']:,} / {peak:,}"
        text.append(f"| {row['device']} / {row['dimension']} | {row['arm']} / {row['run']:05d} | {memory['cold']['rss_mib']:.1f} | {end['rss_mib']:.1f} | {device_memory} |")
    text.extend(['', 'All accepted arms preserve both original and changed inputs. Every candidate',
        'retains two numerical dependencies and one trace; XLA HLO is unchanged by',
        'the changed operands and no host numerical callbacks appear. The observer',
        'controls retain the same payload and snapshot counts without numerical calls:', ''])
    for device, control in report['observer_controls'].items():
        memory = {entry['stage']: entry for entry in control['memory']}
        owner = {entry['stage']: entry for entry in control['owner_memory']}
        text.append(f"- {device}, {control['run']:05d}: reuse reporting adds {memory['warm_20']['rss_mib']-memory['prepared']['rss_mib']:.2f} MiB; owner reporting adds {owner['all_python_owners_released']['rss_mib']-owner['prepared']['rss_mib']:.2f} MiB.")
    text.extend(['', 'The similar small candidate/observer growth supports reporting allocation as',
        'an explanation for this bounded reuse trajectory. It is not an exact byte',
        'subtraction or proof of leak freedom. The prior D1 CPU and D1/D3 GPU cases',
        'pass the numerical gates despite substantial host-memory growth.', '',
        'Run 04536 fails with SIGSEGV after 243.995367 seconds, without completed',
        'capacity JSON or JUnit. GDB diagnostic 04537 reproduces native allocation',
        'failure after 278.808786 seconds during call eleven. Ten completed calls',
        'pass replay and independent Gaussian checks. Maps rise from 13,914 after',
        'call one to 63,459 after call ten against vm.max_map_count=65,530.',
        'The log reports LLVM "Cannot allocate memory" at lines 666--667, followed',
        'by defunct JIT resources and SIGSEGV in ORC IRCompileLayer / XLA JitCompiler.',
        'The mapping limit is strongly supported, but the exact failed syscall and',
        'peak count were not captured. The late external monitor is empty and is',
        'not evidence. No system limit, global cache, environment or package changed;',
        'no further prior-D3 CPU retry is planned.', '',
        '| Device / D | Owner replacement run | RSS after first / fourth owner MiB | RSS after all Python owners released MiB | Post-release heap MiB | Post-release GPU current bytes |',
        '|---|---|---|---:|---:|---:|'])
    for row in rows:
        if row['kind'] != 'owner_replacement':
            continue
        assert row['valid']
        memory = {entry['stage']: entry for entry in row['memory']}
        raw = json.loads((RAW / f"run-{row['run']:05d}" / 'posterior-initializer-capacity.json').read_text())
        final = raw['stages']['all_python_owners_released']
        heap = sum(group['Rss'] for key, group in final['mapping_groups'].items() if key.strip() == '[heap]') / 2**20
        gpu = 'N/A' if final['gpu'] is None else f"{final['gpu']['current']:,}"
        text.append(f"| {row['device']} / {row['dimension']} | {row['run']:05d} | {memory['owner_1_completed']['rss_mib']:.1f} / {memory['owner_4_completed']['rss_mib']:.1f} | {memory['all_python_owners_released']['rss_mib']:.1f} | {heap:.1f} | {gpu} |")
    text.extend(['', 'All weak references to each target, owner, compiled function and dependency',
        'scope clear. Most retained host memory is in the process heap. This repeats',
        'the distinction established by the [KDM native investigation](filter_gradient_kdm_native_ownership_result_20260926.md):',
        'Python collection does not prove native executable eviction. Retain one',
        'owner for fixed callbacks/settings, pass varying inputs as tensor operands,',
        'and use explicit bounded worker lifetimes when configurations change.',
        'Initializer-specific and actual DZ5 containment remains to be executed.', '',
        '| GPU dimension / arm | Current allocation on warm owner return, bytes | Current after formatting, bytes | Returned tensor payload, bytes |',
        '|---|---|---:|---:|'])
    for row in rows:
        if row['device'] != 'GPU' or row['kind'] != 'reuse' or row['arm'] == 'prior':
            continue
        returns = row['owner_returns'][1:]
        calls = row['call_memory'][2:]
        assert len(returns) == len(calls) == 20
        assert all(a['memory']['gpu']['peak'] == b['gpu']['peak'] for a, b in zip(returns, calls, strict=True))
        currents = [entry['memory']['gpu']['current'] for entry in returns]
        completed = {entry['gpu']['current'] for entry in calls}
        output = {entry['output_bytes'] for entry in returns}
        assert len(completed) == len(output) == 1
        text.append(f"| {row['dimension']} / {row['arm']} | {min(currents):,}--{max(currents):,} | {next(iter(completed)):,} | {next(iter(output)):,} |")
    text.extend(['', 'The graph-control device-peak trigger is reproduced and localized before',
        'public formatting. Each per-call peak is already reached on owner return,',
        'and completed current allocation stays constant across twenty calls. The',
        'returned payload is identical in size across graph/XLA. These observations',
        'separate transient numerical allocation from returned tensors and retained',
        'current bytes. They do not identify an exact allocator operation or waive',
        'capacity checks on larger/actual targets. Default XLA uses lower device',
        'peaks in these fixtures; this is descriptive, not statistical superiority.', '',
        'The independent v3 analyzer preserves 15 valid numerical cells, failed',
        '04536, two valid observers and explanatory diagnostic 04537. It checks',
        'complete original/Gaussian/replay records, all memory/collection stages,',
        'environment/fixture identity and the full 690-file original-source closure.',
        'Only the five reviewed reporting/diagnostic paths may differ across workers;',
        'every allowed difference is listed in the JSON. Failed cells receive no',
        'invented memory values or capacity ratios. Frozen prior groups are',
        'explanatory comparators, while candidate and observer gates remain mandatory.', '',
        '| Decision | Criterion / veto | Uncertainty and next action | Not concluded |',
        '|---|---|---|---|',
        '| Accept bounded candidate reuse evidence | Eight CPU/GPU cases pass numerics, replay and stable ownership | Check real consumer dimensions and settings | General leak freedom or D23 capacity |',
        '| Preserve failed prior CPU D3 | Allocation failure reproduced with native stack | Keep both failures; no unchanged retry or ratio | Exact failed syscall or a numerical mismatch |',
        '| Require explicit native lifecycle | Python owners clear, host retention persists | Qualify actual initializer/DZ5 worker exit and parent recovery | Native cache eviction |',
        '| Record graph peak attribution | Peak precedes formatting; current bytes stay flat | Larger consumers retain their own capacity gates | Exact allocation owner or universal harmlessness |',
        '| Keep main unmerged | DZ5, reporting/precision and terminal F01--F20 remain open | Execute the next linked consumer unit | Whole-program completion |', '',
        'Local skeptical result review: the observer is a separate process and can',
        'only explain the scale of small reporting growth. HLO/reference checks occur',
        'after memory measurement. Weak references answer Python ownership only.',
        'The GDB wrapper perturbs execution and cannot replace timing measurements.',
        'The weakest attribution is the exact native allocation owner; direct native',
        'allocation evidence could revise that explanation without changing the',
        'observed retention. No independent reviewer is claimed.', '',
        'Next: [actual DZ5 adapter and process lifetime](filter_gradient_dz5_initializer_adapter_20260928.md).',
        f'Analysis: `{args.analysis.name}`. Archive and verification receipt:',
        f'`artifacts/filter-gradient-repair-20260917/posterior-initializer-capacity-{args.last_run:05d}-evidence.tar.gz`',
        f'and `posterior-initializer-capacity-{args.last_run:05d}-verification.json`.', ''])
    (WORK / 'docs/plans/filter_gradient_posterior_initializer_capacity_result_20260927.md').write_text('\n'.join(text))
    print('Rendered result from complete checked dispositions')


if __name__ == '__main__':
    main()
